package com.snyvo.app.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.snyvo.app.ui.theme.DarkBackground
import com.snyvo.app.ui.theme.DarkSurface
import com.snyvo.app.ui.theme.VioletPrimary

data class ComposeSpeaker(
    val id: String,
    val name: String,
    val handle: String,
    val isHost: Boolean,
    val isSpeaking: Boolean,
    val isMuted: Boolean
)

data class ComposeListener(
    val id: String,
    val name: String,
    val handle: String,
    var hasRaisedHand: Boolean
)

data class ComposeSpeakerRequest(
    val id: String,
    val userId: String,
    val userName: String,
    val userHandle: String,
    val requestedAt: String
)

@Composable
fun VoiceRoomScreen(
    roomId: String,
    onLeaveRoom: () -> Unit
) {
    var isMuted by remember { mutableStateOf(true) }
    var hasRaisedHand by remember { mutableStateOf(false) }
    var showChat by remember { mutableStateOf(false) }
    var showOptionsMenu by remember { mutableStateOf(false) }
    var showRequestsSheet by remember { mutableStateOf(false) }
    var chatMessageInput by remember { mutableStateOf("") }
    var isHostMode by remember { mutableStateOf(false) }
    var feedbackMessage by remember { mutableStateOf<String?>(null) }

    val chatMessages = remember {
        mutableStateListOf(
            "Maya Lin" to "Welcome everyone to the SNYVO stage! Feel free to request an open seat.",
            "Elena Rostova" to "Sounding crisp and clear today! 🎧"
        )
    }

    val speakers = remember {
        mutableStateListOf(
            ComposeSpeaker("1", "Maya Lin", "@mayalin", isHost = true, isSpeaking = true, isMuted = false),
            ComposeSpeaker("2", "Kofi Mensah", "@kofiaudio", isHost = false, isSpeaking = false, isMuted = true),
            ComposeSpeaker("3", "Elena Rostova", "@elena_r", isHost = false, isSpeaking = true, isMuted = false)
        )
    }

    val listeners = remember {
        mutableStateListOf(
            ComposeListener("me", "Alex Vance (You)", "@alexvance", false),
            ComposeListener("l1", "Marcus Chen", "@mchen", false),
            ComposeListener("l2", "Sarah Jenkins", "@sarah_j", true),
            ComposeListener("l3", "Liam O'Connor", "@liam_oc", false),
            ComposeListener("l4", "Chloe Zhao", "@chloe_z", false)
        )
    }

    val speakerRequests = remember {
        mutableStateListOf(
            ComposeSpeakerRequest("req_1", "l2", "Sarah Jenkins", "@sarah_j", "2m ago")
        )
    }

    val isUserSpeaker = speakers.any { it.id == "me" }
    val isStageFull = speakers.size >= 6

    val infiniteTransition = rememberInfiniteTransition(label = "pulseWave")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.18f,
        animationSpec = infiniteRepeatable(
            animation = tween(900, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseScale"
    )

    fun approveRequest(userId: String) {
        if (speakers.size >= 6) {
            feedbackMessage = "Stage is full (6/6 seats). Cannot approve speaker request."
            return
        }
        val req = speakerRequests.find { it.userId == userId }
        val targetName = req?.userName ?: "Listener"
        speakerRequests.removeAll { it.userId == userId }

        val listenerIndex = listeners.indexOfFirst { it.id == userId }
        if (listenerIndex != -1) {
            val lis = listeners.removeAt(listenerIndex)
            speakers.add(
                ComposeSpeaker(
                    id = lis.id,
                    name = lis.name,
                    handle = lis.handle,
                    isHost = false,
                    isSpeaking = false,
                    isMuted = true
                )
            )
        } else {
            speakers.add(
                ComposeSpeaker(
                    id = userId,
                    name = targetName,
                    handle = req?.userHandle ?: "@user",
                    isHost = false,
                    isSpeaking = false,
                    isMuted = true
                )
            )
        }

        if (userId == "me") {
            hasRaisedHand = false
            feedbackMessage = "Your request was approved! You are now on stage."
        } else {
            feedbackMessage = "$targetName approved to Speaker Seat ${speakers.size}"
        }
    }

    fun declineRequest(userId: String) {
        val req = speakerRequests.find { it.userId == userId }
        val name = req?.userName ?: "User"
        speakerRequests.removeAll { it.userId == userId }
        val lis = listeners.find { it.id == userId }
        if (lis != null) {
            lis.hasRaisedHand = false
        }
        if (userId == "me") {
            hasRaisedHand = false
            feedbackMessage = "Your request to speak was declined."
        } else {
            feedbackMessage = "Declined request from $name."
        }
    }

    Scaffold(
        containerColor = DarkBackground,
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onLeaveRoom) {
                    Icon(Icons.Default.KeyboardArrowDown, contentDescription = "Minimize", tint = Color.White)
                }

                Surface(
                    onClick = { isHostMode = !isHostMode },
                    color = if (isHostMode) Color(0x33F59E0B) else Color(0xFF1E293B),
                    shape = RoundedCornerShape(12.dp),
                    border = border(1.dp, if (isHostMode) Color(0xFFF59E0B) else Color.Transparent)
                ) {
                    Text(
                        text = if (isHostMode) "Host Controls Active" else "Late Night Lo-Fi Stage",
                        color = if (isHostMode) Color(0xFFFBBF24) else Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { showOptionsMenu = true }) {
                        Icon(Icons.Default.MoreVert, contentDescription = "Room Options", tint = Color.LightGray)
                    }

                    Button(
                        onClick = onLeaveRoom,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0x33F43F5E)),
                        shape = RoundedCornerShape(20.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Icon(Icons.AutoMirrored.Filled.ExitToApp, contentDescription = null, tint = Color(0xFFFB7185), modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Leave quietly", color = Color(0xFFFB7185), fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        },
        bottomBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF0C0F17))
                    .padding(horizontal = 20.dp, vertical = 14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    IconButton(
                        onClick = { showChat = !showChat },
                        modifier = Modifier
                            .background(if (showChat) VioletPrimary else DarkSurface, CircleShape)
                            .border(1.dp, Color(0xFF1E293B), CircleShape)
                    ) {
                        Icon(Icons.Default.ChatBubbleOutline, contentDescription = "Chat", tint = Color.White)
                    }

                    IconButton(
                        onClick = {
                            if (!isUserSpeaker) {
                                hasRaisedHand = !hasRaisedHand
                                if (hasRaisedHand) {
                                    if (speakerRequests.none { it.userId == "me" }) {
                                        speakerRequests.add(
                                            ComposeSpeakerRequest("req_me", "me", "Alex Vance (You)", "@alexvance", "Just now")
                                        )
                                    }
                                    feedbackMessage = "Speaker request sent to host."
                                } else {
                                    speakerRequests.removeAll { it.userId == "me" }
                                    feedbackMessage = "Speaker request cancelled."
                                }
                            }
                        },
                        modifier = Modifier
                            .background(
                                if (hasRaisedHand) Color(0xFFF59E0B) else DarkSurface,
                                CircleShape
                            )
                            .border(1.dp, Color(0xFF1E293B), CircleShape)
                    ) {
                        Icon(
                            Icons.Default.FrontHand,
                            contentDescription = "Raise Hand",
                            tint = if (hasRaisedHand) Color.Black else Color.LightGray
                        )
                    }
                }

                if (isUserSpeaker) {
                    Button(
                        onClick = { isMuted = !isMuted },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isMuted) Color(0xFF1E293B) else VioletPrimary
                        ),
                        shape = RoundedCornerShape(24.dp),
                        modifier = Modifier.height(48.dp)
                    ) {
                        Icon(if (isMuted) Icons.Default.MicOff else Icons.Default.Mic, contentDescription = "Mic")
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(if (isMuted) "Muted" else "On Air", fontWeight = FontWeight.Bold)
                    }
                } else {
                    Button(
                        onClick = {
                            hasRaisedHand = !hasRaisedHand
                            if (hasRaisedHand) {
                                if (speakerRequests.none { it.userId == "me" }) {
                                    speakerRequests.add(
                                        ComposeSpeakerRequest("req_me", "me", "Alex Vance (You)", "@alexvance", "Just now")
                                    )
                                }
                                feedbackMessage = "Speaker request sent to host."
                            } else {
                                speakerRequests.removeAll { it.userId == "me" }
                                feedbackMessage = "Speaker request cancelled."
                            }
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (hasRaisedHand) Color(0xFFF59E0B) else VioletPrimary
                        ),
                        shape = RoundedCornerShape(24.dp),
                        modifier = Modifier.height(48.dp)
                    ) {
                        Icon(Icons.Default.FrontHand, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (hasRaisedHand) "Request Pending" else "Request to Speak",
                            color = if (hasRaisedHand) Color.Black else Color.White,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Feedback Banner if any
                if (feedbackMessage != null) {
                    item {
                        Surface(
                            color = Color(0x33A78BFA),
                            shape = RoundedCornerShape(12.dp),
                            border = border(1.dp, VioletPrimary),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(feedbackMessage!!, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                                IconButton(onClick = { feedbackMessage = null }, modifier = Modifier.size(20.dp)) {
                                    Icon(Icons.Default.Close, contentDescription = "Dismiss", tint = Color.LightGray)
                                }
                            }
                        }
                    }
                }

                // Host Pending Speaker Requests Banner
                if (isHostMode && speakerRequests.isNotEmpty()) {
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF2E1065))
                        ) {
                            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.FrontHand, contentDescription = null, tint = Color(0xFFFBBF24), modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            "SPEAKER REQUESTS (${speakerRequests.size})",
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 11.sp
                                        )
                                    }
                                    Text(
                                        if (isStageFull) "Stage Full (6/6)" else "${6 - speakers.size} seats open",
                                        color = if (isStageFull) Color(0xFFF87171) else Color(0xFF34D399),
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }

                                speakerRequests.forEach { req ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .background(Color(0xFF0F172A), RoundedCornerShape(10.dp))
                                            .padding(10.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column {
                                            Text(req.userName, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                            Text("${req.userHandle} • ${req.requestedAt}", color = Color.Gray, fontSize = 10.sp)
                                        }

                                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                            Button(
                                                onClick = { approveRequest(req.userId) },
                                                enabled = !isStageFull,
                                                colors = ButtonDefaults.buttonColors(containerColor = VioletPrimary),
                                                shape = RoundedCornerShape(8.dp),
                                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                                            ) {
                                                Text(if (isStageFull) "Full" else "Accept", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                            }

                                            OutlinedButton(
                                                onClick = { declineRequest(req.userId) },
                                                shape = RoundedCornerShape(8.dp),
                                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                                            ) {
                                                Text("Decline", color = Color(0xFFFB7185), fontSize = 11.sp)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // Host Information Card
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = DarkSurface)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(40.dp)
                                        .clip(CircleShape)
                                        .background(Color(0xFF4C1D95)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Default.Star, contentDescription = "Host", tint = Color(0xFFFBBF24), modifier = Modifier.size(20.dp))
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text("Maya Lin", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Surface(
                                            color = Color(0x33F59E0B),
                                            shape = RoundedCornerShape(6.dp)
                                        ) {
                                            Text("HOST", color = Color(0xFFFBBF24), fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp))
                                        }
                                    }
                                    Text("@mayalin", color = Color.Gray, fontSize = 11.sp)
                                }
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Headphones, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("1,420 listening", color = Color.LightGray, fontSize = 11.sp)
                            }
                        }
                    }
                }

                // Stage Header
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "STAGE SEATS (${speakers.size} / 6)",
                            color = Color.Gray,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = "Voice Club Stage",
                            color = Color(0xFFA78BFA),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }

                // Speakers Grid (Top 3 + Bottom 3)
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            speakers.take(3).forEach { speaker ->
                                val speaking = if (speaker.id == "me") !isMuted else speaker.isSpeaking
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    modifier = Modifier
                                        .weight(1f)
                                        .background(DarkSurface, RoundedCornerShape(16.dp))
                                        .border(
                                            1.dp,
                                            if (speaking) VioletPrimary else Color(0xFF1E293B),
                                            RoundedCornerShape(16.dp)
                                        )
                                        .padding(10.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        if (speaking) {
                                            Box(
                                                modifier = Modifier
                                                    .size(56.dp)
                                                    .scale(pulseScale)
                                                    .border(2.dp, Color(0x66A78BFA), CircleShape)
                                            )
                                        }
                                        Box(
                                            modifier = Modifier
                                                .size(48.dp)
                                                .clip(CircleShape)
                                                .background(Color(0xFF2E1065)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(Icons.Default.Person, contentDescription = null, tint = Color.White, modifier = Modifier.size(24.dp))
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(speaker.name, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                                    Text(speaker.handle, color = Color.Gray, fontSize = 9.sp, maxLines = 1)
                                }
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            val row2Speakers = speakers.drop(3)
                            for (i in 0 until 3) {
                                if (i < row2Speakers.size) {
                                    val speaker = row2Speakers[i]
                                    val speaking = if (speaker.id == "me") !isMuted else speaker.isSpeaking
                                    Column(
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        modifier = Modifier
                                            .weight(1f)
                                            .background(DarkSurface, RoundedCornerShape(16.dp))
                                            .border(
                                                1.dp,
                                                if (speaking) VioletPrimary else Color(0xFF1E293B),
                                                RoundedCornerShape(16.dp)
                                            )
                                            .padding(10.dp)
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(48.dp)
                                                .clip(CircleShape)
                                                .background(Color(0xFF2E1065)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(Icons.Default.Person, contentDescription = null, tint = Color.White, modifier = Modifier.size(24.dp))
                                        }
                                        Spacer(modifier = Modifier.height(6.dp))
                                        Text(speaker.name, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                                        Text(speaker.handle, color = Color.Gray, fontSize = 9.sp, maxLines = 1)
                                    }
                                } else {
                                    val seatNum = 4 + i
                                    Column(
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        modifier = Modifier
                                            .weight(1f)
                                            .background(Color(0x14FFFFFF), RoundedCornerShape(16.dp))
                                            .border(1.dp, Color(0xFF334155), RoundedCornerShape(16.dp))
                                            .clickable {
                                                if (isHostMode && speakerRequests.isNotEmpty()) {
                                                    approveRequest(speakerRequests[0].userId)
                                                } else if (!isUserSpeaker) {
                                                    hasRaisedHand = !hasRaisedHand
                                                    if (hasRaisedHand) {
                                                        if (speakerRequests.none { it.userId == "me" }) {
                                                            speakerRequests.add(
                                                                ComposeSpeakerRequest("req_me", "me", "Alex Vance (You)", "@alexvance", "Just now")
                                                            )
                                                        }
                                                        feedbackMessage = "Speaker request sent to host."
                                                    }
                                                }
                                            }
                                            .padding(10.dp)
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(48.dp)
                                                .clip(CircleShape)
                                                .background(Color(0xFF1E293B)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(Icons.Default.Add, contentDescription = "Open Seat", tint = Color.Gray, modifier = Modifier.size(20.dp))
                                        }
                                        Spacer(modifier = Modifier.height(6.dp))
                                        Text("Seat $seatNum", color = Color.LightGray, fontSize = 11.sp, fontWeight = FontWeight.Medium)
                                        Text(
                                            if (isHostMode && speakerRequests.isNotEmpty()) "Assign Request" else "Open Seat",
                                            color = Color(0xFFA78BFA),
                                            fontSize = 9.sp
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // Listeners section
                item {
                    Text(
                        text = "LISTENERS IN ROOM (${listeners.size + 1416})",
                        color = Color.Gray,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                }

                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        listeners.forEach { listener ->
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier
                                    .weight(1f)
                                    .background(DarkSurface, RoundedCornerShape(12.dp))
                                    .padding(8.dp)
                                    .clickable {
                                        if (isHostMode && listener.hasRaisedHand) {
                                            approveRequest(listener.id)
                                        }
                                    }
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Box(
                                        modifier = Modifier
                                            .size(40.dp)
                                            .clip(CircleShape)
                                            .background(Color(0xFF1E293B)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(Icons.Default.Person, contentDescription = null, tint = Color.LightGray, modifier = Modifier.size(20.dp))
                                    }
                                    if (listener.hasRaisedHand) {
                                        Box(
                                            modifier = Modifier
                                                .align(Alignment.TopEnd)
                                                .size(16.dp)
                                                .background(Color(0xFFF59E0B), CircleShape),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(Icons.Default.FrontHand, contentDescription = null, tint = Color.Black, modifier = Modifier.size(10.dp))
                                        }
                                    }
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(listener.name.split(" ")[0], color = Color.White, fontSize = 10.sp, maxLines = 1)
                            }
                        }
                    }
                }
            }

            // Text Chat Drawer Overlay
            if (showChat) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .fillMaxHeight(0.6f)
                        .align(Alignment.BottomCenter),
                    shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF111827))
                ) {
                    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Room Discussion", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            IconButton(onClick = { showChat = false }) {
                                Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.Gray)
                            }
                        }

                        LazyColumn(
                            modifier = Modifier.weight(1f),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(chatMessages) { (sender, text) ->
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(DarkSurface, RoundedCornerShape(10.dp))
                                        .padding(8.dp)
                                 ) {
                                    Text(sender, color = Color(0xFFA78BFA), fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                    Text(text, color = Color.White, fontSize = 12.sp)
                                }
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedTextField(
                                value = chatMessageInput,
                                onValueChange = { chatMessageInput = it },
                                placeholder = { Text("Send to room...", color = Color.Gray, fontSize = 12.sp) },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(16.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = VioletPrimary,
                                    unfocusedBorderColor = Color(0xFF374151),
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White
                                )
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            IconButton(
                                onClick = {
                                    if (chatMessageInput.isNotBlank()) {
                                        chatMessages.add("Alex Vance (You)" to chatMessageInput)
                                        chatMessageInput = ""
                                    }
                                }
                            ) {
                                Icon(Icons.Default.Send, contentDescription = "Send", tint = VioletPrimary)
                            }
                        }
                    }
                }
            }

            // Room Options Dialog
            if (showOptionsMenu) {
                AlertDialog(
                    onDismissRequest = { showOptionsMenu = false },
                    title = { Text("Stage Options & Etiquette", color = Color.White) },
                    text = {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("• Keep microphone muted when not actively speaking.", color = Color.LightGray, fontSize = 12.sp)
                            Text("• Tap empty seats or raise hand to request speaking turn.", color = Color.LightGray, fontSize = 12.sp)
                            Text("• The Host manages stage requests and open seats.", color = Color.LightGray, fontSize = 12.sp)
                        }
                    },
                    confirmButton = {
                        TextButton(onClick = { showOptionsMenu = false }) {
                            Text("Got it", color = VioletPrimary)
                        }
                    },
                    containerColor = DarkSurface
                )
            }
        }
    }
}
