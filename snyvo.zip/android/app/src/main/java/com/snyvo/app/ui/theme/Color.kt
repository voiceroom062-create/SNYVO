package com.snyvo.app.ui.theme

import androidx.compose.ui.graphics.Color

val DarkBackground = Color(0xFF090B10)
val DarkSurface = Color(0xFF121620)
val DarkSurfaceElevated = Color(0xFF1A202E)
val VioletPrimary = Color(0xFF7C3AED)
val VioletAccent = Color(0xFF8B5CF6)
val IndigoAccent = Color(0xFF6366F1)
val EmeraldLive = Color(0xFF10B981)
val RoseLeave = Color(0xFFF43F5E)
val AmberCrown = Color(0xFFF59E0B)
val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)
val BorderSubtle = Color(0xFF1E293B)
