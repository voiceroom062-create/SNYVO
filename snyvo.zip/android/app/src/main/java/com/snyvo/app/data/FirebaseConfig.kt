package com.snyvo.app.data

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await

/**
 * SNYVO Android Firebase & Real-time Voice Architecture
 * Prepared for Firebase Authentication and Firestore Room Sync
 */
class FirebaseRepository(
    private val auth: FirebaseAuth = FirebaseAuth.getInstance(),
    private val firestore: FirebaseFirestore = FirebaseFirestore.getInstance()
) {
    suspend fun signInWithEmail(email: String, pass: String): Boolean {
        return try {
            auth.signInWithEmailAndPassword(email, pass).await()
            true
        } catch (e: Exception) {
            false
        }
    }

    suspend fun createVoiceRoom(title: String, clubName: String, topic: String): String {
        val roomData = hashMapOf(
            "title" to title,
            "clubName" to clubName,
            "topic" to topic,
            "hostId" to (auth.currentUser?.uid ?: "guest"),
            "createdAt" to System.currentTimeMillis(),
            "isLive" to true
        )
        val docRef = firestore.collection("voice_rooms").add(roomData).await()
        return docRef.id
    }

    suspend fun toggleParticipantMute(roomId: String, isMuted: Boolean) {
        val uid = auth.currentUser?.uid ?: return
        firestore.collection("voice_rooms").document(roomId)
            .collection("participants").document(uid)
            .update("isMuted", isMuted).await()
    }
}
