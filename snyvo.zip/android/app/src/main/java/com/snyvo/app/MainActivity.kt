package com.snyvo.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import com.snyvo.app.navigation.SnyvoNavGraph
import com.snyvo.app.ui.theme.SnyvoTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            SnyvoTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color(0xFF090B10)
                ) {
                    SnyvoNavGraph()
                }
            }
        }
    }
}
