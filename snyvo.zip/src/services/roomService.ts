/**
 * SNYVO Real-Time Voice Room Service
 * 
 * Provides connection state, audio mute/unmute management,
 * speaker hand-raise queue, and live reactions.
 * Prepared for Firebase Firestore real-time presence + WebRTC audio mesh or LiveKit SFU.
 */

import {
  VoiceRoom,
  Speaker,
  Listener,
  User,
  ReactionParticle,
  SpeakerRequest,
  MicrophoneState,
  MicrophonePermissionStatus,
  UserRoomRole,
  SeatStatus,
  SpeakerSeat,
  RoomParticipant
} from '../types';
import { sampleRooms } from '../data/mockData';
import { voiceAudioService } from './audio/voiceAudioService';
import { AudioServiceError } from './audio/voiceTypes';

class RoomService {
  private rooms: VoiceRoom[] = [...sampleRooms];
  private activeRoomId: string | null = null;
  private isMuted: boolean = true;
  private isSpeaking: boolean = false;
  private hasRaisedHand: boolean = false;
  private userRequestStatus: 'idle' | 'pending' | 'accepted' | 'declined' = 'idle';
  private userRequestMessage: string | null = null;
  private listeners: (() => void)[] = [];
  private reactionListeners: ((reaction: ReactionParticle) => void)[] = [];

  constructor() {
    // Restore or initialize rooms
    const saved = localStorage.getItem('snyvo_rooms');
    if (saved) {
      try {
        this.rooms = JSON.parse(saved);
      } catch (e) {
        this.rooms = [...sampleRooms];
      }
    } else {
      this.rooms = [...sampleRooms];
    }

    // Merge sampleRoom details & append missing sample rooms
    sampleRooms.forEach(sr => {
      const existing = this.rooms.find(r => r.id === sr.id);
      if (existing) {
        if (!existing.coverImage) existing.coverImage = sr.coverImage;
        if (!existing.country) existing.country = sr.country;
        if (!existing.countryCode) existing.countryCode = sr.countryCode;
        if (existing.isHot === undefined) existing.isHot = sr.isHot;
        if (existing.roomCoins === undefined || existing.roomCoins === 0) existing.roomCoins = sr.roomCoins;
        if (!existing.giftsReceivedCount) existing.giftsReceivedCount = sr.giftsReceivedCount;
      } else {
        this.rooms.push({ ...sr });
      }
    });

    // Ensure all rooms have valid speakerRequests, maxSeats = 10, and unique seatIndexes
    this.rooms.forEach(room => {
      if (!room.maxSeats || room.maxSeats < 10) room.maxSeats = 10;
      if (!room.lockedSeats) room.lockedSeats = [];
      const maxSeats = room.maxSeats;
      if (!room.speakerRequests) {
        room.speakerRequests = [];
      }

      // Ensure speakers have unique seatIndex from 0 to maxSeats - 1
      const taken = new Set<number>();
      room.speakers.forEach((sp, idx) => {
        if (typeof sp.seatIndex === 'number' && sp.seatIndex >= 0 && sp.seatIndex < maxSeats && !taken.has(sp.seatIndex)) {
          taken.add(sp.seatIndex);
        } else {
          for (let s = 0; s < maxSeats; s++) {
            if (!taken.has(s)) {
              sp.seatIndex = s;
              taken.add(s);
              break;
            }
          }
          if (sp.seatIndex === undefined) {
            sp.seatIndex = idx % maxSeats;
          }
        }
      });

      // Populate requests for any listener with raisedHand
      room.listeners.forEach(lis => {
        if (lis.raisedHand && !room.speakerRequests!.some(r => r.userId === lis.id)) {
          room.speakerRequests!.push({
            id: `req_${lis.id}`,
            userId: lis.id,
            userName: lis.name,
            userHandle: lis.handle,
            userAvatar: lis.avatar,
            requestedAt: '2m ago',
            status: 'pending'
          });
        }
      });

      // Ensure room real-time properties
      room.hostId = room.host.id;
      if (!room.moderatorIds) room.moderatorIds = [room.host.id];
      if (!room.coHostIds) room.coHostIds = [];
      if (!room.micStates) room.micStates = {};
      if (!room.connectionState) room.connectionState = 'connected';
      if (!room.audioServiceStatus) room.audioServiceStatus = 'not_connected';

      room.speakers.forEach(sp => {
        if (!sp.role) {
          if (sp.id === room.host.id) sp.role = 'host';
          else if (sp.isCoHost) sp.role = 'cohost';
          else if (sp.isModerator) sp.role = 'moderator';
          else sp.role = 'speaker';
        }
        if (!sp.micState) {
          sp.micState = sp.isMuted ? 'off' : 'on';
        }
        if (!sp.seatStatus) {
          sp.seatStatus = sp.isSpeaking ? 'speaking' : sp.isMuted ? 'muted' : 'occupied';
        }
        room.micStates![sp.id] = sp.micState;
      });

      room.listeners.forEach(lis => {
        if (!lis.role) lis.role = 'listener';
        if (!lis.micState) lis.micState = 'off';
        room.micStates![lis.id] = 'off';
      });
    });

    // Ensure room_1 has Maya Lin, Kofi Mensah, Elena Rostova as 3 speakers initially so seats 4-10 are open
    const r1 = this.rooms.find(r => r.id === 'room_1');
    if (r1) {
      r1.speakers = r1.speakers.filter(s => s.id !== 'usr_me' && s.id !== 'usr_guest');
      r1.maxSeats = 10;
      if (!r1.lockedSeats) r1.lockedSeats = [];
      // Assign Maya Lin to Seat 1 (index 0), Kofi to Seat 2 (index 1), Elena to Seat 3 (index 2)
      r1.speakers.forEach((sp, idx) => {
        sp.seatIndex = idx;
      });
      if (!r1.speakerRequests || r1.speakerRequests.length === 0) {
        r1.speakerRequests = [
          {
            id: 'req_lis_3',
            userId: 'lis_3',
            userName: 'Marcus Bell',
            userHandle: '@marcusbell',
            userAvatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=200&auto=format&fit=crop&q=80',
            requestedAt: '2m ago',
            status: 'pending'
          }
        ];
      }
    }
  }

  // =========================================================================
  // REAL-TIME AUDIO & MICROPHONE SYSTEM
  // =========================================================================

  public getMicrophoneState(): MicrophoneState {
    return voiceAudioService.getMicState();
  }

  public getMicrophonePermissionStatus(): MicrophonePermissionStatus {
    return voiceAudioService.getPermissionStatus();
  }

  public async requestMicrophonePermission(): Promise<{ granted: boolean; error?: AudioServiceError }> {
    const res = await voiceAudioService.requestMicrophonePermission();
    this.notify();
    return res;
  }

  /**
   * Authoritative microphone toggle connected to hardware permissions and room state
   */
  public async toggleMicrophone(user: User): Promise<{
    success: boolean;
    state: MicrophoneState;
    error?: AudioServiceError;
  }> {
    const role = this.getUserRole(this.activeRoomId || '', user.id);
    const result = await voiceAudioService.toggleMicrophone(role);

    this.isMuted = result.state !== 'on';
    this.isSpeaking = result.state === 'on';

    if (this.activeRoomId) {
      const room = this.rooms.find(r => r.id === this.activeRoomId);
      if (room) {
        if (!room.micStates) room.micStates = {};
        room.micStates[user.id] = result.state;

        const speaker = room.speakers.find(s => s.id === user.id);
        if (speaker) {
          speaker.isMuted = this.isMuted;
          speaker.isSpeaking = this.isSpeaking;
          speaker.micState = result.state;
          speaker.seatStatus = result.state === 'on' ? 'speaking' : this.isMuted ? 'muted' : 'occupied';
        }
      }
    }

    this.save();
    this.notify();
    return result;
  }

  /**
   * Authoritative method to turn microphone ON for the user.
   */
  public async setMicrophoneOn(user: User): Promise<{
    success: boolean;
    state: MicrophoneState;
    error?: AudioServiceError;
  }> {
    const role = this.getUserRole(this.activeRoomId || '', user.id);
    const result = await voiceAudioService.turnMicrophoneOn(role);

    this.isMuted = result.state !== 'on';
    this.isSpeaking = result.state === 'on';

    if (this.activeRoomId) {
      const room = this.rooms.find(r => r.id === this.activeRoomId);
      if (room) {
        if (!room.micStates) room.micStates = {};
        room.micStates[user.id] = result.state;

        const speaker = room.speakers.find(s => s.id === user.id);
        if (speaker) {
          speaker.isMuted = this.isMuted;
          speaker.isSpeaking = this.isSpeaking;
          speaker.micState = result.state;
          speaker.seatStatus = result.state === 'on' ? 'speaking' : this.isMuted ? 'muted' : 'occupied';
        }
      }
    }

    this.save();
    this.notify();
    return result;
  }

  /**
   * Authoritative method to turn microphone OFF for the user.
   */
  public async setMicrophoneOff(user: User): Promise<{
    success: boolean;
    state: MicrophoneState;
  }> {
    const result = await voiceAudioService.turnMicrophoneOff();

    this.isMuted = true;
    this.isSpeaking = false;

    if (this.activeRoomId) {
      const room = this.rooms.find(r => r.id === this.activeRoomId);
      if (room) {
        if (!room.micStates) room.micStates = {};
        room.micStates[user.id] = result.state;

        const speaker = room.speakers.find(s => s.id === user.id);
        if (speaker) {
          speaker.isMuted = true;
          speaker.isSpeaking = false;
          speaker.micState = result.state;
          speaker.seatStatus = 'muted';
        }
      }
    }

    this.save();
    this.notify();
    return result;
  }

  /**
   * Host / Moderator action: Mute a speaker on stage
   */
  public muteSpeakerByHost(roomId: string, targetSpeakerId: string, actorUserId: string): { success: boolean; message: string } {
    const room = this.rooms.find(r => r.id === roomId);
    if (!room) return { success: false, message: 'Room not found' };

    const actorRole = this.getUserRole(roomId, actorUserId);
    if (actorRole !== 'host' && actorRole !== 'cohost' && actorRole !== 'moderator') {
      return { success: false, message: 'Only Host or Moderator can mute participants.' };
    }

    const speaker = room.speakers.find(s => s.id === targetSpeakerId);
    if (!speaker) return { success: false, message: 'Speaker not found on stage' };

    speaker.isMuted = true;
    speaker.isSpeaking = false;
    speaker.micState = 'muted_by_host';
    speaker.seatStatus = 'muted';

    if (!room.micStates) room.micStates = {};
    room.micStates[targetSpeakerId] = 'muted_by_host';

    // If target is current user
    if (targetSpeakerId === 'usr_me' || targetSpeakerId === 'usr_guest') {
      voiceAudioService.setMutedByHost(true);
      this.isMuted = true;
      this.isSpeaking = false;
    }

    this.save();
    this.notify();
    return { success: true, message: `${speaker.name} was muted by the host.` };
  }

  /**
   * Host / Moderator action: Allow speaker to unmute their microphone
   */
  public unmuteSpeakerByHost(roomId: string, targetSpeakerId: string, actorUserId: string): { success: boolean; message: string } {
    const room = this.rooms.find(r => r.id === roomId);
    if (!room) return { success: false, message: 'Room not found' };

    const actorRole = this.getUserRole(roomId, actorUserId);
    if (actorRole !== 'host' && actorRole !== 'cohost' && actorRole !== 'moderator') {
      return { success: false, message: 'Only Host or Moderator can unmute participants.' };
    }

    const speaker = room.speakers.find(s => s.id === targetSpeakerId);
    if (!speaker) return { success: false, message: 'Speaker not found on stage' };

    speaker.micState = 'off';
    speaker.seatStatus = 'muted';

    if (!room.micStates) room.micStates = {};
    room.micStates[targetSpeakerId] = 'off';

    // If target is current user
    if (targetSpeakerId === 'usr_me' || targetSpeakerId === 'usr_guest') {
      voiceAudioService.setMutedByHost(false);
    }

    this.save();
    this.notify();
    return { success: true, message: `${speaker.name} can now unmute their microphone.` };
  }

  /**
   * Get user role in a room (host, cohost, moderator, speaker, listener)
   */
  public getUserRole(roomId: string, userId: string): UserRoomRole {
    const room = this.rooms.find(r => r.id === roomId);
    if (!room) return 'listener';

    if (room.host.id === userId || room.hostId === userId) return 'host';
    if (room.coHostIds?.includes(userId)) return 'cohost';
    if (room.moderatorIds?.includes(userId)) return 'moderator';

    const speaker = room.speakers.find(s => s.id === userId);
    if (speaker) {
      if (speaker.isHost) return 'host';
      if (speaker.isCoHost) return 'cohost';
      if (speaker.isModerator) return 'moderator';
      return 'speaker';
    }

    return 'listener';
  }

  /**
   * Update a user's role in the room
   */
  public setUserRole(
    roomId: string,
    targetUserId: string,
    role: UserRoomRole,
    actorUserId: string
  ): { success: boolean; message: string } {
    const room = this.rooms.find(r => r.id === roomId);
    if (!room) return { success: false, message: 'Room not found' };

    const actorRole = this.getUserRole(roomId, actorUserId);
    if (actorRole !== 'host' && actorRole !== 'cohost') {
      return { success: false, message: 'Permission denied: Only host can change participant roles.' };
    }

    if (!room.moderatorIds) room.moderatorIds = [room.host.id];
    if (!room.coHostIds) room.coHostIds = [];

    // Remove from previous roles
    room.moderatorIds = room.moderatorIds.filter(id => id !== targetUserId);
    room.coHostIds = room.coHostIds.filter(id => id !== targetUserId);

    if (role === 'cohost') {
      room.coHostIds.push(targetUserId);
    } else if (role === 'moderator') {
      room.moderatorIds.push(targetUserId);
    }

    // Update speaker instance if seated
    const speaker = room.speakers.find(s => s.id === targetUserId);
    if (speaker) {
      speaker.role = role;
      speaker.isCoHost = role === 'cohost';
      speaker.isModerator = role === 'moderator' || role === 'cohost' || role === 'host';
    }

    this.save();
    this.notify();
    return { success: true, message: `Updated participant role to ${role.toUpperCase()}.` };
  }

  /**
   * Generates formatted SpeakerSeat list for the room
   */
  public getRoomSeats(roomId: string, currentUserId: string): SpeakerSeat[] {
    const room = this.rooms.find(r => r.id === roomId);
    if (!room) return [];
    return voiceAudioService.generateSpeakerSeats(
      room.maxSeats || 10,
      room.speakers,
      room.lockedSeats || [],
      currentUserId
    );
  }

  /**
   * Retrieves full list of participants with roles and mic states
   */
  public getRoomParticipants(roomId: string): RoomParticipant[] {
    const room = this.rooms.find(r => r.id === roomId);
    if (!room) return [];

    const participants: RoomParticipant[] = [];

    room.speakers.forEach(sp => {
      participants.push({
        id: sp.id,
        name: sp.name,
        handle: sp.handle,
        avatar: sp.avatar,
        role: this.getUserRole(roomId, sp.id),
        micState: sp.micState || (sp.isMuted ? 'off' : 'on'),
        seatIndex: sp.seatIndex,
        isSpeaking: sp.isSpeaking
      });
    });

    room.listeners.forEach(lis => {
      participants.push({
        id: lis.id,
        name: lis.name,
        handle: lis.handle,
        avatar: lis.avatar,
        role: 'listener',
        micState: 'off',
        isSpeaking: false
      });
    });

    return participants;
  }

  public getRooms(): VoiceRoom[] {
    return this.rooms;
  }

  public getRoom(id: string): VoiceRoom | undefined {
    return this.rooms.find(r => r.id === id);
  }

  public getActiveRoom(): VoiceRoom | null {
    if (!this.activeRoomId) return null;
    return this.getRoom(this.activeRoomId) || null;
  }

  public getActiveRoomId(): string | null {
    return this.activeRoomId;
  }

  public isUserMuted(): boolean {
    return this.isMuted;
  }

  public isUserSpeaking(): boolean {
    return this.isSpeaking;
  }

  public userHasRaisedHand(): boolean {
    return this.hasRaisedHand;
  }

  public subscribe(callback: () => void): () => void {
    this.listeners.push(callback);
    return () => {
      this.listeners = this.listeners.filter(cb => cb !== callback);
    };
  }

  public onReaction(callback: (reaction: ReactionParticle) => void): () => void {
    this.reactionListeners.push(callback);
    return () => {
      this.reactionListeners = this.reactionListeners.filter(cb => cb !== callback);
    };
  }

  public joinRoom(roomId: string, user: User, joinAsSpeaker: boolean = false): VoiceRoom | null {
    const room = this.rooms.find(r => r.id === roomId);
    if (!room) return null;

    this.activeRoomId = roomId;
    this.isMuted = true;
    this.isSpeaking = false;
    this.hasRaisedHand = false;

    // Connect to real-time audio service provider layer
    voiceAudioService.connectAudioRoom(roomId, user.id);

    // Check if user is already a speaker or listener
    const existingSpeaker = room.speakers.find(s => s.id === user.id);
    const existingListener = room.listeners.find(l => l.id === user.id);

    if (joinAsSpeaker && !existingSpeaker) {
      // Remove from listeners if present
      room.listeners = room.listeners.filter(l => l.id !== user.id);
      const isHost = room.host.id === user.id;
      const role: UserRoomRole = isHost ? 'host' : 'speaker';
      room.speakers.push({
        id: user.id,
        name: user.name,
        handle: user.handle,
        avatar: user.avatar,
        isHost,
        isModerator: isHost,
        role,
        isMuted: true,
        isSpeaking: false,
        micState: 'off',
        seatStatus: 'muted'
      });
      if (!room.micStates) room.micStates = {};
      room.micStates[user.id] = 'off';
    } else if (!existingSpeaker && !existingListener) {
      room.listeners.push({
        id: user.id,
        name: user.name,
        handle: user.handle,
        avatar: user.avatar,
        role: 'listener',
        raisedHand: false,
        micState: 'off'
      });
      room.listenerCount += 1;
      if (!room.micStates) room.micStates = {};
      room.micStates[user.id] = 'off';
    }

    this.save();
    this.notify();
    return room;
  }

  public leaveRoom(user?: User) {
    if (!this.activeRoomId) return;
    const room = this.rooms.find(r => r.id === this.activeRoomId);
    if (room && user) {
      // If user was speaker, remove from speaker list unless they are the persistent host
      if (room.host.id !== user.id) {
        room.speakers = room.speakers.filter(s => s.id !== user.id);
      }
      room.listeners = room.listeners.filter(l => l.id !== user.id);
      room.listenerCount = Math.max(1, room.listenerCount - 1);
    }
    this.activeRoomId = null;
    this.isMuted = true;
    this.isSpeaking = false;
    this.hasRaisedHand = false;

    // Disconnect audio tracks and provider channel
    voiceAudioService.disconnectAudioRoom();

    this.save();
    this.notify();
  }

  public toggleMute(user: User): boolean {
    this.toggleMicrophone(user);
    return this.isMuted;
  }

  public toggleRaiseHand(user: User): boolean {
    this.hasRaisedHand = !this.hasRaisedHand;
    if (this.activeRoomId) {
      if (this.hasRaisedHand) {
        this.requestToSpeak(user);
      } else {
        this.cancelSpeakerRequest(user.id);
      }
    }
    return this.hasRaisedHand;
  }

  public requestToSpeak(user: User): { success: boolean; message: string } {
    if (!this.activeRoomId) return { success: false, message: 'No active room' };
    const room = this.rooms.find(r => r.id === this.activeRoomId);
    if (!room) return { success: false, message: 'Room not found' };

    // If already a speaker
    if (room.speakers.some(s => s.id === user.id)) {
      return { success: false, message: 'You are already a speaker on stage.' };
    }

    if (!room.speakerRequests) {
      room.speakerRequests = [];
    }

    const existingReq = room.speakerRequests.find(r => r.userId === user.id && r.status === 'pending');
    if (!existingReq) {
      room.speakerRequests.push({
        id: `req_${user.id}_${Date.now()}`,
        userId: user.id,
        userName: user.name,
        userHandle: user.handle,
        userAvatar: user.avatar,
        requestedAt: 'Just now',
        status: 'pending'
      });
    }

    const listener = room.listeners.find(l => l.id === user.id);
    if (listener) {
      listener.raisedHand = true;
    }
    this.hasRaisedHand = true;
    this.userRequestStatus = 'pending';
    this.userRequestMessage = 'Speaker request submitted. Awaiting host approval.';

    this.save();
    this.notify();
    return { success: true, message: 'Speaker request submitted. Awaiting host approval.' };
  }

  public cancelSpeakerRequest(userId: string): { success: boolean; message: string } {
    if (!this.activeRoomId) return { success: false, message: 'No active room' };
    const room = this.rooms.find(r => r.id === this.activeRoomId);
    if (!room) return { success: false, message: 'Room not found' };

    if (room.speakerRequests) {
      room.speakerRequests = room.speakerRequests.filter(r => r.userId !== userId);
    }

    const listener = room.listeners.find(l => l.id === userId);
    if (listener) {
      listener.raisedHand = false;
    }

    this.hasRaisedHand = false;
    this.userRequestStatus = 'idle';
    this.userRequestMessage = null;
    this.save();
    this.notify();
    return { success: true, message: 'Speaker request cancelled.' };
  }

  public approveSpeakerRequest(roomId: string, userId: string): { success: boolean; message: string; speakerName?: string; seatNumber?: number } {
    const room = this.rooms.find(r => r.id === roomId);
    if (!room) return { success: false, message: 'Room not found' };

    const maxSeats = room.maxSeats || 8;
    const occupiedSeatIndices = new Set(
      room.speakers
        .map(s => s.seatIndex)
        .filter((idx): idx is number => typeof idx === 'number' && idx >= 0 && idx < maxSeats)
    );

    if (occupiedSeatIndices.size >= maxSeats || room.speakers.length >= maxSeats) {
      return {
        success: false,
        message: 'No speaker seats available.'
      };
    }

    // Find first available Speaker Seat (0 to maxSeats - 1)
    let firstAvailableSeat = -1;
    for (let i = 0; i < maxSeats; i++) {
      if (!occupiedSeatIndices.has(i)) {
        firstAvailableSeat = i;
        break;
      }
    }

    if (firstAvailableSeat === -1) {
      return {
        success: false,
        message: 'No speaker seats available.'
      };
    }

    let userToAdd: { id: string; name: string; handle: string; avatar: string } | null = null;

    if (room.speakerRequests) {
      const reqIndex = room.speakerRequests.findIndex(r => r.userId === userId);
      if (reqIndex !== -1) {
        const req = room.speakerRequests[reqIndex];
        userToAdd = {
          id: req.userId,
          name: req.userName,
          handle: req.userHandle,
          avatar: req.userAvatar
        };
        // Remove pending request
        room.speakerRequests.splice(reqIndex, 1);
      }
    }

    if (!userToAdd) {
      const lis = room.listeners.find(l => l.id === userId);
      if (lis) {
        userToAdd = {
          id: lis.id,
          name: lis.name,
          handle: lis.handle,
          avatar: lis.avatar
        };
      }
    }

    if (!userToAdd) {
      return { success: false, message: 'User not found in requests or listeners.' };
    }

    // Remove from listeners and decrease listener count
    room.listeners = room.listeners.filter(l => l.id !== userId);
    room.listenerCount = Math.max(0, room.listenerCount - 1);

    // Add to speakers in first available seat
    const existingSpeaker = room.speakers.find(s => s.id === userId);
    if (!existingSpeaker) {
      room.speakers.push({
        id: userToAdd.id,
        name: userToAdd.name,
        handle: userToAdd.handle,
        avatar: userToAdd.avatar,
        isHost: false,
        isModerator: false,
        isMuted: true,
        isSpeaking: false,
        seatIndex: firstAvailableSeat,
      });
    } else {
      existingSpeaker.seatIndex = firstAvailableSeat;
    }

    // If local active user is approved, update raised hand state and status
    if (userId === 'usr_me' || userId === 'usr_guest') {
      this.hasRaisedHand = false;
      this.userRequestStatus = 'accepted';
      this.userRequestMessage = `Your request was approved! You are in Seat ${firstAvailableSeat + 1}.`;
    }

    this.save();
    this.notify();
    return {
      success: true,
      message: `${userToAdd.name} approved! Moved to Speaker Seat ${firstAvailableSeat + 1}.`,
      speakerName: userToAdd.name,
      seatNumber: firstAvailableSeat + 1
    };
  }

  public declineSpeakerRequest(roomId: string, userId: string): { success: boolean; message: string; userName?: string } {
    const room = this.rooms.find(r => r.id === roomId);
    if (!room) return { success: false, message: 'Room not found' };

    let targetName = 'User';
    if (room.speakerRequests) {
      const req = room.speakerRequests.find(r => r.userId === userId);
      if (req) {
        targetName = req.userName;
      }
      // Remove the pending request
      room.speakerRequests = room.speakerRequests.filter(r => r.userId !== userId);
    }

    const listener = room.listeners.find(l => l.id === userId);
    if (listener) {
      listener.raisedHand = false;
      targetName = listener.name;
    }

    if (userId === 'usr_me' || userId === 'usr_guest') {
      this.hasRaisedHand = false;
      this.userRequestStatus = 'declined';
      this.userRequestMessage = 'Your request to speak was declined by the host.';
    }

    this.save();
    this.notify();
    return {
      success: true,
      message: `Speaker request for ${targetName} was declined.`,
      userName: targetName
    };
  }

  public moveSpeakerSeat(roomId: string, speakerId: string, targetSeatIndex: number): {
    success: boolean;
    message: string;
    speakerName?: string;
    oldSeatNumber?: number;
    newSeatNumber?: number;
  } {
    const room = this.rooms.find(r => r.id === roomId);
    if (!room) return { success: false, message: 'Room not found' };

    const maxSeats = room.maxSeats || 8;
    if (targetSeatIndex < 0 || targetSeatIndex >= maxSeats) {
      return { success: false, message: `Invalid seat position. Must be between 1 and ${maxSeats}.` };
    }

    const speaker = room.speakers.find(s => s.id === speakerId);
    if (!speaker) {
      return { success: false, message: 'Speaker is not on stage.' };
    }

    const currentSeat = speaker.seatIndex ?? 0;
    if (currentSeat === targetSeatIndex) {
      return { success: false, message: `Already sitting in Seat ${targetSeatIndex + 1}.` };
    }

    // Check if target seat is occupied by another speaker
    const occupying = room.speakers.find(s => s.seatIndex === targetSeatIndex && s.id !== speakerId);
    if (occupying) {
      return { success: false, message: `Seat ${targetSeatIndex + 1} is already occupied by ${occupying.name}.` };
    }

    const oldSeatNumber = currentSeat + 1;
    const newSeatNumber = targetSeatIndex + 1;

    // Move speaker to target seat - preserving all profile, mic, speaking, host status
    speaker.seatIndex = targetSeatIndex;

    this.save();
    this.notify();
    return {
      success: true,
      message: `${speaker.name} moved from Seat ${oldSeatNumber} to Seat ${newSeatNumber}.`,
      speakerName: speaker.name,
      oldSeatNumber,
      newSeatNumber
    };
  }

  public getAvailableSeats(roomId: string): { seatIndex: number; seatNumber: number }[] {
    const room = this.rooms.find(r => r.id === roomId);
    if (!room) return [];
    const maxSeats = room.maxSeats || 10;
    const occupied = new Set(room.speakers.map(s => s.seatIndex));
    const locked = new Set(room.lockedSeats || []);
    const available: { seatIndex: number; seatNumber: number }[] = [];
    for (let i = 0; i < maxSeats; i++) {
      if (!occupied.has(i) && !locked.has(i)) {
        available.push({ seatIndex: i, seatNumber: i + 1 });
      }
    }
    return available;
  }

  /**
   * Take / Sit on a Voice Room seat (Flexible / Optional Seating)
   * Real-time sync & race-condition protected:
   * Only one user can occupy a seat at a time.
   */
  public takeSeat(roomId: string, user: User, targetSeatIndex?: number): { success: boolean; message: string; seatNumber?: number } {
    const room = this.rooms.find(r => r.id === roomId);
    if (!room) return { success: false, message: 'Room not found' };

    const maxSeats = room.maxSeats || 10;
    const existingSpeaker = room.speakers.find(s => s.id === user.id);

    let assignedSeat = targetSeatIndex;

    if (assignedSeat !== undefined) {
      if (assignedSeat < 0 || assignedSeat >= maxSeats) {
        return { success: false, message: `Invalid seat position. Must be between 1 and ${maxSeats}.` };
      }
      if (room.lockedSeats && room.lockedSeats.includes(assignedSeat)) {
        return { success: false, message: `Seat #${assignedSeat + 1} is locked by the host.` };
      }
      // Race condition check: Verify no other user occupies this seat
      const occupiedByOther = room.speakers.find(s => s.seatIndex === assignedSeat && s.id !== user.id);
      if (occupiedByOther) {
        return { success: false, message: 'Seat is no longer available.' };
      }
    } else {
      // Find first available unlocked seat
      const occupiedSet = new Set(room.speakers.map(s => s.seatIndex));
      const lockedSet = new Set(room.lockedSeats || []);
      for (let i = 0; i < maxSeats; i++) {
        if (!occupiedSet.has(i) && !lockedSet.has(i)) {
          assignedSeat = i;
          break;
        }
      }
      if (assignedSeat === undefined) {
        return { success: false, message: 'No empty seats available at this time.' };
      }
    }

    // Remove user from listeners if currently listed as listener
    const listenerIdx = room.listeners.findIndex(l => l.id === user.id);
    if (listenerIdx !== -1) {
      room.listeners.splice(listenerIdx, 1);
      room.listenerCount = Math.max(0, room.listenerCount - 1);
    }

    // Clear any pending speaker requests for this user
    if (room.speakerRequests) {
      room.speakerRequests = room.speakerRequests.filter(r => r.userId !== user.id);
    }

    if (existingSpeaker) {
      existingSpeaker.seatIndex = assignedSeat;
    } else {
      room.speakers.push({
        id: user.id,
        name: user.name,
        handle: user.handle,
        avatar: user.avatar,
        isHost: room.host.id === user.id,
        isModerator: room.host.id === user.id,
        isMuted: this.isMuted,
        isSpeaking: false,
        seatIndex: assignedSeat,
        userLevel: user.level || 1,
        vipLevel: user.vipLevel || undefined
      });
    }

    if (user.id === 'usr_me' || user.id === 'usr_guest') {
      this.hasRaisedHand = false;
      this.userRequestStatus = 'accepted';
      this.userRequestMessage = `You are now on Seat #${assignedSeat + 1}.`;
    }

    this.save();
    this.notify();
    return {
      success: true,
      message: `You sat on Seat #${assignedSeat + 1}.`,
      seatNumber: assignedSeat + 1
    };
  }

  /**
   * Leave Seat / Get Down from Voice Room seat
   * User vacates the seat but REMAINS in the room as an audience participant.
   */
  public leaveSeat(roomId: string, userId: string): { success: boolean; message: string } {
    const room = this.rooms.find(r => r.id === roomId);
    if (!room) return { success: false, message: 'Room not found' };

    const speakerIndex = room.speakers.findIndex(s => s.id === userId);
    if (speakerIndex === -1) {
      return { success: false, message: 'You are not currently sitting on any seat.' };
    }

    const [removedSpeaker] = room.speakers.splice(speakerIndex, 1);

    // Return to audience as a normal room participant
    const alreadyListener = room.listeners.some(l => l.id === userId);
    if (!alreadyListener) {
      room.listeners.push({
        id: removedSpeaker.id,
        name: removedSpeaker.name,
        handle: removedSpeaker.handle,
        avatar: removedSpeaker.avatar,
        raisedHand: false,
      });
      room.listenerCount += 1;
    }

    if (userId === 'usr_me' || userId === 'usr_guest') {
      this.isMuted = true;
      this.isSpeaking = false;
      this.hasRaisedHand = false;
      this.userRequestStatus = 'idle';
      this.userRequestMessage = null;
    }

    this.save();
    this.notify();
    return {
      success: true,
      message: 'You left your seat and returned to the room audience.'
    };
  }

  /**
   * Lock or unlock a seat (Host control)
   */
  public toggleLockSeat(roomId: string, seatIndex: number): { success: boolean; isLocked: boolean; message: string } {
    const room = this.rooms.find(r => r.id === roomId);
    if (!room) return { success: false, isLocked: false, message: 'Room not found' };

    if (!room.lockedSeats) room.lockedSeats = [];
    const idx = room.lockedSeats.indexOf(seatIndex);
    let isLocked = false;
    if (idx !== -1) {
      room.lockedSeats.splice(idx, 1);
      isLocked = false;
    } else {
      room.lockedSeats.push(seatIndex);
      isLocked = true;
    }

    this.save();
    this.notify();
    return {
      success: true,
      isLocked,
      message: isLocked ? `Seat #${seatIndex + 1} locked` : `Seat #${seatIndex + 1} unlocked`
    };
  }

  public getUserRequestStatus(): 'idle' | 'pending' | 'accepted' | 'declined' {
    return this.userRequestStatus;
  }

  public getUserRequestMessage(): string | null {
    return this.userRequestMessage;
  }

  public clearUserRequestStatus() {
    this.userRequestStatus = 'idle';
    this.userRequestMessage = null;
    this.notify();
  }

  public demoteToListener(roomId: string, speakerId: string): { success: boolean; message: string } {
    const room = this.rooms.find(r => r.id === roomId);
    if (!room) return { success: false, message: 'Room not found' };

    if (room.host.id === speakerId) {
      return { success: false, message: 'The room host cannot be removed from stage.' };
    }

    const speakerIndex = room.speakers.findIndex(s => s.id === speakerId);
    if (speakerIndex === -1) return { success: false, message: 'Speaker not found on stage' };

    const [demoted] = room.speakers.splice(speakerIndex, 1);
    room.listeners.push({
      id: demoted.id,
      name: demoted.name,
      handle: demoted.handle,
      avatar: demoted.avatar,
      raisedHand: false,
    });
    room.listenerCount += 1;

    this.save();
    this.notify();
    return { success: true, message: `${demoted.name} moved back to audience.` };
  }

  public simulateListenerRequest(roomId: string): { success: boolean; message: string } {
    const room = this.rooms.find(r => r.id === roomId);
    if (!room) return { success: false, message: 'Room not found' };

    if (!room.speakerRequests) room.speakerRequests = [];

    // Check if there is an unrequested listener
    const candidate = room.listeners.find(l => !l.raisedHand && !room.speakerRequests!.some(r => r.userId === l.id));
    if (candidate) {
      candidate.raisedHand = true;
      room.speakerRequests.push({
        id: `req_${candidate.id}_${Date.now()}`,
        userId: candidate.id,
        userName: candidate.name,
        userHandle: candidate.handle,
        userAvatar: candidate.avatar,
        requestedAt: 'Just now',
        status: 'pending'
      });
      this.save();
      this.notify();
      return { success: true, message: `${candidate.name} requested to speak!` };
    }

    // If no candidate, add a new listener request
    const dummyNames = ['Camila Ramos', 'Jackson Reed', 'Nadia Nour', 'Tyler Scott'];
    const pick = dummyNames[Math.floor(Math.random() * dummyNames.length)];
    const dummyId = `lis_sim_${Date.now()}`;
    const newLis: Listener = {
      id: dummyId,
      name: pick,
      handle: `@${pick.toLowerCase().replace(/\s+/g, '_')}`,
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=200&auto=format&fit=crop&q=80',
      raisedHand: true,
    };
    room.listeners.push(newLis);
    room.listenerCount += 1;
    room.speakerRequests.push({
      id: `req_${dummyId}`,
      userId: dummyId,
      userName: newLis.name,
      userHandle: newLis.handle,
      userAvatar: newLis.avatar,
      requestedAt: 'Just now',
      status: 'pending'
    });
    this.save();
    this.notify();
    return { success: true, message: `${pick} joined and requested to speak!` };
  }

  public inviteToStage(speakerUser: User) {
    if (!this.activeRoomId) return;
    const room = this.rooms.find(r => r.id === this.activeRoomId);
    if (!room) return;

    room.listeners = room.listeners.filter(l => l.id !== speakerUser.id);
    const existing = room.speakers.find(s => s.id === speakerUser.id);
    if (!existing) {
      room.speakers.push({
        id: speakerUser.id,
        name: speakerUser.name,
        handle: speakerUser.handle,
        avatar: speakerUser.avatar,
        isHost: false,
        isModerator: false,
        isMuted: true,
        isSpeaking: false,
      });
    }
    this.hasRaisedHand = false;
    this.save();
    this.notify();
  }

  public sendReaction(emoji: string, senderName: string) {
    const reaction: ReactionParticle = {
      id: `rx_${Date.now()}_${Math.random()}`,
      emoji,
      x: 20 + Math.random() * 60, // random percentage across width
      senderName,
    };
    this.reactionListeners.forEach(cb => cb(reaction));
  }

  public getUserActiveRoom(userId: string): VoiceRoom | null {
    const u = userId === 'usr_guest' ? 'usr_me' : userId;
    return this.rooms.find(r => {
      if (!r.isLive) return false;
      const hostId = r.host.id === 'usr_guest' ? 'usr_me' : r.host.id;
      if (hostId === u) return true;
      return r.speakers.some(s => (s.id === 'usr_guest' ? 'usr_me' : s.id) === u);
    }) || null;
  }

  public createRoom(title: string, topic: string, clubName: string, hostUser: User): VoiceRoom {
    // One ID = One Room Board:
    // A single user ID can only have one active Room Board at a time.
    // If user already has an active room, return them to their existing room board.
    const hostId = hostUser.id === 'usr_guest' ? 'usr_me' : hostUser.id;
    const existingActiveRoom = this.rooms.find(r => {
      const rHost = r.host.id === 'usr_guest' ? 'usr_me' : r.host.id;
      return rHost === hostId && r.isLive;
    });

    if (existingActiveRoom) {
      this.activeRoomId = existingActiveRoom.id;
      this.isMuted = false;
      this.isSpeaking = true;
      this.save();
      this.notify();
      return existingActiveRoom;
    }

    const newRoom: VoiceRoom = {
      id: `room_${Date.now()}`,
      title,
      clubName: clubName || 'Open Stage',
      topic: topic || 'General Chat',
      description: 'Live voice room created in SNYVO.',
      host: hostUser,
      speakers: [
        {
          id: hostUser.id,
          name: hostUser.name,
          handle: hostUser.handle,
          avatar: hostUser.avatar,
          isHost: true,
          isModerator: true,
          isMuted: false,
          isSpeaking: true,
          seatIndex: 0,
        }
      ],
      listeners: [],
      listenerCount: 1,
      isLive: true,
      startedAt: 'Just now',
      tags: [topic.split(' ')[0] || 'Social', 'LiveVoice'],
      maxSeats: 8,
      roomCoins: 0,
      speakerRequests: []
    };

    this.rooms.unshift(newRoom);
    this.activeRoomId = newRoom.id;
    this.isMuted = false;
    this.isSpeaking = true;
    this.save();
    this.notify();
    return newRoom;
  }

  public addRoomCoins(roomId: string, amount: number) {
    const room = this.rooms.find(r => r.id === roomId);
    if (room) {
      room.roomCoins = (room.roomCoins || 0) + amount;
      this.save();
      this.notify();
    }
  }

  private save() {
    try {
      localStorage.setItem('snyvo_rooms', JSON.stringify(this.rooms));
    } catch (e) {
      // storage full or disabled
    }
  }

  private notify() {
    this.listeners.forEach(cb => cb());
  }
}

export const roomService = new RoomService();
