import { LevelBadge, LevelUpEvent } from '../types';

/**
 * SNYVO ID Level / Sending Level / Receiving Level System
 *
 * Core Principles:
 * 1. Default for newly registered user:
 *    - Sending Level: 1
 *    - Receiving Level: 1
 *    - Total Coins Sent: 0
 *    - Total Coins Received: 0
 * 2. Sequential order: 1 -> 2 -> 3 -> ... -> 180 -> 181 -> 182 -> ... -> 500 -> 1000 -> 5000+
 *    - NO FIXED MAXIMUM LEVEL.
 *    - Level 180 is a key milestone, NOT the cap.
 * 3. Exact milestones:
 *    - 300,000 coins -> Level 3
 *    - 50,000,000 coins -> Level 10
 *    - 3,000,000,000 coins -> Level 180
 * 4. Sending Level calculated ONLY from lifetime coins sent.
 * 5. Receiving Level calculated ONLY from lifetime coins received.
 * 6. Cumulative lifetime calculation persisted across logout/reinstall/cache clear.
 */

export interface UserLevelStats {
  userId: string;
  totalCoinsSent: number;
  totalCoinsReceived: number;
  sendingLevel: number;
  receivingLevel: number;
}

const STORAGE_KEY_LEVEL_STATS = 'snyvo_level_stats_v2';

// Pre-computed thresholds for Levels 1 to 180 ensuring exact milestones:
// Level 1: 0
// Level 3: 300,000
// Level 10: 50,000,000
// Level 180: 3,000,000,000
const LEVEL_THRESHOLDS_UP_TO_180: number[] = new Array(181);

function initializeThresholds() {
  LEVEL_THRESHOLDS_UP_TO_180[0] = 0;
  LEVEL_THRESHOLDS_UP_TO_180[1] = 0;
  LEVEL_THRESHOLDS_UP_TO_180[2] = 100_000;
  LEVEL_THRESHOLDS_UP_TO_180[3] = 300_000; // EXACT MILESTONE 1
  LEVEL_THRESHOLDS_UP_TO_180[4] = 1_200_000;
  LEVEL_THRESHOLDS_UP_TO_180[5] = 3_500_000;
  LEVEL_THRESHOLDS_UP_TO_180[6] = 8_000_000;
  LEVEL_THRESHOLDS_UP_TO_180[7] = 15_000_000;
  LEVEL_THRESHOLDS_UP_TO_180[8] = 24_000_000;
  LEVEL_THRESHOLDS_UP_TO_180[9] = 36_000_000;
  LEVEL_THRESHOLDS_UP_TO_180[10] = 50_000_000; // EXACT MILESTONE 2

  // Smooth monotonic curve for Levels 11 through 180
  // t in [0, 1] as level progresses from 10 to 180
  const startCoins = 50_000_000;
  const targetCoins = 3_000_000_000; // EXACT MILESTONE 3
  const deltaCoins = targetCoins - startCoins; // 2,950,000,000

  for (let lvl = 11; lvl <= 180; lvl++) {
    const t = (lvl - 10) / 170;
    // Power curve ensuring strictly positive slope and smooth step sizes
    const fraction = 0.35 * t + 0.65 * Math.pow(t, 1.3);
    const coins = Math.round(startCoins + deltaCoins * fraction);
    LEVEL_THRESHOLDS_UP_TO_180[lvl] = coins;
  }

  // Ensure exact milestone at 180
  LEVEL_THRESHOLDS_UP_TO_180[180] = 3_000_000_000;
}

initializeThresholds();

// Coin step per level beyond 180
const STEP_BEYOND_180 = 21_000_000;

class LevelService {
  private statsCache: Record<string, UserLevelStats> = {};
  private levelUpSubscribers: ((event: LevelUpEvent) => void)[] = [];

  constructor() {
    this.loadStats();
  }

  private loadStats() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY_LEVEL_STATS);
      if (raw) {
        this.statsCache = JSON.parse(raw);
      }
    } catch (e) {
      this.statsCache = {};
    }
  }

  private saveStats() {
    try {
      localStorage.setItem(STORAGE_KEY_LEVEL_STATS, JSON.stringify(this.statsCache));
    } catch (e) {
      console.error('Failed to save level stats', e);
    }
  }

  /**
   * Calculates Level from cumulative lifetime coins.
   * Scalable Threshold Engine with NO upper limit.
   */
  public getLevelFromCoins(coins: number): number {
    if (!coins || coins <= 0) return 1;

    // Check beyond Level 180
    if (coins >= 3_000_000_000) {
      const extra = coins - 3_000_000_000;
      const additionalLevels = Math.floor(extra / STEP_BEYOND_180);
      return 180 + additionalLevels;
    }

    // Binary search in precomputed thresholds for 1..180
    let low = 1;
    let high = 180;
    let result = 1;

    while (low <= high) {
      const mid = Math.floor((low + high) / 2);
      if (LEVEL_THRESHOLDS_UP_TO_180[mid] <= coins) {
        result = mid;
        low = mid + 1;
      } else {
        high = mid - 1;
      }
    }

    return result;
  }

  /**
   * Returns minimum coins required to attain a specific level.
   * Continuous and scalable to any level (Level 181, 200, 500, 1000, 5000+).
   */
  public getCoinThresholdForLevel(level: number): number {
    if (level <= 1) return 0;
    if (level <= 180) {
      return LEVEL_THRESHOLDS_UP_TO_180[level];
    }
    return 3_000_000_000 + (level - 180) * STEP_BEYOND_180;
  }

  /**
   * Detailed progression metrics for UI progress bars
   */
  public getProgressToNextLevel(coins: number): {
    currentLevel: number;
    nextLevel: number;
    currentLevelMinCoins: number;
    nextLevelCoins: number;
    progressPercent: number;
    coinsNeeded: number;
  } {
    const currentLevel = this.getLevelFromCoins(coins);
    const nextLevel = currentLevel + 1;
    const currentLevelMinCoins = this.getCoinThresholdForLevel(currentLevel);
    const nextLevelCoins = this.getCoinThresholdForLevel(nextLevel);

    const range = nextLevelCoins - currentLevelMinCoins;
    const achieved = Math.max(0, coins - currentLevelMinCoins);
    const progressPercent = Math.min(100, Math.max(0, Math.round((achieved / range) * 100)));
    const coinsNeeded = Math.max(0, nextLevelCoins - coins);

    return {
      currentLevel,
      nextLevel,
      currentLevelMinCoins,
      nextLevelCoins,
      progressPercent,
      coinsNeeded,
    };
  }

  /**
   * Fetches user's lifetime stats or initializes defaults for a new user:
   * Sending Level: 1, Receiving Level: 1, Total Coins Sent: 0, Total Coins Received: 0
   */
  public getUserLevelStats(userId: string): UserLevelStats {
    const key = userId === 'usr_guest' ? 'usr_me' : userId;
    if (!this.statsCache[key]) {
      // Initialize default
      const defaultStats: UserLevelStats = {
        userId: key,
        totalCoinsSent: 0,
        totalCoinsReceived: 0,
        sendingLevel: 1,
        receivingLevel: 1,
      };
      this.statsCache[key] = defaultStats;
      this.saveStats();
    }
    return this.statsCache[key];
  }

  /**
   * Secure Server-Authoritative Transaction Recording:
   * Only called on confirmed, successful transactions.
   * Updates cumulative totals and triggers real-time level recalculations.
   */
  public recordTransaction(
    senderId: string,
    receiverId: string,
    coinsAmount: number,
    senderName = 'Alex Vance',
    receiverName = 'Recipient',
    senderAvatar = 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150',
    receiverAvatar = 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150'
  ): {
    senderLeveledUp: boolean;
    receiverLeveledUp: boolean;
    senderOldLevel: number;
    senderNewLevel: number;
    receiverOldLevel: number;
    receiverNewLevel: number;
  } {
    if (coinsAmount <= 0) {
      return {
        senderLeveledUp: false,
        receiverLeveledUp: false,
        senderOldLevel: 1,
        senderNewLevel: 1,
        receiverOldLevel: 1,
        receiverNewLevel: 1,
      };
    }

    const sKey = senderId === 'usr_guest' ? 'usr_me' : senderId;
    const rKey = receiverId === 'usr_guest' ? 'usr_me' : receiverId;

    const senderStats = this.getUserLevelStats(sKey);
    const receiverStats = this.getUserLevelStats(rKey);

    const senderOldLevel = senderStats.sendingLevel;
    const receiverOldLevel = receiverStats.receivingLevel;

    // 1. Update cumulative totals
    senderStats.totalCoinsSent += coinsAmount;
    receiverStats.totalCoinsReceived += coinsAmount;

    // 2. Recalculate levels strictly sequentially
    senderStats.sendingLevel = this.getLevelFromCoins(senderStats.totalCoinsSent);
    receiverStats.receivingLevel = this.getLevelFromCoins(receiverStats.totalCoinsReceived);

    this.statsCache[sKey] = senderStats;
    this.statsCache[rKey] = receiverStats;
    this.saveStats();

    const senderLeveledUp = senderStats.sendingLevel > senderOldLevel;
    const receiverLeveledUp = receiverStats.receivingLevel > receiverOldLevel;

    // 3. Emit level up events
    if (senderLeveledUp) {
      const badge = this.getBadgeForLevel(senderStats.sendingLevel, 'sending');
      this.notifyLevelUp({
        userId: sKey,
        userName: senderName,
        userAvatar: senderAvatar,
        type: 'sending',
        oldLevel: senderOldLevel,
        newLevel: senderStats.sendingLevel,
        totalCoins: senderStats.totalCoinsSent,
        badge,
      });
    }

    if (receiverLeveledUp) {
      const badge = this.getBadgeForLevel(receiverStats.receivingLevel, 'receiving');
      this.notifyLevelUp({
        userId: rKey,
        userName: receiverName,
        userAvatar: receiverAvatar,
        type: 'receiving',
        oldLevel: receiverOldLevel,
        newLevel: receiverStats.receivingLevel,
        totalCoins: receiverStats.totalCoinsReceived,
        badge,
      });
    }

    return {
      senderLeveledUp,
      receiverLeveledUp,
      senderOldLevel,
      senderNewLevel: senderStats.sendingLevel,
      receiverOldLevel,
      receiverNewLevel: receiverStats.receivingLevel,
    };
  }

  /**
   * For Testing & Milestone Simulation in Dev/QA:
   * Sets user's lifetime sent or received coins to verify exact milestones (300K, 50M, 3B, 3.021B).
   */
  public setCoinsForTesting(
    userId: string,
    type: 'sending' | 'receiving',
    coins: number
  ): UserLevelStats {
    const key = userId === 'usr_guest' ? 'usr_me' : userId;
    const stats = this.getUserLevelStats(key);

    const oldLevel = type === 'sending' ? stats.sendingLevel : stats.receivingLevel;

    if (type === 'sending') {
      stats.totalCoinsSent = coins;
      stats.sendingLevel = this.getLevelFromCoins(coins);
    } else {
      stats.totalCoinsReceived = coins;
      stats.receivingLevel = this.getLevelFromCoins(coins);
    }

    this.statsCache[key] = stats;
    this.saveStats();

    const newLevel = type === 'sending' ? stats.sendingLevel : stats.receivingLevel;
    if (newLevel > oldLevel) {
      const badge = this.getBadgeForLevel(newLevel, type);
      this.notifyLevelUp({
        userId: key,
        userName: 'Alex Vance',
        userAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150',
        type,
        oldLevel,
        newLevel,
        totalCoins: coins,
        badge,
      });
    }

    return stats;
  }

  /**
   * Reset stats to New User defaults for testing
   */
  public resetToDefault(userId: string): UserLevelStats {
    const key = userId === 'usr_guest' ? 'usr_me' : userId;
    const resetStats: UserLevelStats = {
      userId: key,
      totalCoinsSent: 0,
      totalCoinsReceived: 0,
      sendingLevel: 1,
      receivingLevel: 1,
    };
    this.statsCache[key] = resetStats;
    this.saveStats();
    return resetStats;
  }

  /**
   * Scalable Level Badge Engine:
   * Produces rich visual badges for ANY level from 1 to 5000+!
   */
  public getBadgeForLevel(level: number, type: 'sending' | 'receiving'): LevelBadge {
    if (type === 'sending') {
      // SENDING BADGE TIERS
      if (level < 10) {
        return {
          level,
          type,
          tierName: 'Bronze Flare',
          gradient: 'from-amber-600 via-orange-600 to-amber-700',
          badgeBg: 'bg-amber-950/80',
          textColor: 'text-amber-300',
          borderColor: 'border-amber-500/60',
          icon: '🔥',
          glowColor: 'shadow-amber-500/20',
        };
      } else if (level < 30) {
        return {
          level,
          type,
          tierName: 'Silver Blaze',
          gradient: 'from-slate-400 via-cyan-500 to-indigo-600',
          badgeBg: 'bg-cyan-950/80',
          textColor: 'text-cyan-300',
          borderColor: 'border-cyan-400/60',
          icon: '⚡',
          glowColor: 'shadow-cyan-500/20',
        };
      } else if (level < 60) {
        return {
          level,
          type,
          tierName: 'Gold Vanguard',
          gradient: 'from-yellow-400 via-amber-500 to-orange-600',
          badgeBg: 'bg-amber-950/90',
          textColor: 'text-yellow-300',
          borderColor: 'border-yellow-400/80',
          icon: '🚀',
          glowColor: 'shadow-yellow-500/30',
        };
      } else if (level < 100) {
        return {
          level,
          type,
          tierName: 'Platinum Phoenix',
          gradient: 'from-emerald-400 via-teal-500 to-cyan-600',
          badgeBg: 'bg-teal-950/90',
          textColor: 'text-emerald-300',
          borderColor: 'border-emerald-400/80',
          icon: '🦅',
          glowColor: 'shadow-teal-500/30',
        };
      } else if (level < 150) {
        return {
          level,
          type,
          tierName: 'Diamond Comet',
          gradient: 'from-blue-400 via-indigo-500 to-violet-600',
          badgeBg: 'bg-blue-950/90',
          textColor: 'text-blue-200',
          borderColor: 'border-blue-400/90',
          icon: '☄️',
          glowColor: 'shadow-blue-500/40',
        };
      } else if (level < 180) {
        return {
          level,
          type,
          tierName: 'Solar Master',
          gradient: 'from-fuchsia-500 via-purple-600 to-rose-600',
          badgeBg: 'bg-purple-950/90',
          textColor: 'text-fuchsia-200',
          borderColor: 'border-fuchsia-400/90',
          icon: '☀️',
          glowColor: 'shadow-fuchsia-500/40',
        };
      } else if (level < 200) {
        // MILESTONE 180 to 199: Sun Emperor
        return {
          level,
          type,
          tierName: 'Sun Emperor (Milestone 180+)',
          gradient: 'from-amber-300 via-rose-500 to-amber-600',
          badgeBg: 'bg-gradient-to-r from-red-950/90 to-amber-950/90',
          textColor: 'text-amber-200',
          borderColor: 'border-amber-300',
          icon: '👑',
          glowColor: 'shadow-amber-500/60',
        };
      } else if (level < 500) {
        return {
          level,
          type,
          tierName: 'Celestial Dragon',
          gradient: 'from-indigo-400 via-purple-500 to-rose-500',
          badgeBg: 'bg-indigo-950/90',
          textColor: 'text-indigo-200',
          borderColor: 'border-indigo-400',
          icon: '🐉',
          glowColor: 'shadow-indigo-500/50',
        };
      } else if (level < 1000) {
        return {
          level,
          type,
          tierName: 'Cosmic Titan',
          gradient: 'from-violet-600 via-fuchsia-700 to-black',
          badgeBg: 'bg-neutral-950',
          textColor: 'text-violet-300',
          borderColor: 'border-violet-400',
          icon: '🌌',
          glowColor: 'shadow-violet-600/60',
        };
      } else {
        // 1000+ Infinite
        return {
          level,
          type,
          tierName: 'Infinity Sovereign',
          gradient: 'from-amber-300 via-teal-300 to-purple-400',
          badgeBg: 'bg-neutral-950',
          textColor: 'text-white',
          borderColor: 'border-yellow-200',
          icon: '♾️',
          glowColor: 'shadow-purple-500/70',
        };
      }
    } else {
      // RECEIVING BADGE TIERS
      if (level < 10) {
        return {
          level,
          type,
          tierName: 'Rose Blossom',
          gradient: 'from-pink-500 via-rose-500 to-pink-600',
          badgeBg: 'bg-pink-950/80',
          textColor: 'text-pink-300',
          borderColor: 'border-pink-500/60',
          icon: '🌸',
          glowColor: 'shadow-pink-500/20',
        };
      } else if (level < 30) {
        return {
          level,
          type,
          tierName: 'Violet Bloom',
          gradient: 'from-purple-500 via-fuchsia-500 to-pink-600',
          badgeBg: 'bg-purple-950/80',
          textColor: 'text-purple-300',
          borderColor: 'border-purple-400/60',
          icon: '💜',
          glowColor: 'shadow-purple-500/20',
        };
      } else if (level < 60) {
        return {
          level,
          type,
          tierName: 'Golden Tiara',
          gradient: 'from-amber-400 via-yellow-500 to-rose-500',
          badgeBg: 'bg-amber-950/90',
          textColor: 'text-amber-200',
          borderColor: 'border-amber-400/80',
          icon: '👑',
          glowColor: 'shadow-amber-500/30',
        };
      } else if (level < 100) {
        return {
          level,
          type,
          tierName: 'Crystal Heart',
          gradient: 'from-cyan-400 via-teal-400 to-blue-500',
          badgeBg: 'bg-cyan-950/90',
          textColor: 'text-cyan-200',
          borderColor: 'border-cyan-400/80',
          icon: '💖',
          glowColor: 'shadow-cyan-500/30',
        };
      } else if (level < 150) {
        return {
          level,
          type,
          tierName: 'Diamond Halo',
          gradient: 'from-sky-300 via-indigo-400 to-purple-500',
          badgeBg: 'bg-blue-950/90',
          textColor: 'text-sky-200',
          borderColor: 'border-sky-300/90',
          icon: '💎',
          glowColor: 'shadow-sky-400/40',
        };
      } else if (level < 180) {
        return {
          level,
          type,
          tierName: 'Royal Empress',
          gradient: 'from-rose-500 via-pink-600 to-purple-700',
          badgeBg: 'bg-rose-950/90',
          textColor: 'text-rose-200',
          borderColor: 'border-rose-400/90',
          icon: '👸',
          glowColor: 'shadow-rose-500/40',
        };
      } else if (level < 200) {
        // MILESTONE 180 to 199: Imperial Sovereign
        return {
          level,
          type,
          tierName: 'Imperial Sovereign (Milestone 180+)',
          gradient: 'from-amber-300 via-rose-600 to-purple-800',
          badgeBg: 'bg-gradient-to-r from-rose-950/90 to-purple-950/90',
          textColor: 'text-amber-200',
          borderColor: 'border-amber-300',
          icon: '✨',
          glowColor: 'shadow-rose-500/60',
        };
      } else if (level < 500) {
        return {
          level,
          type,
          tierName: 'Astral Goddess',
          gradient: 'from-fuchsia-400 via-pink-500 to-cyan-500',
          badgeBg: 'bg-purple-950/90',
          textColor: 'text-fuchsia-200',
          borderColor: 'border-fuchsia-400',
          icon: '🌟',
          glowColor: 'shadow-fuchsia-500/50',
        };
      } else if (level < 1000) {
        return {
          level,
          type,
          tierName: 'Eternal Deity',
          gradient: 'from-purple-600 via-indigo-600 to-black',
          badgeBg: 'bg-neutral-950',
          textColor: 'text-purple-200',
          borderColor: 'border-purple-300',
          icon: '🔮',
          glowColor: 'shadow-purple-600/60',
        };
      } else {
        // 1000+ Infinite
        return {
          level,
          type,
          tierName: 'Mythic Origin',
          gradient: 'from-pink-300 via-yellow-200 to-cyan-300',
          badgeBg: 'bg-neutral-950',
          textColor: 'text-white',
          borderColor: 'border-pink-200',
          icon: '💠',
          glowColor: 'shadow-pink-500/70',
        };
      }
    }
  }

  // Subscriber pattern for Level Up events
  public subscribeLevelUp(callback: (event: LevelUpEvent) => void): () => void {
    this.levelUpSubscribers.push(callback);
    return () => {
      this.levelUpSubscribers = this.levelUpSubscribers.filter((cb) => cb !== callback);
    };
  }

  private notifyLevelUp(event: LevelUpEvent) {
    this.levelUpSubscribers.forEach((cb) => {
      try {
        cb(event);
      } catch (err) {
        console.error('Error notifying level up subscriber', err);
      }
    });
  }
}

export const levelService = new LevelService();
