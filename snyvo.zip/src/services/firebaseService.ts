/**
 * SNYVO Firebase & Real-Time Voice Infrastructure Bridge
 * 
 * This module provides the ready-to-wire service architecture for:
 * 1. Firebase Authentication (Email/Password, Google OAuth, Phone Auth)
 * 2. Cloud Firestore (Voice rooms, presence, clubs, user profiles)
 * 3. Real-Time Audio (WebRTC / Agora / LiveKit voice channels)
 * 
 * In this current v1 preview, it operates seamlessly with local state persistence
 * and mock network latency, providing complete drop-in points when Firebase credentials
 * are configured.
 */

import { User, VoiceRoom } from '../types';
import { currentUser as defaultUser } from '../data/mockData';

export interface FirebaseConfig {
  apiKey: string;
  authDomain: string;
  projectId: string;
  storageBucket: string;
  messagingSenderId: string;
  appId: string;
}

// Check if Firebase is active
export const isFirebaseConfigured = (): boolean => {
  return false; // Toggle to true when .env / config is provided
};

class AuthService {
  private currentUser: User | null = null;
  private listeners: ((user: User | null) => void)[] = [];

  constructor() {
    // Restore from localStorage if available
    const saved = localStorage.getItem('snyvo_user');
    if (saved) {
      try {
        this.currentUser = JSON.parse(saved);
      } catch (e) {
        this.currentUser = defaultUser;
      }
    } else {
      this.currentUser = defaultUser;
    }
  }

  public getCurrentUser(): User | null {
    return this.currentUser;
  }

  public onAuthStateChanged(callback: (user: User | null) => void): () => void {
    this.listeners.push(callback);
    callback(this.currentUser);
    return () => {
      this.listeners = this.listeners.filter(cb => cb !== callback);
    };
  }

  public async signInWithEmail(email: string, pass: string): Promise<User> {
    // Simulated auth delay
    await new Promise(resolve => setTimeout(resolve, 600));
    const user: User = {
      ...defaultUser,
      name: email.split('@')[0].replace('.', ' ') || 'Snyvo Member',
      handle: `@${email.split('@')[0].toLowerCase() || 'user'}`,
    };
    this.currentUser = user;
    localStorage.setItem('snyvo_user', JSON.stringify(user));
    this.notify();
    return user;
  }

  public async signUpWithEmail(name: string, handle: string, email: string, interests: string[]): Promise<User> {
    await new Promise(resolve => setTimeout(resolve, 700));
    const cleanHandle = handle.startsWith('@') ? handle : `@${handle}`;
    const user: User = {
      id: `usr_${Date.now()}`,
      name,
      handle: cleanHandle,
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop&q=80',
      bio: 'New voice in SNYVO club. Exploring ideas and discussions 🎙️',
      followers: 12,
      following: 8,
      roomsHosted: 0,
      clubs: ['Snyvo Early Access'],
      interests: interests.length > 0 ? interests : ['Tech & AI', 'Music & Lo-Fi'],
      isVerified: false,
    };
    this.currentUser = user;
    localStorage.setItem('snyvo_user', JSON.stringify(user));
    this.notify();
    return user;
  }

  public async signInWithGoogle(): Promise<User> {
    await new Promise(resolve => setTimeout(resolve, 500));
    const user: User = { ...defaultUser };
    this.currentUser = user;
    localStorage.setItem('snyvo_user', JSON.stringify(user));
    this.notify();
    return user;
  }

  public async updateProfile(updated: Partial<User>): Promise<User> {
    if (!this.currentUser) throw new Error('Not authenticated');
    this.currentUser = { ...this.currentUser, ...updated };
    localStorage.setItem('snyvo_user', JSON.stringify(this.currentUser));
    this.notify();
    return this.currentUser;
  }

  public async signOut(): Promise<void> {
    this.currentUser = null;
    localStorage.removeItem('snyvo_user');
    this.notify();
  }

  private notify() {
    this.listeners.forEach(cb => cb(this.currentUser));
  }
}

export const authService = new AuthService();
