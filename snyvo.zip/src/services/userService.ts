import { User, ReceivedGift, SentGift, DirectMessage } from '../types';

// Pre-defined unique 8-digit numeric User IDs for clean visual display and copying
export const USER_NUMERIC_IDS: Record<string, string> = {
  'usr_me': '84920194',
  'usr_guest': '84920194',
  'usr_1': '10842915', // Maya Lin
  'usr_2': '39482019', // Kofi Mensah
  'usr_4': '48291038', // Elena Rostova
  'usr_5': '59281044', // Dr. Sarah Thorne
  'usr_6': '72910482', // Kenji Sato
  'usr_7': '29104823', // Priya Sharma
  'usr_8': '61928301', // Oliver King
  'usr_9': '83910247', // Chloe Zhang
  'lis_1': '91827364', // David Chen
  'lis_2': '58291034', // Sophia Williams
  'lis_3': '40192834', // Marcus Bell
  'lis_4': '73910284', // Amara Okafor
  'lis_5': '19283746', // Liam Neeson
  'lis_10': '38291047', // Jordan Rivera
  'lis_11': '67291048', // Zoe Kravitz
  'lis_12': '52910482', // Tariq Al-Mansoor
};

// Deterministic fallback for dynamic user IDs to ensure a clean 8-digit number
export function getNumericUserId(id: string): string {
  if (USER_NUMERIC_IDS[id]) return USER_NUMERIC_IDS[id];
  let hash = 0;
  for (let i = 0; i < id.length; i++) {
    hash = (hash * 31 + id.charCodeAt(i)) % 90000000;
  }
  return String(10000000 + Math.abs(hash));
}

// Initial realistic gift records for seeded profiles with 30% Receiver Credit
const INITIAL_RECEIVED_GIFTS: Record<string, ReceivedGift[]> = {
  'usr_1': [ // Maya Lin
    {
      id: 'gift_rec_1_1',
      giftId: 'g_rose',
      giftName: 'Rose',
      giftIcon: '🎁',
      quantity: 12,
      coinValue: 2400,
      receiverCoins: 720, // 30% of 2,400
      status: 'Completed',
      senderId: 'usr_me',
      senderName: 'Alex Vance',
      senderHandle: '@alexvance',
      senderNumericId: '84920194',
      receiverId: 'usr_1',
      receiverNumericId: '10842915',
      receivedAt: '2 hours ago'
    },
    {
      id: 'gift_rec_1_2',
      giftId: 'g_diamond',
      giftName: 'Diamond',
      giftIcon: '💎',
      quantity: 3,
      coinValue: 15000,
      receiverCoins: 4500, // 30% of 15,000
      status: 'Completed',
      senderId: 'usr_2',
      senderName: 'Kofi Mensah',
      senderHandle: '@kofiaudio',
      senderNumericId: '39482019',
      receiverId: 'usr_1',
      receiverNumericId: '10842915',
      receivedAt: 'Yesterday'
    },
    {
      id: 'gift_rec_1_3',
      giftId: 'g_crown',
      giftName: 'Crown',
      giftIcon: '👑',
      quantity: 2,
      coinValue: 20000,
      receiverCoins: 6000, // 30% of 20,000
      status: 'Completed',
      senderId: 'usr_4',
      senderName: 'Elena Rostova',
      senderHandle: '@elena_r',
      senderNumericId: '48291038',
      receiverId: 'usr_1',
      receiverNumericId: '10842915',
      receivedAt: '3 days ago'
    }
  ],
  'usr_5': [ // Dr. Sarah Thorne
    {
      id: 'gift_rec_5_1',
      giftId: 'g_rocket',
      giftName: 'Rocket',
      giftIcon: '🚀',
      quantity: 5,
      coinValue: 250000,
      receiverCoins: 75000, // 30% of 250,000
      status: 'Completed',
      senderId: 'usr_6',
      senderName: 'Kenji Sato',
      senderHandle: '@kenjisato',
      senderNumericId: '72910482',
      receiverId: 'usr_5',
      receiverNumericId: '59281044',
      receivedAt: '1 day ago'
    },
    {
      id: 'gift_rec_5_2',
      giftId: 'g_diamond',
      giftName: 'Diamond',
      giftIcon: '💎',
      quantity: 8,
      coinValue: 40000,
      receiverCoins: 12000, // 30% of 40,000
      status: 'Completed',
      senderId: 'usr_7',
      senderName: 'Priya Sharma',
      senderHandle: '@priyacodes',
      senderNumericId: '29104823',
      receiverId: 'usr_5',
      receiverNumericId: '59281044',
      receivedAt: '2 days ago'
    },
    {
      id: 'gift_rec_5_3',
      giftId: 'g_rose',
      giftName: 'Rose',
      giftIcon: '🎁',
      quantity: 4,
      coinValue: 800,
      receiverCoins: 240, // 30% of 800
      status: 'Completed',
      senderId: 'lis_11',
      senderName: 'Zoe Kravitz',
      senderHandle: '@zoek',
      senderNumericId: '67291048',
      receiverId: 'usr_5',
      receiverNumericId: '59281044',
      receivedAt: '4 days ago'
    }
  ],
  'usr_8': [ // Oliver King
    {
      id: 'gift_rec_8_1',
      giftId: 'g_coffee',
      giftName: 'Hot Coffee',
      giftIcon: '☕',
      quantity: 6,
      coinValue: 6000,
      receiverCoins: 1800, // 30% of 6,000
      status: 'Completed',
      senderId: 'usr_9',
      senderName: 'Chloe Zhang',
      senderHandle: '@chloezhang',
      senderNumericId: '83910247',
      receiverId: 'usr_8',
      receiverNumericId: '61928301',
      receivedAt: '5 hours ago'
    },
    {
      id: 'gift_rec_8_2',
      giftId: 'g_rocket',
      giftName: 'Rocket',
      giftIcon: '🚀',
      quantity: 2,
      coinValue: 100000,
      receiverCoins: 30000, // 30% of 100,000
      status: 'Completed',
      senderId: 'usr_me',
      senderName: 'Alex Vance',
      senderHandle: '@alexvance',
      senderNumericId: '84920194',
      receiverId: 'usr_8',
      receiverNumericId: '61928301',
      receivedAt: 'Yesterday'
    }
  ],
  'usr_me': [ // Alex Vance (Current user)
    {
      id: 'gift_rec_me_1',
      giftId: 'g_melody',
      giftName: 'Melody Note',
      giftIcon: '🎵',
      quantity: 7,
      coinValue: 3500,
      receiverCoins: 1050, // 30% of 3,500
      status: 'Completed',
      senderId: 'usr_1',
      senderName: 'Maya Lin',
      senderHandle: '@mayalin',
      senderNumericId: '10842915',
      receiverId: 'usr_me',
      receiverNumericId: '84920194',
      receivedAt: 'Yesterday'
    },
    {
      id: 'gift_rec_me_2',
      giftId: 'g_diamond',
      giftName: 'Diamond',
      giftIcon: '💎',
      quantity: 2,
      coinValue: 10000,
      receiverCoins: 3000, // 30% of 10,000
      status: 'Completed',
      senderId: 'usr_5',
      senderName: 'Dr. Sarah Thorne',
      senderHandle: '@sarahthorne',
      senderNumericId: '59281044',
      receiverId: 'usr_me',
      receiverNumericId: '84920194',
      receivedAt: '2 days ago'
    }
  ],
  'usr_guest': [
    {
      id: 'gift_rec_guest_1',
      giftId: 'g_melody',
      giftName: 'Melody Note',
      giftIcon: '🎵',
      quantity: 7,
      coinValue: 3500,
      receiverCoins: 1050, // 30% of 3,500
      status: 'Completed',
      senderId: 'usr_1',
      senderName: 'Maya Lin',
      senderHandle: '@mayalin',
      senderNumericId: '10842915',
      receiverId: 'usr_guest',
      receiverNumericId: '84920194',
      receivedAt: 'Yesterday'
    }
  ]
};

// Initial realistic sent gifts (Only viewable by profile owner!)
const INITIAL_SENT_GIFTS: Record<string, SentGift[]> = {
  'usr_me': [
    {
      id: 'gift_sent_me_1',
      giftId: 'g_rose',
      giftName: 'Rose',
      giftIcon: '🎁',
      quantity: 12,
      coinValue: 2400,
      receiverCoins: 720,
      status: 'Completed',
      recipientId: 'usr_1',
      recipientName: 'Maya Lin',
      recipientHandle: '@mayalin',
      recipientNumericId: '10842915',
      sentAt: '2 hours ago'
    },
    {
      id: 'gift_sent_me_2',
      giftId: 'g_rocket',
      giftName: 'Rocket',
      giftIcon: '🚀',
      quantity: 2,
      coinValue: 100000,
      receiverCoins: 30000,
      status: 'Completed',
      recipientId: 'usr_8',
      recipientName: 'Oliver King',
      recipientHandle: '@oliverbuilds',
      recipientNumericId: '61928301',
      sentAt: 'Yesterday'
    }
  ],
  'usr_guest': [
    {
      id: 'gift_sent_guest_1',
      giftId: 'g_rose',
      giftName: 'Rose',
      giftIcon: '🎁',
      quantity: 12,
      coinValue: 2400,
      receiverCoins: 720,
      status: 'Completed',
      recipientId: 'usr_1',
      recipientName: 'Maya Lin',
      recipientHandle: '@mayalin',
      recipientNumericId: '10842915',
      sentAt: '2 hours ago'
    }
  ]
};

// Initial messages between Alex and Maya Lin
const INITIAL_DIRECT_MESSAGES: DirectMessage[] = [
  {
    id: 'dm_1',
    senderId: 'usr_1',
    recipientId: 'usr_me',
    text: 'Hey Alex! Loved your voice room yesterday on ambient audio 🎙️✨',
    timestamp: 'Yesterday 10:14 PM',
    delivered: true,
    seen: true
  },
  {
    id: 'dm_2',
    senderId: 'usr_me',
    recipientId: 'usr_1',
    text: 'Thanks Maya! The lo-fi stream in your room right now is pure vibe.',
    timestamp: 'Yesterday 10:22 PM',
    delivered: true,
    seen: true
  }
];

class UserService {
  private follows: Set<string> = new Set();
  private receivedGifts: Record<string, ReceivedGift[]> = {};
  private sentGifts: Record<string, SentGift[]> = {};
  private directMessages: DirectMessage[] = [];
  private subscribers: (() => void)[] = [];

  constructor() {
    this.loadState();
  }

  private loadState() {
    // Follows
    const savedFollows = localStorage.getItem('snyvo_user_follows');
    if (savedFollows) {
      try {
        const arr: string[] = JSON.parse(savedFollows);
        this.follows = new Set(arr);
      } catch (e) {
        this.follows = new Set(['usr_1']); // default follow Maya Lin
      }
    } else {
      this.follows = new Set(['usr_1']); // default follow Maya Lin
      this.saveFollows();
    }

    // Received Gifts
    const savedReceivedGifts = localStorage.getItem('snyvo_received_gifts');
    if (savedReceivedGifts) {
      try {
        this.receivedGifts = JSON.parse(savedReceivedGifts);
      } catch (e) {
        this.receivedGifts = { ...INITIAL_RECEIVED_GIFTS };
      }
    } else {
      this.receivedGifts = { ...INITIAL_RECEIVED_GIFTS };
      this.saveReceivedGifts();
    }

    // Sent Gifts
    const savedSentGifts = localStorage.getItem('snyvo_sent_gifts');
    if (savedSentGifts) {
      try {
        this.sentGifts = JSON.parse(savedSentGifts);
      } catch (e) {
        this.sentGifts = { ...INITIAL_SENT_GIFTS };
      }
    } else {
      this.sentGifts = { ...INITIAL_SENT_GIFTS };
      this.saveSentGifts();
    }

    // Direct Messages
    const savedDMs = localStorage.getItem('snyvo_direct_messages');
    if (savedDMs) {
      try {
        this.directMessages = JSON.parse(savedDMs);
      } catch (e) {
        this.directMessages = [...INITIAL_DIRECT_MESSAGES];
      }
    } else {
      this.directMessages = [...INITIAL_DIRECT_MESSAGES];
      this.saveDirectMessages();
    }
  }

  private saveFollows() {
    try {
      localStorage.setItem('snyvo_user_follows', JSON.stringify(Array.from(this.follows)));
    } catch (e) {
      // ignore
    }
  }

  private saveReceivedGifts() {
    try {
      localStorage.setItem('snyvo_received_gifts', JSON.stringify(this.receivedGifts));
    } catch (e) {
      // ignore
    }
  }

  private saveSentGifts() {
    try {
      localStorage.setItem('snyvo_sent_gifts', JSON.stringify(this.sentGifts));
    } catch (e) {
      // ignore
    }
  }

  private saveDirectMessages() {
    try {
      localStorage.setItem('snyvo_direct_messages', JSON.stringify(this.directMessages));
    } catch (e) {
      // ignore
    }
  }

  public subscribe(cb: () => void): () => void {
    this.subscribers.push(cb);
    return () => {
      this.subscribers = this.subscribers.filter(s => s !== cb);
    };
  }

  private notify() {
    this.subscribers.forEach(cb => cb());
  }

  // --- Follow System ---
  public isFollowing(targetUserId: string): boolean {
    return this.follows.has(targetUserId);
  }

  public followUser(targetUserId: string): boolean {
    if (!targetUserId) return false;
    if (this.follows.has(targetUserId)) return false; // avoid duplicate
    this.follows.add(targetUserId);
    this.saveFollows();
    this.notify();
    return true;
  }

  public unfollowUser(targetUserId: string): boolean {
    if (!targetUserId) return false;
    const removed = this.follows.delete(targetUserId);
    if (removed) {
      this.saveFollows();
      this.notify();
    }
    return removed;
  }

  public getFollowersCount(targetUser: User): number {
    const baseCount = targetUser.followers || 0;
    // If the current user follows them and was not already counted in base
    // we determine offset consistently
    const following = this.isFollowing(targetUser.id);
    const initiallyFollowed = targetUser.id === 'usr_1';
    if (following && !initiallyFollowed) {
      return baseCount + 1;
    } else if (!following && initiallyFollowed) {
      return Math.max(0, baseCount - 1);
    }
    return baseCount;
  }

  // --- Gifts Received ---
  public getReceivedGifts(userId: string): ReceivedGift[] {
    return this.receivedGifts[userId] || [];
  }

  public getTotalReceivedGiftsCount(userId: string): number {
    const gifts = this.getReceivedGifts(userId);
    return gifts.reduce((total, item) => total + item.quantity, 0);
  }

  // --- Sent Gifts (Owner Privacy Protected) ---
  public getSentGifts(userId: string, requestingUserId: string): SentGift[] {
    // Strict privacy rule #7: Only profile owner can view their sent gifts history
    const isOwner = requestingUserId === userId || (
      (requestingUserId === 'usr_me' || requestingUserId === 'usr_guest') &&
      (userId === 'usr_me' || userId === 'usr_guest')
    );
    if (!isOwner) {
      return [];
    }
    return this.sentGifts[userId] || this.sentGifts['usr_me'] || [];
  }

  /**
   * Records an authentic gift transaction into both recipient's Received list
   * and sender's Sent list, preserving privacy and full transaction data.
   */
  public recordGiftTransaction(data: {
    giftId: string;
    giftName: string;
    giftIcon: string;
    quantity: number;
    totalCoins?: number;
    receiverCoins?: number;
    senderId: string;
    senderName: string;
    senderHandle: string;
    senderAvatar?: string;
    senderNumericId: string;
    recipientId: string;
    recipientName: string;
    recipientHandle: string;
    recipientAvatar?: string;
    recipientNumericId: string;
  }) {
    const sId = data.senderId === 'usr_guest' ? 'usr_me' : data.senderId;
    const rId = data.recipientId === 'usr_guest' ? 'usr_me' : data.recipientId;

    const totalCoins = data.totalCoins || (data.quantity * 500);
    const receiverCoins = data.receiverCoins !== undefined ? data.receiverCoins : Math.floor((totalCoins * 30) / 100);
    const nowIso = new Date().toISOString();

    if (!this.receivedGifts[rId]) {
      this.receivedGifts[rId] = [];
    }
    this.receivedGifts[rId].unshift({
      id: `gift_rec_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      giftId: data.giftId,
      giftName: data.giftName,
      giftIcon: data.giftIcon,
      quantity: data.quantity,
      coinValue: totalCoins,
      receiverCoins: receiverCoins,
      status: 'Completed',
      senderId: sId,
      senderName: data.senderName,
      senderHandle: data.senderHandle,
      senderAvatar: data.senderAvatar,
      senderNumericId: data.senderNumericId,
      receiverId: rId,
      receiverNumericId: data.recipientNumericId,
      receivedAt: 'Just now',
      isoDate: nowIso,
    });
    this.saveReceivedGifts();

    if (!this.sentGifts[sId]) {
      this.sentGifts[sId] = [];
    }
    this.sentGifts[sId].unshift({
      id: `gift_sent_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      giftId: data.giftId,
      giftName: data.giftName,
      giftIcon: data.giftIcon,
      quantity: data.quantity,
      coinValue: totalCoins,
      receiverCoins: receiverCoins,
      status: 'Completed',
      recipientId: rId,
      recipientName: data.recipientName,
      recipientHandle: data.recipientHandle,
      recipientAvatar: data.recipientAvatar,
      recipientNumericId: data.recipientNumericId,
      sentAt: 'Just now',
      isoDate: nowIso,
    });
    this.saveSentGifts();

    this.notify();
  }

  // --- Direct Messaging System ---
  public getConversation(userId1: string, userId2: string): DirectMessage[] {
    const u1 = userId1 === 'usr_guest' ? 'usr_me' : userId1;
    const u2 = userId2 === 'usr_guest' ? 'usr_me' : userId2;

    return this.directMessages.filter(msg => {
      const s = msg.senderId === 'usr_guest' ? 'usr_me' : msg.senderId;
      const r = msg.recipientId === 'usr_guest' ? 'usr_me' : msg.recipientId;
      return (s === u1 && r === u2) || (s === u2 && r === u1);
    });
  }

  public sendMessage(senderId: string, recipientId: string, text: string): DirectMessage {
    const newMsg: DirectMessage = {
      id: `dm_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
      senderId,
      recipientId,
      text: text.trim(),
      timestamp: 'Just now',
      delivered: true,
      seen: false
    };

    this.directMessages.push(newMsg);
    this.saveDirectMessages();
    this.notify();
    return newMsg;
  }
}

export const userService = new UserService();
