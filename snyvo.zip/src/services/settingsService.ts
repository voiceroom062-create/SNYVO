/**
 * SNYVO Settings Service
 * Handles user-specific isolated preferences, security linking (Phone, Facebook, Google),
 * 30-day account deletion schedule & cancellation, dynamic cache metrics, and notifications.
 */

export interface BlockedUser {
  id: string;
  name: string;
  handle: string;
  avatar: string;
  numericId: string;
  blockedAt: number;
}

export interface UserSettings {
  phoneNumber: string | null;
  phoneVerified: boolean;
  facebookConnected: boolean;
  facebookAccountName: string | null;
  googleConnected: boolean;
  googleAccountEmail: string | null;
  deletionScheduledAt: number | null; // epoch timestamp in ms
  giftBannerEnabled: boolean;
  messageNotifications: {
    directMessages: boolean;
    roomInvites: boolean;
    soundEnabled: boolean;
    vibrationEnabled: boolean;
    dndMode: boolean;
  };
  blockedUsers: BlockedUser[];
  cacheCleared: boolean;
  appVersion: string;
}

const DEFAULT_BLOCKED_USERS: BlockedUser[] = [
  {
    id: 'blk_1',
    name: 'Tariq SoundBot',
    handle: '@tariq_mic',
    avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
    numericId: '98402811',
    blockedAt: Date.now() - 86400000 * 3,
  },
  {
    id: 'blk_2',
    name: 'Echo Audio Bot',
    handle: '@echomicro',
    avatar: 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?w=150&auto=format&fit=crop&q=80',
    numericId: '47291083',
    blockedAt: Date.now() - 86400000 * 7,
  },
];

export const APP_VERSION = 'v2.4.1 (Build 2026.09)';

export const settingsService = {
  getStorageKey(userId: string): string {
    return `snyvo_settings_${userId}`;
  },

  getUserSettings(userId: string): UserSettings {
    try {
      const raw = localStorage.getItem(this.getStorageKey(userId));
      if (raw) {
        const parsed = JSON.parse(raw);
        return {
          phoneNumber: parsed.phoneNumber ?? null,
          phoneVerified: parsed.phoneVerified ?? false,
          facebookConnected: parsed.facebookConnected ?? false,
          facebookAccountName: parsed.facebookAccountName ?? null,
          googleConnected: parsed.googleConnected ?? true, // default connected as logged in
          googleAccountEmail: parsed.googleAccountEmail ?? 'user@snyvo.me',
          deletionScheduledAt: parsed.deletionScheduledAt ?? null,
          giftBannerEnabled: parsed.giftBannerEnabled ?? true,
          messageNotifications: {
            directMessages: parsed.messageNotifications?.directMessages ?? true,
            roomInvites: parsed.messageNotifications?.roomInvites ?? true,
            soundEnabled: parsed.messageNotifications?.soundEnabled ?? true,
            vibrationEnabled: parsed.messageNotifications?.vibrationEnabled ?? true,
            dndMode: parsed.messageNotifications?.dndMode ?? false,
          },
          blockedUsers: parsed.blockedUsers ?? DEFAULT_BLOCKED_USERS,
          cacheCleared: parsed.cacheCleared ?? false,
          appVersion: APP_VERSION,
        };
      }
    } catch (e) {
      console.error('Failed to load settings for user', userId, e);
    }

    const defaultSettings: UserSettings = {
      phoneNumber: null,
      phoneVerified: false,
      facebookConnected: false,
      facebookAccountName: null,
      googleConnected: true,
      googleAccountEmail: 'user@snyvo.me',
      deletionScheduledAt: null,
      giftBannerEnabled: true,
      messageNotifications: {
        directMessages: true,
        roomInvites: true,
        soundEnabled: true,
        vibrationEnabled: true,
        dndMode: false,
      },
      blockedUsers: DEFAULT_BLOCKED_USERS,
      cacheCleared: false,
      appVersion: APP_VERSION,
    };

    localStorage.setItem(this.getStorageKey(userId), JSON.stringify(defaultSettings));
    return defaultSettings;
  },

  saveUserSettings(userId: string, partial: Partial<UserSettings>): UserSettings {
    const current = this.getUserSettings(userId);
    const updated = {
      ...current,
      ...partial,
      messageNotifications: {
        ...current.messageNotifications,
        ...(partial.messageNotifications || {}),
      },
    };
    try {
      localStorage.setItem(this.getStorageKey(userId), JSON.stringify(updated));
      // Also update independent gift banner flag for instant room synchronization
      if (typeof partial.giftBannerEnabled === 'boolean') {
        localStorage.setItem(`snyvo_gift_banner_${userId}`, String(partial.giftBannerEnabled));
      }
    } catch (e) {
      console.error('Failed to save settings for user', userId, e);
    }
    return updated;
  },

  /**
   * 30-Day Deletion System
   * Calculates remaining days and hours without resetting on refresh.
   */
  getRemainingDeletionTime(deletionScheduledAt: number | null): {
    isScheduled: boolean;
    daysRemaining: number;
    hoursRemaining: number;
    isExpired: boolean;
  } {
    if (!deletionScheduledAt) {
      return { isScheduled: false, daysRemaining: 30, hoursRemaining: 0, isExpired: false };
    }

    const THIRTY_DAYS_MS = 30 * 24 * 60 * 60 * 1000;
    const elapsed = Date.now() - deletionScheduledAt;
    const remainingMs = THIRTY_DAYS_MS - elapsed;

    if (remainingMs <= 0) {
      return { isScheduled: true, daysRemaining: 0, hoursRemaining: 0, isExpired: true };
    }

    const totalHours = Math.floor(remainingMs / (1000 * 60 * 60));
    const daysRemaining = Math.floor(totalHours / 24);
    const hoursRemaining = totalHours % 24;

    return {
      isScheduled: true,
      daysRemaining: Math.max(0, daysRemaining),
      hoursRemaining: Math.max(0, hoursRemaining),
      isExpired: false,
    };
  },

  scheduleAccountDeletion(userId: string): UserSettings {
    const scheduledAt = Date.now();
    return this.saveUserSettings(userId, { deletionScheduledAt: scheduledAt });
  },

  cancelAccountDeletion(userId: string): UserSettings {
    return this.saveUserSettings(userId, { deletionScheduledAt: null });
  },

  linkPhoneNumber(userId: string, phone: string): UserSettings {
    return this.saveUserSettings(userId, {
      phoneNumber: phone,
      phoneVerified: true,
    });
  },

  linkFacebook(userId: string, name: string): UserSettings {
    return this.saveUserSettings(userId, {
      facebookConnected: true,
      facebookAccountName: name,
    });
  },

  disconnectFacebook(userId: string): UserSettings {
    return this.saveUserSettings(userId, {
      facebookConnected: false,
      facebookAccountName: null,
    });
  },

  linkGoogle(userId: string, email: string): UserSettings {
    return this.saveUserSettings(userId, {
      googleConnected: true,
      googleAccountEmail: email,
    });
  },

  disconnectGoogle(userId: string): UserSettings {
    return this.saveUserSettings(userId, {
      googleConnected: false,
      googleAccountEmail: null,
    });
  },

  unblockUser(userId: string, blockedUserId: string): BlockedUser[] {
    const current = this.getUserSettings(userId);
    const updatedList = (current.blockedUsers || []).filter((u) => u.id !== blockedUserId);
    this.saveUserSettings(userId, { blockedUsers: updatedList });
    return updatedList;
  },

  /**
   * Calculates actual and dynamic cache usage
   */
  getCacheSize(userId: string): { formatted: string; rawMB: number } {
    const current = this.getUserSettings(userId);
    if (current.cacheCleared) {
      return { formatted: '0 MB', rawMB: 0 };
    }

    // Dynamic calculation based on user data length + base voice room assets (around 40.6 MB)
    let localStorageBytes = 0;
    try {
      for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        if (key) {
          const val = localStorage.getItem(key) || '';
          localStorageBytes += (key.length + val.length) * 2;
        }
      }
    } catch {
      localStorageBytes = 250000;
    }

    // Combine actual storage with simulated voice audio packet buffer (approx 40.4 MB)
    const baseVoiceCacheMB = 40.4;
    const dynamicMB = baseVoiceCacheMB + Math.round((localStorageBytes / (1024 * 1024)) * 10) / 10;
    const rounded = Math.round(dynamicMB * 10) / 10;

    return {
      formatted: `${rounded} MB`,
      rawMB: rounded,
    };
  },

  clearCache(userId: string): { formatted: string; rawMB: number } {
    // Only clear safe temporary / transient cache items
    try {
      const keysToRemove: string[] = [];
      for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        if (
          key &&
          (key.startsWith('snyvo_temp_') ||
            key.startsWith('snyvo_audio_cache_') ||
            key.startsWith('snyvo_img_cache_'))
        ) {
          keysToRemove.push(key);
        }
      }
      keysToRemove.forEach((k) => localStorage.removeItem(k));
    } catch (e) {
      console.error('Error clearing cache', e);
    }

    this.saveUserSettings(userId, { cacheCleared: true });
    return { formatted: '0 MB', rawMB: 0 };
  },

  saveUserRating(userId: string, stars: number, feedback?: string): void {
    try {
      const ratingData = {
        userId,
        stars,
        feedback: feedback || '',
        timestamp: Date.now(),
      };
      localStorage.setItem(`snyvo_rating_${userId}`, JSON.stringify(ratingData));
    } catch (e) {
      console.error('Failed to save rating', e);
    }
  },

  verifyPassword(userId: string, pass: string): boolean {
    const stored = localStorage.getItem(`snyvo_password_${userId}`);
    // If no password set yet, default to '123456' for demonstration
    if (!stored) {
      return pass === '123456' || pass === 'password';
    }
    return stored === pass;
  },

  changePassword(userId: string, newPass: string): void {
    localStorage.setItem(`snyvo_password_${userId}`, newPass);
  },

  hasCustomPassword(userId: string): boolean {
    return Boolean(localStorage.getItem(`snyvo_password_${userId}`));
  },
};
