// ============================================================================
// SNYVO CHAT SERVICE & REPOSITORY ARCHITECTURE
// ============================================================================
// Real-time backend preparation:
// This service provides a clean repository/service pattern designed to connect
// directly to WebSocket / Server-Sent Events (SSE) / Firebase Firestore.
// 
// In this frontend environment without a live backend connection:
// - Data is persisted locally in-memory and in client storage.
// - Messages are displayed locally.
// - No fake multi-user internet synchronization or fake claims are made.
// ============================================================================

import { User } from '../types';
import {
  ChatRole,
  RoomChatMessage,
  ChatModerationLog,
  DirectConversation,
  DirectChatMessage,
} from '../types/chat';

class ChatService {
  private roomMessages: Map<string, RoomChatMessage[]> = new Map();
  private roomSubscribers: Map<string, Set<() => void>> = new Map();
  private directConversations: DirectConversation[] = [];
  private directMessages: Map<string, DirectChatMessage[]> = new Map();
  private directSubscribers: Set<() => void> = new Set();
  private mutedUsersInRoom: Map<string, Set<string>> = new Map();
  private blockedUsers: Set<string> = new Set();
  private moderationLogs: ChatModerationLog[] = [];

  constructor() {
    this.initDefaultDirectConversations();
  }

  // ==========================================================================
  // ROOM CHAT METHODS
  // ==========================================================================

  /**
   * Get all messages for a specific voice room
   */
  public getRoomMessages(roomId: string, hostUser?: User): RoomChatMessage[] {
    if (!this.roomMessages.has(roomId)) {
      this.initDefaultRoomMessages(roomId, hostUser);
    }
    return this.roomMessages.get(roomId) || [];
  }

  /**
   * Subscribe to new room messages
   */
  public subscribeRoomChat(roomId: string, listener: () => void): () => void {
    if (!this.roomSubscribers.has(roomId)) {
      this.roomSubscribers.set(roomId, new Set());
    }
    const set = this.roomSubscribers.get(roomId)!;
    set.add(listener);

    return () => {
      set.delete(listener);
      if (set.size === 0) {
        this.roomSubscribers.delete(roomId);
      }
    };
  }

  private notifyRoomSubscribers(roomId: string) {
    const set = this.roomSubscribers.get(roomId);
    if (set) {
      set.forEach(cb => cb());
    }
  }

  /**
   * Send a message to a voice room chat
   */
  public async sendRoomMessage(
    roomId: string,
    payload: {
      text: string;
      sender: User;
      role: ChatRole;
    }
  ): Promise<RoomChatMessage> {
    if (!this.roomMessages.has(roomId)) {
      this.initDefaultRoomMessages(roomId);
    }

    const messages = this.roomMessages.get(roomId)!;
    const now = new Date();
    const formattedTime = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    const newMsg: RoomChatMessage = {
      id: `rcmsg_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      roomId,
      senderId: payload.sender.id,
      senderName: payload.sender.name,
      senderHandle: payload.sender.handle,
      senderAvatar: payload.sender.avatar,
      senderRole: payload.role,
      senderLevel: payload.sender.level || 12,
      senderBadge: this.resolveRoleBadge(payload.role),
      text: payload.text.trim(),
      timestamp: Date.now(),
      time: formattedTime,
    };

    messages.push(newMsg);
    this.notifyRoomSubscribers(roomId);
    return newMsg;
  }

  /**
   * Delete a room message (Moderator / Host / Author action)
   */
  public async deleteRoomMessage(roomId: string, messageId: string, actorId: string): Promise<boolean> {
    const messages = this.roomMessages.get(roomId);
    if (!messages) return false;

    const idx = messages.findIndex(m => m.id === messageId);
    if (idx !== -1) {
      messages[idx].isDeleted = true;
      messages[idx].text = '[Message deleted by moderator]';

      this.moderationLogs.push({
        id: `modlog_${Date.now()}`,
        action: 'delete_message',
        actorId,
        actorName: 'Moderator',
        targetUserId: messages[idx].senderId,
        targetUserName: messages[idx].senderName,
        targetMessageId: messageId,
        reason: 'Violation of room etiquette',
        timestamp: Date.now(),
        roomId,
      });

      this.notifyRoomSubscribers(roomId);
      return true;
    }
    return false;
  }

  /**
   * Mute user from sending chat messages in room
   */
  public muteUserInRoom(roomId: string, userId: string, actorName = 'Host'): void {
    if (!this.mutedUsersInRoom.has(roomId)) {
      this.mutedUsersInRoom.set(roomId, new Set());
    }
    this.mutedUsersInRoom.get(roomId)!.add(userId);

    this.moderationLogs.push({
      id: `modlog_${Date.now()}`,
      action: 'mute_user',
      actorId: 'host_mod',
      actorName,
      targetUserId: userId,
      targetUserName: userId,
      reason: 'Muted from room chat',
      timestamp: Date.now(),
      roomId,
    });
  }

  public isUserMutedInRoom(roomId: string, userId: string): boolean {
    const muted = this.mutedUsersInRoom.get(roomId);
    return muted ? muted.has(userId) : false;
  }

  /**
   * Block a user
   */
  public blockUser(userId: string, targetName = 'User'): void {
    this.blockedUsers.add(userId);
    this.moderationLogs.push({
      id: `modlog_${Date.now()}`,
      action: 'block_user',
      actorId: 'me',
      actorName: 'You',
      targetUserId: userId,
      targetUserName: targetName,
      timestamp: Date.now(),
    });
  }

  public isUserBlocked(userId: string): boolean {
    return this.blockedUsers.has(userId);
  }

  /**
   * Report a user
   */
  public reportUser(data: {
    actorId: string;
    actorName: string;
    targetUserId: string;
    targetUserName: string;
    targetMessageId?: string;
    reason: string;
    roomId?: string;
  }): void {
    this.moderationLogs.push({
      id: `modlog_${Date.now()}`,
      action: 'report_user',
      ...data,
      timestamp: Date.now(),
    });
  }

  public getModerationLogs(): ChatModerationLog[] {
    return [...this.moderationLogs];
  }

  private resolveRoleBadge(role: ChatRole) {
    switch (role) {
      case 'host':
        return { name: 'Host', color: 'text-amber-300', bg: 'bg-amber-500/20 border-amber-500/30', icon: '👑' };
      case 'cohost':
        return { name: 'Co-Host', color: 'text-violet-300', bg: 'bg-violet-500/20 border-violet-500/30', icon: '🛡️' };
      case 'moderator':
        return { name: 'Mod', color: 'text-cyan-300', bg: 'bg-cyan-500/20 border-cyan-500/30', icon: '⚡' };
      case 'speaker':
        return { name: 'Speaker', color: 'text-emerald-300', bg: 'bg-emerald-500/20 border-emerald-500/30', icon: '🎤' };
      case 'listener':
      default:
        return { name: 'Member', color: 'text-neutral-400', bg: 'bg-neutral-800 border-neutral-700', icon: '🎧' };
    }
  }

  private initDefaultRoomMessages(roomId: string, hostUser?: User) {
    const hostName = hostUser?.name || 'Maya Lin';
    const hostAvatar = hostUser?.avatar || 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=200&auto=format&fit=crop&q=80';

    const defaultMessages: RoomChatMessage[] = [
      {
        id: `rc_${roomId}_1`,
        roomId,
        senderId: 'usr_host_default',
        senderName: hostName,
        senderHandle: '@host',
        senderAvatar: hostAvatar,
        senderRole: 'host',
        senderLevel: 32,
        senderBadge: { name: 'Host', color: 'text-amber-300', bg: 'bg-amber-500/20 border-amber-500/30', icon: '👑' },
        text: 'Welcome to the stage! Feel free to request a seat or share thoughts here in the room chat. 🎙️✨',
        timestamp: Date.now() - 600000,
        time: '10m ago',
      },
      {
        id: `rc_${roomId}_2`,
        roomId,
        senderId: 'usr_mod_1',
        senderName: 'Dr. Sarah Thorne',
        senderHandle: '@drthorne',
        senderAvatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=200&auto=format&fit=crop&q=80',
        senderRole: 'moderator',
        senderLevel: 25,
        senderBadge: { name: 'Mod', color: 'text-cyan-300', bg: 'bg-cyan-500/20 border-cyan-500/30', icon: '🛡️' },
        text: 'Moderation is active. Keep the conversation respectful and enjoyable for everyone! 🛡️',
        timestamp: Date.now() - 360000,
        time: '6m ago',
      },
      {
        id: `rc_${roomId}_3`,
        roomId,
        senderId: 'usr_speaker_1',
        senderName: 'Marcus Bell',
        senderHandle: '@marcusb',
        senderAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&auto=format&fit=crop&q=80',
        senderRole: 'speaker',
        senderLevel: 18,
        senderBadge: { name: 'Speaker', color: 'text-emerald-300', bg: 'bg-emerald-500/20 border-emerald-500/30', icon: '🎤' },
        text: 'Glad to be on the board today. The sound stage clarity is impressive!',
        timestamp: Date.now() - 180000,
        time: '3m ago',
      },
      {
        id: `rc_${roomId}_4`,
        roomId,
        senderId: 'usr_listener_1',
        senderName: 'Elena Rostova',
        senderHandle: '@elena_r',
        senderAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&auto=format&fit=crop&q=80',
        senderRole: 'listener',
        senderLevel: 14,
        senderBadge: { name: 'Member', color: 'text-neutral-400', bg: 'bg-neutral-800 border-neutral-700', icon: '🎧' },
        text: 'Great topic discussion! 👏🔥 Sending support from Tokyo.',
        timestamp: Date.now() - 30000,
        time: 'Just now',
      }
    ];

    this.roomMessages.set(roomId, defaultMessages);
  }

  // ==========================================================================
  // DIRECT / PRIVATE CHAT CONVERSATION METHODS (Bottom Chat Tab)
  // ==========================================================================

  public getConversations(): DirectConversation[] {
    return [...this.directConversations];
  }

  public getConversationMessages(conversationId: string): DirectChatMessage[] {
    return this.directMessages.get(conversationId) || [];
  }

  public subscribeDirectChat(listener: () => void): () => void {
    this.directSubscribers.add(listener);
    return () => {
      this.directSubscribers.delete(listener);
    };
  }

  private notifyDirectSubscribers() {
    this.directSubscribers.forEach(cb => cb());
  }

  public async sendDirectMessage(
    conversationId: string,
    text: string,
    sender: User
  ): Promise<DirectChatMessage> {
    const list = this.directMessages.get(conversationId) || [];
    const now = new Date();
    const formattedTime = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    const newMsg: DirectChatMessage = {
      id: `dm_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      conversationId,
      senderId: sender.id,
      recipientId: 'recipient',
      text: text.trim(),
      timestamp: Date.now(),
      time: formattedTime,
      status: 'sent',
      isFromMe: true,
    };

    list.push(newMsg);
    this.directMessages.set(conversationId, list);

    // Update conversation metadata
    const conv = this.directConversations.find(c => c.id === conversationId);
    if (conv) {
      conv.lastMessage = {
        text: newMsg.text,
        timestamp: newMsg.timestamp,
        time: 'Just now',
        isFromMe: true,
        unread: false,
      };
      // Move to top
      this.directConversations = [
        conv,
        ...this.directConversations.filter(c => c.id !== conversationId),
      ];
    }

    this.notifyDirectSubscribers();
    return newMsg;
  }

  public markConversationAsRead(conversationId: string): void {
    const conv = this.directConversations.find(c => c.id === conversationId);
    if (conv) {
      conv.unreadCount = 0;
      conv.lastMessage.unread = false;
      this.notifyDirectSubscribers();
    }
  }

  private initDefaultDirectConversations() {
    this.directConversations = [
      {
        id: 'conv_1',
        participant: {
          id: 'usr_maya',
          name: 'Maya Lin',
          handle: '@mayavoice',
          avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=200&auto=format&fit=crop&q=80',
          bio: 'Host of Midnight Thinkers Club 🎙️',
          followers: 3200,
          following: 150,
          roomsHosted: 128,
          clubs: ['Midnight Thinkers', 'Acoustic Jam'],
          interests: ['Music', 'Philosophy'],
          isVerified: true,
          level: 32,
          numericId: '849201',
        },
        lastMessage: {
          text: 'Are you joining the live stage tonight? We reserved Seat #2 for you! 🎤',
          timestamp: Date.now() - 120000,
          time: '2m ago',
          isFromMe: false,
          unread: true,
        },
        unreadCount: 1,
        isPinned: true,
        isFriend: true,
        category: 'friends',
      },
      {
        id: 'conv_2',
        participant: {
          id: 'usr_dr_thorne',
          name: 'Dr. Sarah Thorne',
          handle: '@drthorne',
          avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=200&auto=format&fit=crop&q=80',
          bio: 'AI researcher & Voice Room Moderator 🛡️',
          followers: 4100,
          following: 210,
          roomsHosted: 64,
          clubs: ['Future of AI', 'Deep Tech'],
          interests: ['AI', 'Audio Tech'],
          isVerified: true,
          level: 28,
          numericId: '902144',
        },
        lastMessage: {
          text: 'Thanks for participating in our AI discussion earlier. Great insights on speech synthesis!',
          timestamp: Date.now() - 3600000,
          time: '1h ago',
          isFromMe: false,
          unread: false,
        },
        unreadCount: 0,
        isPinned: false,
        isFriend: true,
        category: 'friends',
      },
      {
        id: 'conv_3',
        participant: {
          id: 'usr_marcus',
          name: 'Marcus Bell',
          handle: '@marcusb',
          avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&auto=format&fit=crop&q=80',
          bio: 'Audio engineer & indie producer 🎧',
          followers: 1800,
          following: 400,
          roomsHosted: 19,
          clubs: ['Indie Audio', 'Beats & Sound'],
          interests: ['Sound Design', 'Hardware'],
          isVerified: false,
          level: 19,
          numericId: '381920',
        },
        lastMessage: {
          text: 'Let me know what microphone setup you used, audio quality was crystal clear.',
          timestamp: Date.now() - 86400000,
          time: 'Yesterday',
          isFromMe: false,
          unread: false,
        },
        unreadCount: 0,
        isPinned: false,
        isFriend: false,
        category: 'all',
      },
      {
        id: 'conv_4',
        participant: {
          id: 'usr_snyvo_official',
          name: 'SNYVO Assistant',
          handle: '@snyvo_team',
          avatar: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=200&auto=format&fit=crop&q=80',
          bio: 'Official SNYVO Voice Platform Concierge 🤖',
          followers: 89000,
          following: 1,
          roomsHosted: 1,
          clubs: ['SNYVO Announcements'],
          interests: ['Voice Rooms', 'Community'],
          isVerified: true,
          level: 99,
          numericId: '100001',
        },
        lastMessage: {
          text: 'Welcome to SNYVO Chat! Explore voice rooms, connect with friends, and enjoy stage discussions.',
          timestamp: Date.now() - 172800000,
          time: '2d ago',
          isFromMe: false,
          unread: false,
        },
        unreadCount: 0,
        isPinned: true,
        isFriend: false,
        category: 'official',
      },
    ];

    // Seed messages for conv_1 (Maya Lin)
    this.directMessages.set('conv_1', [
      {
        id: 'dm_1_1',
        conversationId: 'conv_1',
        senderId: 'usr_maya',
        recipientId: 'me',
        text: 'Hey Alex! Great seeing you in the Midnight Thinkers lounge earlier. ✨',
        timestamp: Date.now() - 3600000,
        time: '1:15 PM',
        status: 'read',
        isFromMe: false,
      },
      {
        id: 'dm_1_2',
        conversationId: 'conv_1',
        senderId: 'me',
        recipientId: 'usr_maya',
        text: 'Hey Maya! Thanks for the shoutout on stage, the sound clarity was awesome.',
        timestamp: Date.now() - 1800000,
        time: '1:42 PM',
        status: 'read',
        isFromMe: true,
      },
      {
        id: 'dm_1_3',
        conversationId: 'conv_1',
        senderId: 'usr_maya',
        recipientId: 'me',
        text: 'Are you joining the live stage tonight? We reserved Seat #2 for you! 🎤',
        timestamp: Date.now() - 120000,
        time: '2:10 PM',
        status: 'delivered',
        isFromMe: false,
      }
    ]);

    // Seed messages for conv_4 (SNYVO Official)
    this.directMessages.set('conv_4', [
      {
        id: 'dm_4_1',
        conversationId: 'conv_4',
        senderId: 'usr_snyvo_official',
        recipientId: 'me',
        text: 'Welcome to SNYVO Chat! Explore voice rooms, connect with friends, and enjoy stage discussions.',
        timestamp: Date.now() - 172800000,
        time: 'Sep 2',
        status: 'read',
        isFromMe: false,
      }
    ]);
  }
}

export const chatService = new ChatService();
