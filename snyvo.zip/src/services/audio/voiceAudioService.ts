/**
 * SNYVO Voice Audio Service
 * 
 * Manages:
 * 1. Physical & logical microphone states (OFF, ON, Muted by Host, Permission Denied, Permission Granted)
 * 2. Real Android & Web browser microphone permission acquisition via MediaDevices API
 * 3. User roles & speaker seat states (Empty, Occupied, Speaking, Muted)
 * 4. Pluggable real-time audio provider integration layer (WebRTC / LiveKit / Agora)
 * 5. Structured error reporting for permission denials, connection issues, and provider states
 * 
 * NOTE: This service does not fabricate fake voice network packets. It prepares a strict,
 * production-ready audio subsystem ready to bind to any WebRTC SFU or audio provider.
 */

import { MicrophoneState, MicrophonePermissionStatus, UserRoomRole, SeatStatus, SpeakerSeat, Speaker } from '../../types';
import {
  AudioServiceStatus,
  AudioServiceError,
  IAudioServiceProvider
} from './voiceTypes';

type StateChangeListener = () => void;
type ErrorListener = (error: AudioServiceError) => void;

class VoiceAudioService {
  private micState: MicrophoneState = 'off';
  private permissionStatus: MicrophonePermissionStatus = 'prompt';
  private localMediaStream: MediaStream | null = null;
  private isMutedByHost: boolean = false;
  private audioProvider: IAudioServiceProvider | null = null;
  private serviceStatus: AudioServiceStatus = 'not_connected';
  private lastError: AudioServiceError | null = null;
  private stateListeners: Set<StateChangeListener> = new Set();
  private errorListeners: Set<ErrorListener> = new Set();

  constructor() {
    this.checkInitialPermissions();
  }

  /**
   * Check if microphone permission is already granted via the Permissions API
   */
  private async checkInitialPermissions() {
    if (typeof navigator !== 'undefined' && navigator.permissions?.query) {
      try {
        const result = await navigator.permissions.query({ name: 'microphone' as PermissionName });
        if (result.state === 'granted') {
          this.permissionStatus = 'granted';
          if (this.micState === 'permission_denied') {
            this.micState = 'off';
          }
        } else if (result.state === 'denied') {
          this.permissionStatus = 'denied';
          this.micState = 'permission_denied';
        } else {
          this.permissionStatus = 'prompt';
        }

        result.onchange = () => {
          if (result.state === 'granted') {
            this.permissionStatus = 'granted';
            if (this.micState === 'permission_denied') {
              this.micState = 'off';
            }
          } else if (result.state === 'denied') {
            this.permissionStatus = 'denied';
            this.micState = 'permission_denied';
            this.stopLocalAudioTracks();
          }
          this.notify();
        };
      } catch (e) {
        // Permissions API for microphone might not be supported on all browsers
      }
    }
  }

  // =========================================================================
  // 1. MICROPHONE STATE SYSTEM
  // =========================================================================

  public getMicState(): MicrophoneState {
    return this.micState;
  }

  public getPermissionStatus(): MicrophonePermissionStatus {
    return this.permissionStatus;
  }

  public getServiceStatus(): AudioServiceStatus {
    return this.serviceStatus;
  }

  public getLastError(): AudioServiceError | null {
    return this.lastError;
  }

  public clearLastError(): void {
    this.lastError = null;
    this.notify();
  }

  public isMutedByHostOrModerator(): boolean {
    return this.isMutedByHost;
  }

  /**
   * Request actual browser / Android device microphone permissions.
   * Handles user denial, system security blocks, or missing hardware devices.
   */
  public async requestMicrophonePermission(): Promise<{ granted: boolean; error?: AudioServiceError }> {
    if (typeof navigator === 'undefined' || !navigator.mediaDevices?.getUserMedia) {
      const error: AudioServiceError = {
        type: 'permission_denied',
        message: 'Audio input devices are not supported on this browser or platform.',
        details: 'navigator.mediaDevices.getUserMedia is unavailable',
        timestamp: Date.now(),
        actionableAdvice: 'Please use a modern browser such as Chrome or Edge with HTTPS.'
      };
      this.micState = 'permission_denied';
      this.permissionStatus = 'unsupported';
      this.emitError(error);
      this.notify();
      return { granted: false, error };
    }

    try {
      // Request audio stream from hardware
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true,
        },
      });

      this.localMediaStream = stream;
      this.permissionStatus = 'granted';
      
      // If was previously denied, reset to permission_granted / off
      if (this.micState === 'permission_denied') {
        this.micState = 'off';
      }
      this.clearLastError();
      this.notify();
      return { granted: true };
    } catch (err: unknown) {
      const errorObj = err as Error;
      let errorType: AudioServiceError['type'] = 'permission_denied';
      let message = 'Microphone permission was denied.';
      let advice = 'Please tap the camera/mic icon in your address bar or Android app settings to allow microphone access.';

      if (errorObj.name === 'NotFoundError' || errorObj.name === 'DevicesNotFoundError') {
        errorType = 'device_not_found';
        message = 'No microphone device was detected on your system.';
        advice = 'Please connect a headset, external microphone, or enable your system audio input.';
      } else if (errorObj.name === 'NotReadableError' || errorObj.name === 'TrackStartError') {
        errorType = 'permission_denied';
        message = 'Your microphone is currently being used by another application.';
        advice = 'Please close other calling apps (e.g. Zoom, Meet, WhatsApp) and try again.';
      } else if (errorObj.name === 'SecurityError') {
        errorType = 'permission_denied';
        message = 'Microphone access is restricted by your browser security context.';
        advice = 'Ensure the site is served over HTTPS and iframe permissions are enabled.';
      }

      const error: AudioServiceError = {
        type: errorType,
        message,
        details: errorObj.message || String(err),
        timestamp: Date.now(),
        actionableAdvice: advice,
      };

      this.permissionStatus = 'denied';
      this.micState = 'permission_denied';
      this.emitError(error);
      this.notify();
      return { granted: false, error };
    }
  }

  /**
   * Toggles the microphone state according to rules:
   * - If muted by host: user cannot unmute until host unmutes them.
   * - If mic is currently OFF: requests permission if needed, then turns ON.
   * - If mic is currently ON: disables tracks and turns OFF.
   * - If mic is permission_denied: re-prompts permission.
   */
  public async toggleMicrophone(userRole: UserRoomRole = 'speaker'): Promise<{
    success: boolean;
    state: MicrophoneState;
    error?: AudioServiceError;
  }> {
    // 1. Check if user is muted by Host or Moderator
    if (this.isMutedByHost) {
      const error: AudioServiceError = {
        type: 'permission_denied',
        message: 'You have been muted by the Host or Moderator.',
        details: 'The stage host controls speaking permissions.',
        timestamp: Date.now(),
        actionableAdvice: 'Wait for the host to unmute you or raise your hand to request stage audio.'
      };
      this.micState = 'muted_by_host';
      this.emitError(error);
      this.notify();
      return { success: false, state: 'muted_by_host', error };
    }

    // 2. Listeners cannot enable mic without taking a seat or being invited
    if (userRole === 'listener') {
      const error: AudioServiceError = {
        type: 'permission_denied',
        message: 'Listeners cannot speak from the audience.',
        details: 'Must take an open speaker seat or be accepted by the host first.',
        timestamp: Date.now(),
        actionableAdvice: 'Tap an open seat or raise your hand to request speaking on stage.'
      };
      this.emitError(error);
      this.notify();
      return { success: false, state: 'off', error };
    }

    // 3. If currently ON -> Turn OFF
    if (this.micState === 'on') {
      this.disableLocalTracks();
      this.micState = 'off';
      if (this.audioProvider?.isMicrophoneEnabled()) {
        await this.audioProvider.disableMicrophone().catch(() => {});
      }
      this.notify();
      return { success: true, state: 'off' };
    }

    // 4. If currently OFF or PERMISSION_DENIED -> Attempt to turn ON
    if (this.permissionStatus !== 'granted' || !this.localMediaStream) {
      const result = await this.requestMicrophonePermission();
      if (!result.granted) {
        return { success: false, state: 'permission_denied', error: result.error };
      }
    }

    // Enable tracks
    this.enableLocalTracks();
    this.micState = 'on';

    if (this.audioProvider) {
      await this.audioProvider.enableMicrophone().catch(() => {});
    }

    this.notify();
    return { success: true, state: 'on' };
  }

  /**
   * Explicitly turns microphone ON for the local user.
   * Checks host mute status, listener role, and requests permissions if not granted.
   */
  public async turnMicrophoneOn(userRole: UserRoomRole = 'speaker'): Promise<{
    success: boolean;
    state: MicrophoneState;
    error?: AudioServiceError;
  }> {
    // 1. Check if user is muted by Host or Moderator
    if (this.isMutedByHost) {
      const error: AudioServiceError = {
        type: 'permission_denied',
        message: 'You have been muted by the Host or Moderator.',
        details: 'The stage host controls speaking permissions.',
        timestamp: Date.now(),
        actionableAdvice: 'Wait for the host to unmute you or raise your hand to request stage audio.'
      };
      this.micState = 'muted_by_host';
      this.emitError(error);
      this.notify();
      return { success: false, state: 'muted_by_host', error };
    }

    // 2. Listeners cannot enable mic without taking a seat or being invited
    if (userRole === 'listener') {
      const error: AudioServiceError = {
        type: 'permission_denied',
        message: 'Listeners cannot speak from the audience.',
        details: 'Must take an open speaker seat or be accepted by the host first.',
        timestamp: Date.now(),
        actionableAdvice: 'Tap an open seat or raise your hand to request speaking on stage.'
      };
      this.emitError(error);
      this.notify();
      return { success: false, state: 'off', error };
    }

    // 3. If already ON, return success
    if (this.micState === 'on') {
      return { success: true, state: 'on' };
    }

    // 4. If permission not granted or stream not created, request permission
    if (this.permissionStatus !== 'granted' || !this.localMediaStream) {
      const result = await this.requestMicrophonePermission();
      if (!result.granted) {
        return { success: false, state: 'permission_denied', error: result.error };
      }
    }

    // Enable tracks
    this.enableLocalTracks();
    this.micState = 'on';

    if (this.audioProvider) {
      await this.audioProvider.enableMicrophone().catch(() => {});
    }

    this.notify();
    return { success: true, state: 'on' };
  }

  /**
   * Explicitly turns microphone OFF for the local user.
   */
  public async turnMicrophoneOff(): Promise<{
    success: boolean;
    state: MicrophoneState;
  }> {
    if (this.isMutedByHost) {
      return { success: true, state: 'muted_by_host' };
    }

    this.disableLocalTracks();
    this.micState = 'off';
    if (this.audioProvider?.isMicrophoneEnabled()) {
      await this.audioProvider.disableMicrophone().catch(() => {});
    }
    this.notify();
    return { success: true, state: 'off' };
  }

  /**
   * Called by Host or Moderator action to mute this participant
   */
  public setMutedByHost(muted: boolean): void {
    this.isMutedByHost = muted;
    if (muted) {
      this.disableLocalTracks();
      this.micState = 'muted_by_host';
      if (this.audioProvider?.isMicrophoneEnabled()) {
        this.audioProvider.disableMicrophone().catch(() => {});
      }
      const error: AudioServiceError = {
        type: 'permission_denied',
        message: 'You were muted by the Room Host.',
        timestamp: Date.now(),
        actionableAdvice: 'Your microphone has been disabled by the room moderator.'
      };
      this.emitError(error);
    } else {
      // When unmuted by host, place in OFF state so user chooses when to activate mic
      this.micState = 'off';
      this.clearLastError();
    }
    this.notify();
  }

  private enableLocalTracks(): void {
    if (this.localMediaStream) {
      this.localMediaStream.getAudioTracks().forEach(track => {
        track.enabled = true;
      });
    }
  }

  private disableLocalTracks(): void {
    if (this.localMediaStream) {
      this.localMediaStream.getAudioTracks().forEach(track => {
        track.enabled = false;
      });
    }
  }

  private stopLocalAudioTracks(): void {
    if (this.localMediaStream) {
      this.localMediaStream.getTracks().forEach(track => track.stop());
      this.localMediaStream = null;
    }
  }

  // =========================================================================
  // 2. SPEAKER SEATS & ROLES
  // =========================================================================

  /**
   * Derives seat status for a given seat:
   * - Empty: no speaker
   * - Speaking: speaker is active, mic is ON and not muted
   * - Muted: speaker is assigned, but mic is OFF or muted by host
   * - Occupied: speaker is seated, idle
   */
  public deriveSeatStatus(speaker?: Speaker | null, isCurrentLocalUser: boolean = false): SeatStatus {
    if (!speaker) return 'empty';

    // If this is the current local user, check authoritative local mic state
    if (isCurrentLocalUser) {
      if (this.micState === 'on') return 'speaking';
      if (this.micState === 'muted_by_host' || this.micState === 'off') return 'muted';
      return 'occupied';
    }

    if (speaker.isSpeaking && !speaker.isMuted) return 'speaking';
    if (speaker.isMuted) return 'muted';
    return 'occupied';
  }

  /**
   * Builds an array of SpeakerSeat objects for a room given its maxSeats
   */
  public generateSpeakerSeats(
    maxSeats: number = 10,
    speakers: Speaker[] = [],
    lockedSeats: number[] = [],
    currentUserId: string = ''
  ): SpeakerSeat[] {
    const seats: SpeakerSeat[] = [];

    for (let i = 0; i < maxSeats; i++) {
      const speaker = speakers.find(s => s.seatIndex === i);
      const isCurrent = speaker ? speaker.id === currentUserId : false;
      const status = this.deriveSeatStatus(speaker, isCurrent);
      const isLocked = lockedSeats.includes(i);

      let seatMicState: MicrophoneState | undefined;
      if (speaker) {
        if (isCurrent) {
          seatMicState = this.micState;
        } else {
          seatMicState = speaker.isMuted ? 'off' : 'on';
        }
      }

      seats.push({
        seatIndex: i,
        status: isLocked ? 'empty' : status,
        user: speaker || null,
        isLocked,
        micState: seatMicState,
      });
    }

    return seats;
  }

  // =========================================================================
  // 3. REAL-TIME AUDIO PROVIDER ARCHITECTURE
  // =========================================================================

  /**
   * Registers a real audio provider (e.g. LiveKit, Agora, Daily.co, WebRTC SFU)
   */
  public registerProvider(provider: IAudioServiceProvider): void {
    this.audioProvider = provider;
    if (provider.isConfigured) {
      this.serviceStatus = 'not_connected';
    }
    this.notify();
  }

  public getRegisteredProvider(): IAudioServiceProvider | null {
    return this.audioProvider;
  }

  /**
   * Connects to the real-time audio room via the provider.
   * If no provider is configured yet, reports a friendly 'audio_service_not_connected' state.
   */
  public async connectAudioRoom(roomId: string, userId: string): Promise<{
    connected: boolean;
    error?: AudioServiceError;
  }> {
    if (!roomId) {
      const error: AudioServiceError = {
        type: 'room_unavailable',
        message: 'Room identifier is missing or room is no longer active.',
        timestamp: Date.now(),
        actionableAdvice: 'Please return to Lounge and choose an active room.'
      };
      this.serviceStatus = 'error';
      this.emitError(error);
      this.notify();
      return { connected: false, error };
    }

    if (!this.audioProvider || !this.audioProvider.isConfigured) {
      // Clean, transparent diagnostic state without fake voice server
      this.serviceStatus = 'not_connected';
      const info: AudioServiceError = {
        type: 'audio_service_not_connected',
        message: 'Real-time audio provider is ready for external SDK credentials (e.g. Agora or LiveKit).',
        details: 'Provider interface IAudioServiceProvider implemented.',
        timestamp: Date.now(),
        actionableAdvice: 'External audio servers are currently unlinked. Microphone states and stage presence operate locally.'
      };
      // We do not throw, we record status
      this.notify();
      return { connected: false, error: info };
    }

    try {
      this.serviceStatus = 'connecting';
      this.notify();

      const joined = await this.audioProvider.joinChannel(roomId, userId);
      if (joined) {
        this.serviceStatus = 'connected';
        this.notify();
        return { connected: true };
      } else {
        throw new Error('Failed to join audio channel');
      }
    } catch (err: unknown) {
      const error: AudioServiceError = {
        type: 'connection_unavailable',
        message: 'Could not establish connection to the real-time audio server.',
        details: err instanceof Error ? err.message : String(err),
        timestamp: Date.now(),
        actionableAdvice: 'Please check your internet connection or try rejoining the room.'
      };
      this.serviceStatus = 'error';
      this.emitError(error);
      this.notify();
      return { connected: false, error };
    }
  }

  /**
   * Leaves the active real-time audio channel and cleans up microphone hardware tracks
   */
  public async disconnectAudioRoom(): Promise<void> {
    this.disableLocalTracks();
    this.stopLocalAudioTracks();
    this.micState = 'off';
    this.isMutedByHost = false;

    if (this.audioProvider) {
      await this.audioProvider.leaveChannel().catch(() => {});
    }

    this.serviceStatus = 'not_connected';
    this.notify();
  }

  // =========================================================================
  // 4. SUBSCRIPTIONS & EVENT DISPATCH
  // =========================================================================

  public subscribe(listener: StateChangeListener): () => void {
    this.stateListeners.add(listener);
    return () => {
      this.stateListeners.delete(listener);
    };
  }

  public onError(listener: ErrorListener): () => void {
    this.errorListeners.add(listener);
    return () => {
      this.errorListeners.delete(listener);
    };
  }

  private notify(): void {
    this.stateListeners.forEach(cb => {
      try {
        cb();
      } catch (e) {
        console.error('Error in VoiceAudioService listener:', e);
      }
    });
  }

  private emitError(error: AudioServiceError): void {
    this.lastError = error;
    this.errorListeners.forEach(cb => {
      try {
        cb(error);
      } catch (e) {
        console.error('Error in VoiceAudioService error listener:', e);
      }
    });
  }
}

export const voiceAudioService = new VoiceAudioService();
