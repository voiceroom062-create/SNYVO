/**
 * SNYVO Real-Time Voice Provider & Audio Types
 * Clean abstraction layer for future WebRTC / LiveKit / Agora / Daily audio providers.
 */

import { MicrophoneState, UserRoomRole, SeatStatus } from '../../types';

export type AudioServiceStatus =
  | 'uninitialized'
  | 'not_connected'
  | 'connecting'
  | 'connected'
  | 'reconnecting'
  | 'error';

export type AudioErrorType =
  | 'permission_denied'
  | 'connection_unavailable'
  | 'room_unavailable'
  | 'audio_service_not_connected'
  | 'device_not_found'
  | 'unknown';

export interface AudioServiceError {
  type: AudioErrorType;
  message: string;
  details?: string;
  timestamp: number;
  actionableAdvice?: string;
}

export interface AudioProviderConfig {
  appId?: string;
  token?: string;
  channelId?: string;
  userId: string;
  userName?: string;
}

/**
 * Standard interface that any real-time audio SDK provider must implement
 * (e.g., LiveKit, Agora, WebRTC Mesh, Daily.co)
 */
export interface IAudioServiceProvider {
  readonly name: string;
  readonly isConfigured: boolean;
  initialize(config: AudioProviderConfig): Promise<boolean>;
  joinChannel(channelName: string, userId: string): Promise<boolean>;
  leaveChannel(): Promise<void>;
  enableMicrophone(): Promise<boolean>;
  disableMicrophone(): Promise<boolean>;
  isMicrophoneEnabled(): boolean;
  onUserSpeakingStateChanged?(callback: (userId: string, isSpeaking: boolean) => void): void;
  onError?(callback: (error: AudioServiceError) => void): void;
}

export interface VoiceRoomAudioSession {
  roomId: string;
  userId: string;
  role: UserRoomRole;
  seatIndex?: number;
  seatStatus: SeatStatus;
  micState: MicrophoneState;
  isMutedByHost: boolean;
  hasLocalPermission: boolean;
}
