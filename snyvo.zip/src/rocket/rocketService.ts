import { ROCKET_MILESTONES, RocketMilestone, RocketRoomState, RocketLaunchEvent } from './types';
import { rocketSoundEngine } from './rocketSoundEngine';

export class RocketService {
  private states: Map<string, RocketRoomState> = new Map();
  private listeners: (() => void)[] = [];
  private launchListeners: ((event: RocketLaunchEvent | null) => void)[] = [];
  private activeLaunch: RocketLaunchEvent | null = null;

  constructor() {
    this.loadFromStorage();
  }

  private getStorageKey(roomId: string): string {
    return `snyvo_rocket_state_${roomId}`;
  }

  private loadFromStorage() {
    try {
      for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        if (key && key.startsWith('snyvo_rocket_state_')) {
          const roomId = key.replace('snyvo_rocket_state_', '');
          const val = localStorage.getItem(key);
          if (val) {
            this.states.set(roomId, JSON.parse(val));
          }
        }
      }
    } catch {
      // Storage access error handling
    }
  }

  private saveState(state: RocketRoomState) {
    this.states.set(state.roomId, state);
    try {
      localStorage.setItem(this.getStorageKey(state.roomId), JSON.stringify(state));
    } catch {
      // Ignore quota errors
    }
    this.notify();
  }

  /**
   * Returns current rocket state for a specific room.
   * If new, seeds with an initial active amount (e.g. 1,850,000 coins as in prompt)
   * so the user can immediately experience the progress and milestone triggers.
   */
  public getRoomState(roomId: string, initialRoomCoins: number = 0): RocketRoomState {
    let state = this.states.get(roomId);
    if (!state) {
      // Check localStorage directly
      try {
        const raw = localStorage.getItem(this.getStorageKey(roomId));
        if (raw) {
          state = JSON.parse(raw);
          if (state) {
            this.states.set(roomId, state);
            return state;
          }
        }
      } catch {
        // fallback
      }

      // Default initial state: seeded at 1,850,000 coins (as in user prompt example)
      // or at the actual roomCoins if greater.
      const startingCoins = Math.max(initialRoomCoins, 1_850_000);

      // Determine already completed milestones if any
      const completed: number[] = [];
      ROCKET_MILESTONES.forEach(m => {
        if (startingCoins >= m.targetCoins) {
          completed.push(m.id);
        }
      });

      state = {
        roomId,
        currentCoins: startingCoins,
        completedRockets: completed,
        lastUpdated: Date.now(),
      };

      this.saveState(state);
    }

    return state;
  }

  /**
   * Formats coin amount cleanly matching prompt specification:
   * 850,000 -> "850K"
   * 1,950,000 -> "1.95M"
   * 2,000,000 -> "2M"
   * 2,400,000 -> "2.4M"
   * 10,000,000 -> "10M"
   */
  public formatCoins(amount: number): string {
    if (amount >= 1_000_000) {
      const millions = amount / 1_000_000;
      if (millions % 1 === 0) {
        return `${millions}M`;
      }
      // If ends with round tenths (e.g. 2.40M) -> "2.4M", else "1.95M"
      const formatted = millions.toFixed(2);
      if (formatted.endsWith('0')) {
        return `${millions.toFixed(1)}M`;
      }
      return `${formatted}M`;
    }
    if (amount >= 1_000) {
      const thousands = amount / 1_000;
      if (thousands % 1 === 0) {
        return `${thousands}K`;
      }
      return `${thousands.toFixed(1).replace('.0', '')}K`;
    }
    return amount.toLocaleString();
  }

  /**
   * Called when a verified Gift Transaction occurs in the room.
   * Updates coin count atomically in real-time, checks milestones,
   * and triggers the Rocket Launch Event if a milestone is achieved.
   */
  public recordGiftCoins(
    roomId: string,
    giftCoins: number,
    senderName?: string,
    giftName?: string
  ): { state: RocketRoomState; triggeredRocket: RocketMilestone | null } {
    const currentState = this.getRoomState(roomId);
    const previousCoins = currentState.currentCoins;
    const newCoins = previousCoins + giftCoins;

    let triggeredRocket: RocketMilestone | null = null;

    // Check each milestone in order (1 to 5)
    for (const milestone of ROCKET_MILESTONES) {
      const alreadyCompleted = currentState.completedRockets.includes(milestone.id);
      if (!alreadyCompleted && newCoins >= milestone.targetCoins) {
        triggeredRocket = milestone;
        break; // Launch first achieved milestone
      }
    }

    const updatedCompleted = [...currentState.completedRockets];
    if (triggeredRocket && !updatedCompleted.includes(triggeredRocket.id)) {
      updatedCompleted.push(triggeredRocket.id);
    }

    const updatedState: RocketRoomState = {
      ...currentState,
      currentCoins: newCoins,
      completedRockets: updatedCompleted,
      lastUpdated: Date.now(),
    };

    this.saveState(updatedState);

    // If milestone reached, trigger synchronized launch event and audio
    if (triggeredRocket) {
      this.triggerLaunch(triggeredRocket, newCoins, senderName, giftName);
    }

    return { state: updatedState, triggeredRocket };
  }

  /**
   * Triggers a synchronized Rocket Launch Event
   */
  public triggerLaunch(
    rocket: RocketMilestone,
    currentCoins: number,
    senderName?: string,
    giftName?: string
  ) {
    const event: RocketLaunchEvent = {
      rocket,
      currentCoins,
      senderName,
      giftName,
      startedAt: Date.now(),
    };

    this.activeLaunch = event;

    // Trigger synchronized Web Audio
    try {
      rocketSoundEngine.playRocketLaunch(rocket.level);
    } catch {
      // audio error handling
    }

    this.notifyLaunch(event);
  }

  /**
   * Developer / User Manual Test Launch for any Rocket 1 to 5
   */
  public testTriggerLaunch(roomId: string, rocketId: number) {
    const rocket = ROCKET_MILESTONES.find(m => m.id === rocketId) || ROCKET_MILESTONES[0];
    const currentState = this.getRoomState(roomId);
    const completed = new Set(currentState.completedRockets);
    completed.add(rocket.id);

    const updatedState: RocketRoomState = {
      ...currentState,
      currentCoins: Math.max(currentState.currentCoins, rocket.targetCoins),
      completedRockets: Array.from(completed),
      lastUpdated: Date.now(),
    };

    this.saveState(updatedState);
    this.triggerLaunch(rocket, updatedState.currentCoins, 'SNYVO VIP', 'Rocket Booster');
  }

  /**
   * Adds coins directly (for test boost)
   */
  public addTestCoins(roomId: string, amount: number) {
    return this.recordGiftCoins(roomId, amount, 'Demo Supporter', 'Coin Boost');
  }

  /**
   * Dismiss the currently active launch animation overlay
   */
  public dismissLaunch() {
    this.activeLaunch = null;
    rocketSoundEngine.stopAll();
    this.notifyLaunch(null);
  }

  public getActiveLaunch(): RocketLaunchEvent | null {
    return this.activeLaunch;
  }

  public subscribe(cb: () => void): () => void {
    this.listeners.push(cb);
    return () => {
      this.listeners = this.listeners.filter(l => l !== cb);
    };
  }

  public subscribeLaunch(cb: (event: RocketLaunchEvent | null) => void): () => void {
    this.launchListeners.push(cb);
    return () => {
      this.launchListeners = this.launchListeners.filter(l => l !== cb);
    };
  }

  private notify() {
    this.listeners.forEach(cb => {
      try {
        cb();
      } catch (e) {
        console.error(e);
      }
    });
  }

  private notifyLaunch(event: RocketLaunchEvent | null) {
    this.launchListeners.forEach(cb => {
      try {
        cb(event);
      } catch (e) {
        console.error(e);
      }
    });
  }
}

export const rocketService = new RocketService();
