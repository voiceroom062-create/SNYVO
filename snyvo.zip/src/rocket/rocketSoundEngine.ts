/**
 * SNYVO Rocket Launch Sound Engine
 * Synthesizes synchronized Web Audio for all 5 tiers of Rocket milestones
 * 
 * 🚀 Rocket 1: Small Rocket, Short Launch SFX
 * 🚀 Rocket 2: Medium Rocket, Medium Launch Sound
 * 🚀 Rocket 3: Large Rocket, Cinematic Rocket Sound
 * 🚀 Rocket 4: Mega Rocket, Premium Launch Music + SFX
 * 🚀 Rocket 5: Ultra Rocket, Premium Cinematic Music + Rocket Launch SFX + Celebration Effect
 */

class RocketSoundEngine {
  private audioCtx: AudioContext | null = null;
  private isMuted: boolean = false;
  private currentSourceNodes: (AudioNode | number)[] = [];

  constructor() {
    // Check if muted in storage
    const stored = localStorage.getItem('snyvo_rocket_sound_muted');
    if (stored !== null) {
      this.isMuted = stored === 'true';
    } else {
      // Also sync with gift mute preference if set
      const giftMute = localStorage.getItem('snyvo_gift_sound_muted');
      if (giftMute !== null) {
        this.isMuted = giftMute === 'true';
      }
    }
  }

  private initCtx(): AudioContext | null {
    try {
      if (!this.audioCtx) {
        const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
        this.audioCtx = new AudioContextClass();
      }
      if (this.audioCtx.state === 'suspended') {
        this.audioCtx.resume();
      }
      return this.audioCtx;
    } catch {
      return null;
    }
  }

  public setMuted(muted: boolean) {
    this.isMuted = muted;
    try {
      localStorage.setItem('snyvo_rocket_sound_muted', muted ? 'true' : 'false');
    } catch {
      // ignore
    }
    if (muted) {
      this.stopAll();
    }
  }

  public getMuted(): boolean {
    return this.isMuted;
  }

  public stopAll() {
    this.currentSourceNodes.forEach(item => {
      if (typeof item === 'number') {
        window.clearTimeout(item);
      } else {
        try {
          if ('stop' in item && typeof (item as AudioScheduledSourceNode).stop === 'function') {
            (item as AudioScheduledSourceNode).stop();
          }
        } catch {
          // ignore
        }
      }
    });
    this.currentSourceNodes = [];
  }

  /**
   * Main entry point to play rocket sound based on rocket level (1 to 5)
   */
  public playRocketLaunch(level: number) {
    if (this.isMuted) return;
    const ctx = this.initCtx();
    if (!ctx) return;

    this.stopAll();

    switch (level) {
      case 1:
        this.playRocket1(ctx);
        break;
      case 2:
        this.playRocket2(ctx);
        break;
      case 3:
        this.playRocket3(ctx);
        break;
      case 4:
        this.playRocket4(ctx);
        break;
      case 5:
      default:
        this.playRocket5(ctx);
        break;
    }
  }

  /**
   * 🚀 Rocket 1: Small Rocket - Short Launch SFX (approx 2.2s)
   * High-pitch ignition, turbulent exhaust whoosh, ascending pitch sweep
   */
  private playRocket1(ctx: AudioContext) {
    const t0 = ctx.currentTime;

    // Thruster Noise
    const noiseNode = this.createWhiteNoise(ctx);
    const filter = ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.setValueAtTime(350, t0);
    filter.frequency.exponentialRampToValueAtTime(1400, t0 + 2.0);
    filter.Q.value = 3.0;

    const noiseGain = ctx.createGain();
    noiseGain.gain.setValueAtTime(0.01, t0);
    noiseGain.gain.linearRampToValueAtTime(0.25, t0 + 0.3);
    noiseGain.gain.exponentialRampToValueAtTime(0.001, t0 + 2.2);

    noiseNode.connect(filter);
    filter.connect(noiseGain);
    noiseGain.connect(ctx.destination);

    // Whistle/Turbine sweep
    const osc = ctx.createOscillator();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(180, t0);
    osc.frequency.exponentialRampToValueAtTime(750, t0 + 2.0);

    const oscGain = ctx.createGain();
    oscGain.gain.setValueAtTime(0.05, t0);
    oscGain.gain.linearRampToValueAtTime(0.18, t0 + 0.5);
    oscGain.gain.exponentialRampToValueAtTime(0.001, t0 + 2.2);

    osc.connect(oscGain);
    oscGain.connect(ctx.destination);

    noiseNode.start(t0);
    osc.start(t0);
    noiseNode.stop(t0 + 2.3);
    osc.stop(t0 + 2.3);

    this.currentSourceNodes.push(noiseNode, osc);
  }

  /**
   * 🚀 Rocket 2: Medium Rocket - Medium Launch Sound (approx 3.2s)
   * Deeper booster rumble, dual stage pitch escalation + liftoff chimes
   */
  private playRocket2(ctx: AudioContext) {
    const t0 = ctx.currentTime;

    // Deep Booster Rumble
    const noiseNode = this.createWhiteNoise(ctx);
    const filter = ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(180, t0);
    filter.frequency.exponentialRampToValueAtTime(800, t0 + 2.8);

    const rumbleGain = ctx.createGain();
    rumbleGain.gain.setValueAtTime(0.01, t0);
    rumbleGain.gain.linearRampToValueAtTime(0.35, t0 + 0.4);
    rumbleGain.gain.exponentialRampToValueAtTime(0.001, t0 + 3.2);

    noiseNode.connect(filter);
    filter.connect(rumbleGain);
    rumbleGain.connect(ctx.destination);

    // Dual-tone harmonic ascent
    [220, 330].forEach((freq, idx) => {
      const osc = ctx.createOscillator();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, t0 + 0.2);
      osc.frequency.exponentialRampToValueAtTime(freq * 3.5, t0 + 3.0);

      const g = ctx.createGain();
      g.gain.setValueAtTime(0.01, t0 + 0.2);
      g.gain.linearRampToValueAtTime(0.12 - idx * 0.03, t0 + 0.6);
      g.gain.exponentialRampToValueAtTime(0.001, t0 + 3.2);

      osc.connect(g);
      g.connect(ctx.destination);
      osc.start(t0 + 0.2);
      osc.stop(t0 + 3.3);
      this.currentSourceNodes.push(osc);
    });

    noiseNode.start(t0);
    noiseNode.stop(t0 + 3.3);
    this.currentSourceNodes.push(noiseNode);
  }

  /**
   * 🚀 Rocket 3: Large Rocket - Cinematic Rocket Sound (approx 4.5s)
   * Earth-shaking sub-bass liftoff, sweeping cinematic chord swell
   */
  private playRocket3(ctx: AudioContext) {
    const t0 = ctx.currentTime;

    // Sub-bass rumble (55Hz)
    const subOsc = ctx.createOscillator();
    subOsc.type = 'sine';
    subOsc.frequency.setValueAtTime(55, t0);
    subOsc.frequency.exponentialRampToValueAtTime(110, t0 + 4.0);

    const subGain = ctx.createGain();
    subGain.gain.setValueAtTime(0.05, t0);
    subGain.gain.linearRampToValueAtTime(0.45, t0 + 0.6);
    subGain.gain.exponentialRampToValueAtTime(0.001, t0 + 4.5);

    subOsc.connect(subGain);
    subGain.connect(ctx.destination);
    subOsc.start(t0);
    subOsc.stop(t0 + 4.6);
    this.currentSourceNodes.push(subOsc);

    // Roaring Booster Noise
    const noise = this.createWhiteNoise(ctx);
    const band = ctx.createBiquadFilter();
    band.type = 'bandpass';
    band.frequency.setValueAtTime(150, t0);
    band.frequency.exponentialRampToValueAtTime(1200, t0 + 3.5);
    band.Q.value = 2.0;

    const noiseGain = ctx.createGain();
    noiseGain.gain.setValueAtTime(0.01, t0);
    noiseGain.gain.linearRampToValueAtTime(0.35, t0 + 0.5);
    noiseGain.gain.exponentialRampToValueAtTime(0.001, t0 + 4.5);

    noise.connect(band);
    band.connect(noiseGain);
    noiseGain.connect(ctx.destination);
    noise.start(t0);
    noise.stop(t0 + 4.6);
    this.currentSourceNodes.push(noise);

    // Cinematic Chord Progression (D major fanfare)
    const notes = [146.83, 185.00, 220.00, 293.66]; // D3, F#3, A3, D4
    notes.forEach((freq, idx) => {
      const o = ctx.createOscillator();
      o.type = 'sawtooth';
      o.frequency.setValueAtTime(freq, t0 + 0.8 + idx * 0.25);
      o.frequency.exponentialRampToValueAtTime(freq * 1.5, t0 + 4.2);

      const f = ctx.createBiquadFilter();
      f.type = 'lowpass';
      f.frequency.setValueAtTime(400, t0 + 0.8);
      f.frequency.exponentialRampToValueAtTime(2500, t0 + 3.0);

      const g = ctx.createGain();
      g.gain.setValueAtTime(0.001, t0 + 0.8 + idx * 0.25);
      g.gain.linearRampToValueAtTime(0.08, t0 + 1.2 + idx * 0.25);
      g.gain.exponentialRampToValueAtTime(0.001, t0 + 4.5);

      o.connect(f);
      f.connect(g);
      g.connect(ctx.destination);
      o.start(t0 + 0.8 + idx * 0.25);
      o.stop(t0 + 4.6);
      this.currentSourceNodes.push(o);
    });
  }

  /**
   * 🚀 Rocket 4: Mega Rocket - Premium Launch Music + SFX (approx 5.5s)
   * Deep orbital thrusters, cinematic brass crescendo, ascending arpeggio
   */
  private playRocket4(ctx: AudioContext) {
    const t0 = ctx.currentTime;

    // Sub-bass booster
    const subOsc = ctx.createOscillator();
    subOsc.type = 'sine';
    subOsc.frequency.setValueAtTime(45, t0);
    subOsc.frequency.exponentialRampToValueAtTime(90, t0 + 5.0);

    const subGain = ctx.createGain();
    subGain.gain.setValueAtTime(0.05, t0);
    subGain.gain.linearRampToValueAtTime(0.5, t0 + 0.8);
    subGain.gain.exponentialRampToValueAtTime(0.001, t0 + 5.5);

    subOsc.connect(subGain);
    subGain.connect(ctx.destination);
    subOsc.start(t0);
    subOsc.stop(t0 + 5.6);
    this.currentSourceNodes.push(subOsc);

    // Powerful rocket turbine exhaust
    const noise = this.createWhiteNoise(ctx);
    const filter = ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(250, t0);
    filter.frequency.exponentialRampToValueAtTime(2200, t0 + 4.0);

    const noiseGain = ctx.createGain();
    noiseGain.gain.setValueAtTime(0.01, t0);
    noiseGain.gain.linearRampToValueAtTime(0.4, t0 + 0.5);
    noiseGain.gain.exponentialRampToValueAtTime(0.001, t0 + 5.5);

    noise.connect(filter);
    filter.connect(noiseGain);
    noiseGain.connect(ctx.destination);
    noise.start(t0);
    noise.stop(t0 + 5.6);
    this.currentSourceNodes.push(noise);

    // Majestic 5-note brass fanfare
    const fanfareNotes = [261.63, 329.63, 392.00, 523.25, 659.25]; // C4, E4, G4, C5, E5
    fanfareNotes.forEach((freq, idx) => {
      const startTime = t0 + 0.5 + idx * 0.35;
      const o = ctx.createOscillator();
      o.type = 'sawtooth';
      o.frequency.setValueAtTime(freq, startTime);

      const f = ctx.createBiquadFilter();
      f.type = 'lowpass';
      f.frequency.setValueAtTime(800, startTime);
      f.frequency.linearRampToValueAtTime(3200, startTime + 0.6);

      const g = ctx.createGain();
      g.gain.setValueAtTime(0.001, startTime);
      g.gain.linearRampToValueAtTime(0.12, startTime + 0.1);
      g.gain.exponentialRampToValueAtTime(0.001, t0 + 5.5);

      o.connect(f);
      f.connect(g);
      g.connect(ctx.destination);
      o.start(startTime);
      o.stop(t0 + 5.6);
      this.currentSourceNodes.push(o);
    });
  }

  /**
   * 🚀 Rocket 5: Ultra Rocket - Premium Cinematic Music + Rocket Launch SFX + Celebration Effect (approx 7.0s)
   * Tremendous Saturn-V style liftoff roar + glorious orchestral triumphant fanfare + celebratory sparkle chimes
   */
  private playRocket5(ctx: AudioContext) {
    const t0 = ctx.currentTime;

    // 1. Ultra Sub-Bass Roar (38Hz -> 85Hz)
    const subOsc = ctx.createOscillator();
    subOsc.type = 'triangle';
    subOsc.frequency.setValueAtTime(38, t0);
    subOsc.frequency.exponentialRampToValueAtTime(95, t0 + 6.0);

    const subGain = ctx.createGain();
    subGain.gain.setValueAtTime(0.05, t0);
    subGain.gain.linearRampToValueAtTime(0.55, t0 + 1.0);
    subGain.gain.exponentialRampToValueAtTime(0.001, t0 + 6.8);

    subOsc.connect(subGain);
    subGain.connect(ctx.destination);
    subOsc.start(t0);
    subOsc.stop(t0 + 7.0);
    this.currentSourceNodes.push(subOsc);

    // 2. Continuous Multi-Stage Rocket Booster Combustion
    const noise = this.createWhiteNoise(ctx);
    const noiseFilter = ctx.createBiquadFilter();
    noiseFilter.type = 'bandpass';
    noiseFilter.frequency.setValueAtTime(200, t0);
    noiseFilter.frequency.exponentialRampToValueAtTime(2800, t0 + 5.0);
    noiseFilter.Q.value = 1.8;

    const noiseGain = ctx.createGain();
    noiseGain.gain.setValueAtTime(0.01, t0);
    noiseGain.gain.linearRampToValueAtTime(0.45, t0 + 0.8);
    noiseGain.gain.exponentialRampToValueAtTime(0.001, t0 + 6.8);

    noise.connect(noiseFilter);
    noiseFilter.connect(noiseGain);
    noiseGain.connect(ctx.destination);
    noise.start(t0);
    noise.stop(t0 + 7.0);
    this.currentSourceNodes.push(noise);

    // 3. Ultra Cinematic Triumph Fanfare (Royal F-Major to A-Major Ascent)
    const orchestralChords = [
      { t: 0.8, notes: [174.61, 220.00, 261.63, 349.23] }, // F major
      { t: 2.0, notes: [196.00, 246.94, 293.66, 392.00] }, // G major
      { t: 3.2, notes: [220.00, 277.18, 329.63, 440.00] }, // A major
      { t: 4.4, notes: [261.63, 329.63, 392.00, 523.25, 659.25] }, // High C major victory
    ];

    orchestralChords.forEach(chord => {
      const chordStart = t0 + chord.t;
      chord.notes.forEach((freq, idx) => {
        const osc = ctx.createOscillator();
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(freq, chordStart);

        const filter = ctx.createBiquadFilter();
        filter.type = 'lowpass';
        filter.frequency.setValueAtTime(700, chordStart);
        filter.frequency.exponentialRampToValueAtTime(3500, chordStart + 0.8);

        const g = ctx.createGain();
        g.gain.setValueAtTime(0.001, chordStart);
        g.gain.linearRampToValueAtTime(0.09 - idx * 0.01, chordStart + 0.15);
        g.gain.exponentialRampToValueAtTime(0.001, chordStart + 1.6);

        osc.connect(filter);
        filter.connect(g);
        g.connect(ctx.destination);
        osc.start(chordStart);
        osc.stop(chordStart + 1.8);
        this.currentSourceNodes.push(osc);
      });
    });

    // 4. Celebration Sparkle Chimes (Glittering Star bursts)
    const sparkleNotes = [1046.5, 1318.5, 1567.98, 2093.0, 2637.0, 3135.96];
    sparkleNotes.forEach((freq, idx) => {
      const st = t0 + 4.6 + idx * 0.18;
      const o = ctx.createOscillator();
      o.type = 'sine';
      o.frequency.setValueAtTime(freq, st);

      const g = ctx.createGain();
      g.gain.setValueAtTime(0.001, st);
      g.gain.linearRampToValueAtTime(0.08, st + 0.04);
      g.gain.exponentialRampToValueAtTime(0.001, st + 0.6);

      o.connect(g);
      g.connect(ctx.destination);
      o.start(st);
      o.stop(st + 0.7);
      this.currentSourceNodes.push(o);
    });
  }

  private createWhiteNoise(ctx: AudioContext): AudioBufferSourceNode {
    const bufferSize = ctx.sampleRate * 7.5;
    const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      data[i] = Math.random() * 2 - 1;
    }
    const noise = ctx.createBufferSource();
    noise.buffer = buffer;
    return noise;
  }
}

export const rocketSoundEngine = new RocketSoundEngine();
