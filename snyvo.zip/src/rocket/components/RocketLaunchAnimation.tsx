import React, { useEffect, useState } from 'react';
import {
  Rocket,
  Sparkles,
  Flame,
  Volume2,
  VolumeX,
  X,
  CheckCircle2,
  Trophy
} from 'lucide-react';
import { RocketLaunchEvent } from '../types';
import { rocketSoundEngine } from '../rocketSoundEngine';

interface RocketLaunchAnimationProps {
  event: RocketLaunchEvent;
  onDismiss: () => void;
}

export const RocketLaunchAnimation: React.FC<RocketLaunchAnimationProps> = ({
  event,
  onDismiss
}) => {
  const [stage, setStage] = useState<'prep' | 'ignite' | 'liftoff' | 'cinematic' | 'celebrate'>('prep');
  const [isMuted, setIsMuted] = useState(() => rocketSoundEngine.getMuted());
  const [countdown, setCountdown] = useState(3);

  const { rocket, currentCoins, senderName, giftName } = event;

  // Toggle audio
  const handleToggleMute = (e: React.MouseEvent) => {
    e.stopPropagation();
    const next = !isMuted;
    setIsMuted(next);
    rocketSoundEngine.setMuted(next);
  };

  useEffect(() => {
    // 10-step Sequence timing synchronized with rocket duration
    // Stage 1: Preparation (0ms - 900ms) - Countdown & Clamps
    const prepTimer = setTimeout(() => {
      setCountdown(2);
    }, 350);

    const prepTimer2 = setTimeout(() => {
      setCountdown(1);
    }, 700);

    // Stage 2: Ignition & Flame (900ms - 1700ms) - Thruster Ignition
    const igniteTimer = setTimeout(() => {
      setStage('ignite');
    }, 900);

    // Stage 3: Liftoff & Fly Upwards (1700ms - 3200ms) - Ascend across screen
    const liftoffTimer = setTimeout(() => {
      setStage('liftoff');
    }, 1700);

    // Stage 4: Cinematic Banner (3000ms+)
    const cinematicTimer = setTimeout(() => {
      setStage('cinematic');
    }, 3000);

    // Stage 5: Celebration & return
    const totalDuration = Math.max(4500, rocket.soundDurationMs + 800);
    const completeTimer = setTimeout(() => {
      onDismiss();
    }, totalDuration);

    return () => {
      clearTimeout(prepTimer);
      clearTimeout(prepTimer2);
      clearTimeout(igniteTimer);
      clearTimeout(liftoffTimer);
      clearTimeout(cinematicTimer);
      clearTimeout(completeTimer);
    };
  }, [rocket, onDismiss]);

  // Rocket size and design based on tier
  const getRocketVisuals = () => {
    switch (rocket.id) {
      case 1:
        return {
          scaleClass: 'w-24 h-36',
          titleColor: 'text-amber-400',
          borderColor: 'border-amber-500/50',
          glowBg: 'bg-amber-500/20',
          flameHeight: 'h-16',
          thrustGradient: 'from-amber-400 via-orange-500 to-red-600',
        };
      case 2:
        return {
          scaleClass: 'w-28 h-44',
          titleColor: 'text-orange-400',
          borderColor: 'border-orange-500/50',
          glowBg: 'bg-orange-500/25',
          flameHeight: 'h-24',
          thrustGradient: 'from-yellow-300 via-orange-500 to-red-600',
        };
      case 3:
        return {
          scaleClass: 'w-32 h-52',
          titleColor: 'text-pink-400',
          borderColor: 'border-pink-500/50',
          glowBg: 'bg-pink-500/25',
          flameHeight: 'h-32',
          thrustGradient: 'from-pink-300 via-violet-500 to-blue-600',
        };
      case 4:
        return {
          scaleClass: 'w-36 h-60',
          titleColor: 'text-violet-400',
          borderColor: 'border-violet-500/50',
          glowBg: 'bg-violet-600/30',
          flameHeight: 'h-40',
          thrustGradient: 'from-violet-300 via-fuchsia-500 to-rose-600',
        };
      case 5:
      default:
        return {
          scaleClass: 'w-40 h-68',
          titleColor: 'text-cyan-300',
          borderColor: 'border-cyan-400/60',
          glowBg: 'bg-cyan-500/30',
          flameHeight: 'h-48',
          thrustGradient: 'from-cyan-300 via-violet-400 via-amber-300 to-rose-600',
        };
    }
  };

  const visuals = getRocketVisuals();

  return (
    <div
      id="snyvo-rocket-launch-overlay"
      className="fixed inset-0 z-[100] flex flex-col items-center justify-center bg-black/80 backdrop-blur-md overflow-hidden animate-fade-in select-none"
    >
      {/* Top Floating Controls Bar */}
      <div className="absolute top-4 right-4 flex items-center space-x-2 z-[110]">
        <button
          onClick={handleToggleMute}
          className="p-2 rounded-full bg-neutral-900/80 border border-neutral-700 text-white hover:bg-neutral-800 transition-colors shadow-lg cursor-pointer"
          title={isMuted ? 'Unmute Audio' : 'Mute Audio'}
        >
          {isMuted ? <VolumeX className="w-5 h-5 text-red-400" /> : <Volume2 className="w-5 h-5 text-emerald-400" />}
        </button>

        <button
          onClick={onDismiss}
          className="p-2 rounded-full bg-neutral-900/80 border border-neutral-700 text-white hover:bg-neutral-800 transition-colors shadow-lg cursor-pointer"
          title="Skip Launch"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Cosmic Starfield & Nebula Particles */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        {/* Deep space stars */}
        <div className="absolute top-1/4 left-1/6 w-2 h-2 rounded-full bg-white animate-ping" />
        <div className="absolute top-1/3 right-1/4 w-1.5 h-1.5 rounded-full bg-amber-300 animate-pulse" />
        <div className="absolute top-2/3 left-1/3 w-2 h-2 rounded-full bg-cyan-300 animate-pulse" />
        <div className="absolute bottom-1/4 right-1/5 w-1 h-1 rounded-full bg-pink-300 animate-ping" />

        {/* Ambient Radial Nebula Flare */}
        <div className={`absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] rounded-full ${visuals.glowBg} blur-3xl opacity-70 transition-all duration-1000`} />
      </div>

      {/* 🚀 MAIN ROCKET ASSEMBLY STAGE */}
      <div className="relative flex flex-col items-center justify-center z-10 w-full max-w-md px-4">
        
        {/* Step 1 & 2: Launch Preparation Countdown & Telemetry */}
        {stage === 'prep' && (
          <div className="mb-6 flex flex-col items-center animate-bounce">
            <div className="px-4 py-1.5 rounded-full bg-amber-500/20 border border-amber-400/60 backdrop-blur-md mb-2">
              <span className="text-xs font-black tracking-widest uppercase text-amber-300 flex items-center space-x-1.5">
                <Flame className="w-4 h-4 text-amber-400 animate-pulse" />
                <span>IGNITION COUNTDOWN</span>
              </span>
            </div>
            <div className="text-6xl sm:text-7xl font-black text-white tracking-wider drop-shadow-[0_0_25px_rgba(245,158,11,0.8)]">
              {countdown}
            </div>
          </div>
        )}

        {/* Cinematic Header Milestone Badge */}
        <div className="text-center mb-4 transition-all">
          <div className="inline-flex items-center space-x-2 px-4 py-1.5 rounded-full bg-neutral-900/90 border border-amber-500/40 shadow-xl backdrop-blur-md mb-2">
            <Trophy className="w-4 h-4 text-amber-400" />
            <span className="text-xs font-black uppercase tracking-wider text-amber-300">
              {rocket.name} Milestone Achieved!
            </span>
          </div>

          <h2 className="text-2xl sm:text-3xl font-black text-white drop-shadow-md">
            🪙 {rocket.formattedTarget} Coins Milestone
          </h2>

          {senderName && (
            <p className="text-xs text-neutral-300 mt-1">
              Triggered by <strong className="text-amber-400 font-bold">{senderName}</strong>
              {giftName ? ` with ${giftName}` : ''}!
            </p>
          )}
        </div>

        {/* 🚀 THE ROCKET BODY (Steps 3, 4, 5, 6) */}
        <div
          id="rocket-flight-vehicle"
          className={`relative flex flex-col items-center transition-all duration-1000 ${
            stage === 'liftoff' || stage === 'cinematic' || stage === 'celebrate'
              ? '-translate-y-[120vh] scale-125 opacity-90 transition-transform duration-[2200ms] ease-in'
              : 'translate-y-0 scale-100'
          }`}
        >
          {/* Dynamic Rocket Vehicle Graphic */}
          <div className="relative flex flex-col items-center">
            {/* Nosecone Thruster Glow */}
            <div className="w-4 h-4 rounded-full bg-amber-400 blur-sm absolute -top-2 animate-ping" />

            {/* Rocket Silhouette & Body Structure */}
            <div className={`relative ${visuals.scaleClass} flex flex-col items-center justify-center`}>
              
              {/* SVG Vector Rocket with High Detail */}
              <svg
                viewBox="0 0 100 160"
                className="w-full h-full drop-shadow-[0_0_20px_rgba(255,255,255,0.4)]"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                {/* Nose Cone */}
                <path
                  d="M50 5 C40 30, 30 50, 30 75 L70 75 C70 50, 60 30, 50 5 Z"
                  fill="url(#rocketNoseGradient)"
                />

                {/* Main Fuselage Body */}
                <rect x="30" y="70" width="40" height="60" rx="4" fill="url(#rocketBodyGradient)" />

                {/* Command Window / Porthole */}
                <circle cx="50" cy="90" r="9" fill="#0f172a" stroke="#38bdf8" strokeWidth="2.5" />
                <circle cx="52" cy="88" r="3" fill="#bae6fd" opacity="0.8" />

                {/* SNYVO Logo on Fuselage */}
                <text x="50" y="112" textAnchor="middle" fontSize="6" fontWeight="bold" fill="#ffffff" letterSpacing="0.8">
                  SNYVO
                </text>
                <text x="50" y="122" textAnchor="middle" fontSize="7" fontWeight="black" fill="#fbbf24">
                  R{rocket.id}
                </text>

                {/* Left Fin / Booster Wing */}
                <path d="M30 105 L12 135 L30 130 Z" fill="url(#rocketFinGradient)" />

                {/* Right Fin / Booster Wing */}
                <path d="M70 105 L88 135 L70 130 Z" fill="url(#rocketFinGradient)" />

                {/* Central Engine Nozzle Bells */}
                <path d="M36 130 L32 142 L46 142 L44 130 Z" fill="#334155" />
                <path d="M56 130 L54 142 L68 142 L64 130 Z" fill="#334155" />

                {/* Gradients */}
                <defs>
                  <linearGradient id="rocketNoseGradient" x1="0" y1="0" x2="1" y2="1">
                    <stop offset="0%" stopColor="#ef4444" />
                    <stop offset="100%" stopColor="#b91c1c" />
                  </linearGradient>
                  <linearGradient id="rocketBodyGradient" x1="0" y1="0" x2="1" y2="0">
                    <stop offset="0%" stopColor="#f8fafc" />
                    <stop offset="50%" stopColor="#ffffff" />
                    <stop offset="100%" stopColor="#cbd5e1" />
                  </linearGradient>
                  <linearGradient id="rocketFinGradient" x1="0" y1="0" x2="1" y2="1">
                    <stop offset="0%" stopColor="#ef4444" />
                    <stop offset="100%" stopColor="#7f1d1d" />
                  </linearGradient>
                </defs>
              </svg>
            </div>

            {/* Step 4 & 5: Powerful Animated Rocket Flames & Particle Trail */}
            {(stage === 'ignite' || stage === 'liftoff' || stage === 'cinematic' || stage === 'celebrate') && (
              <div className="flex flex-col items-center -mt-3">
                {/* Core Plasma Flame */}
                <div
                  className={`w-12 sm:w-16 ${visuals.flameHeight} bg-gradient-to-b ${visuals.thrustGradient} rounded-b-full blur-[1px] animate-pulse drop-shadow-[0_0_30px_rgba(249,115,22,1)] relative`}
                >
                  {/* Inner White-Hot Core */}
                  <div className="absolute top-0 left-1/2 -translate-x-1/2 w-6 h-3/4 bg-white rounded-b-full blur-xs" />
                </div>

                {/* Multi-layered Smoke & Sparkle Billow Plumes */}
                <div className="flex items-center space-x-2 -mt-4 opacity-90">
                  <div className="w-10 h-10 rounded-full bg-neutral-300/40 blur-md animate-ping" />
                  <div className="w-14 h-14 rounded-full bg-amber-200/50 blur-lg animate-pulse" />
                  <div className="w-10 h-10 rounded-full bg-neutral-300/40 blur-md animate-ping" />
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Step 7: Cinematic Celebration Announcement Card */}
        <div className="mt-8 text-center max-w-sm w-full bg-neutral-950/85 border border-violet-500/30 rounded-2xl p-4 shadow-2xl backdrop-blur-md">
          <div className="flex items-center justify-center space-x-1.5 mb-1.5 text-emerald-400 font-bold text-xs">
            <CheckCircle2 className="w-4 h-4" />
            <span>Rocket #{rocket.id} Launched Successfully</span>
          </div>

          <p className="text-xs text-neutral-300 leading-relaxed">
            {rocket.description}.
          </p>

          <div className="mt-3 flex items-center justify-center space-x-2">
            <button
              onClick={onDismiss}
              className="px-5 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 hover:brightness-110 text-neutral-950 font-black text-xs shadow-md shadow-amber-500/30 cursor-pointer active:scale-95 transition-all"
            >
              Continue to Room Board
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
