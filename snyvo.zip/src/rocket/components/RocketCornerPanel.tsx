import React, { useState } from 'react';
import {
  Rocket,
  CheckCircle2,
  Sparkles,
  ChevronDown,
  ChevronUp,
  Flame,
  Volume2,
  VolumeX,
  Plus
} from 'lucide-react';
import { ROCKET_MILESTONES, RocketMilestone, RocketRoomState } from '../types';
import { rocketService } from '../rocketService';
import { rocketSoundEngine } from '../rocketSoundEngine';

interface RocketCornerPanelProps {
  roomId: string;
  rocketState: RocketRoomState;
  onOpenGiftBox?: () => void;
}

export const RocketCornerPanel: React.FC<RocketCornerPanelProps> = ({
  roomId,
  rocketState,
  onOpenGiftBox
}) => {
  const [isExpanded, setIsExpanded] = useState(false);
  const [isMuted, setIsMuted] = useState(() => rocketSoundEngine.getMuted());
  const [showTestMenu, setShowTestMenu] = useState(false);

  const toggleMute = () => {
    const next = !isMuted;
    setIsMuted(next);
    rocketSoundEngine.setMuted(next);
  };

  const currentCoins = rocketState.currentCoins;
  const completedIds = new Set(rocketState.completedRockets);

  // Find next uncompleted rocket
  const nextRocket = ROCKET_MILESTONES.find(m => !completedIds.has(m.id)) || ROCKET_MILESTONES[ROCKET_MILESTONES.length - 1];

  const handleTestLaunch = (rocketId: number) => {
    rocketService.testTriggerLaunch(roomId, rocketId);
    setShowTestMenu(false);
  };

  const handleAddTestCoins = (coins: number) => {
    rocketService.addTestCoins(roomId, coins);
  };

  return (
    <div
      id="snyvo-rocket-corner-panel"
      className="w-full bg-gradient-to-r from-neutral-950/90 via-neutral-900/85 to-neutral-950/90 border border-violet-500/25 hover:border-violet-400/40 rounded-2xl p-2 sm:p-2.5 shadow-lg backdrop-blur-md transition-all relative overflow-hidden"
    >
      {/* Background ambient cosmic glow */}
      <div className="absolute -top-10 -right-10 w-28 h-28 bg-violet-600/10 rounded-full blur-2xl pointer-events-none" />
      <div className="absolute -bottom-10 -left-10 w-28 h-28 bg-amber-500/10 rounded-full blur-2xl pointer-events-none" />

      {/* Top Header Bar */}
      <div className="flex items-center justify-between gap-1 mb-1.5 px-0.5">
        <div className="flex items-center space-x-1.5 min-w-0">
          <div className="w-5 h-5 rounded-full bg-gradient-to-tr from-amber-500 to-rose-600 flex items-center justify-center shadow-xs">
            <Rocket className="w-3 h-3 text-white animate-bounce" />
          </div>
          <div className="flex items-center space-x-1">
            <span className="text-[11px] font-extrabold text-white tracking-wide uppercase truncate">
              Rocket Progress
            </span>
            <span className="text-[10px] font-bold text-amber-400 bg-amber-950/70 border border-amber-500/30 px-1.5 py-0.2 rounded-full">
              🪙 {rocketService.formatCoins(currentCoins)}
            </span>
          </div>
        </div>

        {/* Controls: Audio mute, Expand/Collapse, Test trigger */}
        <div className="flex items-center space-x-1 shrink-0">
          {onOpenGiftBox && (
            <button
              id="rocket-panel-quick-gift-btn"
              onClick={onOpenGiftBox}
              className="text-[9px] font-bold text-white bg-gradient-to-r from-rose-600 to-amber-500 hover:brightness-110 px-2 py-0.5 rounded-full shadow-xs active:scale-95 transition-all flex items-center space-x-1 cursor-pointer"
              title="Send Gift to Boost Rocket Progress"
            >
              <span>🎁</span>
              <span className="hidden xs:inline">Boost</span>
            </button>
          )}

          <button
            id="rocket-sound-toggle-btn"
            onClick={toggleMute}
            className="p-1 rounded-md text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors cursor-pointer"
            title={isMuted ? 'Unmute Rocket SFX' : 'Mute Rocket SFX'}
          >
            {isMuted ? <VolumeX className="w-3 h-3 text-red-400" /> : <Volume2 className="w-3 h-3 text-emerald-400" />}
          </button>

          <button
            id="rocket-panel-expand-btn"
            onClick={() => setIsExpanded(!isExpanded)}
            className="p-1 rounded-md text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors cursor-pointer"
            title={isExpanded ? 'Collapse' : 'Expand Details'}
          >
            {isExpanded ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
          </button>
        </div>
      </div>

      {/* 5 ROCKETS LIVE COIN COUNT GRID (Small, Clean & Premium) */}
      <div
        id="snyvo-rocket-milestones-grid"
        className="grid grid-cols-5 gap-1 sm:gap-1.5"
      >
        {ROCKET_MILESTONES.map((milestone) => {
          const isCompleted = completedIds.has(milestone.id);
          const isCurrentTarget = nextRocket.id === milestone.id;
          const progressPercent = Math.min(100, Math.max(0, (currentCoins / milestone.targetCoins) * 100));

          // Tier accent borders and colors
          const getTierStyle = () => {
            switch (milestone.id) {
              case 1:
                return { ring: 'from-amber-500 to-orange-500', text: 'text-amber-400', border: 'border-amber-500/40' };
              case 2:
                return { ring: 'from-red-500 to-orange-500', text: 'text-orange-400', border: 'border-red-500/40' };
              case 3:
                return { ring: 'from-pink-500 to-violet-500', text: 'text-pink-400', border: 'border-pink-500/40' };
              case 4:
                return { ring: 'from-violet-500 to-indigo-500', text: 'text-violet-400', border: 'border-violet-500/40' };
              case 5:
              default:
                return { ring: 'from-cyan-400 via-violet-500 to-amber-400', text: 'text-cyan-300', border: 'border-cyan-400/40' };
            }
          };

          const style = getTierStyle();

          return (
            <div
              key={`rocket-slot-${milestone.id}`}
              id={`rocket-card-${milestone.id}`}
              className={`flex flex-col items-center justify-between p-1 sm:p-1.5 rounded-xl border transition-all relative select-none ${
                isCompleted
                  ? 'bg-emerald-950/30 border-emerald-500/40 shadow-xs'
                  : isCurrentTarget
                  ? 'bg-neutral-900/90 border-amber-400/60 shadow-md shadow-amber-500/10 ring-1 ring-amber-400/30'
                  : 'bg-neutral-950/60 border-neutral-800/80 opacity-80'
              }`}
              title={`${milestone.name} Milestone: ${milestone.formattedTarget} Coins (${milestone.description})`}
            >
              {/* Rocket Top Indicator */}
              <div className="relative flex items-center justify-center my-0.5">
                {isCompleted ? (
                  <div className="w-5 h-5 rounded-full bg-emerald-500/20 border border-emerald-400/50 flex items-center justify-center">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                  </div>
                ) : (
                  <div
                    className={`w-5 h-5 rounded-full flex items-center justify-center transition-transform ${
                      isCurrentTarget ? 'scale-110' : ''
                    }`}
                  >
                    <span className="text-xs leading-none">🚀</span>
                    {isCurrentTarget && (
                      <span className="absolute -bottom-1 w-1.5 h-1.5 rounded-full bg-amber-400 animate-ping" />
                    )}
                  </div>
                )}
              </div>

              {/* Rocket Label & Number */}
              <div className="text-center w-full min-w-0 mt-0.5">
                <span className="text-[9px] font-extrabold text-neutral-300 block truncate leading-tight">
                  R{milestone.id}
                </span>

                {/* EXACT LIVE COIN COUNT SPECIFIED BY USER */}
                {isCompleted ? (
                  <span className="text-[8px] sm:text-[9px] font-bold text-emerald-400 block truncate leading-tight mt-0.5">
                    ✅ {milestone.formattedTarget} Done
                  </span>
                ) : (
                  <span className="text-[8px] sm:text-[9px] font-bold text-neutral-200 block truncate leading-tight mt-0.5">
                    {rocketService.formatCoins(currentCoins)} / {milestone.formattedTarget}
                  </span>
                )}
              </div>

              {/* Mini Progress Bar */}
              <div className="w-full bg-neutral-800 rounded-full h-1 mt-1 overflow-hidden">
                <div
                  className={`h-full transition-all duration-500 ${
                    isCompleted
                      ? 'bg-emerald-400'
                      : isCurrentTarget
                      ? `bg-gradient-to-r ${style.ring}`
                      : 'bg-neutral-600'
                  }`}
                  style={{ width: `${progressPercent}%` }}
                />
              </div>
            </div>
          );
        })}
      </div>

      {/* Expanded Details & Simulator for testing/demonstrating launches */}
      {isExpanded && (
        <div className="mt-2.5 pt-2 border-t border-neutral-800/80 text-xs space-y-2 animate-fade-in">
          <div className="flex items-center justify-between text-[10px] text-neutral-400">
            <span className="flex items-center space-x-1">
              <Sparkles className="w-3 h-3 text-amber-400" />
              <span>Target: <strong className="text-white">{nextRocket.name}</strong> ({nextRocket.description})</span>
            </span>
            <span>
              Remaining: <strong className="text-amber-300">
                {rocketService.formatCoins(Math.max(0, nextRocket.targetCoins - currentCoins))}
              </strong> Coins
            </span>
          </div>

          {/* Quick Coin Simulator Buttons to demonstrate Real-Time updates & Launch */}
          <div className="bg-neutral-950/80 rounded-xl p-2 border border-neutral-800 flex flex-wrap items-center justify-between gap-1.5">
            <span className="text-[10px] font-semibold text-neutral-400">
              ⚡ Demo Live Boost:
            </span>
            <div className="flex items-center space-x-1">
              <button
                onClick={() => handleAddTestCoins(100_000)}
                className="text-[10px] bg-amber-950/70 hover:bg-amber-900 border border-amber-600/40 text-amber-300 font-bold px-2 py-0.5 rounded-md cursor-pointer transition-colors active:scale-95"
                title="Send +100,000 Coins Gift"
              >
                +100K Coins
              </button>
              <button
                onClick={() => handleAddTestCoins(500_000)}
                className="text-[10px] bg-amber-950/70 hover:bg-amber-900 border border-amber-600/40 text-amber-300 font-bold px-2 py-0.5 rounded-md cursor-pointer transition-colors active:scale-95"
                title="Send +500,000 Coins Gift"
              >
                +500K Coins
              </button>
              <button
                onClick={() => setShowTestMenu(!showTestMenu)}
                className="text-[10px] bg-violet-950/70 hover:bg-violet-900 border border-violet-600/40 text-violet-300 font-bold px-2 py-0.5 rounded-md cursor-pointer transition-colors active:scale-95"
                title="Test Specific Rocket Launch Event"
              >
                🚀 Test Launch ▾
              </button>
            </div>
          </div>

          {/* Test Launch Menu */}
          {showTestMenu && (
            <div className="grid grid-cols-5 gap-1 pt-1">
              {ROCKET_MILESTONES.map((m) => (
                <button
                  key={`test-launch-${m.id}`}
                  onClick={() => handleTestLaunch(m.id)}
                  className="py-1 px-1 rounded-lg bg-neutral-800 hover:bg-violet-900/60 border border-neutral-700 hover:border-violet-500 text-center cursor-pointer transition-all active:scale-95"
                >
                  <span className="text-[9px] font-bold text-white block">R{m.id} ({m.formattedTarget})</span>
                  <span className="text-[8px] text-neutral-400 block truncate">{m.tierName}</span>
                </button>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
