export interface RocketMilestone {
  id: number; // 1 to 5
  level: number;
  name: string;
  targetCoins: number;
  formattedTarget: string; // "2M", "5M", "10M", "15M", "20M"
  tierName: 'Small' | 'Medium' | 'Large' | 'Mega' | 'Ultra';
  tierBadge: string;
  rocketSize: 'sm' | 'md' | 'lg' | 'xl' | '2xl';
  soundDurationMs: number;
  flameColors: string[];
  description: string;
}

export const ROCKET_MILESTONES: RocketMilestone[] = [
  {
    id: 1,
    level: 1,
    name: 'Rocket 1',
    targetCoins: 2_000_000,
    formattedTarget: '2M',
    tierName: 'Small',
    tierBadge: '🚀 Rocket 1',
    rocketSize: 'sm',
    soundDurationMs: 2500,
    flameColors: ['#f97316', '#fbbf24', '#f59e0b'],
    description: 'Small Rocket - Short Launch SFX'
  },
  {
    id: 2,
    level: 2,
    name: 'Rocket 2',
    targetCoins: 5_000_000,
    formattedTarget: '5M',
    tierName: 'Medium',
    tierBadge: '🚀 Rocket 2',
    rocketSize: 'md',
    soundDurationMs: 3500,
    flameColors: ['#ef4444', '#f97316', '#eab308'],
    description: 'Medium Rocket - Medium Launch Sound'
  },
  {
    id: 3,
    level: 3,
    name: 'Rocket 3',
    targetCoins: 10_000_000,
    formattedTarget: '10M',
    tierName: 'Large',
    tierBadge: '🚀 Rocket 3',
    rocketSize: 'lg',
    soundDurationMs: 4500,
    flameColors: ['#ec4899', '#8b5cf6', '#3b82f6'],
    description: 'Large Rocket - Cinematic Rocket Sound'
  },
  {
    id: 4,
    level: 4,
    name: 'Rocket 4',
    targetCoins: 15_000_000,
    formattedTarget: '15M',
    tierName: 'Mega',
    tierBadge: '🚀 Rocket 4',
    rocketSize: 'xl',
    soundDurationMs: 5500,
    flameColors: ['#8b5cf6', '#ec4899', '#f43f5e', '#fbbf24'],
    description: 'Mega Rocket - Premium Launch Music + SFX'
  },
  {
    id: 5,
    level: 5,
    name: 'Rocket 5',
    targetCoins: 20_000_000,
    formattedTarget: '20M',
    tierName: 'Ultra',
    tierBadge: '🚀 Rocket 5 (Ultra)',
    rocketSize: '2xl',
    soundDurationMs: 7000,
    flameColors: ['#38bdf8', '#818cf8', '#c084fc', '#f43f5e', '#fbbf24'],
    description: 'Ultra Rocket - Premium Cinematic Music + Rocket Launch SFX + Celebration'
  }
];

export interface RocketRoomState {
  roomId: string;
  currentCoins: number;
  completedRockets: number[]; // e.g. [1] or [1, 2]
  lastUpdated: number;
}

export interface RocketLaunchEvent {
  rocket: RocketMilestone;
  currentCoins: number;
  senderName?: string;
  giftName?: string;
  startedAt: number;
}
