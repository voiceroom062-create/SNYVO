// SNYVO Chat System Type Definitions
// Prepared for real-time WebSocket / SSE / Firestore messaging architecture

import { User } from '../types';

export type ChatRole = 'host' | 'cohost' | 'moderator' | 'speaker' | 'listener';

export interface ChatBadgeInfo {
  name: string;
  color: string;
  icon?: string;
  bg?: string;
}

export interface RoomChatMessage {
  id: string;
  roomId: string;
  senderId: string;
  senderName: string;
  senderHandle: string;
  senderAvatar: string;
  senderRole: ChatRole;
  senderLevel?: number;
  senderBadge?: ChatBadgeInfo;
  text: string;
  timestamp: number;
  time: string;
  isDeleted?: boolean;
  isPinned?: boolean;
  replyTo?: {
    id: string;
    senderName: string;
    text: string;
  };
}

export type ModerationActionType = 'delete_message' | 'mute_user' | 'block_user' | 'report_user';

export interface ChatModerationLog {
  id: string;
  action: ModerationActionType;
  actorId: string;
  actorName: string;
  targetUserId: string;
  targetUserName: string;
  targetMessageId?: string;
  reason?: string;
  timestamp: number;
  roomId?: string;
}

export interface DirectConversation {
  id: string;
  participant: User;
  lastMessage: {
    text: string;
    timestamp: number;
    time: string;
    isFromMe: boolean;
    unread: boolean;
  };
  unreadCount: number;
  isPinned?: boolean;
  isFriend?: boolean;
  category: 'all' | 'friends' | 'official' | 'groups';
  draftText?: string;
}

export interface DirectChatMessage {
  id: string;
  conversationId: string;
  senderId: string;
  recipientId: string;
  text: string;
  timestamp: number;
  time: string;
  status: 'sent' | 'delivered' | 'read';
  isFromMe: boolean;
}
