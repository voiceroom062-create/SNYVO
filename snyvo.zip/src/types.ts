export interface User {
  id: string;
  name: string;
  handle: string;
  avatar: string;
  bio: string;
  followers: number;
  following: number;
  roomsHosted: number;
  clubs: string[];
  interests: string[];
  isVerified?: boolean;
  numericId?: string;
  level?: number;
  vipLevel?: number | null;
  isOnline?: boolean;
  currentRoomId?: string | null;
  currentRoomTitle?: string | null;
  photos?: string[];
  country?: string;
  countryFlag?: string;
  signature?: string;
  gender?: 'male' | 'female' | 'secret' | string;
  age?: number;
  showAge?: boolean;
  sendingLevel?: number;
  receivingLevel?: number;
  totalCoinsSent?: number;
  totalCoinsReceived?: number;
}

export interface LevelBadge {
  level: number;
  type: 'sending' | 'receiving';
  tierName: string;
  gradient: string;
  badgeBg: string;
  textColor: string;
  borderColor: string;
  icon: string;
  glowColor: string;
}

export interface LevelUpEvent {
  userId: string;
  userName: string;
  userAvatar: string;
  type: 'sending' | 'receiving';
  oldLevel: number;
  newLevel: number;
  totalCoins: number;
  badge: LevelBadge;
}

export interface GiftItem {
  id: string;
  name: string;
  icon: string;
  category?: string;
  coinValue: number;
}

export interface ReceivedGift {
  id: string;
  giftId: string;
  giftName: string;
  giftIcon: string;
  quantity: number;
  coinValue?: number; // Total 100% gift value in coins
  receiverCoins?: number; // 30% receiver share credited to ID balance
  status?: 'Completed';
  senderId: string;
  senderName: string;
  senderHandle: string;
  senderAvatar?: string;
  senderNumericId: string;
  receiverId?: string;
  receiverNumericId?: string;
  receivedAt: string;
  isoDate?: string;
}

export interface SentGift {
  id: string;
  giftId: string;
  giftName: string;
  giftIcon: string;
  quantity: number;
  coinValue?: number; // Total 100% gift value in coins
  receiverCoins?: number; // 30% receiver share
  status?: 'Completed';
  recipientId: string;
  recipientName: string;
  recipientHandle: string;
  recipientAvatar?: string;
  recipientNumericId: string;
  sentAt: string;
  isoDate?: string;
}

export interface DirectMessage {
  id: string;
  senderId: string;
  recipientId: string;
  text: string;
  timestamp: string;
  delivered: boolean;
  seen: boolean;
}

// ==========================================
// REAL-TIME VOICE SYSTEM TYPES & STATES
// ==========================================

export type MicrophoneState = 
  | 'off'                     // Mic OFF
  | 'on'                      // Mic ON
  | 'muted_by_host'           // Muted by Host/Moderator
  | 'permission_denied'       // Permission denied
  | 'permission_granted';     // Permission granted (ready/idle)

export type MicrophonePermissionStatus = 'prompt' | 'granted' | 'denied' | 'unsupported';

export type UserRoomRole = 'host' | 'cohost' | 'moderator' | 'speaker' | 'listener';

export type SeatStatus = 'empty' | 'occupied' | 'speaking' | 'muted';

export interface SpeakerSeat {
  seatIndex: number;
  status: SeatStatus;
  user?: Speaker | null;
  isLocked?: boolean;
  micState?: MicrophoneState;
}

export type RealtimeConnectionState = 
  | 'disconnected' 
  | 'connecting' 
  | 'connected' 
  | 'reconnecting' 
  | 'unavailable'
  | 'error';

export interface Speaker {
  id: string;
  name: string;
  handle: string;
  avatar: string;
  isHost: boolean;
  isModerator: boolean;
  isCoHost?: boolean;
  role?: UserRoomRole;
  isMuted: boolean;
  isSpeaking: boolean;
  micState?: MicrophoneState;
  seatStatus?: SeatStatus;
  raisedHand?: boolean;
  seatIndex?: number;
  userIdDisplay?: string;
  vipLevel?: number;
  userLevel?: number;
  coins?: number;
}

export interface Listener {
  id: string;
  name: string;
  handle: string;
  avatar: string;
  role?: UserRoomRole;
  raisedHand?: boolean;
  micState?: MicrophoneState;
}

export interface RoomParticipant {
  id: string;
  name: string;
  handle: string;
  avatar: string;
  role: UserRoomRole;
  micState: MicrophoneState;
  seatIndex?: number;
  isSpeaking: boolean;
}

export interface SpeakerRequest {
  id: string;
  userId: string;
  userName: string;
  userHandle: string;
  userAvatar: string;
  requestedAt: string;
  status: 'pending' | 'accepted' | 'declined';
}

export interface VoiceRoom {
  id: string;
  title: string;
  clubName?: string;
  topic: string;
  description: string;
  host: User;
  hostId?: string;
  moderatorIds?: string[];
  coHostIds?: string[];
  participants?: RoomParticipant[];
  speakers: Speaker[];
  listeners: Listener[];
  listenerCount: number;
  seats?: SpeakerSeat[];
  micStates?: Record<string, MicrophoneState>;
  connectionState?: RealtimeConnectionState;
  audioServiceStatus?: 'not_connected' | 'connecting' | 'connected' | 'error';
  isLive: boolean;
  startedAt: string;
  tags: string[];
  speakerRequests?: SpeakerRequest[];
  maxSeats?: number;
  lockedSeats?: number[];
  roomCoins?: number;
  coverImage?: string;
  isHot?: boolean;
  country?: string;
  countryCode?: string;
  activityScore?: number;
  giftsReceivedCount?: number;
  rankingScore?: number;
}

export interface ScheduledEvent {
  id: string;
  title: string;
  clubName: string;
  time: string;
  hostName: string;
  hostAvatar: string;
  interestedCount: number;
  isReminded: boolean;
}

export type ScreenType = 
  | 'splash'
  | 'login'
  | 'signup'
  | 'home'
  | 'room'
  | 'profile'
  | 'explore'
  | 'activity'
  | 'chat';

export * from './types/chat';

export interface ReactionParticle {
  id: string;
  emoji: string;
  x: number;
  senderName: string;
}
