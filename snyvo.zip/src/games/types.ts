import { User } from '../types';

export type GameCategory = 'free' | 'coin';

export interface GameDefinition {
  id: string;
  title: string;
  category: GameCategory;
  entryCoins: number;
  minPlayers: number;
  maxPlayers: number;
  icon: string;
  bannerGradient: string;
  tagline: string;
  description: string;
  rules: string[];
  isAvailable: boolean;
  accentColor: string;
}

export interface GamePlayer {
  userId: string;
  numericId: string;
  name: string;
  avatar: string;
  seatIndex: number;
  color: string;
  isReady: boolean;
  isHost: boolean;
  isBot?: boolean;
  score: number;
  coins?: number;
}

export interface CoinTransaction {
  id: string;
  userId: string;
  type: 'game_entry' | 'game_reward' | 'gift' | 'daily_reward' | 'coin_purchase';
  amount: number; // negative for deduction, positive for reward
  gameId?: string;
  gameTitle?: string;
  matchId?: string;
  timestamp: string;
  balanceAfter: number;
  referenceId: string;
  description: string;
  giftValue?: number; // 100% full gift coin value
  receiverShare?: number; // 30% receiver share
  status?: 'Completed';
}

export interface GameHistoryItem {
  id: string;
  gameId: string;
  gameTitle: string;
  gameIcon: string;
  roomId: string;
  roomTitle: string;
  category: GameCategory;
  entryFee: number;
  reward: number;
  timestamp: string;
  players: {
    userId: string;
    numericId: string;
    name: string;
    avatar: string;
    score: number;
    isWinner: boolean;
    color: string;
  }[];
  winnerName: string;
  winnerId: string;
  winnerNumericId: string;
  winnerAvatar: string;
  transactionId?: string;
}

export interface ActiveMatchState {
  matchId: string;
  gameId: string;
  roomId: string;
  category: GameCategory;
  entryCoins: number;
  prizePool: number;
  players: GamePlayer[];
  currentTurnIndex: number;
  status: 'lobby' | 'playing' | 'finished';
  winner: GamePlayer | null;
  startedAt: string;
  endedAt?: string;
  transactionId?: string;
}
