import { CoinTransaction } from './types';

// Default authentic coin balances for users in SNYVO
// Current user (Alex Vance / usr_me) has a creator wallet balance capable of testing gifts & games
const INITIAL_USER_BALANCES: Record<string, number> = {
  'usr_me': 1000000, // 1,000,000 Coins for testing full gift ecosystem & mega animations
  'usr_guest': 1000000,
  'usr_1': 45000, // Maya Lin
  'usr_2': 31000, // Kofi Mensah
  'usr_4': 22000, // Elena Rostova
  'usr_5': 58000, // Dr. Sarah Thorne
  'usr_8': 39000, // Oliver King
  'usr_9': 18000, // Chloe Zhang
  'lis_1': 9500,  // David Chen
  'lis_2': 14000, // Sophia Williams
  'lis_3': 6000,  // Marcus Bell
};

const STORAGE_KEY_BALANCES = 'snyvo_coin_balances_v1';
const STORAGE_KEY_TRANSACTIONS = 'snyvo_coin_transactions_v1';
const STORAGE_KEY_PROCESSED_TX = 'snyvo_processed_transactions_v1';

class WalletService {
  private balances: Record<string, number> = {};
  private transactions: CoinTransaction[] = [];
  private processedTransactions: Set<string> = new Set();
  private subscribers: (() => void)[] = [];

  constructor() {
    this.loadState();
  }

  private loadState() {
    // Balances
    const savedBalances = localStorage.getItem(STORAGE_KEY_BALANCES);
    if (savedBalances) {
      try {
        this.balances = JSON.parse(savedBalances);
        // Ensure user has sufficient coins to test the new premium gift levels
        if ((this.balances['usr_me'] || 0) < 100000) {
          this.balances['usr_me'] = 1000000;
          this.balances['usr_guest'] = 1000000;
          this.saveBalances();
        }
      } catch (e) {
        this.balances = { ...INITIAL_USER_BALANCES };
      }
    } else {
      this.balances = { ...INITIAL_USER_BALANCES };
      this.saveBalances();
    }

    // Transactions
    const savedTx = localStorage.getItem(STORAGE_KEY_TRANSACTIONS);
    if (savedTx) {
      try {
        this.transactions = JSON.parse(savedTx);
      } catch (e) {
        this.transactions = [];
      }
    }

    // Processed transactions for deduplication
    const savedProcessed = localStorage.getItem(STORAGE_KEY_PROCESSED_TX);
    if (savedProcessed) {
      try {
        const arr = JSON.parse(savedProcessed);
        this.processedTransactions = new Set(arr);
      } catch (e) {
        this.processedTransactions = new Set();
      }
    }
  }

  private saveBalances() {
    try {
      localStorage.setItem(STORAGE_KEY_BALANCES, JSON.stringify(this.balances));
    } catch (e) {
      // ignore
    }
  }

  private saveTransactions() {
    try {
      localStorage.setItem(STORAGE_KEY_TRANSACTIONS, JSON.stringify(this.transactions));
    } catch (e) {
      // ignore
    }
  }

  private saveProcessed() {
    try {
      localStorage.setItem(STORAGE_KEY_PROCESSED_TX, JSON.stringify(Array.from(this.processedTransactions)));
    } catch (e) {
      // ignore
    }
  }

  public subscribe(callback: () => void): () => void {
    this.subscribers.push(callback);
    return () => {
      this.subscribers = this.subscribers.filter(cb => cb !== callback);
    };
  }

  private notify() {
    this.subscribers.forEach(cb => cb());
  }

  public getBalance(userId: string): number {
    const key = (userId === 'usr_guest') ? 'usr_me' : userId;
    if (this.balances[key] === undefined) {
      // Deterministic realistic balance for any new user (50 - 150)
      this.balances[key] = 80;
      this.saveBalances();
    }
    return this.balances[key];
  }

  public canAfford(userId: string, requiredCoins: number): {
    allowed: boolean;
    currentBalance: number;
    required: number;
    difference: number;
  } {
    const balance = this.getBalance(userId);
    return {
      allowed: balance >= requiredCoins,
      currentBalance: balance,
      required: requiredCoins,
      difference: Math.max(0, requiredCoins - balance),
    };
  }

  /**
   * Deducts entry fee for a game match.
   * Enforces security, balance validation, and idempotency (prevents double deduction for same match/user).
   */
  public deductGameEntry(
    userId: string,
    amount: number,
    gameId: string,
    gameTitle: string,
    matchId: string
  ): { success: boolean; transaction?: CoinTransaction; error?: string } {
    if (amount <= 0) {
      return { success: true };
    }

    const key = (userId === 'usr_guest') ? 'usr_me' : userId;
    const idempotencyKey = `entry_${matchId}_${key}`;

    if (this.processedTransactions.has(idempotencyKey)) {
      // Already deducted for this match - idempotent success
      return { success: true };
    }

    const currentBalance = this.getBalance(key);
    if (currentBalance < amount) {
      return {
        success: false,
        error: `Not Enough Coins. Required: ${amount} 🪙, Available: ${currentBalance} 🪙`,
      };
    }

    const newBalance = currentBalance - amount;
    this.balances[key] = newBalance;
    this.saveBalances();

    const tx: CoinTransaction = {
      id: `tx_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      userId: key,
      type: 'game_entry',
      amount: -amount,
      gameId,
      gameTitle,
      matchId,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      balanceAfter: newBalance,
      referenceId: idempotencyKey,
      description: `Entry fee for ${gameTitle}`,
    };

    this.transactions.unshift(tx);
    this.saveTransactions();

    this.processedTransactions.add(idempotencyKey);
    this.saveProcessed();

    this.notify();
    return { success: true, transaction: tx };
  }

  /**
   * Awards game prize pool to winner.
   * Validates idempotency to prevent duplicate prize distribution.
   */
  public awardGamePrize(
    userId: string,
    amount: number,
    gameId: string,
    gameTitle: string,
    matchId: string
  ): { success: boolean; transaction?: CoinTransaction } {
    if (amount <= 0) {
      return { success: true };
    }

    const key = (userId === 'usr_guest') ? 'usr_me' : userId;
    const idempotencyKey = `prize_${matchId}_${key}`;

    if (this.processedTransactions.has(idempotencyKey)) {
      return { success: true };
    }

    const currentBalance = this.getBalance(key);
    const newBalance = currentBalance + amount;
    this.balances[key] = newBalance;
    this.saveBalances();

    const tx: CoinTransaction = {
      id: `tx_win_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      userId: key,
      type: 'game_reward',
      amount: amount,
      gameId,
      gameTitle,
      matchId,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      balanceAfter: newBalance,
      referenceId: idempotencyKey,
      description: `1st Place Prize in ${gameTitle}`,
    };

    this.transactions.unshift(tx);
    this.saveTransactions();

    this.processedTransactions.add(idempotencyKey);
    this.saveProcessed();

    this.notify();
    return { success: true, transaction: tx };
  }

  public getTransactions(userId: string): CoinTransaction[] {
    const key = (userId === 'usr_guest') ? 'usr_me' : userId;
    return this.transactions.filter(t => t.userId === key);
  }

  /**
   * Authoritative credit for coin purchases verified by admin.
   * Enforces idempotency against double credit, updates balance, and logs clear ledger transaction.
   */
  public creditPurchasedCoins(
    userId: string,
    amount: number,
    orderId: string,
    packageName: string,
    trxId: string,
    amountBdt: number
  ): { success: boolean; error?: string; newBalance?: number; transaction?: CoinTransaction } {
    if (amount <= 0) {
      return { success: false, error: 'Invalid coin amount' };
    }

    const key = (userId === 'usr_guest') ? 'usr_me' : userId;
    const idempotencyKey = `coin_purchase_${orderId}`;

    if (this.processedTransactions.has(idempotencyKey)) {
      return {
        success: true,
        newBalance: this.getBalance(key),
      };
    }

    const currentBalance = this.getBalance(key);
    const newBalance = currentBalance + amount;
    this.balances[key] = newBalance;
    this.saveBalances();

    const tx: CoinTransaction = {
      id: `tx_buy_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      userId: key,
      type: 'coin_purchase',
      amount: amount,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      balanceAfter: newBalance,
      referenceId: idempotencyKey,
      description: `Purchased ${packageName} (+${amount.toLocaleString()} 🪙 / ৳${amountBdt}) [TrxID: ${trxId}]`,
      status: 'Completed',
    };

    this.transactions.unshift(tx);
    this.saveTransactions();

    this.processedTransactions.add(idempotencyKey);
    this.saveProcessed();

    this.notify();
    return { success: true, newBalance, transaction: tx };
  }

  /**
   * Calculate 30% Receiver Share according to SNYVO rules:
   * Receiver Coin = Gift Coin × 30 / 100
   * 1,000 -> 300
   * 10,000 -> 3,000
   * 50,000 -> 15,000
   * 100,000 -> 30,000
   * 500,000 -> 150,000
   */
  public calculateReceiverShare(totalCoins: number): number {
    return Math.floor((totalCoins * 30) / 100);
  }

  /**
   * Secure server-authoritative transfer of gift coins with 30% Receiver Share:
   * 1. Sender pays 100% of gift value (deducted from sender's ID balance)
   * 2. Receiver gets verified 30% credit (added to receiver's ID balance)
   * 3. Remaining 70% is NOT credited to receiver
   * 4. Enforces balance verification, idempotency against replay/duplicate credit, and persistent ledger records.
   */
  public transferGiftCoins(
    senderId: string,
    receiverId: string,
    totalCoins: number,
    giftName: string,
    quantity: number,
    giftTransactionId: string
  ): {
    success: boolean;
    error?: string;
    senderBalance?: number;
    receiverBalance?: number;
    receiverCoins?: number;
    transaction?: CoinTransaction;
  } {
    if (totalCoins <= 0) {
      return { success: false, error: 'Invalid gift amount' };
    }

    const sKey = (senderId === 'usr_guest') ? 'usr_me' : senderId;
    const rKey = (receiverId === 'usr_guest') ? 'usr_me' : receiverId;
    const idempotencyKey = `gift_${giftTransactionId}`;

    if (this.processedTransactions.has(idempotencyKey)) {
      return {
        success: true,
        senderBalance: this.getBalance(sKey),
        receiverBalance: this.getBalance(rKey),
        receiverCoins: this.calculateReceiverShare(totalCoins),
      };
    }

    const senderBalance = this.getBalance(sKey);
    if (senderBalance < totalCoins) {
      return {
        success: false,
        error: `Not Enough Coins. Required: ${totalCoins.toLocaleString()} 🪙, Available: ${senderBalance.toLocaleString()} 🪙`,
        senderBalance,
      };
    }

    // 1. Deduct 100% full gift value from sender
    const newSenderBal = senderBalance - totalCoins;
    this.balances[sKey] = newSenderBal;

    // 2. Calculate exact 30% Receiver Share
    // Receiver Coin = Gift Coin × 30 / 100
    const receiverCoins = this.calculateReceiverShare(totalCoins);

    // 3. Credit 30% to receiver's ID balance
    const receiverBal = this.getBalance(rKey);
    const newReceiverBal = receiverBal + receiverCoins;
    this.balances[rKey] = newReceiverBal;

    this.saveBalances();

    // 4. Record sender transaction (debit 100%)
    const senderTx: CoinTransaction = {
      id: `tx_gift_out_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      userId: sKey,
      type: 'gift',
      amount: -totalCoins,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      balanceAfter: newSenderBal,
      referenceId: idempotencyKey,
      description: `Sent ${quantity}x ${giftName} (-${totalCoins.toLocaleString()} 🪙)`,
      giftValue: totalCoins,
      receiverShare: receiverCoins,
      status: 'Completed',
    };

    // 5. Record receiver transaction (credit 30% Share)
    const receiverTx: CoinTransaction = {
      id: `tx_gift_in_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      userId: rKey,
      type: 'gift',
      amount: receiverCoins,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      balanceAfter: newReceiverBal,
      referenceId: idempotencyKey,
      description: `Received ${quantity}x ${giftName} (+${receiverCoins.toLocaleString()} 🪙 / 30% Share)`,
      giftValue: totalCoins,
      receiverShare: receiverCoins,
      status: 'Completed',
    };

    this.transactions.unshift(senderTx);
    this.transactions.unshift(receiverTx);
    this.saveTransactions();

    this.processedTransactions.add(idempotencyKey);
    this.saveProcessed();

    this.notify();
    return {
      success: true,
      senderBalance: newSenderBal,
      receiverBalance: newReceiverBal,
      receiverCoins,
      transaction: senderTx,
    };
  }

  /**
   * Top-up coins (for seamless testing of mega gifts & creator transactions)
   */
  public topUpCoins(userId: string, amount: number): { success: boolean; newBalance: number } {
    return this.addCoins(userId, amount, `Added ${amount.toLocaleString()} 🪙 (Top-Up)`);
  }

  /**
   * Add coins to user's wallet with custom description
   */
  public addCoins(userId: string, amount: number, description?: string): { success: boolean; newBalance: number } {
    const key = (userId === 'usr_guest') ? 'usr_me' : userId;
    const current = this.getBalance(key);
    const newBal = current + amount;
    this.balances[key] = newBal;
    this.saveBalances();

    const tx: CoinTransaction = {
      id: `tx_reward_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      userId: key,
      type: 'daily_reward',
      amount,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      balanceAfter: newBal,
      referenceId: `rew_${Date.now()}`,
      description: description || `Reward: +${amount.toLocaleString()} 🪙`,
    };
    this.transactions.unshift(tx);
    this.saveTransactions();

    this.notify();
    return { success: true, newBalance: newBal };
  }
}

export const walletService = new WalletService();
