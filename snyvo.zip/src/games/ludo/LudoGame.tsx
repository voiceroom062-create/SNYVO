import React, { useState, useEffect } from 'react';
import { Dice1, Dice2, Dice3, Dice4, Dice5, Dice6, Play, Award, Sparkles } from 'lucide-react';
import { GamePlayer } from '../types';

interface LudoGameProps {
  players: GamePlayer[];
  currentTurnIndex: number;
  onTurnEnd: (nextTurnIndex: number, updatedPlayers: GamePlayer[]) => void;
  onGameEnd: (winner: GamePlayer, finalPlayers: GamePlayer[]) => void;
}

interface LudoToken {
  id: number;
  playerIndex: number;
  inYard: boolean;
  step: number; // 0 = start, 56 = home
  isHome: boolean;
}

const PLAYER_COLORS = [
  { name: 'Red', hex: '#ef4444', bg: 'bg-red-500', yard: 'bg-red-950/60 border-red-500' },
  { name: 'Green', hex: '#10b981', bg: 'bg-emerald-500', yard: 'bg-emerald-950/60 border-emerald-500' },
  { name: 'Yellow', hex: '#f59e0b', bg: 'bg-amber-500', yard: 'bg-amber-950/60 border-amber-500' },
  { name: 'Blue', hex: '#3b82f6', bg: 'bg-blue-500', yard: 'bg-blue-950/60 border-blue-500' }
];

const DICE_ICONS = [Dice1, Dice2, Dice3, Dice4, Dice5, Dice6];

export const LudoGame: React.FC<LudoGameProps> = ({
  players,
  currentTurnIndex,
  onTurnEnd,
  onGameEnd
}) => {
  // Each player has 2 tokens in this fast-paced voice room version for smooth responsive matches
  const [tokens, setTokens] = useState<LudoToken[]>(() => {
    const list: LudoToken[] = [];
    players.forEach((_, pIdx) => {
      list.push({ id: pIdx * 2, playerIndex: pIdx, inYard: true, step: 0, isHome: false });
      list.push({ id: pIdx * 2 + 1, playerIndex: pIdx, inYard: true, step: 0, isHome: false });
    });
    return list;
  });

  const [diceValue, setDiceValue] = useState<number>(6); // start on 6 for easy opener
  const [isRolling, setIsRolling] = useState<boolean>(false);
  const [canMoveToken, setCanMoveToken] = useState<boolean>(false);
  const [statusMsg, setStatusMsg] = useState<string>('Roll the dice to begin!');

  const currentPlayer = players[currentTurnIndex] || players[0];
  const colorTheme = PLAYER_COLORS[currentTurnIndex % PLAYER_COLORS.length];

  // Auto-play for Bot
  useEffect(() => {
    if (currentPlayer.isBot) {
      if (!isRolling && !canMoveToken) {
        const timer = setTimeout(() => handleRollDice(), 900);
        return () => clearTimeout(timer);
      } else if (canMoveToken) {
        const timer = setTimeout(() => {
          // Find any movable token
          const myTokens = tokens.filter(t => t.playerIndex === currentTurnIndex && !t.isHome);
          const yardToken = myTokens.find(t => t.inYard);
          const activeToken = myTokens.find(t => !t.inYard);

          if (diceValue === 6 && yardToken) {
            handleMoveToken(yardToken.id);
          } else if (activeToken) {
            handleMoveToken(activeToken.id);
          } else if (yardToken && diceValue === 6) {
            handleMoveToken(yardToken.id);
          } else {
            // Cannot move, pass turn
            passTurn();
          }
        }, 800);
        return () => clearTimeout(timer);
      }
    }
  }, [currentPlayer, isRolling, canMoveToken, currentTurnIndex, diceValue, tokens]);

  const handleRollDice = () => {
    if (isRolling || canMoveToken) return;
    setIsRolling(true);

    let count = 0;
    const interval = setInterval(() => {
      setDiceValue(Math.floor(Math.random() * 6) + 1);
      count++;
      if (count > 6) {
        clearInterval(interval);
        const finalVal = Math.floor(Math.random() * 6) + 1;
        setDiceValue(finalVal);
        setIsRolling(false);
        checkMovable(finalVal);
      }
    }, 80);
  };

  const checkMovable = (roll: number) => {
    const myTokens = tokens.filter(t => t.playerIndex === currentTurnIndex && !t.isHome);
    const hasYard = myTokens.some(t => t.inYard);
    const hasActive = myTokens.some(t => !t.inYard);

    if (roll === 6 && (hasYard || hasActive)) {
      setCanMoveToken(true);
      setStatusMsg('Tap a token to release or advance!');
    } else if (hasActive) {
      setCanMoveToken(true);
      setStatusMsg('Tap an active token to move!');
    } else {
      // Cannot move any token
      setStatusMsg(`Rolled ${roll}. No movable tokens! Passing turn...`);
      setTimeout(() => {
        passTurn();
      }, 1000);
    }
  };

  const handleMoveToken = (tokenId: number) => {
    const targetToken = tokens.find(t => t.id === tokenId);
    if (!targetToken || targetToken.playerIndex !== currentTurnIndex || targetToken.isHome) return;

    if (targetToken.inYard) {
      if (diceValue !== 6) return; // Need a 6 to open
      // Open token to start track
      const updated = tokens.map(t => (t.id === tokenId ? { ...t, inYard: false, step: 1 } : t));
      setTokens(updated);
      setCanMoveToken(false);
      setStatusMsg('Token released into the arena! Rolled 6 = Roll again!');
      // Rolled 6 grants extra turn
      return;
    }

    // Move active token forward
    let nextStep = targetToken.step + diceValue;
    let isHome = false;
    if (nextStep >= 28) {
      // Reached Home goal!
      nextStep = 28;
      isHome = true;
    }

    // Update tokens & check captures
    let captureOccurred = false;
    const updated = tokens.map(t => {
      if (t.id === tokenId) {
        return { ...t, step: nextStep, isHome };
      }
      // Check capture on opponent non-home tokens (except safe spots: step 1, 9, 17)
      if (!isHome && !t.inYard && !t.isHome && t.playerIndex !== currentTurnIndex && t.step === nextStep) {
        if (nextStep !== 1 && nextStep !== 9 && nextStep !== 17) {
          captureOccurred = true;
          return { ...t, inYard: true, step: 0 };
        }
      }
      return t;
    });

    setTokens(updated);
    setCanMoveToken(false);

    // Calculate score for player
    const myHomeCount = updated.filter(t => t.playerIndex === currentTurnIndex && t.isHome).length;
    const newScore = (players[currentTurnIndex].score || 0) + (isHome ? 50 : diceValue * 2) + (captureOccurred ? 25 : 0);

    const updatedPlayers = players.map((p, idx) => ({
      ...p,
      score: idx === currentTurnIndex ? newScore : p.score
    }));

    // Check Win Condition (both tokens home)
    if (myHomeCount >= 2) {
      setStatusMsg(`🏆 ${currentPlayer.name} brought all tokens home and won!`);
      setTimeout(() => {
        onGameEnd(currentPlayer, updatedPlayers);
      }, 1000);
      return;
    }

    if (diceValue === 6 || captureOccurred) {
      setStatusMsg(captureOccurred ? 'Opponent captured! Extra turn!' : 'Rolled 6! Roll again!');
    } else {
      passTurn(updatedPlayers);
    }
  };

  const passTurn = (updatedPlayersList?: GamePlayer[]) => {
    setCanMoveToken(false);
    const nextIndex = (currentTurnIndex + 1) % players.length;
    const finalPlayers = updatedPlayersList || players;
    setStatusMsg(`${finalPlayers[nextIndex].name}'s turn`);
    onTurnEnd(nextIndex, finalPlayers);
  };

  const DiceIconComponent = DICE_ICONS[diceValue - 1] || Dice1;

  return (
    <div className="flex flex-col items-center w-full max-w-sm mx-auto select-none">
      {/* Top Turn Header */}
      <div className="w-full flex items-center justify-between px-3 py-1.5 bg-neutral-900/90 rounded-xl border border-neutral-800 text-[11px] mb-2">
        <div className="flex items-center space-x-2">
          <div className={`w-3 h-3 rounded-full ${colorTheme.bg}`} />
          <span className="text-white font-bold">{currentPlayer.name}&apos;s Turn</span>
        </div>
        <span className="text-[10px] text-neutral-400">
          Target: <span className="text-amber-400 font-bold">Home Triangle</span>
        </span>
      </div>

      {/* Ludo Board Area */}
      <div className="relative w-[340px] h-[340px] bg-neutral-950 border-4 border-neutral-800 rounded-2xl shadow-2xl p-2 flex flex-col justify-between overflow-hidden">
        {/* 4 Quadrants: Red, Green, Yellow, Blue yards */}
        <div className="grid grid-cols-2 gap-2 h-full">
          {players.slice(0, 4).map((p, pIdx) => {
            const theme = PLAYER_COLORS[pIdx % PLAYER_COLORS.length];
            const pTokens = tokens.filter(t => t.playerIndex === pIdx);
            const isTurn = pIdx === currentTurnIndex;

            return (
              <div
                key={p.userId}
                className={`rounded-xl p-2 flex flex-col justify-between border-2 transition-all ${theme.yard} ${
                  isTurn ? 'ring-2 ring-white/60' : 'opacity-85'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold text-white truncate max-w-[80px]">
                    {p.name}
                  </span>
                  <span className="text-[9px] font-mono px-1 py-0.5 rounded bg-black/40 text-neutral-300">
                    {pTokens.filter(t => t.isHome).length}/2 Home
                  </span>
                </div>

                {/* Tokens inside yard or on track */}
                <div className="flex items-center justify-center space-x-3 py-2">
                  {pTokens.map(tok => {
                    const canClick = isTurn && canMoveToken && !tok.isHome && (tok.inYard ? diceValue === 6 : true);

                    return (
                      <button
                        key={tok.id}
                        type="button"
                        onClick={() => canClick && handleMoveToken(tok.id)}
                        disabled={!canClick}
                        style={{ backgroundColor: theme.hex }}
                        className={`w-9 h-9 rounded-full border-2 border-white shadow-lg flex flex-col items-center justify-center transition-transform ${
                          tok.isHome
                            ? 'bg-amber-400 border-amber-200'
                            : canClick
                            ? 'animate-bounce cursor-pointer scale-110 ring-4 ring-white/70'
                            : 'opacity-90'
                        }`}
                      >
                        <span className="text-[9px] font-extrabold text-white">
                          {tok.isHome ? '👑' : tok.inYard ? 'Base' : `${tok.step}`}
                        </span>
                      </button>
                    );
                  })}
                </div>

                <div className="flex items-center justify-between text-[9px] text-neutral-300">
                  <span>Score: {p.score || 0}</span>
                  {isTurn && <span className="text-amber-300 font-bold">Active</span>}
                </div>
              </div>
            );
          })}
        </div>

        {/* Center Home Triangle Visual */}
        <div className="absolute inset-0 m-auto w-16 h-16 rounded-full bg-gradient-to-tr from-violet-600 via-amber-500 to-indigo-600 border-4 border-neutral-900 shadow-2xl flex items-center justify-center text-white text-xs font-extrabold pointer-events-none">
          🏆
        </div>
      </div>

      {/* Dice & Control Deck */}
      <div className="w-full mt-2.5 p-3 rounded-2xl bg-neutral-900/90 border border-neutral-800 flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div
            onClick={!currentPlayer.isBot && !isRolling && !canMoveToken ? handleRollDice : undefined}
            className={`w-14 h-14 rounded-2xl ${colorTheme.bg} flex items-center justify-center text-white shadow-lg border-2 border-white/40 cursor-pointer transition-transform ${
              isRolling ? 'animate-spin scale-110' : 'hover:scale-105 active:scale-95'
            }`}
          >
            <DiceIconComponent className="w-8 h-8 stroke-[2.2]" />
          </div>

          <div>
            <p className="text-xs font-bold text-white">
              {isRolling ? 'Rolling...' : `Rolled: ${diceValue}`}
            </p>
            <p className="text-[11px] text-neutral-400">
              {canMoveToken ? 'Select token to move' : 'Tap dice to roll'}
            </p>
          </div>
        </div>

        <button
          onClick={handleRollDice}
          disabled={isRolling || canMoveToken || currentPlayer.isBot}
          className={`px-4 py-2.5 rounded-xl font-bold text-xs transition-all shadow-md cursor-pointer ${
            isRolling || canMoveToken || currentPlayer.isBot
              ? 'bg-neutral-800 text-neutral-500 cursor-not-allowed'
              : 'bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-500 hover:to-indigo-500 text-white shadow-violet-600/30 active:scale-95'
          }`}
        >
          <span>Roll Dice</span>
        </button>
      </div>

      <p className="mt-1.5 text-[10px] text-neutral-400 text-center truncate">{statusMsg}</p>
    </div>
  );
};
