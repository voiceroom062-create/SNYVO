import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Play, RotateCcw, Target, Award, Sparkles } from 'lucide-react';
import { GamePlayer } from '../types';

interface CarromGameProps {
  players: GamePlayer[];
  currentTurnIndex: number;
  onTurnEnd: (nextTurnIndex: number, updatedPlayers: GamePlayer[]) => void;
  onGameEnd: (winner: GamePlayer, finalPlayers: GamePlayer[]) => void;
}

interface Puck {
  id: string;
  type: 'white' | 'black' | 'queen';
  x: number; // 0 to 400
  y: number; // 0 to 400
  vx: number;
  vy: number;
  radius: number;
  points: number;
  inPocket: boolean;
}

const BOARD_SIZE = 380;
const CORNER_OFFSET = 28;
const POCKET_RADIUS = 18;
const POCKETS = [
  { x: CORNER_OFFSET, y: CORNER_OFFSET },
  { x: BOARD_SIZE - CORNER_OFFSET, y: CORNER_OFFSET },
  { x: CORNER_OFFSET, y: BOARD_SIZE - CORNER_OFFSET },
  { x: BOARD_SIZE - CORNER_OFFSET, y: BOARD_SIZE - CORNER_OFFSET }
];

export const CarromGame: React.FC<CarromGameProps> = ({
  players,
  currentTurnIndex,
  onTurnEnd,
  onGameEnd
}) => {
  const [playerScores, setPlayerScores] = useState<number[]>(players.map(p => p.score || 0));
  const [strikerX, setStrikerX] = useState<number>(BOARD_SIZE / 2);
  const [aimAngle, setAimAngle] = useState<number>(270); // facing upwards
  const [strikerPower, setStrikerPower] = useState<number>(55);
  const [isShooting, setIsShooting] = useState<boolean>(false);
  const [statusMessage, setStatusMessage] = useState<string>('Aim and adjust power to strike!');
  const [lastPocketEvent, setLastPocketEvent] = useState<string | null>(null);

  const currentPlayer = players[currentTurnIndex] || players[0];

  // Initialize Pucks around center (Center is 190, 190)
  const [pucks, setPucks] = useState<Puck[]>(() => {
    const initial: Puck[] = [];
    const cx = BOARD_SIZE / 2;
    const cy = BOARD_SIZE / 2;

    // Queen in center
    initial.push({
      id: 'queen',
      type: 'queen',
      x: cx,
      y: cy,
      vx: 0,
      vy: 0,
      radius: 9,
      points: 25,
      inPocket: false
    });

    // Inner circle of 6 pucks
    for (let i = 0; i < 6; i++) {
      const angle = (i * 60 * Math.PI) / 180;
      const isWhite = i % 2 === 0;
      initial.push({
        id: `inner_${i}`,
        type: isWhite ? 'white' : 'black',
        x: cx + Math.cos(angle) * 22,
        y: cy + Math.sin(angle) * 22,
        vx: 0,
        vy: 0,
        radius: 8.5,
        points: isWhite ? 10 : 5,
        inPocket: false
      });
    }

    // Outer circle of 6 pucks
    for (let i = 0; i < 6; i++) {
      const angle = ((i * 60 + 30) * Math.PI) / 180;
      const isWhite = i % 2 === 1;
      initial.push({
        id: `outer_${i}`,
        type: isWhite ? 'white' : 'black',
        x: cx + Math.cos(angle) * 44,
        y: cy + Math.sin(angle) * 44,
        vx: 0,
        vy: 0,
        radius: 8.5,
        points: isWhite ? 10 : 5,
        inPocket: false
      });
    }

    return initial;
  });

  // Striker state
  const strikerRef = useRef({
    x: BOARD_SIZE / 2,
    y: BOARD_SIZE - 48,
    vx: 0,
    vy: 0,
    radius: 12,
    inPocket: false
  });

  // Animation frame loop
  const animRef = useRef<number | null>(null);

  // Check game over
  useEffect(() => {
    const remainingPucks = pucks.filter(p => !p.inPocket);
    if (remainingPucks.length === 0) {
      // Find highest score
      let highestIndex = 0;
      let highestScore = -999;
      playerScores.forEach((score, idx) => {
        if (score > highestScore) {
          highestScore = score;
          highestIndex = idx;
        }
      });
      const winner = players[highestIndex];
      const finalPlayers = players.map((p, idx) => ({ ...p, score: playerScores[idx] }));
      onGameEnd(winner, finalPlayers);
    }
  }, [pucks, playerScores, players, onGameEnd]);

  // AI Turn automation if current player is a bot
  useEffect(() => {
    if (currentPlayer.isBot && !isShooting) {
      const timer = setTimeout(() => {
        // AI chooses an angle aiming roughly toward a remaining puck
        const activePucks = pucks.filter(p => !p.inPocket);
        if (activePucks.length > 0) {
          const target = activePucks[Math.floor(Math.random() * activePucks.length)];
          const dx = target.x - strikerX;
          const dy = target.y - (BOARD_SIZE - 48);
          let angleDeg = (Math.atan2(dy, dx) * 180) / Math.PI;
          if (angleDeg < 0) angleDeg += 360;
          setAimAngle(angleDeg);
          setStrikerPower(50 + Math.random() * 35);
          setTimeout(() => {
            handleShoot();
          }, 600);
        }
      }, 1200);
      return () => clearTimeout(timer);
    }
  }, [currentPlayer, isShooting, pucks, strikerX]);

  const handleShoot = useCallback(() => {
    if (isShooting) return;
    setIsShooting(true);
    setStatusMessage(`${currentPlayer.name} strikes!`);

    const speed = (strikerPower / 100) * 16;
    const rad = (aimAngle * Math.PI) / 180;
    strikerRef.current.x = strikerX;
    strikerRef.current.y = BOARD_SIZE - 48;
    strikerRef.current.vx = Math.cos(rad) * speed;
    strikerRef.current.vy = Math.sin(rad) * speed;
    strikerRef.current.inPocket = false;

    let pocketedPointsThisTurn = 0;
    let strikerFoul = false;

    const FRICTION = 0.965;
    const MIN_SPEED = 0.15;

    const updatePhysics = () => {
      let isMoving = false;

      // Update Striker
      const s = strikerRef.current;
      if (!s.inPocket && (Math.abs(s.vx) > MIN_SPEED || Math.abs(s.vy) > MIN_SPEED)) {
        isMoving = true;
        s.x += s.vx;
        s.y += s.vy;
        s.vx *= FRICTION;
        s.vy *= FRICTION;

        // Border bounces
        if (s.x < 18 + s.radius) { s.x = 18 + s.radius; s.vx = -s.vx * 0.8; }
        if (s.x > BOARD_SIZE - 18 - s.radius) { s.x = BOARD_SIZE - 18 - s.radius; s.vx = -s.vx * 0.8; }
        if (s.y < 18 + s.radius) { s.y = 18 + s.radius; s.vy = -s.vy * 0.8; }
        if (s.y > BOARD_SIZE - 18 - s.radius) { s.y = BOARD_SIZE - 18 - s.radius; s.vy = -s.vy * 0.8; }

        // Check striker pocket
        POCKETS.forEach(p => {
          const dist = Math.hypot(s.x - p.x, s.y - p.y);
          if (dist < POCKET_RADIUS + 2) {
            s.inPocket = true;
            s.vx = 0;
            s.vy = 0;
            strikerFoul = true;
          }
        });
      }

      // Update Pucks
      setPucks(prevPucks => {
        const nextPucks = prevPucks.map(puck => {
          if (puck.inPocket) return puck;

          let px = puck.x + puck.vx;
          let py = puck.y + puck.vy;
          let pvx = puck.vx * FRICTION;
          let pvy = puck.vy * FRICTION;

          if (Math.abs(pvx) > MIN_SPEED || Math.abs(pvy) > MIN_SPEED) {
            isMoving = true;
          }

          // Border collision
          if (px < 18 + puck.radius) { px = 18 + puck.radius; pvx = -pvx * 0.8; }
          if (px > BOARD_SIZE - 18 - puck.radius) { px = BOARD_SIZE - 18 - puck.radius; pvx = -pvx * 0.8; }
          if (py < 18 + puck.radius) { py = 18 + puck.radius; pvy = -pvy * 0.8; }
          if (py > BOARD_SIZE - 18 - puck.radius) { py = BOARD_SIZE - 18 - puck.radius; pvy = -pvy * 0.8; }

          // Check pocket
          let inPocket = false;
          POCKETS.forEach(pocket => {
            const dist = Math.hypot(px - pocket.x, py - pocket.y);
            if (dist < POCKET_RADIUS + 4) {
              inPocket = true;
              pvx = 0;
              pvy = 0;
              pocketedPointsThisTurn += puck.points;
            }
          });

          // Collision with striker
          if (!s.inPocket) {
            const sDist = Math.hypot(px - s.x, py - s.y);
            if (sDist < puck.radius + s.radius) {
              const nx = (px - s.x) / (sDist || 1);
              const ny = (py - s.y) / (sDist || 1);
              const push = 1.2;
              pvx += nx * (Math.abs(s.vx) + Math.abs(s.vy)) * push;
              pvy += ny * (Math.abs(s.vx) + Math.abs(s.vy)) * push;
              s.vx *= 0.5;
              s.vy *= 0.5;
            }
          }

          return { ...puck, x: px, y: py, vx: pvx, vy: pvy, inPocket };
        });

        return nextPucks;
      });

      if (isMoving) {
        animRef.current = requestAnimationFrame(updatePhysics);
      } else {
        // Shot ended
        setIsShooting(false);
        strikerRef.current.x = BOARD_SIZE / 2;
        strikerRef.current.y = BOARD_SIZE - 48;
        strikerRef.current.vx = 0;
        strikerRef.current.vy = 0;
        strikerRef.current.inPocket = false;

        let turnScoreGain = pocketedPointsThisTurn;
        if (strikerFoul) {
          turnScoreGain -= 5;
          setLastPocketEvent('Striker Foul! (-5 pts)');
        } else if (pocketedPointsThisTurn > 0) {
          setLastPocketEvent(`Pocketed! +${pocketedPointsThisTurn} pts ✨`);
        } else {
          setLastPocketEvent(null);
        }

        const newScores = [...playerScores];
        newScores[currentTurnIndex] = Math.max(0, newScores[currentTurnIndex] + turnScoreGain);
        setPlayerScores(newScores);

        const updated = players.map((p, idx) => ({ ...p, score: newScores[idx] }));

        // If player pocketed a coin and didn't foul, they get another shot!
        const bonusShot = pocketedPointsThisTurn > 0 && !strikerFoul;
        if (bonusShot) {
          setStatusMessage(`${currentPlayer.name} pocketed! Extra shot awarded! 🎯`);
        } else {
          const nextIndex = (currentTurnIndex + 1) % players.length;
          setStatusMessage(`Turn passed to ${players[nextIndex].name}`);
          onTurnEnd(nextIndex, updated);
        }
      }
    };

    animRef.current = requestAnimationFrame(updatePhysics);
  }, [aimAngle, currentTurnIndex, currentPlayer.name, isShooting, onTurnEnd, playerScores, players, strikerPower, strikerX]);

  useEffect(() => {
    return () => {
      if (animRef.current) cancelAnimationFrame(animRef.current);
    };
  }, []);

  const remainingWhite = pucks.filter(p => !p.inPocket && p.type === 'white').length;
  const remainingBlack = pucks.filter(p => !p.inPocket && p.type === 'black').length;
  const queenPocketed = pucks.find(p => p.type === 'queen')?.inPocket;

  return (
    <div className="flex flex-col items-center w-full max-w-sm mx-auto select-none">
      {/* Mini Score strip */}
      <div className="w-full flex items-center justify-between px-2 py-1.5 bg-neutral-900/90 rounded-xl border border-neutral-800 text-[11px] mb-2">
        <div className="flex items-center space-x-1.5">
          <Target className="w-3.5 h-3.5 text-amber-400" />
          <span className="text-neutral-300 font-semibold">{currentPlayer.name}&apos;s Shot</span>
        </div>
        <div className="flex items-center space-x-2 text-[10px]">
          <span className="text-neutral-400">⚪ {remainingWhite}</span>
          <span className="text-neutral-400">⚫ {remainingBlack}</span>
          <span className={queenPocketed ? 'text-neutral-500 line-through' : 'text-rose-400 font-bold'}>👑 Queen</span>
        </div>
      </div>

      {/* SVG Carrom Board */}
      <div className="relative w-[340px] h-[340px] bg-[#deb887] border-[12px] border-[#5c3a21] rounded-2xl shadow-2xl overflow-hidden flex-shrink-0">
        {/* Subtle wood texture & concentric design */}
        <div className="absolute inset-0 bg-gradient-to-br from-[#deb887] via-[#d2a679] to-[#c79c5e] opacity-95" />

        <svg viewBox={`0 0 ${BOARD_SIZE} ${BOARD_SIZE}`} className="absolute inset-0 w-full h-full">
          {/* Outer Border Lines */}
          <rect x="18" y="18" width={BOARD_SIZE - 36} height={BOARD_SIZE - 36} fill="none" stroke="#8b4513" strokeWidth="1.5" />
          <rect x="22" y="22" width={BOARD_SIZE - 44} height={BOARD_SIZE - 44} fill="none" stroke="#8b4513" strokeWidth="0.8" opacity="0.6" />

          {/* Corner Pockets */}
          {POCKETS.map((pkt, idx) => (
            <g key={idx}>
              <circle cx={pkt.x} cy={pkt.y} r={POCKET_RADIUS} fill="#1a1a1a" />
              <circle cx={pkt.x} cy={pkt.y} r={POCKET_RADIUS - 2} fill="#0d0d0d" />
              <circle cx={pkt.x} cy={pkt.y} r={POCKET_RADIUS} fill="none" stroke="#8b4513" strokeWidth="2" />
            </g>
          ))}

          {/* Center Circle & Star */}
          <circle cx={BOARD_SIZE / 2} cy={BOARD_SIZE / 2} r="38" fill="none" stroke="#8b4513" strokeWidth="1.5" />
          <circle cx={BOARD_SIZE / 2} cy={BOARD_SIZE / 2} r="14" fill="#a0522d" opacity="0.3" />
          <circle cx={BOARD_SIZE / 2} cy={BOARD_SIZE / 2} r="4" fill="#8b4513" />

          {/* Player Baselines */}
          <line x1="60" y1={BOARD_SIZE - 48} x2={BOARD_SIZE - 60} y2={BOARD_SIZE - 48} stroke="#8b4513" strokeWidth="1.5" strokeDasharray="3,3" />
          <circle cx="60" cy={BOARD_SIZE - 48} r="8" fill="#8b4513" opacity="0.3" />
          <circle cx={BOARD_SIZE - 60} cy={BOARD_SIZE - 48} r="8" fill="#8b4513" opacity="0.3" />

          {/* Pucks */}
          {pucks.map(puck => {
            if (puck.inPocket) return null;
            let fill = '#ffffff';
            let stroke = '#d1d5db';
            if (puck.type === 'black') {
              fill = '#1f2937';
              stroke = '#111827';
            } else if (puck.type === 'queen') {
              fill = '#ef4444';
              stroke = '#b91c1c';
            }
            return (
              <g key={puck.id}>
                <circle cx={puck.x} cy={puck.y} r={puck.radius} fill={fill} stroke={stroke} strokeWidth="1.5" className="drop-shadow-sm" />
                <circle cx={puck.x} cy={puck.y} r={puck.radius * 0.4} fill="none" stroke={stroke} strokeWidth="0.8" opacity="0.7" />
              </g>
            );
          })}

          {/* Striker */}
          {!strikerRef.current.inPocket && (
            <g>
              <circle
                cx={isShooting ? strikerRef.current.x : strikerX}
                cy={isShooting ? strikerRef.current.y : BOARD_SIZE - 48}
                r={strikerRef.current.radius}
                fill="#f59e0b"
                stroke="#b45309"
                strokeWidth="2.5"
                className="drop-shadow-md"
              />
              <circle
                cx={isShooting ? strikerRef.current.x : strikerX}
                cy={isShooting ? strikerRef.current.y : BOARD_SIZE - 48}
                r="4"
                fill="#78350f"
              />
            </g>
          )}

          {/* Aim Direction Line (Only before shooting) */}
          {!isShooting && (
            <line
              x1={strikerX}
              y1={BOARD_SIZE - 48}
              x2={strikerX + Math.cos((aimAngle * Math.PI) / 180) * (strikerPower * 0.9)}
              y2={BOARD_SIZE - 48 + Math.sin((aimAngle * Math.PI) / 180) * (strikerPower * 0.9)}
              stroke="#ef4444"
              strokeWidth="2"
              strokeDasharray="4,4"
              strokeLinecap="round"
            />
          )}
        </svg>

        {/* Pocket Notification Banner */}
        {lastPocketEvent && (
          <div className="absolute top-2 inset-x-4 py-1 px-3 bg-neutral-950/90 border border-amber-500/50 rounded-full text-center text-xs font-bold text-amber-300 animate-fade-in shadow-lg">
            {lastPocketEvent}
          </div>
        )}
      </div>

      {/* Controls Bar */}
      <div className="w-full mt-2.5 space-y-2 bg-neutral-900/90 p-3 rounded-2xl border border-neutral-800 text-xs">
        {/* Baseline Position Slider */}
        <div className="flex items-center space-x-2">
          <span className="text-[10px] text-neutral-400 font-medium w-14">Position:</span>
          <input
            type="range"
            min="70"
            max={BOARD_SIZE - 70}
            value={strikerX}
            disabled={isShooting || currentPlayer.isBot}
            onChange={e => setStrikerX(Number(e.target.value))}
            className="flex-1 accent-amber-500 cursor-pointer h-1.5 bg-neutral-800 rounded-lg"
          />
        </div>

        {/* Aim Angle Slider */}
        <div className="flex items-center space-x-2">
          <span className="text-[10px] text-neutral-400 font-medium w-14">Aim:</span>
          <input
            type="range"
            min="200"
            max="340"
            value={aimAngle}
            disabled={isShooting || currentPlayer.isBot}
            onChange={e => setAimAngle(Number(e.target.value))}
            className="flex-1 accent-violet-500 cursor-pointer h-1.5 bg-neutral-800 rounded-lg"
          />
          <span className="text-[10px] text-neutral-400 font-mono w-8 text-right">{aimAngle}°</span>
        </div>

        {/* Strike Power Slider */}
        <div className="flex items-center space-x-2">
          <span className="text-[10px] text-neutral-400 font-medium w-14">Power:</span>
          <input
            type="range"
            min="20"
            max="100"
            value={strikerPower}
            disabled={isShooting || currentPlayer.isBot}
            onChange={e => setStrikerPower(Number(e.target.value))}
            className="flex-1 accent-rose-500 cursor-pointer h-1.5 bg-neutral-800 rounded-lg"
          />
          <span className="text-[10px] text-neutral-400 font-mono w-8 text-right">{strikerPower}%</span>
        </div>

        {/* Strike Button */}
        <button
          onClick={handleShoot}
          disabled={isShooting || currentPlayer.isBot}
          className={`w-full py-2.5 rounded-xl font-bold text-xs flex items-center justify-center space-x-2 transition-all cursor-pointer ${
            isShooting || currentPlayer.isBot
              ? 'bg-neutral-800 text-neutral-500 cursor-not-allowed'
              : 'bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-500 hover:to-orange-500 text-white shadow-md shadow-amber-600/30 active:scale-95'
          }`}
        >
          <Play className="w-3.5 h-3.5 fill-current" />
          <span>{currentPlayer.isBot ? 'Bot is Aiming...' : 'Strike Now!'}</span>
        </button>

        <p className="text-[10px] text-neutral-400 text-center truncate">{statusMessage}</p>
      </div>
    </div>
  );
};
