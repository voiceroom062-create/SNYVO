import React, { useState, useEffect, useRef } from 'react';
import { Zap, AlertCircle, Award, Flame } from 'lucide-react';
import { GamePlayer } from '../types';

interface ReactionGameProps {
  players: GamePlayer[];
  currentTurnIndex: number;
  prizePool: number;
  onTurnEnd: (nextTurnIndex: number, updatedPlayers: GamePlayer[]) => void;
  onGameEnd: (winner: GamePlayer, finalPlayers: GamePlayer[]) => void;
}

export const ReactionGame: React.FC<ReactionGameProps> = ({
  players,
  prizePool,
  onGameEnd
}) => {
  const [round, setRound] = useState<number>(1);
  const [gameState, setGameState] = useState<'waiting' | 'ready' | 'flash' | 'round_result'>('waiting');
  const [reactionTimes, setReactionTimes] = useState<Record<string, number | null>>({});
  const [scores, setScores] = useState<Record<string, number>>(() => {
    const s: Record<string, number> = {};
    players.forEach(p => { s[p.userId] = 0; });
    return s;
  });
  const [feedback, setFeedback] = useState<string>('Round 1: Get ready...');

  const startTimeRef = useRef<number>(0);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  // Start round cycle
  useEffect(() => {
    startNewRound();
    return () => {
      if (timerRef.current) clearTimeout(timerRef.current);
    };
  }, [round]);

  const startNewRound = () => {
    setGameState('ready');
    setFeedback(`Round ${round} of 3: Wait for GREEN... Do not tap yet!`);
    setReactionTimes({});

    // Random delay between 1.8s and 4.5s
    const delay = Math.floor(Math.random() * 2700) + 1800;
    timerRef.current = setTimeout(() => {
      setGameState('flash');
      startTimeRef.current = Date.now();
      setFeedback('⚡ TAP THE BUZZER NOW! ⚡');

      // Trigger bot reaction times realistically
      players.forEach(p => {
        if (p.isBot) {
          const botTime = Math.floor(Math.random() * 260) + 240; // 240-500ms
          setTimeout(() => {
            recordReaction(p.userId, botTime);
          }, botTime);
        }
      });
    }, delay);
  };

  const recordReaction = (userId: string, timeMs: number) => {
    setReactionTimes(prev => {
      if (prev[userId] !== undefined) return prev; // already tapped
      return { ...prev, [userId]: timeMs };
    });
  };

  const handleBuzzerTap = () => {
    const userPlayer = players.find(p => !p.isBot) || players[0];

    if (gameState === 'ready') {
      // False start!
      if (timerRef.current) clearTimeout(timerRef.current);
      setGameState('round_result');
      setFeedback(`⚠️ False start! ${userPlayer.name} tapped too early! (-50 pts)`);
      setScores(prev => ({
        ...prev,
        [userPlayer.userId]: Math.max(0, (prev[userPlayer.userId] || 0) - 50)
      }));
      setTimeout(() => advanceRound(), 2500);
      return;
    }

    if (gameState === 'flash') {
      const elapsed = Date.now() - startTimeRef.current;
      recordReaction(userPlayer.userId, elapsed);
    }
  };

  // Check if all players recorded their reaction time for the round
  useEffect(() => {
    if (gameState === 'flash') {
      const tappedCount = Object.keys(reactionTimes).length;
      if (tappedCount >= players.length) {
        // Round complete, calculate points
        setGameState('round_result');

        // Sort by fastest time
        const sorted = Object.entries(reactionTimes).sort((a, b) => {
          const valA = a[1] !== null && a[1] !== undefined ? Number(a[1]) : 9999;
          const valB = b[1] !== null && b[1] !== undefined ? Number(b[1]) : 9999;
          return valA - valB;
        });
        const winnerEntry = sorted[0];
        const winnerPlayer = players.find(p => p.userId === winnerEntry[0]);

        const roundPoints = 100;
        setScores(prev => ({
          ...prev,
          [winnerEntry[0]]: (prev[winnerEntry[0]] || 0) + roundPoints
        }));

        setFeedback(`⚡ ${winnerPlayer?.name} was fastest with ${winnerEntry[1]}ms! (+100 pts)`);
        setTimeout(() => advanceRound(), 2500);
      }
    }
  }, [reactionTimes, gameState, players]);

  const advanceRound = () => {
    if (round < 3) {
      setRound(prev => prev + 1);
    } else {
      // Game Over! Determine overall winner
      let highestUserId = players[0].userId;
      let highestScore = -999;

      Object.entries(scores).forEach(([uId, sVal]) => {
        const s = Number(sVal);
        if (s > highestScore) {
          highestScore = s;
          highestUserId = uId;
        }
      });

      const winner = players.find(p => p.userId === highestUserId) || players[0];
      const finalPlayers = players.map(p => ({
        ...p,
        score: scores[p.userId] || 0
      }));

      onGameEnd(winner, finalPlayers);
    }
  };

  const userPlayer = players.find(p => !p.isBot) || players[0];
  const userTime = reactionTimes[userPlayer.userId];

  return (
    <div className="flex flex-col items-center w-full max-w-sm mx-auto select-none">
      {/* Top Banner with Prize Pool */}
      <div className="w-full flex items-center justify-between px-3 py-2 bg-neutral-900/90 rounded-xl border border-yellow-500/30 text-xs mb-2">
        <div className="flex items-center space-x-1.5">
          <Zap className="w-4 h-4 text-yellow-400" />
          <span className="text-white font-bold">Round {round}/3</span>
        </div>
        <div className="flex items-center space-x-1 px-2.5 py-0.5 rounded-full bg-yellow-950/60 border border-yellow-500/40 text-yellow-300 font-bold text-xs">
          <span>Prize: 🪙 {prizePool}</span>
        </div>
      </div>

      {/* Main Flash Area */}
      <div
        onClick={handleBuzzerTap}
        className={`relative w-[340px] h-[300px] rounded-3xl border-4 flex flex-col items-center justify-center p-6 text-center shadow-2xl transition-all cursor-pointer ${
          gameState === 'ready'
            ? 'bg-red-950/80 border-red-500 shadow-red-950/50'
            : gameState === 'flash'
            ? 'bg-emerald-600 border-emerald-300 scale-105 shadow-emerald-500/50 animate-pulse'
            : 'bg-neutral-900 border-neutral-800'
        }`}
      >
        {gameState === 'ready' && (
          <div className="space-y-3">
            <div className="w-16 h-16 rounded-full bg-red-600/30 border-2 border-red-500 flex items-center justify-center mx-auto text-red-400 animate-pulse">
              <AlertCircle className="w-8 h-8" />
            </div>
            <h3 className="text-xl font-black text-red-300 uppercase tracking-wider">WAIT FOR GREEN</h3>
            <p className="text-xs text-red-200/80">Tapping now results in a penalty!</p>
          </div>
        )}

        {gameState === 'flash' && (
          <div className="space-y-2">
            <Zap className="w-16 h-16 text-white mx-auto animate-bounce" />
            <h2 className="text-3xl font-black text-white tracking-widest">TAP NOW!</h2>
            {userTime !== undefined && (
              <p className="text-base font-bold text-yellow-200">Your Time: {userTime} ms!</p>
            )}
          </div>
        )}

        {gameState === 'round_result' && (
          <div className="space-y-2">
            <Award className="w-12 h-12 text-yellow-400 mx-auto" />
            <h3 className="text-sm font-bold text-white">Round Completed</h3>
            <p className="text-xs text-yellow-300 font-medium">{feedback}</p>
          </div>
        )}

        {gameState === 'waiting' && (
          <div className="space-y-2">
            <h3 className="text-base font-bold text-white">Get Ready...</h3>
          </div>
        )}
      </div>

      {/* Live Player Reflex Table */}
      <div className="w-full mt-3 p-3 rounded-2xl bg-neutral-900/90 border border-neutral-800 space-y-2 text-xs">
        <span className="text-[10px] font-bold uppercase tracking-wider text-neutral-400">
          Match Standings
        </span>
        <div className="grid grid-cols-2 gap-2">
          {players.map(p => (
            <div
              key={p.userId}
              className="p-2 rounded-xl bg-neutral-950/70 border border-neutral-800/80 flex items-center justify-between"
            >
              <div className="flex items-center space-x-2 min-w-0">
                <img src={p.avatar} alt={p.name} className="w-6 h-6 rounded-full object-cover" />
                <span className="text-[11px] font-bold text-white truncate">{p.name.split(' ')[0]}</span>
              </div>
              <span className="text-xs font-mono font-bold text-yellow-400">{scores[p.userId] || 0} pts</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
