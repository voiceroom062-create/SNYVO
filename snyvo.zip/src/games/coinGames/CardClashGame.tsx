import React, { useState, useEffect } from 'react';
import { Layers, Sparkles, Award, Play } from 'lucide-react';
import { GamePlayer } from '../types';

interface CardClashGameProps {
  players: GamePlayer[];
  currentTurnIndex: number;
  prizePool: number;
  onTurnEnd: (nextTurnIndex: number, updatedPlayers: GamePlayer[]) => void;
  onGameEnd: (winner: GamePlayer, finalPlayers: GamePlayer[]) => void;
}

interface Card {
  suit: '♠' | '♥' | '♦' | '♣';
  val: number;
  name: string;
}

const SUITS: ('♠' | '♥' | '♦' | '♣')[] = ['♠', '♥', '♦', '♣'];

function generateHand(): Card[] {
  const cards: Card[] = [];
  for (let i = 0; i < 3; i++) {
    const val = Math.floor(Math.random() * 10) + 2; // 2 - 11 (Ace)
    const suit = SUITS[Math.floor(Math.random() * SUITS.length)];
    const name = val === 11 ? 'A' : val === 10 ? 'K' : val === 9 ? 'Q' : `${val}`;
    cards.push({ suit, val, name });
  }
  return cards;
}

export const CardClashGame: React.FC<CardClashGameProps> = ({
  players,
  prizePool,
  onGameEnd
}) => {
  const [round, setRound] = useState<number>(1);
  const [playerHands, setPlayerHands] = useState<Record<string, Card[]>>(() => {
    const h: Record<string, Card[]> = {};
    players.forEach(p => { h[p.userId] = generateHand(); });
    return h;
  });
  const [selectedCards, setSelectedCards] = useState<Record<string, Card | null>>({});
  const [revealed, setRevealed] = useState<boolean>(false);
  const [scores, setScores] = useState<Record<string, number>>(() => {
    const s: Record<string, number> = {};
    players.forEach(p => { s[p.userId] = 0; });
    return s;
  });
  const [statusMsg, setStatusMsg] = useState<string>('Select your best card to clash!');

  const userPlayer = players.find(p => !p.isBot) || players[0];
  const userHand = playerHands[userPlayer.userId] || [];

  const handleSelectCard = (card: Card) => {
    if (revealed) return;
    setSelectedCards(prev => ({ ...prev, [userPlayer.userId]: card }));
    setStatusMsg(`Selected ${card.name}${card.suit}. Clashing against room members!`);

    // Pick cards for bots
    const newSelected = { ...selectedCards, [userPlayer.userId]: card };
    players.forEach(p => {
      if (p.isBot) {
        const bHand = playerHands[p.userId] || [];
        const botCard = bHand[Math.floor(Math.random() * bHand.length)];
        newSelected[p.userId] = botCard;
      }
    });

    setSelectedCards(newSelected);
    setRevealed(true);

    // Determine round winner
    setTimeout(() => {
      let maxVal = -1;
      let roundWinnerId = userPlayer.userId;

      Object.entries(newSelected).forEach(([uId, cardItem]) => {
        const c = cardItem as Card | null;
        if (c && c.val > maxVal) {
          maxVal = c.val;
          roundWinnerId = uId;
        }
      });

      const winPlayer = players.find(p => p.userId === roundWinnerId);
      setScores(prev => ({ ...prev, [roundWinnerId]: (prev[roundWinnerId] || 0) + 1 }));
      setStatusMsg(`Round ${round} won by ${winPlayer?.name} with ${maxVal} pts!`);

      setTimeout(() => {
        if (round < 3) {
          setRound(r => r + 1);
          setRevealed(false);
          setSelectedCards({});
          // Deal new hands
          const nextHands: Record<string, Card[]> = {};
          players.forEach(p => { nextHands[p.userId] = generateHand(); });
          setPlayerHands(nextHands);
          setStatusMsg(`Round ${round + 1}: Pick your card!`);
        } else {
          // Game finish
          let overallWinnerId = players[0].userId;
          let maxWins = -1;
          Object.entries(scores).forEach(([uId, wCountVal]) => {
            const wCount = Number(wCountVal);
            if (wCount > maxWins) {
              maxWins = wCount;
              overallWinnerId = uId;
            }
          });

          const winner = players.find(p => p.userId === overallWinnerId) || players[0];
          const finalPlayers = players.map(p => ({ ...p, score: (scores[p.userId] || 0) * 100 }));
          onGameEnd(winner, finalPlayers);
        }
      }, 2500);
    }, 1200);
  };

  return (
    <div className="flex flex-col items-center w-full max-w-sm mx-auto select-none">
      {/* Top Banner */}
      <div className="w-full flex items-center justify-between px-3 py-2 bg-neutral-900/90 rounded-xl border border-rose-500/30 text-xs mb-2">
        <div className="flex items-center space-x-1.5">
          <Layers className="w-4 h-4 text-rose-400" />
          <span className="text-white font-bold">Round {round}/3</span>
        </div>
        <div className="flex items-center space-x-1 px-2.5 py-0.5 rounded-full bg-rose-950/60 border border-rose-500/40 text-rose-300 font-bold text-xs">
          <span>Prize: 🪙 {prizePool}</span>
        </div>
      </div>

      {/* Clash Arena */}
      <div className="relative w-[340px] h-[300px] bg-neutral-950 border-4 border-rose-900/40 rounded-3xl p-4 flex flex-col justify-between shadow-2xl overflow-hidden">
        {/* Opponents' Played Cards */}
        <div className="flex items-center justify-around">
          {players.filter(p => p.userId !== userPlayer.userId).map(opp => {
            const oppCard = selectedCards[opp.userId];
            const isRed = oppCard?.suit === '♥' || oppCard?.suit === '♦';

            return (
              <div key={opp.userId} className="flex flex-col items-center space-y-1">
                <div className="flex items-center space-x-1">
                  <img src={opp.avatar} alt={opp.name} className="w-5 h-5 rounded-full object-cover" />
                  <span className="text-[10px] text-neutral-300 font-bold truncate max-w-[60px]">{opp.name}</span>
                </div>
                <div className={`w-14 h-20 rounded-xl border-2 flex flex-col items-center justify-center shadow-lg transition-all ${
                  revealed && oppCard
                    ? `bg-neutral-900 border-white text-base font-black ${isRed ? 'text-rose-500' : 'text-neutral-100'}`
                    : 'bg-rose-950/40 border-rose-600/40 text-rose-400 font-mono text-xs'
                }`}>
                  {revealed && oppCard ? (
                    <>
                      <span>{oppCard.name}</span>
                      <span className="text-sm">{oppCard.suit}</span>
                    </>
                  ) : (
                    <span>🂠</span>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* Center Clash Alert */}
        <div className="text-center py-2">
          <p className="text-xs font-bold text-rose-200 bg-rose-950/50 py-1 px-3 rounded-full border border-rose-500/30 inline-block">
            {statusMsg}
          </p>
        </div>

        {/* User Hand */}
        <div>
          <span className="text-[10px] font-bold text-neutral-400 block mb-1">Your Hand:</span>
          <div className="flex items-center justify-center space-x-2">
            {userHand.map((c, idx) => {
              const isSelected = selectedCards[userPlayer.userId] === c;
              const isRed = c.suit === '♥' || c.suit === '♦';

              return (
                <button
                  key={idx}
                  onClick={() => handleSelectCard(c)}
                  disabled={revealed}
                  className={`w-16 h-22 rounded-xl border-2 flex flex-col items-center justify-between p-1.5 transition-transform shadow-lg cursor-pointer ${
                    isSelected
                      ? 'bg-neutral-900 border-amber-400 scale-105 ring-4 ring-amber-400/40'
                      : 'bg-neutral-900 hover:bg-neutral-800 border-neutral-700 hover:scale-105'
                  } ${isRed ? 'text-rose-500' : 'text-white'}`}
                >
                  <span className="text-xs font-black self-start">{c.name}</span>
                  <span className="text-xl">{c.suit}</span>
                  <span className="text-[9px] font-mono text-neutral-400">{c.val} pts</span>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Rounds scoreboard */}
      <div className="w-full mt-2.5 p-2.5 rounded-2xl bg-neutral-900/90 border border-neutral-800 flex items-center justify-around text-xs">
        {players.map(p => (
          <div key={p.userId} className="flex items-center space-x-1.5">
            <img src={p.avatar} alt={p.name} className="w-5 h-5 rounded-full object-cover" />
            <span className="text-neutral-300 font-bold">{p.name.split(' ')[0]}:</span>
            <span className="text-amber-400 font-bold">{scores[p.userId] || 0} Wins</span>
          </div>
        ))}
      </div>
    </div>
  );
};
