import React, { useState, useEffect } from 'react';
import { Dice1, Dice2, Dice3, Dice4, Dice5, Dice6, RotateCcw, Footprints, Award } from 'lucide-react';
import { GamePlayer } from '../types';

interface SnakeAndLadderGameProps {
  players: GamePlayer[];
  currentTurnIndex: number;
  onTurnEnd: (nextTurnIndex: number, updatedPlayers: GamePlayer[]) => void;
  onGameEnd: (winner: GamePlayer, finalPlayers: GamePlayer[]) => void;
}

// Ladders: bottom -> top
const LADDERS: Record<number, number> = {
  4: 14,
  9: 31,
  20: 38,
  28: 84,
  40: 59,
  51: 67,
  63: 81,
  71: 91,
};

// Snakes: head -> tail
const SNAKES: Record<number, number> = {
  17: 7,
  54: 34,
  62: 19,
  64: 60,
  87: 24,
  93: 73,
  95: 56,
  98: 29,
};

const DICE_ICONS = [Dice1, Dice2, Dice3, Dice4, Dice5, Dice6];

export const SnakeAndLadderGame: React.FC<SnakeAndLadderGameProps> = ({
  players,
  currentTurnIndex,
  onTurnEnd,
  onGameEnd,
}) => {
  // Positions of each player on 1-100 board. Start at 1.
  const [positions, setPositions] = useState<number[]>(() => players.map(() => 1));
  const [diceValue, setDiceValue] = useState<number>(1);
  const [isRolling, setIsRolling] = useState<boolean>(false);
  const [bannerMessage, setBannerMessage] = useState<string>('Roll the dice to advance on the 100-tile board!');
  const [lastEvent, setLastEvent] = useState<{ type: 'snake' | 'ladder' | 'six'; text: string } | null>(null);

  const currentPlayer = players[currentTurnIndex] || players[0];

  // Auto-roll for Bot players
  useEffect(() => {
    if (currentPlayer.isBot && !isRolling) {
      const timer = setTimeout(() => {
        handleRollDice();
      }, 1000);
      return () => clearTimeout(timer);
    }
  }, [currentPlayer, isRolling]);

  const handleRollDice = () => {
    if (isRolling) return;
    setIsRolling(true);
    setLastEvent(null);

    // Roll animation
    let count = 0;
    const interval = setInterval(() => {
      setDiceValue(Math.floor(Math.random() * 6) + 1);
      count++;
      if (count > 6) {
        clearInterval(interval);
        const finalRoll = Math.floor(Math.random() * 6) + 1;
        setDiceValue(finalRoll);
        applyMove(finalRoll);
      }
    }, 80);
  };

  const applyMove = (roll: number) => {
    const currentPos = positions[currentTurnIndex];
    let newPos = currentPos + roll;

    // Bounce back if overshoot 100, or exact finish
    if (newPos > 100) {
      const overshoot = newPos - 100;
      newPos = 100 - overshoot;
    }

    // Check ladder or snake
    let event: { type: 'snake' | 'ladder' | 'six'; text: string } | null = null;
    let finalPos = newPos;

    if (LADDERS[newPos]) {
      finalPos = LADDERS[newPos];
      event = {
        type: 'ladder',
        text: `🪜 Ladder! Climbed from ${newPos} up to ${finalPos}!`,
      };
    } else if (SNAKES[newPos]) {
      finalPos = SNAKES[newPos];
      event = {
        type: 'snake',
        text: `🐍 Snake bite! Slid down from ${newPos} to ${finalPos}!`,
      };
    } else if (roll === 6) {
      event = {
        type: 'six',
        text: `🎲 Rolled a 6! Extra roll awarded!`,
      };
    }

    setLastEvent(event);

    const nextPositions = [...positions];
    nextPositions[currentTurnIndex] = finalPos;
    setPositions(nextPositions);

    const updatedPlayers = players.map((p, idx) => ({
      ...p,
      score: nextPositions[idx],
    }));

    setIsRolling(false);

    // Check Win condition (reached 100)
    if (finalPos === 100) {
      setBannerMessage(`🏆 ${currentPlayer.name} reached 100 and won the match!`);
      setTimeout(() => {
        onGameEnd(currentPlayer, updatedPlayers);
      }, 1000);
      return;
    }

    // If rolled a 6, extra roll!
    if (roll === 6) {
      setBannerMessage(`${currentPlayer.name} rolled a 6! Roll again!`);
    } else {
      const nextIndex = (currentTurnIndex + 1) % players.length;
      setBannerMessage(`${players[nextIndex].name}'s turn to roll`);
      onTurnEnd(nextIndex, updatedPlayers);
    }
  };

  const DiceComponent = DICE_ICONS[diceValue - 1] || Dice1;

  // Render 10x10 board from 100 down to 1
  // Row 10: 100..91 (left to right)
  // Row 9: 81..90 (left to right)
  // etc.
  const boardRows: number[][] = [];
  for (let r = 9; r >= 0; r--) {
    const row: number[] = [];
    const isEvenRowFromBottom = r % 2 === 1; // 9, 7, 5, 3, 1 are right-to-left
    for (let c = 0; c < 10; c++) {
      const num = isEvenRowFromBottom ? (r * 10 + (10 - c)) : (r * 10 + (c + 1));
      row.push(num);
    }
    boardRows.push(row);
  }

  return (
    <div className="flex flex-col items-center w-full max-w-sm mx-auto select-none">
      {/* Top Turn & Notification Banner */}
      <div className="w-full flex items-center justify-between px-3 py-1.5 bg-neutral-900/90 rounded-xl border border-neutral-800 text-[11px] mb-2">
        <div className="flex items-center space-x-1.5">
          <Footprints className="w-3.5 h-3.5 text-emerald-400" />
          <span className="text-white font-bold">{currentPlayer.name}&apos;s Turn</span>
        </div>
        <div className="text-[10px] text-neutral-400">
          Position: <span className="text-emerald-300 font-bold">{positions[currentTurnIndex]}/100</span>
        </div>
      </div>

      {/* 10x10 Snake & Ladder Board */}
      <div className="relative w-[340px] h-[340px] bg-neutral-950 border-4 border-emerald-800/60 rounded-2xl shadow-2xl p-1 overflow-hidden flex flex-col justify-between">
        <div className="grid grid-cols-10 grid-rows-10 gap-0.5 w-full h-full">
          {boardRows.flat().map(num => {
            const isLadderBottom = !!LADDERS[num];
            const isSnakeHead = !!SNAKES[num];
            const isGoal = num === 100;

            // Find players on this square
            const occupyingPlayers = players.filter((_, idx) => positions[idx] === num);

            // Alternating checkerboard tints
            const isOddTile = (Math.floor((num - 1) / 10) + (num % 10)) % 2 === 0;

            return (
              <div
                key={num}
                className={`relative flex items-center justify-center rounded-[3px] text-[8px] font-mono transition-colors ${
                  isGoal
                    ? 'bg-gradient-to-br from-amber-500 to-yellow-600 text-neutral-950 font-extrabold shadow-inner'
                    : isSnakeHead
                    ? 'bg-rose-950/60 text-rose-300 border border-rose-500/40'
                    : isLadderBottom
                    ? 'bg-emerald-950/60 text-emerald-300 border border-emerald-500/40'
                    : isOddTile
                    ? 'bg-neutral-900/90 text-neutral-400'
                    : 'bg-neutral-900/50 text-neutral-500'
                }`}
              >
                {/* Tile Number */}
                <span className="absolute top-0.5 left-0.5 text-[7px] leading-none opacity-80">{num}</span>

                {/* Snake or Ladder Icon Marker */}
                {isSnakeHead && <span className="text-[9px] leading-none">🐍</span>}
                {isLadderBottom && <span className="text-[9px] leading-none">🪜</span>}
                {isGoal && <span className="text-[9px] leading-none">👑</span>}

                {/* Player Tokens on this square */}
                {occupyingPlayers.length > 0 && (
                  <div className="absolute inset-0 flex items-center justify-center -space-x-1 z-10">
                    {occupyingPlayers.map(p => (
                      <div
                        key={p.userId}
                        style={{ backgroundColor: p.color }}
                        className="w-3.5 h-3.5 rounded-full border border-white shadow-sm flex items-center justify-center text-[7px] font-bold text-white"
                        title={p.name}
                      >
                        {p.name[0]}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Dynamic Event Banner Overlay */}
        {lastEvent && (
          <div
            className={`absolute top-2 inset-x-4 py-1.5 px-3 rounded-full text-center text-xs font-bold shadow-lg animate-fade-in ${
              lastEvent.type === 'snake'
                ? 'bg-rose-950 border border-rose-500 text-rose-200'
                : lastEvent.type === 'ladder'
                ? 'bg-emerald-950 border border-emerald-500 text-emerald-200'
                : 'bg-violet-950 border border-violet-500 text-violet-200'
            }`}
          >
            {lastEvent.text}
          </div>
        )}
      </div>

      {/* Dice Roller & Control Deck */}
      <div className="w-full mt-2.5 p-3 rounded-2xl bg-neutral-900/90 border border-neutral-800 flex items-center justify-between">
        <div className="flex items-center space-x-3">
          {/* Animated 3D Dice Display */}
          <div
            onClick={!currentPlayer.isBot && !isRolling ? handleRollDice : undefined}
            className={`w-14 h-14 rounded-2xl bg-gradient-to-br from-emerald-600 to-teal-700 flex items-center justify-center text-white shadow-lg shadow-emerald-600/30 border-2 border-emerald-400/40 cursor-pointer transition-transform ${
              isRolling ? 'animate-spin scale-110' : 'hover:scale-105 active:scale-95'
            }`}
          >
            <DiceComponent className="w-8 h-8 stroke-[2.2]" />
          </div>

          <div>
            <p className="text-xs font-bold text-white">
              {isRolling ? 'Rolling...' : `Rolled: ${diceValue}`}
            </p>
            <p className="text-[11px] text-neutral-400">
              {currentPlayer.isBot ? 'Bot rolling...' : 'Tap dice to roll!'}
            </p>
          </div>
        </div>

        <button
          onClick={handleRollDice}
          disabled={isRolling || currentPlayer.isBot}
          className={`px-4 py-2.5 rounded-xl font-bold text-xs flex items-center space-x-1.5 transition-all shadow-md cursor-pointer ${
            isRolling || currentPlayer.isBot
              ? 'bg-neutral-800 text-neutral-500 cursor-not-allowed'
              : 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-emerald-600/30 active:scale-95'
          }`}
        >
          <span>Roll Dice</span>
        </button>
      </div>

      <p className="mt-1.5 text-[10px] text-neutral-400 text-center truncate">{bannerMessage}</p>
    </div>
  );
};
