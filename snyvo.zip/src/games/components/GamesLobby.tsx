import React, { useState, useEffect } from 'react';
import {
  Gamepad2,
  Trophy,
  History,
  Coins,
  Sparkles,
  Users,
  ChevronRight,
  Info,
  X,
  Target,
  Footprints,
  Dice6,
  Zap,
  Layers,
  Flame,
  Grid,
  ShieldCheck,
} from 'lucide-react';
import { GameDefinition } from '../types';
import { AVAILABLE_GAMES, gameService } from '../gameService';
import { walletService } from '../walletService';
import { User, VoiceRoom } from '../../types';
import { GameInviteModal } from './GameInviteModal';
import { GameHistoryModal } from './GameHistoryModal';

interface GamesLobbyProps {
  room: VoiceRoom;
  currentUser: User;
  onClose: () => void;
  onLaunchGame: (game: GameDefinition, players: any[]) => void;
}

const ICON_MAP: Record<string, React.ElementType> = {
  Target: Target,
  Footprints: Footprints,
  Dice6: Dice6,
  Zap: Zap,
  Layers: Layers,
  Flame: Flame,
  Grid: Grid,
  Sparkles: Sparkles,
};

export const GamesLobby: React.FC<GamesLobbyProps> = ({
  room,
  currentUser,
  onClose,
  onLaunchGame,
}) => {
  const [activeTab, setActiveTab] = useState<'free' | 'coin'>('free');
  const [selectedGameForInvite, setSelectedGameForInvite] = useState<GameDefinition | null>(null);
  const [selectedGameForRules, setSelectedGameForRules] = useState<GameDefinition | null>(null);
  const [showHistory, setShowHistory] = useState<boolean>(false);
  const [coinBalance, setCoinBalance] = useState<number>(() => walletService.getBalance(currentUser.id));

  // Subscribe to wallet changes
  useEffect(() => {
    const unsub = walletService.subscribe(() => {
      setCoinBalance(walletService.getBalance(currentUser.id));
    });
    return unsub;
  }, [currentUser.id]);

  const freeGames = AVAILABLE_GAMES.filter(g => g.category === 'free');
  const coinGames = AVAILABLE_GAMES.filter(g => g.category === 'coin');
  const displayedGames = activeTab === 'free' ? freeGames : coinGames;

  const handleSelectGame = (game: GameDefinition) => {
    if (game.category === 'coin') {
      const afford = walletService.canAfford(currentUser.id, game.entryCoins);
      if (!afford.allowed) {
        alert(
          `Not Enough Coins!\nRequired entry: ${game.entryCoins} 🪙\nYour balance: ${afford.currentBalance} 🪙\n\nWin matches or receive tips from room listeners to gain coins!`
        );
        return;
      }
    }
    setSelectedGameForInvite(game);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/85 backdrop-blur-sm animate-fade-in p-0 sm:p-4">
      <div className="w-full max-w-md bg-neutral-900 border border-neutral-800 rounded-t-3xl sm:rounded-3xl p-5 shadow-2xl text-white max-h-[90vh] flex flex-col">
        {/* Top Header */}
        <div className="flex items-center justify-between pb-3 border-b border-neutral-800">
          <div className="flex items-center space-x-2.5">
            <div className="w-9 h-9 rounded-2xl bg-gradient-to-tr from-violet-600 to-indigo-600 flex items-center justify-center text-white shadow-md shadow-violet-600/30">
              <Gamepad2 className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-extrabold text-white">Voice Room Games</h3>
              <p className="text-[11px] text-neutral-400">Play live with room members while talking</p>
            </div>
          </div>

          <div className="flex items-center space-x-1.5">
            <button
              onClick={() => setShowHistory(true)}
              className="p-2 rounded-xl bg-neutral-800/80 hover:bg-neutral-800 text-neutral-300 hover:text-white transition-colors cursor-pointer"
              title="Game History"
            >
              <History className="w-4 h-4" />
            </button>

            <button
              onClick={onClose}
              className="p-2 rounded-xl text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Wallet & Status Strip */}
        <div className="py-2.5 flex items-center justify-between">
          {/* Category Tabs */}
          <div className="flex bg-neutral-950 p-1 rounded-xl border border-neutral-800">
            <button
              onClick={() => setActiveTab('free')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                activeTab === 'free'
                  ? 'bg-emerald-600 text-white shadow'
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              Free Games ({freeGames.length})
            </button>
            <button
              onClick={() => setActiveTab('coin')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                activeTab === 'coin'
                  ? 'bg-yellow-600 text-white shadow'
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              Coin Games ({coinGames.length})
            </button>
          </div>

          {/* Wallet Balance Badge */}
          <div className="flex items-center space-x-1.5 px-3 py-1.5 rounded-xl bg-yellow-950/40 border border-yellow-500/30 text-yellow-300 text-xs font-bold shadow-sm">
            <Coins className="w-3.5 h-3.5 text-yellow-400" />
            <span>{coinBalance} 🪙</span>
          </div>
        </div>

        {/* Games Grid / List */}
        <div className="flex-1 overflow-y-auto py-2 space-y-3 scrollbar-none">
          {displayedGames.map(game => {
            const IconComponent = ICON_MAP[game.icon] || Sparkles;
            const isCoin = game.category === 'coin';

            return (
              <div
                key={game.id}
                className="group p-4 rounded-2xl bg-neutral-950/70 border border-neutral-800/80 hover:border-violet-500/50 transition-all space-y-3 relative overflow-hidden"
              >
                {/* Background ambient gradient glow */}
                <div
                  className={`absolute -right-12 -top-12 w-32 h-32 rounded-full bg-gradient-to-br ${game.bannerGradient} blur-2xl pointer-events-none opacity-40`}
                />

                <div className="flex items-start justify-between relative z-10">
                  <div className="flex items-center space-x-3">
                    <div
                      className={`w-11 h-11 rounded-2xl flex items-center justify-center text-white shadow-md ${
                        isCoin
                          ? 'bg-gradient-to-tr from-amber-600 to-yellow-600 shadow-amber-600/30'
                          : 'bg-gradient-to-tr from-violet-600 to-indigo-600 shadow-violet-600/30'
                      }`}
                    >
                      <IconComponent className="w-6 h-6" />
                    </div>

                    <div>
                      <div className="flex items-center space-x-2">
                        <h4 className="text-sm font-extrabold text-white">{game.title}</h4>
                        <span
                          className={`text-[9px] font-black px-2 py-0.5 rounded-full ${
                            isCoin
                              ? 'bg-yellow-950/80 text-yellow-300 border border-yellow-500/40'
                              : 'bg-emerald-950/80 text-emerald-300 border border-emerald-500/40'
                          }`}
                        >
                          {isCoin ? `🪙 ${game.entryCoins} Entry` : 'FREE'}
                        </span>
                      </div>
                      <p className="text-[11px] text-neutral-400 mt-0.5 line-clamp-1">{game.tagline}</p>
                    </div>
                  </div>

                  <button
                    onClick={() => setSelectedGameForRules(game)}
                    className="p-1.5 text-neutral-400 hover:text-white rounded-lg hover:bg-neutral-800 transition-colors cursor-pointer"
                    title="Rules & How to Play"
                  >
                    <Info className="w-4 h-4" />
                  </button>
                </div>

                <p className="text-xs text-neutral-400 line-clamp-2 relative z-10">
                  {game.description}
                </p>

                {/* Footer specs & Play button */}
                <div className="flex items-center justify-between pt-1 relative z-10">
                  <div className="flex items-center space-x-2 text-[11px] text-neutral-400">
                    <span className="flex items-center space-x-1">
                      <Users className="w-3.5 h-3.5 text-neutral-400" />
                      <span>{game.minPlayers}-{game.maxPlayers} Players</span>
                    </span>
                    <span>•</span>
                    <span className="text-emerald-400 font-medium">In-Room Multiplayer</span>
                  </div>

                  <button
                    onClick={() => handleSelectGame(game)}
                    className="py-1.5 px-4 rounded-xl font-bold text-xs bg-violet-600 hover:bg-violet-500 text-white shadow-md shadow-violet-600/20 active:scale-95 transition-all flex items-center space-x-1 cursor-pointer"
                  >
                    <span>Play</span>
                    <ChevronRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Footer info note */}
        <div className="pt-2.5 border-t border-neutral-800 text-center">
          <p className="text-[10px] text-neutral-400">
            🎙️ Voice conversation, mic &amp; room chat remain active during all matches.
          </p>
        </div>
      </div>

      {/* Invite Modal */}
      {selectedGameForInvite && (
        <GameInviteModal
          game={selectedGameForInvite}
          room={room}
          currentUser={currentUser}
          onClose={() => setSelectedGameForInvite(null)}
          onStartGame={players => {
            const gameToLaunch = selectedGameForInvite;
            setSelectedGameForInvite(null);
            onLaunchGame(gameToLaunch, players);
          }}
        />
      )}

      {/* Rules Modal */}
      {selectedGameForRules && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 p-4 animate-fade-in">
          <div className="w-full max-w-sm bg-neutral-900 border border-neutral-800 rounded-3xl p-5 text-white space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-neutral-800">
              <h3 className="text-sm font-bold text-white">{selectedGameForRules.title} Rules</h3>
              <button
                onClick={() => setSelectedGameForRules(null)}
                className="text-neutral-400 hover:text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <ul className="space-y-2 text-xs text-neutral-300 list-disc list-inside">
              {selectedGameForRules.rules.map((r, idx) => (
                <li key={idx} className="leading-relaxed">
                  {r}
                </li>
              ))}
            </ul>

            <button
              onClick={() => setSelectedGameForRules(null)}
              className="w-full py-2.5 rounded-xl bg-violet-600 text-white font-bold text-xs"
            >
              Got it
            </button>
          </div>
        </div>
      )}

      {/* History Modal */}
      {showHistory && (
        <GameHistoryModal
          history={gameService.getHistory()}
          currentUserId={currentUser.id}
          onClose={() => setShowHistory(false)}
        />
      )}
    </div>
  );
};
