import React from 'react';
import { Trophy, Award, Coins, ArrowRight, RotateCcw, CheckCircle2, ShieldCheck, X } from 'lucide-react';
import { GamePlayer, GameDefinition } from '../types';

interface GameResultModalProps {
  winner: GamePlayer;
  players: GamePlayer[];
  game: GameDefinition;
  prizePool: number;
  transactionId?: string;
  onRematch: () => void;
  onBackToRoom: () => void;
}

export const GameResultModal: React.FC<GameResultModalProps> = ({
  winner,
  players,
  game,
  prizePool,
  transactionId,
  onRematch,
  onBackToRoom
}) => {
  const isCoinGame = game.category === 'coin';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 backdrop-blur-md p-4 animate-fade-in">
      <div className="w-full max-w-sm bg-neutral-900 border border-neutral-800 rounded-3xl p-6 shadow-2xl text-white text-center space-y-4">
        {/* Trophy Animation */}
        <div className="relative w-20 h-20 mx-auto">
          <div className="absolute inset-0 rounded-full bg-amber-500/20 animate-ping opacity-60" />
          <div className="w-20 h-20 rounded-full bg-gradient-to-tr from-amber-600 via-yellow-500 to-amber-300 flex items-center justify-center text-neutral-950 shadow-xl shadow-amber-500/30">
            <Trophy className="w-10 h-10" />
          </div>
        </div>

        {/* Title */}
        <div>
          <span className="text-[11px] font-extrabold uppercase tracking-widest text-amber-400">
            Match Completed
          </span>
          <h2 className="text-xl font-black text-white mt-0.5">GAME FINISHED</h2>
          <p className="text-xs text-neutral-400">{game.title}</p>
        </div>

        {/* 🥇 Winner Showcase Card */}
        <div className="p-4 rounded-2xl bg-gradient-to-b from-amber-950/40 to-neutral-950/60 border border-amber-500/40 space-y-2">
          <div className="flex items-center justify-center space-x-1.5 text-amber-400 font-extrabold text-xs">
            <Award className="w-4 h-4" />
            <span>1st Place Champion</span>
          </div>

          <div className="flex flex-col items-center">
            <img
              src={winner.avatar}
              alt={winner.name}
              className="w-16 h-16 rounded-full object-cover border-2 border-amber-400 shadow-md shadow-amber-500/20"
            />
            <h3 className="text-base font-bold text-white mt-1.5">{winner.name}</h3>
            <span className="text-[11px] text-neutral-400 font-mono">
              ID: {winner.numericId}
            </span>
          </div>

          {/* Final Score */}
          <div className="pt-1">
            <span className="text-xs font-semibold text-neutral-300">
              Winning Score: <span className="text-amber-400 font-bold">{winner.score} pts</span>
            </span>
          </div>
        </div>

        {/* Coin Transaction or Free Game Result */}
        {isCoinGame ? (
          <div className="p-3 bg-yellow-950/30 border border-yellow-500/30 rounded-2xl text-xs space-y-1.5">
            <div className="flex items-center justify-between">
              <span className="text-neutral-300">Prize Pool Claimed:</span>
              <span className="text-sm font-extrabold text-yellow-300">🪙 {prizePool} Coins</span>
            </div>
            <div className="flex items-center justify-between text-[11px] text-neutral-400">
              <span>Per-Player Entry:</span>
              <span>🪙 {game.entryCoins} Coins</span>
            </div>
            {transactionId && (
              <div className="pt-1 border-t border-yellow-500/20 flex items-center justify-between text-[10px] font-mono text-emerald-400">
                <span className="flex items-center space-x-1">
                  <ShieldCheck className="w-3 h-3" />
                  <span>Verified Ledger TX</span>
                </span>
                <span>{transactionId}</span>
              </div>
            )}
          </div>
        ) : (
          <div className="p-2.5 bg-emerald-950/30 border border-emerald-500/30 rounded-2xl text-xs text-emerald-300 flex items-center justify-center space-x-1.5">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <span>Free Match • No Coins Deducted</span>
          </div>
        )}

        {/* Players Standings List */}
        <div className="space-y-1.5 text-left">
          <span className="text-[10px] font-bold text-neutral-400 uppercase tracking-wider block">
            Player Standings
          </span>
          <div className="space-y-1 max-h-24 overflow-y-auto">
            {players.map((p, idx) => (
              <div
                key={p.userId}
                className="flex items-center justify-between p-2 rounded-xl bg-neutral-950/60 border border-neutral-800 text-xs"
              >
                <div className="flex items-center space-x-2 min-w-0">
                  <span className="text-[10px] font-bold text-neutral-500 w-3">{idx + 1}</span>
                  <img src={p.avatar} alt={p.name} className="w-6 h-6 rounded-full object-cover" />
                  <span className="text-xs font-medium text-white truncate max-w-[120px]">{p.name}</span>
                </div>
                <span className="text-xs font-mono font-bold text-amber-300">{p.score} pts</span>
              </div>
            ))}
          </div>
        </div>

        {/* Action Buttons */}
        <div className="grid grid-cols-2 gap-2 pt-1">
          <button
            onClick={onRematch}
            className="py-3 px-4 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-white font-bold text-xs flex items-center justify-center space-x-1.5 transition-colors cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Play Again</span>
          </button>

          <button
            onClick={onBackToRoom}
            className="py-3 px-4 rounded-xl bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-500 hover:to-indigo-500 text-white font-bold text-xs flex items-center justify-center space-x-1.5 transition-all shadow-md shadow-violet-600/30 cursor-pointer"
          >
            <span>Back to Board</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};
