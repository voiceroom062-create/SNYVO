import React, { useState } from 'react';
import { Minimize2, Maximize2, X, Trophy, Volume2, VolumeX, ShieldAlert } from 'lucide-react';
import { GameDefinition, GamePlayer, ActiveMatchState } from '../types';
import { CarromGame } from '../carrom/CarromGame';
import { SnakeAndLadderGame } from '../snakeAndLadder/SnakeAndLadderGame';
import { LudoGame } from '../ludo/LudoGame';
import { ReactionGame } from '../coinGames/ReactionGame';
import { CardClashGame } from '../coinGames/CardClashGame';
import { GameResultModal } from './GameResultModal';
import { gameService } from '../gameService';

interface ActiveGameContainerProps {
  game: GameDefinition;
  match: ActiveMatchState;
  roomTitle: string;
  onExitGame: () => void;
}

export const ActiveGameContainer: React.FC<ActiveGameContainerProps> = ({
  game,
  match,
  roomTitle,
  onExitGame,
}) => {
  const [isMinimized, setIsMinimized] = useState<boolean>(false);
  const [currentTurn, setCurrentTurn] = useState<number>(match.currentTurnIndex || 0);
  const [players, setPlayers] = useState<GamePlayer[]>(match.players);
  const [finishedResult, setFinishedResult] = useState<{
    winner: GamePlayer;
    finalPlayers: GamePlayer[];
    txId?: string;
  } | null>(null);

  const handleTurnEnd = (nextTurnIndex: number, updatedPlayers: GamePlayer[]) => {
    setCurrentTurn(nextTurnIndex);
    setPlayers(updatedPlayers);
    gameService.updateMatchState(prev => ({
      ...prev,
      currentTurnIndex: nextTurnIndex,
      players: updatedPlayers,
    }));
  };

  const handleGameEnd = (winner: GamePlayer, finalPlayers: GamePlayer[]) => {
    const historyItem = gameService.finishMatch(winner, finalPlayers, roomTitle);
    setFinishedResult({
      winner,
      finalPlayers,
      txId: historyItem?.transactionId,
    });
  };

  const handleRematch = () => {
    setFinishedResult(null);
    // Restart match with current players
    gameService.createMatch(game, match.roomId, players.map(p => ({ ...p, score: 0 })));
    setPlayers(players.map(p => ({ ...p, score: 0 })));
    setCurrentTurn(0);
  };

  const handleExitConfirm = () => {
    if (window.confirm('Are you sure you want to end this game match and return to full Voice Room?')) {
      gameService.exitMatch();
      onExitGame();
    }
  };

  if (isMinimized) {
    // Minimized Floating Pill/Card on Voice Room
    return (
      <div className="mx-3 mb-2 p-3 bg-neutral-900/95 border border-violet-500/50 rounded-2xl shadow-xl flex items-center justify-between animate-fade-in backdrop-blur-md z-30">
        <div className="flex items-center space-x-2.5">
          <div className="w-8 h-8 rounded-xl bg-violet-600 flex items-center justify-center text-white shadow">
            🎮
          </div>
          <div>
            <div className="flex items-center space-x-1.5">
              <span className="text-xs font-bold text-white">{game.title}</span>
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
            </div>
            <p className="text-[10px] text-neutral-400">
              {players[currentTurn]?.name}&apos;s turn
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-1">
          <button
            onClick={() => setIsMinimized(false)}
            className="p-1.5 rounded-lg bg-violet-600/30 text-violet-300 hover:bg-violet-600/50 text-xs font-bold flex items-center space-x-1 cursor-pointer"
          >
            <Maximize2 className="w-3.5 h-3.5" />
            <span>Maximize</span>
          </button>
          <button
            onClick={handleExitConfirm}
            className="p-1.5 rounded-lg text-neutral-400 hover:text-white cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="w-full bg-neutral-950/95 border-b border-neutral-800 p-2.5 flex flex-col space-y-2 relative animate-fade-in">
      {/* Top Header of Active Game */}
      <div className="flex items-center justify-between px-2 pt-1 pb-1.5 border-b border-neutral-800/80">
        <div className="flex items-center space-x-2">
          <span className="text-sm">🎮</span>
          <span className="text-xs font-black text-white uppercase tracking-wider">
            {game.title}
          </span>
          {game.category === 'coin' && (
            <span className="text-[10px] font-bold px-1.5 py-0.5 rounded-full bg-yellow-950 text-yellow-300 border border-yellow-500/40">
              Prize: 🪙 {match.prizePool}
            </span>
          )}
        </div>

        <div className="flex items-center space-x-1.5">
          {/* Player Mini Avatars */}
          <div className="flex -space-x-1.5 mr-2">
            {players.map((p, idx) => (
              <div
                key={p.userId}
                style={{ borderColor: p.color }}
                className={`w-6 h-6 rounded-full border-2 overflow-hidden ${
                  idx === currentTurn ? 'ring-2 ring-amber-400 scale-110 z-10' : 'opacity-80'
                }`}
                title={`${p.name} (${p.score || 0} pts)`}
              >
                <img src={p.avatar} alt={p.name} className="w-full h-full object-cover" />
              </div>
            ))}
          </div>

          <button
            onClick={() => setIsMinimized(true)}
            className="p-1 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors cursor-pointer"
            title="Minimize Game"
          >
            <Minimize2 className="w-4 h-4" />
          </button>
          <button
            onClick={handleExitConfirm}
            className="p-1 rounded-lg text-neutral-400 hover:text-rose-400 hover:bg-neutral-800 transition-colors cursor-pointer"
            title="Exit Game"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Active Game Component Swapper */}
      <div className="w-full flex justify-center py-1">
        {game.id === 'carrom' && (
          <CarromGame
            players={players}
            currentTurnIndex={currentTurn}
            onTurnEnd={handleTurnEnd}
            onGameEnd={handleGameEnd}
          />
        )}

        {game.id === 'snake_ladder' && (
          <SnakeAndLadderGame
            players={players}
            currentTurnIndex={currentTurn}
            onTurnEnd={handleTurnEnd}
            onGameEnd={handleGameEnd}
          />
        )}

        {game.id === 'ludo' && (
          <LudoGame
            players={players}
            currentTurnIndex={currentTurn}
            onTurnEnd={handleTurnEnd}
            onGameEnd={handleGameEnd}
          />
        )}

        {game.id === 'speed_reaction' && (
          <ReactionGame
            players={players}
            currentTurnIndex={currentTurn}
            prizePool={match.prizePool}
            onTurnEnd={handleTurnEnd}
            onGameEnd={handleGameEnd}
          />
        )}

        {game.id === 'card_clash' && (
          <CardClashGame
            players={players}
            currentTurnIndex={currentTurn}
            prizePool={match.prizePool}
            onTurnEnd={handleTurnEnd}
            onGameEnd={handleGameEnd}
          />
        )}
      </div>

      {/* Game Result Modal */}
      {finishedResult && (
        <GameResultModal
          winner={finishedResult.winner}
          players={finishedResult.finalPlayers}
          game={game}
          prizePool={match.prizePool}
          transactionId={finishedResult.txId}
          onRematch={handleRematch}
          onBackToRoom={() => {
            setFinishedResult(null);
            gameService.exitMatch();
            onExitGame();
          }}
        />
      )}
    </div>
  );
};
