import React, { useState } from 'react';
import { X, Users, Check, AlertCircle, Play, Sparkles, UserPlus, ShieldCheck, HelpCircle } from 'lucide-react';
import { User, VoiceRoom } from '../../types';
import { GameDefinition, GamePlayer } from '../types';
import { getNumericUserId } from '../../services/userService';
import { walletService } from '../walletService';

interface GameInviteModalProps {
  game: GameDefinition;
  room: VoiceRoom;
  currentUser: User;
  onClose: () => void;
  onStartGame: (players: GamePlayer[]) => void;
}

const SEAT_COLORS = [
  { name: 'Red', hex: '#ef4444', label: 'Seat 1 (Host)' },
  { name: 'Blue', hex: '#3b82f6', label: 'Seat 2' },
  { name: 'Yellow', hex: '#f59e0b', label: 'Seat 3' },
  { name: 'Green', hex: '#10b981', label: 'Seat 4' },
];

export const GameInviteModal: React.FC<GameInviteModalProps> = ({
  game,
  room,
  currentUser,
  onClose,
  onStartGame,
}) => {
  const [playerCount, setPlayerCount] = useState<2 | 4>(2);

  // Available room members (speakers and listeners, deduplicated)
  const roomMembers: { id: string; name: string; avatar: string; handle: string; numericId: string }[] = [];
  const addedIds = new Set<string>();

  // Host
  if (room.host) {
    roomMembers.push({
      id: room.host.id,
      name: room.host.name,
      avatar: room.host.avatar,
      handle: room.host.handle,
      numericId: getNumericUserId(room.host.id),
    });
    addedIds.add(room.host.id);
  }

  // Speakers
  room.speakers.forEach(s => {
    if (!addedIds.has(s.id)) {
      roomMembers.push({
        id: s.id,
        name: s.name,
        avatar: s.avatar,
        handle: s.handle,
        numericId: getNumericUserId(s.id),
      });
      addedIds.add(s.id);
    }
  });

  // Listeners
  room.listeners.forEach(l => {
    if (!addedIds.has(l.id)) {
      roomMembers.push({
        id: l.id,
        name: l.name,
        avatar: l.avatar,
        handle: l.handle,
        numericId: getNumericUserId(l.id),
      });
      addedIds.add(l.id);
    }
  });

  // Ensure current user is in
  if (!addedIds.has(currentUser.id)) {
    roomMembers.unshift({
      id: currentUser.id,
      name: currentUser.name,
      avatar: currentUser.avatar,
      handle: currentUser.handle,
      numericId: getNumericUserId(currentUser.id),
    });
    addedIds.add(currentUser.id);
  }

  // Pre-fill slots
  // Slot 0: Current user (auto-ready)
  // Slot 1: First other room member if available
  const [selectedSlots, setSelectedSlots] = useState<{
    userId: string;
    numericId: string;
    name: string;
    avatar: string;
    isReady: boolean;
    isBot?: boolean;
  }[]>(() => {
    const defaultOther = roomMembers.find(m => m.id !== currentUser.id) || {
      id: 'room_partner_1',
      name: 'Maya Lin',
      avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150',
      handle: '@mayalin',
      numericId: '10842915',
    };

    return [
      {
        userId: currentUser.id,
        numericId: getNumericUserId(currentUser.id),
        name: currentUser.name,
        avatar: currentUser.avatar,
        isReady: true,
      },
      {
        userId: defaultOther.id,
        numericId: defaultOther.numericId,
        name: defaultOther.name,
        avatar: defaultOther.avatar,
        isReady: true,
      },
      {
        userId: 'room_partner_2',
        numericId: '39482019',
        name: 'Kofi Mensah',
        avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150',
        isReady: true,
        isBot: true,
      },
      {
        userId: 'room_partner_3',
        numericId: '59281044',
        name: 'Dr. Sarah Thorne',
        avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150',
        isReady: true,
        isBot: true,
      },
    ];
  });

  const [activeSlotPickerIndex, setActiveSlotPickerIndex] = useState<number | null>(null);

  const activePlayersCount = playerCount;
  const currentSlots = selectedSlots.slice(0, activePlayersCount);

  // Check if any slot is duplicate
  const usedUserIds = new Set<string>();
  let hasDuplicate = false;
  currentSlots.forEach(s => {
    if (usedUserIds.has(s.userId)) {
      hasDuplicate = true;
    }
    usedUserIds.add(s.userId);
  });

  const allReady = currentSlots.every(s => s.isReady) && !hasDuplicate;

  const handleSelectMemberForSlot = (
    slotIdx: number,
    member: { id: string; name: string; avatar: string; numericId: string }
  ) => {
    // Validation: prevent same user in multiple slots!
    const isAlreadyAssigned = currentSlots.some((s, idx) => idx !== slotIdx && s.userId === member.id);
    if (isAlreadyAssigned) {
      alert(`${member.name} is already assigned to another player seat!`);
      return;
    }

    const updated = [...selectedSlots];
    updated[slotIdx] = {
      userId: member.id,
      numericId: member.numericId,
      name: member.name,
      avatar: member.avatar,
      isReady: true,
      isBot: member.id.startsWith('room_partner'),
    };

    setSelectedSlots(updated);
    setActiveSlotPickerIndex(null);
  };

  const handleToggleReady = (slotIdx: number) => {
    const updated = [...selectedSlots];
    updated[slotIdx] = {
      ...updated[slotIdx],
      isReady: !updated[slotIdx].isReady,
    };
    setSelectedSlots(updated);
  };

  const handleStart = () => {
    if (!allReady) return;

    // Check coins if coin game
    if (game.category === 'coin' && game.entryCoins > 0) {
      const afford = walletService.canAfford(currentUser.id, game.entryCoins);
      if (!afford.allowed) {
        alert(`Not Enough Coins. You need ${game.entryCoins} 🪙 but have ${afford.currentBalance} 🪙.`);
        return;
      }
    }

    const gamePlayers: GamePlayer[] = currentSlots.map((s, idx) => ({
      userId: s.userId,
      numericId: s.numericId,
      name: s.name,
      avatar: s.avatar,
      seatIndex: idx,
      color: SEAT_COLORS[idx].hex,
      isReady: s.isReady,
      isHost: idx === 0,
      isBot: s.isBot,
      score: 0,
    }));

    onStartGame(gamePlayers);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/85 backdrop-blur-sm animate-fade-in p-0 sm:p-4">
      <div className="w-full max-w-md bg-neutral-900 border border-neutral-800 rounded-t-3xl sm:rounded-3xl p-5 shadow-2xl text-white max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-neutral-800">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 rounded-xl bg-violet-600/20 border border-violet-500/30 flex items-center justify-center text-violet-400">
              <Users className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white">{game.title} — Room Lobby</h3>
              <p className="text-[11px] text-neutral-400">Invite friends from &quot;{room.title}&quot;</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto py-3 space-y-4 scrollbar-none">
          {/* Player Mode Selector (2 Players or 4 Players) */}
          <div>
            <span className="text-[11px] font-bold text-neutral-400 uppercase tracking-wider block mb-1.5">
              Select Match Size
            </span>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setPlayerCount(2)}
                className={`p-2.5 rounded-xl border text-center font-bold text-xs transition-all cursor-pointer ${
                  playerCount === 2
                    ? 'bg-violet-600/30 border-violet-500 text-white shadow-md'
                    : 'bg-neutral-950/60 border-neutral-800 text-neutral-400 hover:text-white'
                }`}
              >
                2 Players Match (1v1)
              </button>
              <button
                type="button"
                onClick={() => setPlayerCount(4)}
                className={`p-2.5 rounded-xl border text-center font-bold text-xs transition-all cursor-pointer ${
                  playerCount === 4
                    ? 'bg-violet-600/30 border-violet-500 text-white shadow-md'
                    : 'bg-neutral-950/60 border-neutral-800 text-neutral-400 hover:text-white'
                }`}
              >
                4 Players Match (Free-For-All)
              </button>
            </div>
          </div>

          {/* Slots Configuration */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <span className="text-[11px] font-bold text-neutral-400 uppercase tracking-wider">
                Player Seats ({activePlayersCount})
              </span>
              <span className="text-[10px] text-violet-400">Tap to swap member</span>
            </div>

            <div className="space-y-2">
              {currentSlots.map((slot, idx) => {
                const seatColor = SEAT_COLORS[idx];
                const isHostSlot = idx === 0;

                return (
                  <div
                    key={`slot-${idx}`}
                    className="p-3 rounded-2xl bg-neutral-950/80 border border-neutral-800 flex items-center justify-between"
                  >
                    <div
                      className="flex items-center space-x-3 cursor-pointer min-w-0 flex-1"
                      onClick={() => !isHostSlot && setActiveSlotPickerIndex(idx)}
                    >
                      <div className="relative">
                        <img
                          src={slot.avatar}
                          alt={slot.name}
                          className="w-10 h-10 rounded-full object-cover border-2"
                          style={{ borderColor: seatColor.hex }}
                        />
                        <div
                          style={{ backgroundColor: seatColor.hex }}
                          className="absolute -top-1 -left-1 w-4 h-4 rounded-full text-[8px] font-black text-white flex items-center justify-center shadow"
                        >
                          {idx + 1}
                        </div>
                      </div>

                      <div className="min-w-0">
                        <div className="flex items-center space-x-1.5">
                          <span className="text-xs font-bold text-white truncate">{slot.name}</span>
                          {isHostSlot && (
                            <span className="text-[9px] bg-violet-950 text-violet-300 px-1.5 py-0.2 rounded font-bold">
                              You
                            </span>
                          )}
                          {slot.isBot && (
                            <span className="text-[9px] bg-neutral-800 text-neutral-400 px-1 rounded">
                              Room Guest
                            </span>
                          )}
                        </div>
                        <p className="text-[10px] text-neutral-400 font-mono">
                          ID: {slot.numericId} • {seatColor.label}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center space-x-2 flex-shrink-0">
                      <button
                        type="button"
                        onClick={() => handleToggleReady(idx)}
                        className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                          slot.isReady
                            ? 'bg-emerald-600/30 border border-emerald-500/50 text-emerald-300'
                            : 'bg-neutral-800 border border-neutral-700 text-neutral-400'
                        }`}
                      >
                        {slot.isReady ? 'Ready' : 'Not Ready'}
                      </button>

                      {!isHostSlot && (
                        <button
                          type="button"
                          onClick={() => setActiveSlotPickerIndex(idx)}
                          className="p-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-400 hover:text-white transition-colors cursor-pointer"
                          title="Change Player"
                        >
                          <UserPlus className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Member Picker Drawer/Overlay */}
          {activeSlotPickerIndex !== null && (
            <div className="p-3 bg-neutral-950 border border-neutral-800 rounded-2xl space-y-2 animate-fade-in">
              <div className="flex items-center justify-between pb-1.5 border-b border-neutral-800 text-xs">
                <span className="font-bold text-white">
                  Choose Room Member for Seat #{activeSlotPickerIndex + 1}
                </span>
                <button
                  onClick={() => setActiveSlotPickerIndex(null)}
                  className="text-neutral-400 hover:text-white"
                >
                  Cancel
                </button>
              </div>

              <div className="space-y-1.5 max-h-36 overflow-y-auto">
                {roomMembers.map(member => {
                  const isAssigned = currentSlots.some(s => s.userId === member.id);

                  return (
                    <div
                      key={member.id}
                      onClick={() => !isAssigned && handleSelectMemberForSlot(activeSlotPickerIndex, member)}
                      className={`p-2 rounded-xl border flex items-center justify-between cursor-pointer transition-colors ${
                        isAssigned
                          ? 'bg-neutral-900/40 border-neutral-800/40 opacity-50 cursor-not-allowed'
                          : 'bg-neutral-900 hover:bg-violet-950/40 border-neutral-800 hover:border-violet-500/50'
                      }`}
                    >
                      <div className="flex items-center space-x-2">
                        <img
                          src={member.avatar}
                          alt={member.name}
                          className="w-7 h-7 rounded-full object-cover"
                        />
                        <div>
                          <p className="text-xs font-semibold text-white">{member.name}</p>
                          <p className="text-[9px] text-neutral-400 font-mono">ID: {member.numericId}</p>
                        </div>
                      </div>

                      {isAssigned ? (
                        <span className="text-[9px] text-neutral-500">Assigned</span>
                      ) : (
                        <span className="text-[10px] text-violet-400 font-bold">Invite</span>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Duplicate slot warning */}
          {hasDuplicate && (
            <div className="p-3 bg-rose-950/50 border border-rose-500/40 rounded-xl text-xs text-rose-300 flex items-center space-x-2">
              <AlertCircle className="w-4 h-4 flex-shrink-0 text-rose-400" />
              <span>One user cannot occupy multiple player seats in the same match.</span>
            </div>
          )}

          {/* Coin Entry Info */}
          {game.category === 'coin' && (
            <div className="p-3 bg-yellow-950/30 border border-yellow-500/30 rounded-2xl text-xs flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <span className="text-base">🪙</span>
                <div>
                  <p className="font-bold text-yellow-300">Required Entry Fee: {game.entryCoins} Coins</p>
                  <p className="text-[10px] text-neutral-400">Total Prize Pool: {game.entryCoins * activePlayersCount} Coins</p>
                </div>
              </div>
              <span className="text-[11px] font-mono text-emerald-400">
                Your Wallet: 🪙 {walletService.getBalance(currentUser.id)}
              </span>
            </div>
          )}
        </div>

        {/* Footer Launch Button */}
        <div className="pt-3 border-t border-neutral-800">
          <button
            onClick={handleStart}
            disabled={!allReady}
            className={`w-full py-3.5 px-4 rounded-xl font-bold text-xs flex items-center justify-center space-x-2 transition-all shadow-lg cursor-pointer ${
              allReady
                ? 'bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-500 hover:to-indigo-500 text-white shadow-violet-600/30 active:scale-98'
                : 'bg-neutral-800 text-neutral-500 cursor-not-allowed border border-neutral-700'
            }`}
          >
            <Play className="w-3.5 h-3.5 fill-current" />
            <span>{allReady ? 'Start Match in Room' : 'Waiting for Players to Ready...'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
