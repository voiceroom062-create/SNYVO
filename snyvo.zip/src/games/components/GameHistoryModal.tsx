import React from 'react';
import { History, X, Trophy, Coins, Target, Footprints, Dice6, Zap, Layers, Sparkles } from 'lucide-react';
import { GameHistoryItem } from '../types';

interface GameHistoryModalProps {
  history: GameHistoryItem[];
  currentUserId: string;
  onClose: () => void;
}

const GAME_ICON_MAP: Record<string, React.ElementType> = {
  carrom: Target,
  snake_ladder: Footprints,
  ludo: Dice6,
  speed_reaction: Zap,
  card_clash: Layers,
};

export const GameHistoryModal: React.FC<GameHistoryModalProps> = ({
  history,
  currentUserId,
  onClose,
}) => {
  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/85 backdrop-blur-sm animate-fade-in p-0 sm:p-4">
      <div className="w-full max-w-md bg-neutral-900 border border-neutral-800 rounded-t-3xl sm:rounded-3xl p-5 shadow-2xl text-white max-h-[85vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-neutral-800">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 rounded-xl bg-violet-600/20 border border-violet-500/30 flex items-center justify-center text-violet-400">
              <History className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white">Voice Room Game History</h3>
              <p className="text-[11px] text-neutral-400">Past multiplayer matches &amp; results</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* History List */}
        <div className="flex-1 overflow-y-auto py-3 space-y-3 scrollbar-none">
          {history.length === 0 ? (
            <div className="py-12 text-center text-neutral-400 space-y-2">
              <Trophy className="w-10 h-10 text-neutral-600 mx-auto" />
              <p className="text-xs font-semibold text-neutral-300">No Game History Yet</p>
              <p className="text-[11px] text-neutral-500">
                Start a game from the Voice Room Board with friends to record match stats!
              </p>
            </div>
          ) : (
            history.map(item => {
              const IconComp = GAME_ICON_MAP[item.gameId] || Sparkles;
              const isCoinGame = item.category === 'coin';
              const isUserWinner = item.winnerId === currentUserId;

              return (
                <div
                  key={item.id}
                  className="p-3.5 rounded-2xl bg-neutral-950/70 border border-neutral-800/90 space-y-2.5 hover:border-neutral-700 transition-colors"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <div className="w-7 h-7 rounded-lg bg-neutral-800 flex items-center justify-center text-violet-400">
                        <IconComp className="w-3.5 h-3.5" />
                      </div>
                      <div>
                        <div className="flex items-center space-x-1.5">
                          <span className="text-xs font-bold text-white">{item.gameTitle}</span>
                          <span
                            className={`text-[9px] font-bold px-1.5 py-0.5 rounded-full ${
                              isCoinGame
                                ? 'bg-yellow-950/60 text-yellow-300 border border-yellow-500/30'
                                : 'bg-emerald-950/60 text-emerald-300 border border-emerald-500/30'
                            }`}
                          >
                            {isCoinGame ? `🪙 ${item.entryFee} Entry` : 'FREE'}
                          </span>
                        </div>
                        <p className="text-[10px] text-neutral-400 truncate">{item.roomTitle}</p>
                      </div>
                    </div>

                    <span className="text-[10px] text-neutral-400">{item.timestamp}</span>
                  </div>

                  {/* Winner info */}
                  <div className="flex items-center justify-between p-2 rounded-xl bg-neutral-900/60 border border-neutral-800/60 text-xs">
                    <div className="flex items-center space-x-2">
                      <span className="text-amber-400 text-xs">🥇</span>
                      <img
                        src={item.winnerAvatar}
                        alt={item.winnerName}
                        className="w-5 h-5 rounded-full object-cover"
                      />
                      <span className="font-semibold text-white">
                        {item.winnerName}
                        {isUserWinner && <span className="text-violet-400 text-[10px] ml-1">(You)</span>}
                      </span>
                      <span className="text-[10px] text-neutral-400 font-mono">
                        ID: {item.winnerNumericId}
                      </span>
                    </div>

                    {isCoinGame && item.reward > 0 && (
                      <span className="text-[11px] font-extrabold text-yellow-400 font-mono">
                        +🪙 {item.reward}
                      </span>
                    )}
                  </div>

                  {/* Players list */}
                  <div className="flex items-center justify-between text-[11px] text-neutral-400 pt-0.5 px-1">
                    <span>Players:</span>
                    <div className="flex -space-x-1.5">
                      {item.players.map(p => (
                        <img
                          key={p.userId}
                          src={p.avatar}
                          alt={p.name}
                          title={`${p.name} (${p.score} pts)`}
                          className="w-5 h-5 rounded-full object-cover border border-neutral-900"
                        />
                      ))}
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Footer */}
        <div className="pt-2 border-t border-neutral-800">
          <button
            onClick={onClose}
            className="w-full py-2.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-white text-xs font-semibold transition-colors cursor-pointer"
          >
            Close History
          </button>
        </div>
      </div>
    </div>
  );
};
