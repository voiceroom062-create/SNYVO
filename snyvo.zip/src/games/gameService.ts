import { GameDefinition, GameHistoryItem, ActiveMatchState, GamePlayer } from './types';
import { walletService } from './walletService';

export const AVAILABLE_GAMES: GameDefinition[] = [
  // --- FREE GAMES ---
  {
    id: 'carrom',
    title: 'Carrom Board',
    category: 'free',
    entryCoins: 0,
    minPlayers: 2,
    maxPlayers: 4,
    icon: 'Target',
    bannerGradient: 'from-amber-600/30 to-orange-700/20',
    tagline: 'Classic Indian Striker & Pocket Board',
    description: 'Aim and strike white, black carrom men and the red queen into corner pockets with authentic rebound physics.',
    rules: [
      '2 or 4 Players take turns shooting from their baseline',
      'White puck = 10 pts, Black puck = 5 pts, Red Queen = 25 pts',
      'Pocketing the striker is a foul (-5 pts)',
      'Player with highest score wins the match'
    ],
    isAvailable: true,
    accentColor: 'amber'
  },
  {
    id: 'snake_ladder',
    title: 'Snake & Ladder (সাপলুডু)',
    category: 'free',
    entryCoins: 0,
    minPlayers: 2,
    maxPlayers: 4,
    icon: 'Footprints',
    bannerGradient: 'from-emerald-600/30 to-teal-800/20',
    tagline: 'Traditional 100-Tile Dice Race',
    description: 'Roll the dice, climb sturdy ladders to leap ahead, and dodge slippery venomous snakes on the road to tile 100.',
    rules: [
      '2 to 4 Players roll a 6-sided dice on their turn',
      'Landing on the bottom of a ladder climbs you directly to the top',
      'Landing on the head of a snake slides you back down',
      'First player to reach or pass square 100 wins the crown'
    ],
    isAvailable: true,
    accentColor: 'emerald'
  },
  {
    id: 'ludo',
    title: 'Ludo Classic',
    category: 'free',
    entryCoins: 0,
    minPlayers: 2,
    maxPlayers: 4,
    icon: 'Dice6',
    bannerGradient: 'from-violet-600/30 to-indigo-800/20',
    tagline: '4-Color Token Strategy Race',
    description: 'Roll a 6 to release your token from base, advance along the colorful track, capture opponents, and guide tokens home.',
    rules: [
      'Roll a 6 to bring tokens out of your home yard',
      'Navigate the 52-step board track toward your color home column',
      'Landing on an opponent sends their token back to base',
      'Star tiles are safe zones where tokens cannot be captured'
    ],
    isAvailable: true,
    accentColor: 'violet'
  },

  // --- COIN GAMES ---
  {
    id: 'speed_reaction',
    title: 'Speed Reaction Duel',
    category: 'coin',
    entryCoins: 20,
    minPlayers: 2,
    maxPlayers: 4,
    icon: 'Zap',
    bannerGradient: 'from-yellow-500/30 to-amber-600/20',
    tagline: 'High-Stakes Millisecond Reflex Buzzer',
    description: 'Wait for the signal flash and tap the buzzer before your friends. False starts cost points!',
    rules: [
      'Entry fee: 🪙 20 Coins per player',
      'Wait for the green flash signal—never tap during red!',
      'Fastest response time in milliseconds wins round points',
      'Player with highest reflex score sweeps the coin prize pool'
    ],
    isAvailable: true,
    accentColor: 'yellow'
  },
  {
    id: 'card_clash',
    title: 'Card Clash Duel',
    category: 'coin',
    entryCoins: 50,
    minPlayers: 2,
    maxPlayers: 4,
    icon: 'Layers',
    bannerGradient: 'from-rose-600/30 to-red-800/20',
    tagline: 'Turn-Based Card Value Showdown',
    description: 'Players are dealt high-value numbered suit cards. Play tactics and power combinations to claim the coin pot.',
    rules: [
      'Entry fee: 🪙 50 Coins per player',
      '3 fast-paced rounds of card showdown',
      'Highest suit + power card combination claims each round',
      'Grand winner takes the accumulated coin pot'
    ],
    isAvailable: true,
    accentColor: 'rose'
  },
  {
    id: 'mind_quiz',
    title: 'Brain Voice Trivia',
    category: 'coin',
    entryCoins: 30,
    minPlayers: 2,
    maxPlayers: 4,
    icon: 'Sparkles',
    bannerGradient: 'from-cyan-600/30 to-blue-800/20',
    tagline: 'Fast Knowledge Duel with Timer',
    description: '3 quick multi-choice questions covering sound, music, tech, and general smarts. Speed counts.',
    rules: [
      'Entry fee: 🪙 30 Coins per player',
      '10 seconds per question to pick the correct answer',
      'Points awarded for accuracy and response speed',
      'Top scorer claims the match prize pool'
    ],
    isAvailable: true,
    accentColor: 'cyan'
  },
  {
    id: 'nitro_racing',
    title: 'Nitro Micro Racing',
    category: 'coin',
    entryCoins: 100,
    minPlayers: 2,
    maxPlayers: 4,
    icon: 'Flame',
    bannerGradient: 'from-orange-600/30 to-red-900/20',
    tagline: 'High-Roller Arcade Mini Circuit',
    description: 'Tournament arcade racing where drifting corners and turbo boosts decide the winner.',
    rules: [
      'High-roller entry: 🪙 100 Coins',
      'Compete on micro circuits with live room banter',
      'Winner claims 1st place gold trophy & coin pool'
    ],
    isAvailable: true,
    accentColor: 'orange'
  },
  {
    id: 'puzzle_duel',
    title: 'Block Puzzle Duel',
    category: 'coin',
    entryCoins: 50,
    minPlayers: 2,
    maxPlayers: 4,
    icon: 'Grid',
    bannerGradient: 'from-fuchsia-600/30 to-purple-900/20',
    tagline: 'Speed Line Clearing Battle',
    description: 'Fit falling polyomino shapes together and clear lines to dump garbage blocks on opponents.',
    rules: [
      'Entry fee: 🪙 50 Coins',
      'Clear consecutive lines to trigger speed combos',
      'Last player standing wins the match'
    ],
    isAvailable: true,
    accentColor: 'fuchsia'
  }
];

const INITIAL_HISTORY: GameHistoryItem[] = [
  {
    id: 'gh_1',
    gameId: 'carrom',
    gameTitle: 'Carrom Board',
    gameIcon: 'Target',
    roomId: 'room_1',
    roomTitle: 'Ambient Lo-Fi & Beats',
    category: 'free',
    entryFee: 0,
    reward: 0,
    timestamp: 'Today, 4:15 PM',
    players: [
      { userId: 'usr_me', numericId: '84920194', name: 'Alex Vance', avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150', score: 45, isWinner: true, color: '#ef4444' },
      { userId: 'usr_1', numericId: '10842915', name: 'Maya Lin', avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150', score: 30, isWinner: false, color: '#3b82f6' }
    ],
    winnerName: 'Alex Vance',
    winnerId: 'usr_me',
    winnerNumericId: '84920194',
    winnerAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150'
  },
  {
    id: 'gh_2',
    gameId: 'snake_ladder',
    gameTitle: 'Snake & Ladder',
    gameIcon: 'Footprints',
    roomId: 'room_2',
    roomTitle: 'Tech Talk: Next-Gen AI',
    category: 'free',
    entryFee: 0,
    reward: 0,
    timestamp: 'Yesterday, 8:40 PM',
    players: [
      { userId: 'usr_2', numericId: '39482019', name: 'Kofi Mensah', avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150', score: 100, isWinner: true, color: '#10b981' },
      { userId: 'usr_me', numericId: '84920194', name: 'Alex Vance', avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150', score: 82, isWinner: false, color: '#ef4444' },
      { userId: 'usr_5', numericId: '59281044', name: 'Dr. Sarah Thorne', avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150', score: 64, isWinner: false, color: '#f59e0b' }
    ],
    winnerName: 'Kofi Mensah',
    winnerId: 'usr_2',
    winnerNumericId: '39482019',
    winnerAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150'
  },
  {
    id: 'gh_3',
    gameId: 'speed_reaction',
    gameTitle: 'Speed Reaction Duel',
    gameIcon: 'Zap',
    roomId: 'room_1',
    roomTitle: 'Ambient Lo-Fi & Beats',
    category: 'coin',
    entryFee: 20,
    reward: 40,
    timestamp: '2 days ago',
    players: [
      { userId: 'usr_me', numericId: '84920194', name: 'Alex Vance', avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150', score: 300, isWinner: true, color: '#ef4444' },
      { userId: 'usr_1', numericId: '10842915', name: 'Maya Lin', avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150', score: 240, isWinner: false, color: '#3b82f6' }
    ],
    winnerName: 'Alex Vance',
    winnerId: 'usr_me',
    winnerNumericId: '84920194',
    winnerAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150',
    transactionId: 'tx_win_demo_1'
  }
];

const STORAGE_KEY_GAME_HISTORY = 'snyvo_game_history_v1';

class GameService {
  private history: GameHistoryItem[] = [];
  private activeMatch: ActiveMatchState | null = null;
  private subscribers: (() => void)[] = [];

  constructor() {
    this.loadHistory();
  }

  private loadHistory() {
    const saved = localStorage.getItem(STORAGE_KEY_GAME_HISTORY);
    if (saved) {
      try {
        this.history = JSON.parse(saved);
      } catch (e) {
        this.history = [...INITIAL_HISTORY];
      }
    } else {
      this.history = [...INITIAL_HISTORY];
      this.saveHistory();
    }
  }

  private saveHistory() {
    try {
      localStorage.setItem(STORAGE_KEY_GAME_HISTORY, JSON.stringify(this.history));
    } catch (e) {
      // ignore
    }
  }

  public subscribe(callback: () => void): () => void {
    this.subscribers.push(callback);
    return () => {
      this.subscribers = this.subscribers.filter(cb => cb !== callback);
    };
  }

  private notify() {
    this.subscribers.forEach(cb => cb());
  }

  public getGames(): GameDefinition[] {
    return AVAILABLE_GAMES;
  }

  public getGameById(id: string): GameDefinition | undefined {
    return AVAILABLE_GAMES.find(g => g.id === id);
  }

  public getHistory(): GameHistoryItem[] {
    return this.history;
  }

  public getUserHistory(userId: string): GameHistoryItem[] {
    const key = (userId === 'usr_guest') ? 'usr_me' : userId;
    return this.history.filter(h => h.players.some(p => p.userId === key));
  }

  public getActiveMatch(): ActiveMatchState | null {
    return this.activeMatch;
  }

  /**
   * Initializes a new match lobby for players in the voice room
   */
  public createMatch(
    game: GameDefinition,
    roomId: string,
    initialPlayers: GamePlayer[]
  ): ActiveMatchState {
    const matchId = `match_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
    const prizePool = game.category === 'coin' ? game.entryCoins * initialPlayers.length : 0;

    const match: ActiveMatchState = {
      matchId,
      gameId: game.id,
      roomId,
      category: game.category,
      entryCoins: game.entryCoins,
      prizePool,
      players: initialPlayers,
      currentTurnIndex: 0,
      status: 'playing',
      winner: null,
      startedAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    // If coin game, deduct entry coins for real players
    if (game.category === 'coin' && game.entryCoins > 0) {
      initialPlayers.forEach(p => {
        if (!p.isBot) {
          walletService.deductGameEntry(p.userId, game.entryCoins, game.id, game.title, matchId);
        }
      });
    }

    this.activeMatch = match;
    this.notify();
    return match;
  }

  public updateMatchState(updater: (prev: ActiveMatchState) => ActiveMatchState) {
    if (!this.activeMatch) return;
    this.activeMatch = updater(this.activeMatch);
    this.notify();
  }

  /**
   * Finalizes the match, awards coins if coin game, and records game history item
   */
  public finishMatch(
    winner: GamePlayer,
    finalPlayers: GamePlayer[],
    roomTitle: string
  ): GameHistoryItem | null {
    if (!this.activeMatch) return null;

    const game = this.getGameById(this.activeMatch.gameId);
    if (!game) return null;

    const matchId = this.activeMatch.matchId;
    let txId: string | undefined;

    // Handle Coin reward
    if (game.category === 'coin' && this.activeMatch.prizePool > 0) {
      if (!winner.isBot) {
        const res = walletService.awardGamePrize(
          winner.userId,
          this.activeMatch.prizePool,
          game.id,
          game.title,
          matchId
        );
        txId = res.transaction?.id;
      }
    }

    this.activeMatch.status = 'finished';
    this.activeMatch.winner = winner;
    this.activeMatch.endedAt = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    this.activeMatch.transactionId = txId;

    const historyRecord: GameHistoryItem = {
      id: `gh_${Date.now()}`,
      gameId: game.id,
      gameTitle: game.title,
      gameIcon: game.icon,
      roomId: this.activeMatch.roomId,
      roomTitle,
      category: game.category,
      entryFee: game.entryCoins,
      reward: this.activeMatch.prizePool,
      timestamp: 'Just now',
      players: finalPlayers.map(p => ({
        userId: p.userId,
        numericId: p.numericId,
        name: p.name,
        avatar: p.avatar,
        score: p.score,
        isWinner: p.userId === winner.userId,
        color: p.color
      })),
      winnerName: winner.name,
      winnerId: winner.userId,
      winnerNumericId: winner.numericId,
      winnerAvatar: winner.avatar,
      transactionId: txId
    };

    this.history.unshift(historyRecord);
    this.saveHistory();

    this.notify();
    return historyRecord;
  }

  public exitMatch() {
    this.activeMatch = null;
    this.notify();
  }
}

export const gameService = new GameService();
