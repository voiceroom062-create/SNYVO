import React, { useState, useEffect } from 'react';
import {
  X,
  Sparkles,
  Check,
  Copy,
  AlertCircle,
  ExternalLink,
  Crown,
  Diamond,
  History,
  ShieldCheck,
  PhoneCall,
  MessageCircle,
  Clock,
  ArrowRight,
  RefreshCw,
} from 'lucide-react';
import { User } from '../types';
import { CoinPackage, PaymentMethod, PurchaseOrder } from '../coins/types';
import { coinConfigService } from '../coins/coinConfigService';
import { purchaseService } from '../coins/purchaseService';
import { vipService, VIP_TIER_CONFIGS } from '../coins/vipService';
import { walletService } from '../games/walletService';
import { getNumericUserId } from '../services/userService';

interface CoinShopModalProps {
  currentUser: User;
  onClose: () => void;
  onOpenAdminPanel?: () => void;
}

export const CoinShopModal: React.FC<CoinShopModalProps> = ({
  currentUser,
  onClose,
  onOpenAdminPanel,
}) => {
  const [activeTab, setActiveTab] = useState<'shop' | 'orders'>('shop');
  const [packages, setPackages] = useState<CoinPackage[]>(() => coinConfigService.getPackages());
  const [adminConfig, setAdminConfig] = useState(() => coinConfigService.getAdminConfig());
  const [selectedPackage, setSelectedPackage] = useState<CoinPackage | null>(null);
  const [selectedPaymentMethod, setSelectedPaymentMethod] = useState<PaymentMethod>('bKash');
  const [senderPhone, setSenderPhone] = useState('');
  const [transactionId, setTransactionId] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successOrder, setSuccessOrder] = useState<PurchaseOrder | null>(null);
  const [userOrders, setUserOrders] = useState<PurchaseOrder[]>(() =>
    purchaseService.getUserOrders(currentUser.id)
  );
  const [copiedField, setCopiedField] = useState<string | null>(null);
  const [currentBalance, setCurrentBalance] = useState(() =>
    walletService.getBalance(currentUser.id)
  );

  const numericId = currentUser.numericId || getNumericUserId(currentUser.id);
  const userVipTier = vipService.getUserVipTier(currentUser.id);
  const userTierInfo = VIP_TIER_CONFIGS[userVipTier];

  useEffect(() => {
    const unsubConfig = coinConfigService.subscribe(() => {
      setPackages(coinConfigService.getPackages());
      setAdminConfig(coinConfigService.getAdminConfig());
    });
    const unsubOrders = purchaseService.subscribe(() => {
      setUserOrders(purchaseService.getUserOrders(currentUser.id));
    });
    const unsubWallet = walletService.subscribe(() => {
      setCurrentBalance(walletService.getBalance(currentUser.id));
    });

    return () => {
      unsubConfig();
      unsubOrders();
      unsubWallet();
    };
  }, [currentUser.id]);

  const handleCopy = (text: string, fieldKey: string) => {
    navigator.clipboard.writeText(text);
    setCopiedField(fieldKey);
    setTimeout(() => setCopiedField(null), 2000);
  };

  const handleSelectPackage = (pkg: CoinPackage) => {
    setSelectedPackage(pkg);
    setErrorMsg(null);
    setSuccessOrder(null);
  };

  const handleSubmitOrder = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedPackage) return;

    setErrorMsg(null);
    setIsSubmitting(true);

    const res = purchaseService.submitPurchaseOrder(
      currentUser,
      selectedPackage.id,
      selectedPaymentMethod,
      senderPhone,
      transactionId
    );

    setIsSubmitting(false);

    if (!res.success) {
      setErrorMsg(res.error || 'Failed to submit payment verification request.');
    } else if (res.order) {
      setSuccessOrder(res.order);
      setSenderPhone('');
      setTransactionId('');
    }
  };

  return (
    <div
      id="coin-shop-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-2 sm:p-4 overflow-y-auto"
    >
      <div
        id="coin-shop-modal-card"
        className="w-full max-w-md max-h-[92vh] flex flex-col rounded-[32px] bg-neutral-950 border border-neutral-800 shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200"
      >
        {/* Modal Header */}
        <div className="p-4 pb-3 border-b border-neutral-800/80 bg-gradient-to-b from-neutral-900 via-neutral-950 to-neutral-950 flex items-center justify-between flex-shrink-0">
          <div className="flex items-center space-x-2.5 min-w-0">
            <div className="w-10 h-10 rounded-2xl bg-amber-500/15 border border-amber-500/40 flex items-center justify-center text-xl flex-shrink-0 shadow-sm shadow-amber-500/20">
              🪙
            </div>
            <div className="min-w-0">
              <h2 className="text-base font-extrabold text-white flex items-center space-x-1.5 truncate">
                <span>BUY COINS & VIP</span>
                <span className="text-xs px-2 py-0.5 rounded-full bg-amber-400/20 text-amber-300 border border-amber-400/40 font-bold">
                  SHOP
                </span>
              </h2>
              <p className="text-[11px] text-neutral-400 flex items-center space-x-1.5 truncate">
                <span>Balance:</span>
                <span className="font-mono font-bold text-amber-300">
                  🪙 {currentBalance.toLocaleString()}
                </span>
                <span className="text-neutral-600">•</span>
                <span className="text-neutral-400">ID: {numericId}</span>
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-1.5">
            {onOpenAdminPanel && (
              <button
                onClick={onOpenAdminPanel}
                className="px-2 py-1 rounded-xl bg-neutral-900 border border-neutral-700 text-neutral-400 hover:text-white text-[10px] font-bold transition-colors"
                title="Admin Control Panel"
              >
                ⚙️ Admin
              </button>
            )}
            <button
              onClick={onClose}
              className="w-8 h-8 rounded-full bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 flex items-center justify-center text-neutral-400 hover:text-white transition-colors"
              aria-label="Close Coin Shop"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Tab Switcher */}
        <div className="px-4 pt-2.5 pb-2 bg-neutral-950 border-b border-neutral-900 flex items-center justify-between flex-shrink-0">
          <div className="grid grid-cols-2 gap-1.5 w-full bg-neutral-900/80 p-1 rounded-2xl border border-neutral-800">
            <button
              onClick={() => {
                setActiveTab('shop');
                setSelectedPackage(null);
                setSuccessOrder(null);
              }}
              className={`py-1.5 text-xs font-bold rounded-xl transition-all flex items-center justify-center space-x-1.5 ${
                activeTab === 'shop'
                  ? 'bg-amber-500 text-neutral-950 shadow-md shadow-amber-500/30'
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              <span>🪙 Packages & Shop</span>
            </button>
            <button
              onClick={() => setActiveTab('orders')}
              className={`py-1.5 text-xs font-bold rounded-xl transition-all flex items-center justify-center space-x-1.5 ${
                activeTab === 'orders'
                  ? 'bg-amber-500 text-neutral-950 shadow-md shadow-amber-500/30'
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              <History className="w-3.5 h-3.5" />
              <span>My Orders ({userOrders.length})</span>
            </button>
          </div>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {activeTab === 'shop' && !selectedPackage && (
            <>
              {/* Mandatory Owner / Admin Contact Notice Alert Banner */}
              <div
                id="admin-contact-notice-banner"
                className="p-3.5 rounded-2xl bg-gradient-to-r from-amber-950/60 via-neutral-900 to-amber-950/60 border border-amber-500/50 shadow-lg shadow-amber-500/10 space-y-2"
              >
                <div className="flex items-start space-x-2.5">
                  <div className="w-8 h-8 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-base flex-shrink-0">
                    📢
                  </div>
                  <div className="min-w-0 flex-1">
                    <h3 className="text-xs font-black text-amber-300 leading-tight">
                      {adminConfig.adminNotice}
                    </h3>
                    <p className="text-[11px] text-neutral-300 mt-1 leading-relaxed">
                      bKash অথবা Nagad-এ সেন্ড মানি করে Transaction ID দিলে অ্যাডমিন ভেরিফাই করে সরাসরি আপনার অ্যাকাউন্টে কয়েন ও VIP পদবী ক্রেডিট করবেন।
                    </p>
                  </div>
                </div>

                {/* Quick Contact Chips */}
                <div className="grid grid-cols-2 gap-2 pt-1">
                  <a
                    href={`https://wa.me/${adminConfig.whatsappNumber.replace(/[^0-9]/g, '')}`}
                    target="_blank"
                    rel="noreferrer"
                    className="p-2 rounded-xl bg-emerald-950/70 border border-emerald-700/60 hover:border-emerald-500 text-emerald-300 flex items-center justify-center space-x-1.5 text-[11px] font-bold transition-all"
                  >
                    <MessageCircle className="w-3.5 h-3.5" />
                    <span>WhatsApp Contact</span>
                  </a>
                  <div className="p-2 rounded-xl bg-neutral-900 border border-neutral-800 text-neutral-300 flex items-center justify-center space-x-1.5 text-[11px] font-bold">
                    <PhoneCall className="w-3.5 h-3.5 text-amber-400" />
                    <span>{adminConfig.supportHours}</span>
                  </div>
                </div>
              </div>

              {/* Current VIP Status Card */}
              <div className="p-3 rounded-2xl bg-neutral-900/60 border border-neutral-800 flex items-center justify-between">
                <div className="flex items-center space-x-2.5">
                  <div className="w-9 h-9 rounded-xl bg-neutral-800 border border-neutral-700 flex items-center justify-center text-lg">
                    {userTierInfo.crown || '👤'}
                  </div>
                  <div>
                    <span className="text-[10px] text-neutral-400 uppercase font-bold tracking-wider block">
                      Current Membership
                    </span>
                    <span className="text-xs font-black text-white flex items-center space-x-1">
                      <span>{userTierInfo.title}</span>
                      <span className="text-[10px]">{userTierInfo.crown}</span>
                    </span>
                  </div>
                </div>
                <span
                  className={`text-[10px] font-extrabold px-2.5 py-1 rounded-full border ${userTierInfo.badgeBg} ${userTierInfo.badgeBorder} ${userTierInfo.badgeText}`}
                >
                  {userTierInfo.badgeLabel}
                </span>
              </div>

              {/* Coin Packages List */}
              <div className="space-y-2.5">
                <div className="flex items-center justify-between">
                  <h3 className="text-xs font-black uppercase tracking-wider text-neutral-400">
                    Select Coin & VIP Package
                  </h3>
                  <span className="text-[10px] text-neutral-500 font-semibold">
                    Configurable by Admin
                  </span>
                </div>

                {packages.map(pkg => {
                  const isSvip = pkg.vipTier === 'SVIP';
                  const isVipPro = pkg.vipTier === 'VIP_PRO';

                  return (
                    <div
                      key={pkg.id}
                      onClick={() => handleSelectPackage(pkg)}
                      className={`group p-3.5 rounded-2xl cursor-pointer transition-all duration-200 border relative overflow-hidden flex flex-col space-y-2.5 ${
                        isSvip
                          ? 'bg-gradient-to-r from-cyan-950/40 via-blue-950/40 to-fuchsia-950/40 hover:from-cyan-950/60 hover:to-fuchsia-950/60 border-cyan-500/60 hover:border-cyan-400 shadow-lg shadow-cyan-950/50 ring-1 ring-cyan-400/30'
                          : isVipPro
                          ? 'bg-gradient-to-r from-purple-950/30 via-neutral-900 to-purple-950/30 hover:border-purple-500/80 border-purple-800/60'
                          : 'bg-neutral-900/80 hover:bg-neutral-900 border-neutral-800 hover:border-amber-500/60'
                      }`}
                    >
                      {/* Top Header: Badge & Price */}
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-2">
                          <span className="text-xl">{isSvip ? '💎' : '🪙'}</span>
                          <div>
                            <div className="flex items-center space-x-1.5">
                              <h4 className="text-xs font-black text-white group-hover:text-amber-200 transition-colors">
                                {pkg.name}
                              </h4>
                              {pkg.badge && (
                                <span
                                  className={`text-[9px] font-black uppercase px-1.5 py-0.5 rounded-md border ${
                                    isSvip
                                      ? 'bg-cyan-500/20 text-cyan-300 border-cyan-400/50 animate-pulse'
                                      : 'bg-amber-500/20 text-amber-300 border-amber-400/40'
                                  }`}
                                >
                                  {pkg.badge}
                                </span>
                              )}
                            </div>
                            <p className="text-[10px] text-neutral-400">{pkg.description}</p>
                          </div>
                        </div>

                        {/* Price Tag in ৳ BDT */}
                        <div className="text-right flex-shrink-0">
                          <span className="text-sm font-black text-emerald-400 font-mono block">
                            ৳{pkg.priceBdt.toLocaleString()}
                          </span>
                          <span className="text-[9px] text-neutral-500 font-medium">BDT</span>
                        </div>
                      </div>

                      {/* Middle Feature Highlights */}
                      <div className="p-2.5 rounded-xl bg-neutral-950/80 border border-neutral-800/80 grid grid-cols-2 gap-2 text-xs">
                        <div>
                          <span className="text-[9px] font-medium text-neutral-400 block">
                            Coins Credited
                          </span>
                          <span className="text-xs font-black text-amber-300 font-mono">
                            🪙 {pkg.coins.toLocaleString()}
                          </span>
                        </div>
                        <div className="border-l border-neutral-800 pl-2">
                          <span className="text-[9px] font-medium text-neutral-400 block">
                            VIP Reward
                          </span>
                          <span className="text-xs font-extrabold text-white flex items-center space-x-1">
                            <span>{pkg.vipCrown}</span>
                            <span className={isSvip ? 'text-cyan-300' : 'text-amber-300'}>
                              {pkg.vipTier === 'SVIP' ? '💎 SVIP' : pkg.vipTier}
                            </span>
                          </span>
                        </div>
                      </div>

                      {/* Benefits & Entry Animation Footnote */}
                      <div className="flex items-center justify-between text-[10px] pt-0.5">
                        <span className="text-neutral-400 flex items-center space-x-1 truncate max-w-[240px]">
                          <Sparkles className="w-3 h-3 text-amber-400 flex-shrink-0" />
                          <span className="truncate">Entry: {pkg.entryEffectTitle}</span>
                        </span>
                        <span className="font-bold text-amber-400 group-hover:text-amber-300 flex items-center space-x-0.5 flex-shrink-0">
                          <span>Select</span>
                          <ArrowRight className="w-3 h-3 transition-transform group-hover:translate-x-0.5" />
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </>
          )}

          {/* Checkout & Submit Confirmation View */}
          {activeTab === 'shop' && selectedPackage && !successOrder && (
            <div className="space-y-4">
              {/* Back to Packages Button */}
              <button
                onClick={() => setSelectedPackage(null)}
                className="text-xs text-neutral-400 hover:text-white flex items-center space-x-1 font-semibold transition-colors"
              >
                <span>← Back to Packages</span>
              </button>

              {/* Selected Package Summary Card */}
              <div
                className={`p-3.5 rounded-2xl border space-y-2 ${
                  selectedPackage.isSvipPackage
                    ? 'bg-gradient-to-r from-cyan-950/60 to-fuchsia-950/60 border-cyan-500/60 shadow-md shadow-cyan-500/20'
                    : 'bg-neutral-900 border-neutral-800'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-[10px] text-neutral-400 font-bold uppercase tracking-wider block">
                      Selected Package
                    </span>
                    <h3 className="text-sm font-extrabold text-white flex items-center space-x-1.5">
                      <span>{selectedPackage.name}</span>
                      <span>{selectedPackage.vipCrown}</span>
                    </h3>
                  </div>
                  <div className="text-right">
                    <span className="text-base font-black text-emerald-400 font-mono block">
                      ৳{selectedPackage.priceBdt}
                    </span>
                    <span className="text-[10px] text-neutral-400">Total BDT</span>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs pt-1 border-t border-neutral-800">
                  <div>
                    <span className="text-[10px] text-neutral-400">You will receive:</span>
                    <p className="font-mono font-bold text-amber-300 text-xs">
                      🪙 {selectedPackage.coins.toLocaleString()} Coins
                    </p>
                  </div>
                  <div>
                    <span className="text-[10px] text-neutral-400">VIP Membership:</span>
                    <p className="font-bold text-white text-xs flex items-center space-x-1">
                      <span>{selectedPackage.vipCrown}</span>
                      <span>{selectedPackage.vipTier}</span>
                    </p>
                  </div>
                </div>
              </div>

              {/* Step 1: Payment Method Selection */}
              <div className="space-y-2">
                <label className="text-xs font-black uppercase tracking-wider text-neutral-400 block">
                  1. Payment Method নির্বাচন করুন
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {/* bKash */}
                  <button
                    type="button"
                    onClick={() => setSelectedPaymentMethod('bKash')}
                    className={`p-3 rounded-2xl border flex flex-col items-center justify-center space-y-1 transition-all ${
                      selectedPaymentMethod === 'bKash'
                        ? 'bg-rose-950/60 border-rose-500 text-white ring-1 ring-rose-400 shadow-md shadow-rose-950/50'
                        : 'bg-neutral-900 border-neutral-800 text-neutral-400 hover:text-white'
                    }`}
                  >
                    <span className="text-base font-black text-rose-400">bKash</span>
                    <span className="text-[10px] font-bold">
                      {adminConfig.bkashType} ({adminConfig.bkashNumber})
                    </span>
                  </button>

                  {/* Nagad */}
                  <button
                    type="button"
                    onClick={() => setSelectedPaymentMethod('Nagad')}
                    className={`p-3 rounded-2xl border flex flex-col items-center justify-center space-y-1 transition-all ${
                      selectedPaymentMethod === 'Nagad'
                        ? 'bg-amber-950/60 border-amber-500 text-white ring-1 ring-amber-400 shadow-md shadow-amber-950/50'
                        : 'bg-neutral-900 border-neutral-800 text-neutral-400 hover:text-white'
                    }`}
                  >
                    <span className="text-base font-black text-amber-400">Nagad</span>
                    <span className="text-[10px] font-bold">
                      {adminConfig.nagadType} ({adminConfig.nagadNumber})
                    </span>
                  </button>
                </div>
              </div>

              {/* Step 2: Payment Details & One-Click Copy */}
              <div className="p-3.5 rounded-2xl bg-neutral-900/90 border border-neutral-800 space-y-2.5">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-extrabold text-white flex items-center space-x-1.5">
                    <span>Send Money To {selectedPaymentMethod}:</span>
                  </span>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-neutral-800 text-neutral-300">
                    {selectedPaymentMethod === 'bKash' ? adminConfig.bkashType : adminConfig.nagadType}
                  </span>
                </div>

                <div className="flex items-center justify-between p-2.5 rounded-xl bg-neutral-950 border border-neutral-800">
                  <span className="font-mono text-sm font-black text-amber-300">
                    {selectedPaymentMethod === 'bKash'
                      ? adminConfig.bkashNumber
                      : adminConfig.nagadNumber}
                  </span>
                  <button
                    type="button"
                    onClick={() =>
                      handleCopy(
                        selectedPaymentMethod === 'bKash'
                          ? adminConfig.bkashNumber
                          : adminConfig.nagadNumber,
                        'number'
                      )
                    }
                    className="flex items-center space-x-1 text-xs font-bold text-violet-300 hover:text-white bg-violet-950 px-2.5 py-1 rounded-lg border border-violet-800/60 transition-colors"
                  >
                    {copiedField === 'number' ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                        <span className="text-emerald-400">Copied!</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" />
                        <span>Copy Number</span>
                      </>
                    )}
                  </button>
                </div>

                <p className="text-[11px] text-neutral-400 leading-relaxed">
                  {adminConfig.paymentInstructions}
                </p>
              </div>

              {/* Step 3: Submission Form */}
              <form onSubmit={handleSubmitOrder} className="space-y-3">
                <label className="text-xs font-black uppercase tracking-wider text-neutral-400 block">
                  2. পেমেন্ট নিশ্চিতকরণ তথ্য দিন
                </label>

                {errorMsg && (
                  <div className="p-3 rounded-xl bg-rose-950/60 border border-rose-700/60 text-rose-300 text-xs flex items-start space-x-2">
                    <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5" />
                    <span>{errorMsg}</span>
                  </div>
                )}

                <div className="space-y-1">
                  <label className="text-[11px] text-neutral-300 font-bold block">
                    প্রেরক মোবাইল নম্বর (Sender Phone) *
                  </label>
                  <input
                    type="tel"
                    required
                    placeholder="e.g. 01712-XXXXXX"
                    value={senderPhone}
                    onChange={e => setSenderPhone(e.target.value)}
                    className="w-full px-3 py-2.5 rounded-xl bg-neutral-900 border border-neutral-800 text-white placeholder-neutral-600 text-xs focus:outline-none focus:border-amber-500 font-mono"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[11px] text-neutral-300 font-bold block">
                    Transaction ID (TrxID) *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. BK9A82X019"
                    value={transactionId}
                    onChange={e => setTransactionId(e.target.value)}
                    className="w-full px-3 py-2.5 rounded-xl bg-neutral-900 border border-neutral-800 text-white placeholder-neutral-600 text-xs focus:outline-none focus:border-amber-500 font-mono uppercase"
                  />
                </div>

                <div className="p-3 rounded-xl bg-neutral-900/60 border border-neutral-800/80 text-[11px] text-neutral-400 flex items-start space-x-2">
                  <ShieldCheck className="w-4 h-4 text-emerald-400 flex-shrink-0 mt-0.5" />
                  <span>
                    নিরাপত্তা নিয়ম: ভেরিফিকেশন ছাড়া অ্যাকাউন্টে কয়েন যোগ হবে না। অ্যাডমিন পেমেন্ট যাচাই করে অনুমোদন দিলে তাৎক্ষণিক কয়েন ও VIP স্ট্যাটাস জমা হবে।
                  </span>
                </div>

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full py-3 rounded-2xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-neutral-950 font-black text-xs sm:text-sm tracking-wide shadow-lg shadow-amber-500/20 transition-all flex items-center justify-center space-x-2 disabled:opacity-60 cursor-pointer active:scale-98"
                >
                  {isSubmitting ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin" />
                      <span>Submitting for Verification...</span>
                    </>
                  ) : (
                    <>
                      <span>Submit Payment for Admin Verification</span>
                      <ArrowRight className="w-4 h-4" />
                    </>
                  )}
                </button>
              </form>
            </div>
          )}

          {/* Success Order Confirmation View */}
          {activeTab === 'shop' && successOrder && (
            <div className="space-y-4 text-center py-2 animate-in fade-in zoom-in-95 duration-200">
              <div className="w-16 h-16 rounded-full bg-emerald-500/20 border border-emerald-500/50 text-emerald-400 flex items-center justify-center text-3xl mx-auto shadow-lg shadow-emerald-500/20">
                ✓
              </div>

              <div className="space-y-1">
                <h3 className="text-base font-black text-white">Payment Submitted!</h3>
                <p className="text-xs text-neutral-300">
                  আপনার পেমেন্ট রিকুয়েস্ট সফলভাবে জমা হয়েছে। অ্যাডমিন ভেরিফাই করছেন।
                </p>
              </div>

              <div className="p-3.5 rounded-2xl bg-neutral-900 border border-neutral-800 text-left space-y-2 text-xs">
                <div className="flex justify-between border-b border-neutral-800/80 pb-1.5">
                  <span className="text-neutral-400">Order ID:</span>
                  <span className="font-mono text-neutral-200 font-bold">{successOrder.id}</span>
                </div>
                <div className="flex justify-between border-b border-neutral-800/80 pb-1.5">
                  <span className="text-neutral-400">Package:</span>
                  <span className="text-white font-bold">{successOrder.packageName}</span>
                </div>
                <div className="flex justify-between border-b border-neutral-800/80 pb-1.5">
                  <span className="text-neutral-400">Coins to Credit:</span>
                  <span className="font-mono text-amber-300 font-bold">
                    🪙 {successOrder.coins.toLocaleString()}
                  </span>
                </div>
                <div className="flex justify-between border-b border-neutral-800/80 pb-1.5">
                  <span className="text-neutral-400">VIP Reward:</span>
                  <span className="text-white font-bold">{successOrder.vipTierReward}</span>
                </div>
                <div className="flex justify-between border-b border-neutral-800/80 pb-1.5">
                  <span className="text-neutral-400">Amount Paid:</span>
                  <span className="font-mono text-emerald-400 font-bold">
                    ৳{successOrder.amountBdt} ({successOrder.paymentMethod})
                  </span>
                </div>
                <div className="flex justify-between border-b border-neutral-800/80 pb-1.5">
                  <span className="text-neutral-400">Transaction ID:</span>
                  <span className="font-mono text-violet-300 font-bold">
                    {successOrder.transactionId}
                  </span>
                </div>
                <div className="flex justify-between pt-1">
                  <span className="text-neutral-400">Current Status:</span>
                  <span className="text-[11px] font-bold text-amber-300 bg-amber-950/70 border border-amber-600/50 px-2 py-0.5 rounded-full flex items-center space-x-1">
                    <Clock className="w-3 h-3 animate-pulse" />
                    <span>Pending Verification</span>
                  </span>
                </div>
              </div>

              <div className="flex items-center space-x-2 pt-2">
                <button
                  type="button"
                  onClick={() => {
                    setSuccessOrder(null);
                    setSelectedPackage(null);
                    setActiveTab('orders');
                  }}
                  className="flex-1 py-2.5 rounded-xl bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 text-xs font-bold text-white transition-colors"
                >
                  View My Orders
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setSuccessOrder(null);
                    setSelectedPackage(null);
                  }}
                  className="flex-1 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-neutral-950 text-xs font-black transition-colors"
                >
                  Buy Another Pack
                </button>
              </div>
            </div>
          )}

          {/* Orders History Tab */}
          {activeTab === 'orders' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-black uppercase tracking-wider text-neutral-400">
                  Your Coin Purchase History
                </h3>
                <span className="text-[11px] text-neutral-500 font-semibold">
                  {userOrders.length} records
                </span>
              </div>

              {userOrders.length === 0 ? (
                <div className="text-center py-10 space-y-2">
                  <div className="w-12 h-12 rounded-full bg-neutral-900 border border-neutral-800 flex items-center justify-center text-xl mx-auto text-neutral-600">
                    🪙
                  </div>
                  <p className="text-xs text-neutral-400">কোনো Coin Purchase ইতিহাস পাওয়া যায়নি।</p>
                  <button
                    onClick={() => setActiveTab('shop')}
                    className="text-xs text-amber-400 hover:underline font-bold"
                  >
                    Go to Coin Shop
                  </button>
                </div>
              ) : (
                userOrders.map(order => {
                  const isApproved = order.status === 'APPROVED';
                  const isPending = order.status === 'PENDING';
                  const isRejected = order.status === 'REJECTED';

                  return (
                    <div
                      key={order.id}
                      className="p-3.5 rounded-2xl bg-neutral-900/80 border border-neutral-800/90 space-y-2"
                    >
                      <div className="flex items-center justify-between">
                        <div>
                          <h4 className="text-xs font-bold text-white flex items-center space-x-1.5">
                            <span>{order.packageName}</span>
                            {order.vipTierReward && order.vipTierReward !== 'REGULAR' && (
                              <span className="text-[10px] font-black text-amber-300">
                                ({order.vipTierReward})
                              </span>
                            )}
                          </h4>
                          <p className="text-[10px] text-neutral-400 mt-0.5">
                            {order.displayTime || new Date(order.createdAt).toLocaleDateString()}
                          </p>
                        </div>

                        {/* Status Badge */}
                        <span
                          className={`text-[10px] font-black px-2.5 py-1 rounded-full border flex items-center space-x-1 ${
                            isApproved
                              ? 'bg-emerald-950/70 border-emerald-600/50 text-emerald-300'
                              : isPending
                              ? 'bg-amber-950/70 border-amber-600/50 text-amber-300'
                              : 'bg-rose-950/70 border-rose-600/50 text-rose-300'
                          }`}
                        >
                          {isApproved && <Check className="w-2.5 h-2.5" />}
                          {isPending && <Clock className="w-2.5 h-2.5 animate-pulse" />}
                          {isRejected && <X className="w-2.5 h-2.5" />}
                          <span>{order.status}</span>
                        </span>
                      </div>

                      <div className="p-2.5 rounded-xl bg-neutral-950 border border-neutral-800/80 grid grid-cols-2 gap-2 text-xs">
                        <div>
                          <span className="text-[10px] text-neutral-400 block">Coins Amount:</span>
                          <span className="font-mono font-bold text-amber-300">
                            🪙 {order.coins.toLocaleString()}
                          </span>
                        </div>
                        <div>
                          <span className="text-[10px] text-neutral-400 block">Paid Amount:</span>
                          <span className="font-mono font-bold text-emerald-400">
                            ৳{order.amountBdt} ({order.paymentMethod})
                          </span>
                        </div>
                      </div>

                      <div className="flex items-center justify-between text-[10px] text-neutral-400 pt-0.5">
                        <div className="flex items-center space-x-1 min-w-0">
                          <span>TrxID:</span>
                          <span className="font-mono font-semibold text-neutral-200">
                            {order.transactionId}
                          </span>
                        </div>
                        {order.adminNote && (
                          <span className="text-neutral-400 italic truncate max-w-[170px]" title={order.adminNote}>
                            {order.adminNote}
                          </span>
                        )}
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
