import React, { useState, useEffect, useRef } from 'react';
import { ArrowLeft, Send, X, Copy, Check, CheckCheck, Radio, Sparkles } from 'lucide-react';
import { User as UserType, DirectMessage } from '../types';
import { userService, getNumericUserId } from '../services/userService';

interface DirectMessageModalProps {
  currentUser: UserType;
  targetUser: UserType;
  onClose: () => void;
  onOpenProfile?: () => void;
}

export const DirectMessageModal: React.FC<DirectMessageModalProps> = ({
  currentUser,
  targetUser,
  onClose,
  onOpenProfile,
}) => {
  const [messages, setMessages] = useState<DirectMessage[]>([]);
  const [inputText, setInputText] = useState('');
  const [copiedId, setCopiedId] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const targetNumericId = targetUser.numericId || getNumericUserId(targetUser.id);

  const refreshMessages = () => {
    const list = userService.getConversation(currentUser.id, targetUser.id);
    setMessages([...list]);
  };

  useEffect(() => {
    refreshMessages();
    const unsub = userService.subscribe(() => {
      refreshMessages();
    });
    return unsub;
  }, [currentUser.id, targetUser.id]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;

    userService.sendMessage(currentUser.id, targetUser.id, inputText.trim());
    setInputText('');
    refreshMessages();
  };

  const handleCopyId = () => {
    navigator.clipboard.writeText(targetNumericId);
    setCopiedId(true);
    setTimeout(() => setCopiedId(false), 2000);
  };

  return (
    <div
      id="direct-message-modal"
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/85 backdrop-blur-md animate-fade-in"
    >
      <div className="w-full max-w-md bg-neutral-900 border border-neutral-800 rounded-t-3xl sm:rounded-3xl shadow-2xl shadow-violet-950/50 text-white h-[90vh] sm:h-[650px] flex flex-col overflow-hidden">
        {/* Chat Top Bar */}
        <div className="p-3.5 border-b border-neutral-800/90 bg-neutral-950/80 backdrop-blur-md flex items-center justify-between flex-shrink-0">
          <div className="flex items-center space-x-2.5 min-w-0">
            <button
              id="dm-back-btn"
              onClick={onClose}
              className="p-1.5 text-neutral-400 hover:text-white rounded-full hover:bg-neutral-800 transition-colors"
              aria-label="Back"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>

            {/* Target Avatar and Details */}
            <div
              onClick={onOpenProfile}
              className="flex items-center space-x-2.5 cursor-pointer min-w-0 group"
            >
              <div className="relative flex-shrink-0">
                <img
                  src={targetUser.avatar}
                  alt={targetUser.name}
                  className="w-10 h-10 rounded-full object-cover ring-2 ring-violet-500/40 group-hover:ring-violet-400 transition-all"
                />
                <span className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-emerald-500 rounded-full border-2 border-neutral-950"></span>
              </div>
              <div className="min-w-0">
                <h4 className="text-xs font-bold text-white group-hover:text-violet-300 transition-colors truncate">
                  {targetUser.name}
                </h4>
                <div className="flex items-center space-x-1.5">
                  <span className="text-[10px] text-neutral-400 truncate font-mono">
                    ID: {targetNumericId}
                  </span>
                  <span className="text-[9px] text-emerald-400 font-semibold flex items-center space-x-0.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                    <span>Online</span>
                  </span>
                </div>
              </div>
            </div>
          </div>

          <div className="flex items-center space-x-1">
            <button
              onClick={handleCopyId}
              className="p-2 text-neutral-400 hover:text-violet-300 rounded-full hover:bg-neutral-800 transition-colors"
              title="Copy User ID"
            >
              {copiedId ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
            </button>
            <button
              onClick={onClose}
              className="p-2 text-neutral-400 hover:text-white rounded-full hover:bg-neutral-800 transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* User Identity Info Banner */}
        <div className="px-4 py-2 bg-violet-950/25 border-b border-violet-900/30 flex items-center justify-between text-[11px] text-violet-300 flex-shrink-0">
          <div className="flex items-center space-x-1.5">
            <Sparkles className="w-3.5 h-3.5 text-violet-400" />
            <span>End-to-end direct audio salon messages</span>
          </div>
          <span className="text-[10px] text-neutral-400 font-mono">
            {targetUser.handle}
          </span>
        </div>

        {/* Message Thread History */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3 scrollbar-thin bg-neutral-950/40">
          {messages.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center p-6 text-neutral-500 space-y-2">
              <div className="w-12 h-12 rounded-full bg-violet-950/40 border border-violet-800/40 flex items-center justify-center text-violet-300 text-xl">
                💬
              </div>
              <p className="text-xs font-semibold text-neutral-300">
                Start a conversation with {targetUser.name}
              </p>
              <p className="text-[11px] text-neutral-500 max-w-[220px]">
                Say hello, share room feedback, or invite them to your next voice stage.
              </p>
            </div>
          ) : (
            messages.map(msg => {
              const isMe = msg.senderId === currentUser.id || msg.senderId === 'usr_me' || msg.senderId === 'usr_guest';

              return (
                <div
                  key={msg.id}
                  className={`flex flex-col ${isMe ? 'items-end' : 'items-start'}`}
                >
                  <div
                    className={`max-w-[78%] px-3.5 py-2.5 rounded-2xl text-xs leading-relaxed ${
                      isMe
                        ? 'bg-violet-600 text-white rounded-br-xs shadow-md shadow-violet-600/20'
                        : 'bg-neutral-800/90 text-neutral-100 rounded-bl-xs border border-neutral-700/60'
                    }`}
                  >
                    <p className="break-words">{msg.text}</p>
                  </div>
                  <div className="flex items-center space-x-1 mt-1 px-1 text-[9px] text-neutral-500">
                    <span>{msg.timestamp}</span>
                    {isMe && (
                      <CheckCheck className="w-3 h-3 text-violet-400 inline" />
                    )}
                  </div>
                </div>
              );
            })
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Message Input Footer */}
        <form
          onSubmit={handleSend}
          className="p-3 border-t border-neutral-800 bg-neutral-950/90 flex items-center space-x-2 flex-shrink-0"
        >
          <input
            id="dm-message-input"
            type="text"
            value={inputText}
            onChange={e => setInputText(e.target.value)}
            placeholder={`Message ${targetUser.name.split(' ')[0]}...`}
            className="flex-1 px-3.5 py-2.5 bg-neutral-900 border border-neutral-800 rounded-xl text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-violet-500 transition-colors"
          />
          <button
            id="dm-send-btn"
            type="submit"
            disabled={!inputText.trim()}
            className="p-2.5 rounded-xl bg-violet-600 hover:bg-violet-500 disabled:opacity-40 disabled:hover:bg-violet-600 text-white transition-all shadow-md shadow-violet-600/30 flex items-center justify-center cursor-pointer"
            aria-label="Send message"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  );
};
