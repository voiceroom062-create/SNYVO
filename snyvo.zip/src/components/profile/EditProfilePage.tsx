import React, { useState, useRef } from 'react';
import {
  ChevronLeft,
  Camera,
  Plus,
  Trash2,
  Star,
  Check,
  X,
  ChevronRight,
  Eye,
  RotateCw,
  Globe,
  User as UserIcon,
  Sparkles,
} from 'lucide-react';
import { User } from '../../types';
import { authService } from '../../services/firebaseService';

interface EditProfilePageProps {
  currentUser: User;
  onBack: () => void;
  onUpdateUser: (user: User) => void;
  onToast: (msg: string) => void;
}

interface CountryItem {
  name: string;
  code: string;
  flag: string;
}

const COUNTRIES: CountryItem[] = [
  { name: 'Bangladesh', code: 'BD', flag: '🇧🇩' },
  { name: 'Saudi Arabia', code: 'SA', flag: '🇸🇦' },
  { name: 'United Arab Emirates', code: 'AE', flag: '🇦🇪' },
  { name: 'India', code: 'IN', flag: '🇮🇳' },
  { name: 'Pakistan', code: 'PK', flag: '🇵🇰' },
  { name: 'United States', code: 'US', flag: '🇺🇸' },
  { name: 'United Kingdom', code: 'GB', flag: '🇬🇧' },
  { name: 'Canada', code: 'CA', flag: '🇨🇦' },
  { name: 'Malaysia', code: 'MY', flag: '🇲🇾' },
  { name: 'Singapore', code: 'SG', flag: '🇸🇬' },
  { name: 'Qatar', code: 'QA', flag: '🇶🇦' },
  { name: 'Kuwait', code: 'KW', flag: '🇰🇼' },
  { name: 'Oman', code: 'OM', flag: '🇴🇲' },
  { name: 'Bahrain', code: 'BH', flag: '🇧🇭' },
  { name: 'Indonesia', code: 'ID', flag: '🇮🇩' },
  { name: 'Turkey', code: 'TR', flag: '🇹🇷' },
  { name: 'Germany', code: 'DE', flag: '🇩🇪' },
  { name: 'France', code: 'FR', flag: '🇫🇷' },
  { name: 'Australia', code: 'AU', flag: '🇦🇺' },
  { name: 'Japan', code: 'JP', flag: '🇯🇵' },
];

export const EditProfilePage: React.FC<EditProfilePageProps> = ({
  currentUser,
  onBack,
  onUpdateUser,
  onToast,
}) => {
  // Load initial member-specific profile state
  const memberKey = `snyvo_profile_custom_${currentUser.id}`;
  const getSavedMemberData = () => {
    try {
      const raw = localStorage.getItem(memberKey);
      if (raw) return JSON.parse(raw);
    } catch (e) {
      console.error(e);
    }
    return null;
  };

  const savedData = getSavedMemberData();

  // Initial photos: up to 5 photos. First is main photo.
  const [photos, setPhotos] = useState<string[]>(() => {
    if (savedData?.photos && Array.isArray(savedData.photos) && savedData.photos.length > 0) {
      return savedData.photos.slice(0, 5);
    }
    if (currentUser.photos && currentUser.photos.length > 0) {
      return currentUser.photos.slice(0, 5);
    }
    return [currentUser.avatar];
  });

  // Basic Information states
  const [nickname, setNickname] = useState<string>(
    savedData?.nickname || currentUser.name || 'Snyvo Member'
  );
  const [country, setCountry] = useState<string>(
    savedData?.country || currentUser.country || 'Bangladesh'
  );
  const [countryFlag, setCountryFlag] = useState<string>(
    savedData?.countryFlag || currentUser.countryFlag || '🇧🇩'
  );
  const [signature, setSignature] = useState<string>(
    savedData?.signature || currentUser.signature || currentUser.bio || ''
  );
  const [gender, setGender] = useState<string>(
    savedData?.gender || currentUser.gender || 'Male'
  );
  const [showAge, setShowAge] = useState<boolean>(
    savedData?.showAge !== undefined ? savedData.showAge : (currentUser.showAge ?? false)
  );
  const [age, setAge] = useState<number>(
    savedData?.age || currentUser.age || 24
  );

  // Sub-dialogs
  const [activeSubDialog, setActiveSubDialog] = useState<
    null | 'nickname' | 'country' | 'signature' | 'gender' | 'age'
  >(null);

  // Temp draft states for sub-dialogs
  const [tempNickname, setTempNickname] = useState(nickname);
  const [tempSignature, setTempSignature] = useState(signature);
  const [tempAge, setTempAge] = useState(age);
  const [countrySearch, setCountrySearch] = useState('');

  // Image upload handler
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [activeSlotForUpload, setActiveSlotForUpload] = useState<number | null>(null);

  // Photo preview modal state
  const [previewPhotoUrl, setPreviewPhotoUrl] = useState<string | null>(null);

  // Handle Photo File Upload
  const handleTriggerUpload = (slotIndex: number) => {
    setActiveSlotForUpload(slotIndex);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
      fileInputRef.current.click();
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || activeSlotForUpload === null) return;

    if (!file.type.startsWith('image/')) {
      onToast('Please select a valid image file');
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      setPhotos((prev) => {
        const next = [...prev];
        if (activeSlotForUpload < next.length) {
          next[activeSlotForUpload] = result;
        } else {
          next.push(result);
        }
        return next.slice(0, 5);
      });
      onToast(`Photo ${activeSlotForUpload === 0 ? 'Main' : activeSlotForUpload + 1} updated!`);
    };
    reader.readAsDataURL(file);
  };

  // Delete photo
  const handleDeletePhoto = (index: number) => {
    if (photos.length <= 1) {
      onToast('You must keep at least 1 Main Profile Picture');
      return;
    }
    setPhotos((prev) => prev.filter((_, i) => i !== index));
    onToast('Photo deleted');
  };

  // Set photo as Main Profile Picture
  const handleSetAsMain = (index: number) => {
    if (index === 0) return;
    setPhotos((prev) => {
      const next = [...prev];
      const [selected] = next.splice(index, 1);
      next.unshift(selected);
      return next;
    });
    onToast('Selected photo set as Main Profile Picture! 🌟');
  };

  // Filtered countries
  const filteredCountries = COUNTRIES.filter((c) =>
    c.name.toLowerCase().includes(countrySearch.toLowerCase())
  );

  // Save changes handler
  const [isSaving, setIsSaving] = useState(false);
  const handleSaveChanges = async () => {
    setIsSaving(true);
    try {
      const mainPhoto = photos[0] || currentUser.avatar;
      const updatedData = {
        name: nickname.trim() || currentUser.name,
        avatar: mainPhoto,
        bio: signature.trim(),
        photos,
        country,
        countryFlag,
        signature: signature.trim(),
        gender,
        showAge,
        age,
      };

      // Save to authService
      const updatedUser = await authService.updateProfile(updatedData);

      // Save to member-specific local storage
      const memberPayload = {
        photos,
        nickname: updatedData.name,
        country,
        countryFlag,
        signature: updatedData.signature,
        gender,
        showAge,
        age,
        updatedAt: Date.now(),
      };
      localStorage.setItem(memberKey, JSON.stringify(memberPayload));

      onUpdateUser(updatedUser);
      onToast('Profile changes saved successfully! ✨');
      onBack();
    } catch (err) {
      console.error(err);
      onToast('Failed to save profile changes');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-neutral-950 text-white flex flex-col overflow-hidden animate-fadeIn">
      {/* Hidden File Input for local device photos */}
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleFileChange}
        accept="image/*"
        className="hidden"
      />

      {/* TOP BAR */}
      <div className="sticky top-0 bg-neutral-950/95 backdrop-blur-md px-4 py-3.5 z-20 border-b border-neutral-900 flex items-center justify-between">
        <button
          type="button"
          onClick={onBack}
          className="flex items-center space-x-1.5 text-neutral-300 hover:text-white transition-colors cursor-pointer py-1 px-2 -ml-2 rounded-xl hover:bg-neutral-900"
        >
          <ChevronLeft className="w-5 h-5" />
          <span className="text-sm font-bold">Back</span>
        </button>

        <h1 className="text-base font-black tracking-wide text-white">Edit Profile</h1>

        <button
          type="button"
          onClick={handleSaveChanges}
          disabled={isSaving}
          className="text-xs font-black px-3.5 py-1.5 rounded-full bg-violet-600 hover:bg-violet-500 text-white shadow-md active:scale-95 transition-all cursor-pointer disabled:opacity-50"
        >
          {isSaving ? 'Saving...' : 'Save'}
        </button>
      </div>

      {/* SCROLLABLE FORM BODY */}
      <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6 max-w-lg mx-auto w-full pb-28 scrollbar-none">
        {/* ============================================================
            1. PROFILE PHOTOS SECTION
            ============================================================ */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-xs font-bold uppercase tracking-wider text-neutral-400">
                Profile Photos
              </h2>
              <p className="text-[11px] text-neutral-500 mt-0.5">
                Up to 5 photos. First photo is your Main Profile Picture.
              </p>
            </div>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-neutral-900 text-neutral-400 border border-neutral-800">
              {photos.length} / 5 Slots
            </span>
          </div>

          {/* Photo Layout: Main Photo on top, then 4 additional photos grid */}
          <div className="space-y-3">
            {/* MAIN PROFILE PHOTO (Slot 1) */}
            <div className="relative rounded-3xl bg-neutral-900 border-2 border-violet-500/40 p-3 shadow-xl overflow-hidden group">
              <div className="flex items-center justify-between mb-2">
                <span className="inline-flex items-center space-x-1 px-2.5 py-0.5 rounded-full bg-violet-950 text-violet-300 text-[10px] font-black border border-violet-700/50">
                  <Star className="w-3 h-3 fill-violet-400 text-violet-400" />
                  <span>Main Profile Picture</span>
                </span>
                <span className="text-[10px] text-neutral-400 font-mono">Slot 1</span>
              </div>

              <div className="relative aspect-[16/10] sm:aspect-[16/9] rounded-2xl overflow-hidden bg-neutral-950 flex items-center justify-center">
                {photos[0] ? (
                  <>
                    <img
                      src={photos[0]}
                      alt="Main Profile"
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-black/30 opacity-90 sm:opacity-0 sm:group-hover:opacity-100 transition-opacity flex items-end justify-between p-3">
                      <button
                        type="button"
                        onClick={() => setPreviewPhotoUrl(photos[0])}
                        className="px-2.5 py-1 rounded-xl bg-black/60 backdrop-blur-md text-white text-[11px] font-bold flex items-center space-x-1 hover:bg-black/80"
                      >
                        <Eye className="w-3 h-3" />
                        <span>Preview</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => handleTriggerUpload(0)}
                        className="px-3 py-1.5 rounded-xl bg-violet-600 hover:bg-violet-500 text-white text-xs font-black shadow-lg flex items-center space-x-1.5 active:scale-95 transition-all"
                      >
                        <Camera className="w-3.5 h-3.5" />
                        <span>Replace Photo</span>
                      </button>
                    </div>
                  </>
                ) : (
                  <button
                    type="button"
                    onClick={() => handleTriggerUpload(0)}
                    className="w-full h-full flex flex-col items-center justify-center text-neutral-500 hover:text-violet-400 transition-colors cursor-pointer"
                  >
                    <Plus className="w-8 h-8 mb-1" />
                    <span className="text-xs font-bold">+ Add Main Photo</span>
                  </button>
                )}
              </div>
            </div>

            {/* ADDITIONAL 4 PHOTOS (Slots 2 to 5) */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
              {[1, 2, 3, 4].map((slotIdx) => {
                const hasPhoto = photos.length > slotIdx;
                const photoSrc = photos[slotIdx];

                return (
                  <div
                    key={slotIdx}
                    className="relative aspect-square rounded-2xl bg-neutral-900 border border-neutral-800 overflow-hidden flex flex-col items-center justify-center group"
                  >
                    {hasPhoto ? (
                      <>
                        <img
                          src={photoSrc}
                          alt={`Photo ${slotIdx + 1}`}
                          className="w-full h-full object-cover"
                        />
                        <div className="absolute inset-0 bg-black/60 backdrop-blur-[2px] opacity-90 sm:opacity-0 sm:group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center p-1.5 space-y-1">
                          <button
                            type="button"
                            onClick={() => handleSetAsMain(slotIdx)}
                            className="w-full py-1 px-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-neutral-950 text-[10px] font-black shadow flex items-center justify-center space-x-1"
                            title="Set as Main Profile Picture"
                          >
                            <Star className="w-2.5 h-2.5 fill-current" />
                            <span>Set Main</span>
                          </button>

                          <div className="flex items-center space-x-1 w-full">
                            <button
                              type="button"
                              onClick={() => handleTriggerUpload(slotIdx)}
                              className="flex-1 py-1 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-white text-[9px] font-bold"
                            >
                              Replace
                            </button>
                            <button
                              type="button"
                              onClick={() => handleDeletePhoto(slotIdx)}
                              className="p-1 rounded-lg bg-rose-950/80 hover:bg-rose-900 text-rose-300"
                              title="Delete Photo"
                            >
                              <Trash2 className="w-3 h-3" />
                            </button>
                          </div>
                        </div>

                        {/* Slot label */}
                        <span className="absolute bottom-1 right-1.5 px-1.5 py-0.5 rounded-md bg-black/70 text-[9px] font-mono text-neutral-400">
                          #{slotIdx + 1}
                        </span>
                      </>
                    ) : (
                      <button
                        type="button"
                        onClick={() => handleTriggerUpload(slotIdx)}
                        className="w-full h-full flex flex-col items-center justify-center p-2 text-neutral-500 hover:text-violet-400 hover:bg-neutral-800/50 transition-all cursor-pointer border-2 border-dashed border-neutral-800 hover:border-violet-500/50 rounded-2xl"
                      >
                        <Plus className="w-5 h-5 mb-1" />
                        <span className="text-[10px] font-bold text-center leading-tight">
                          + Add Photo
                        </span>
                        <span className="text-[8px] text-neutral-600 mt-0.5 font-mono">
                          Photo {slotIdx + 1}
                        </span>
                      </button>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* ============================================================
            2. BASIC INFORMATION SECTION
            ============================================================ */}
        <div className="space-y-2.5">
          <h2 className="text-xs font-bold uppercase tracking-wider text-neutral-400">
            Basic Information
          </h2>

          <div className="bg-white text-neutral-900 rounded-3xl shadow-xl border border-neutral-100 divide-y divide-neutral-100 overflow-hidden">
            {/* Nickname Row */}
            <button
              type="button"
              onClick={() => {
                setTempNickname(nickname);
                setActiveSubDialog('nickname');
              }}
              className="w-full flex items-center justify-between px-4 py-4 hover:bg-neutral-50 active:bg-neutral-100 transition-colors group cursor-pointer text-left"
            >
              <span className="text-sm font-bold text-neutral-800">Nickname</span>
              <div className="flex items-center space-x-2">
                <span className="text-sm font-semibold text-neutral-900 max-w-[170px] truncate">
                  {nickname}
                </span>
                <ChevronRight className="w-4 h-4 text-neutral-400 group-hover:text-neutral-600 group-hover:translate-x-0.5 transition-transform" />
              </div>
            </button>

            {/* Country Row */}
            <button
              type="button"
              onClick={() => {
                setCountrySearch('');
                setActiveSubDialog('country');
              }}
              className="w-full flex items-center justify-between px-4 py-4 hover:bg-neutral-50 active:bg-neutral-100 transition-colors group cursor-pointer text-left"
            >
              <span className="text-sm font-bold text-neutral-800">Country</span>
              <div className="flex items-center space-x-2">
                <span className="text-sm font-semibold text-neutral-900 flex items-center space-x-1.5">
                  <span className="text-base">{countryFlag}</span>
                  <span>{country}</span>
                </span>
                <ChevronRight className="w-4 h-4 text-neutral-400 group-hover:text-neutral-600 group-hover:translate-x-0.5 transition-transform" />
              </div>
            </button>

            {/* Signature Row */}
            <button
              type="button"
              onClick={() => {
                setTempSignature(signature);
                setActiveSubDialog('signature');
              }}
              className="w-full flex items-center justify-between px-4 py-4 hover:bg-neutral-50 active:bg-neutral-100 transition-colors group cursor-pointer text-left"
            >
              <span className="text-sm font-bold text-neutral-800">Signature</span>
              <div className="flex items-center space-x-2 max-w-[65%]">
                <span className="text-sm font-medium text-neutral-500 truncate">
                  {signature || 'Write your signature'}
                </span>
                <ChevronRight className="w-4 h-4 text-neutral-400 group-hover:text-neutral-600 group-hover:translate-x-0.5 transition-transform flex-shrink-0" />
              </div>
            </button>

            {/* Gender Row */}
            <button
              type="button"
              onClick={() => setActiveSubDialog('gender')}
              className="w-full flex items-center justify-between px-4 py-4 hover:bg-neutral-50 active:bg-neutral-100 transition-colors group cursor-pointer text-left"
            >
              <span className="text-sm font-bold text-neutral-800">Gender</span>
              <div className="flex items-center space-x-2">
                <span className="text-sm font-semibold text-neutral-900">
                  {gender === 'Male'
                    ? 'Male ♂️'
                    : gender === 'Female'
                    ? 'Female ♀️'
                    : 'Secret 🔒'}
                </span>
                <ChevronRight className="w-4 h-4 text-neutral-400 group-hover:text-neutral-600 group-hover:translate-x-0.5 transition-transform" />
              </div>
            </button>

            {/* Show Age Row with [ ON / OFF ] Toggle */}
            <div className="flex items-center justify-between px-4 py-4">
              <div>
                <span className="text-sm font-bold text-neutral-800 block">Show Age</span>
                <span className="text-[11px] text-neutral-400">
                  {showAge ? `Visible on Profile (${age} yrs)` : 'Hidden from public Profile'}
                </span>
              </div>

              <div className="flex items-center space-x-3">
                {showAge && (
                  <button
                    type="button"
                    onClick={() => {
                      setTempAge(age);
                      setActiveSubDialog('age');
                    }}
                    className="text-xs font-bold font-mono px-2 py-1 rounded-lg bg-neutral-100 hover:bg-neutral-200 text-neutral-800 border border-neutral-200"
                    title="Change Age"
                  >
                    {age} yrs ✎
                  </button>
                )}

                {/* ON/OFF Toggle Switch */}
                <button
                  type="button"
                  onClick={() => {
                    const next = !showAge;
                    setShowAge(next);
                    onToast(`Show Age toggled ${next ? 'ON' : 'OFF'}`);
                  }}
                  className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors cursor-pointer ${
                    showAge ? 'bg-violet-600' : 'bg-neutral-300'
                  }`}
                  aria-label="Toggle Show Age"
                >
                  <span
                    className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                      showAge ? 'translate-x-6' : 'translate-x-1'
                    }`}
                  />
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* ============================================================
            BOTTOM SAVE CHANGES BUTTON
            ============================================================ */}
        <div className="pt-2">
          <button
            type="button"
            onClick={handleSaveChanges}
            disabled={isSaving}
            className="w-full py-4 rounded-2xl bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-500 hover:to-indigo-500 text-white font-black text-sm shadow-xl shadow-violet-950/40 active:scale-98 transition-all cursor-pointer flex items-center justify-center space-x-2 disabled:opacity-50"
          >
            <Check className="w-5 h-5" />
            <span>{isSaving ? 'Saving Changes...' : 'Save Changes'}</span>
          </button>
          <p className="text-center text-[11px] text-neutral-500 mt-2.5">
            Changes will be reflected immediately across your public SNYVO profile.
          </p>
        </div>
      </div>

      {/* ============================================================
          SUB-DIALOG: 3. NICKNAME
          ============================================================ */}
      {activeSubDialog === 'nickname' && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 animate-fadeIn">
          <div className="w-full max-w-sm bg-neutral-900 border border-neutral-800 rounded-3xl p-5 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-neutral-800 pb-3">
              <h3 className="text-sm font-black text-white">Edit Nickname</h3>
              <button
                type="button"
                onClick={() => setActiveSubDialog(null)}
                className="p-1 rounded-full text-neutral-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-1.5">
              <label className="block text-[10px] font-bold uppercase text-neutral-400">
                Nickname
              </label>
              <input
                type="text"
                value={tempNickname}
                onChange={(e) => setTempNickname(e.target.value)}
                maxLength={30}
                placeholder="Enter your nickname"
                className="w-full px-3.5 py-2.5 bg-neutral-950 border border-neutral-700 rounded-xl text-sm text-white focus:outline-none focus:border-violet-500"
                autoFocus
              />
              <span className="text-[10px] text-neutral-500 block text-right font-mono">
                {tempNickname.length} / 30
              </span>
            </div>

            <div className="flex space-x-2 pt-2">
              <button
                type="button"
                onClick={() => setActiveSubDialog(null)}
                className="flex-1 py-2.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-300 text-xs font-bold"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  if (!tempNickname.trim()) {
                    onToast('Nickname cannot be empty');
                    return;
                  }
                  setNickname(tempNickname.trim());
                  setActiveSubDialog(null);
                  onToast('Nickname updated! Tap Save Changes to persist.');
                }}
                className="flex-1 py-2.5 rounded-xl bg-violet-600 hover:bg-violet-500 text-white text-xs font-black shadow"
              >
                Save
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ============================================================
          SUB-DIALOG: 4. COUNTRY SELECTION
          ============================================================ */}
      {activeSubDialog === 'country' && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4 animate-fadeIn">
          <div className="w-full max-w-sm bg-neutral-900 border border-neutral-800 rounded-t-3xl sm:rounded-3xl p-5 flex flex-col max-h-[80vh] shadow-2xl">
            <div className="flex items-center justify-between border-b border-neutral-800 pb-3">
              <div className="flex items-center space-x-2">
                <Globe className="w-4 h-4 text-violet-400" />
                <h3 className="text-sm font-black text-white">Select Country</h3>
              </div>
              <button
                type="button"
                onClick={() => setActiveSubDialog(null)}
                className="p-1 rounded-full text-neutral-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="my-3">
              <input
                type="text"
                value={countrySearch}
                onChange={(e) => setCountrySearch(e.target.value)}
                placeholder="Search country..."
                className="w-full px-3.5 py-2 bg-neutral-950 border border-neutral-800 rounded-xl text-xs text-white focus:outline-none focus:border-violet-500"
              />
            </div>

            <div className="flex-1 overflow-y-auto space-y-1 pr-1 scrollbar-thin">
              {filteredCountries.map((c) => {
                const isSelected = country === c.name;
                return (
                  <button
                    type="button"
                    key={c.code}
                    onClick={() => {
                      setCountry(c.name);
                      setCountryFlag(c.flag);
                      setActiveSubDialog(null);
                      onToast(`Selected ${c.flag} ${c.name}`);
                    }}
                    className={`w-full flex items-center justify-between p-2.5 rounded-xl text-left transition-colors cursor-pointer ${
                      isSelected
                        ? 'bg-violet-950/80 border border-violet-600 text-white font-bold'
                        : 'hover:bg-neutral-800 text-neutral-300'
                    }`}
                  >
                    <div className="flex items-center space-x-3">
                      <span className="text-xl">{c.flag}</span>
                      <span className="text-xs font-semibold">{c.name}</span>
                    </div>
                    {isSelected && <Check className="w-4 h-4 text-violet-400" />}
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* ============================================================
          SUB-DIALOG: 5. SIGNATURE
          ============================================================ */}
      {activeSubDialog === 'signature' && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 animate-fadeIn">
          <div className="w-full max-w-sm bg-neutral-900 border border-neutral-800 rounded-3xl p-5 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-neutral-800 pb-3">
              <h3 className="text-sm font-black text-white">Personal Signature</h3>
              <button
                type="button"
                onClick={() => setActiveSubDialog(null)}
                className="p-1 rounded-full text-neutral-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-1.5">
              <label className="block text-[10px] font-bold uppercase text-neutral-400">
                Signature / Bio
              </label>
              <textarea
                value={tempSignature}
                onChange={(e) => setTempSignature(e.target.value)}
                maxLength={120}
                rows={3}
                placeholder="Write your signature for other members to see..."
                className="w-full px-3.5 py-2.5 bg-neutral-950 border border-neutral-700 rounded-xl text-xs text-white focus:outline-none focus:border-violet-500 resize-none"
                autoFocus
              />
              <span className="text-[10px] text-neutral-500 block text-right font-mono">
                {tempSignature.length} / 120
              </span>
            </div>

            <div className="flex space-x-2 pt-2">
              <button
                type="button"
                onClick={() => setActiveSubDialog(null)}
                className="flex-1 py-2.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-300 text-xs font-bold"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  setSignature(tempSignature.trim());
                  setActiveSubDialog(null);
                  onToast('Signature updated! Tap Save Changes to persist.');
                }}
                className="flex-1 py-2.5 rounded-xl bg-violet-600 hover:bg-violet-500 text-white text-xs font-black shadow"
              >
                Save
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ============================================================
          SUB-DIALOG: 6. GENDER SELECTION
          ============================================================ */}
      {activeSubDialog === 'gender' && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 animate-fadeIn">
          <div className="w-full max-w-xs bg-neutral-900 border border-neutral-800 rounded-3xl p-5 space-y-3 shadow-2xl">
            <div className="flex items-center justify-between border-b border-neutral-800 pb-3">
              <h3 className="text-sm font-black text-white">Select Gender</h3>
              <button
                type="button"
                onClick={() => setActiveSubDialog(null)}
                className="p-1 rounded-full text-neutral-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-2 pt-1">
              {[
                { id: 'Male', label: 'Male ♂️' },
                { id: 'Female', label: 'Female ♀️' },
                { id: 'Secret', label: 'Secret / Hidden 🔒' },
              ].map((g) => {
                const isSelected = gender === g.id;
                return (
                  <button
                    type="button"
                    key={g.id}
                    onClick={() => {
                      setGender(g.id);
                      setActiveSubDialog(null);
                      onToast(`Gender set to ${g.label}`);
                    }}
                    className={`w-full flex items-center justify-between p-3 rounded-xl text-left transition-colors cursor-pointer ${
                      isSelected
                        ? 'bg-violet-950 border border-violet-600 text-white font-bold'
                        : 'bg-neutral-950 border border-neutral-800 text-neutral-300 hover:bg-neutral-800'
                    }`}
                  >
                    <span className="text-xs">{g.label}</span>
                    {isSelected && <Check className="w-4 h-4 text-violet-400" />}
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* ============================================================
          SUB-DIALOG: AGE PICKER
          ============================================================ */}
      {activeSubDialog === 'age' && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 animate-fadeIn">
          <div className="w-full max-w-xs bg-neutral-900 border border-neutral-800 rounded-3xl p-5 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-neutral-800 pb-3">
              <h3 className="text-sm font-black text-white">Set Your Age</h3>
              <button
                type="button"
                onClick={() => setActiveSubDialog(null)}
                className="p-1 rounded-full text-neutral-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-2">
              <label className="block text-[10px] font-bold uppercase text-neutral-400">
                Age (Years)
              </label>
              <input
                type="number"
                min={13}
                max={99}
                value={tempAge}
                onChange={(e) => setTempAge(parseInt(e.target.value, 10) || 18)}
                className="w-full px-3.5 py-2.5 bg-neutral-950 border border-neutral-700 rounded-xl text-sm font-mono text-white text-center focus:outline-none focus:border-violet-500"
              />
              <p className="text-[10px] text-neutral-500 text-center">
                Only displayed when "Show Age" is turned ON
              </p>
            </div>

            <div className="flex space-x-2 pt-1">
              <button
                type="button"
                onClick={() => setActiveSubDialog(null)}
                className="flex-1 py-2.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-300 text-xs font-bold"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  setAge(tempAge);
                  setActiveSubDialog(null);
                  onToast(`Age set to ${tempAge}`);
                }}
                className="flex-1 py-2.5 rounded-xl bg-violet-600 hover:bg-violet-500 text-white text-xs font-black shadow"
              >
                Done
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ============================================================
          PHOTO PREVIEW MODAL
          ============================================================ */}
      {previewPhotoUrl && (
        <div
          className="fixed inset-0 z-50 bg-black/95 backdrop-blur-md flex flex-col items-center justify-center p-4 animate-fadeIn"
          onClick={() => setPreviewPhotoUrl(null)}
        >
          <div
            className="relative max-w-md w-full max-h-[85vh] flex flex-col items-center"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              type="button"
              onClick={() => setPreviewPhotoUrl(null)}
              className="absolute -top-12 right-0 p-2 rounded-full bg-neutral-800 hover:bg-neutral-700 text-white"
            >
              <X className="w-5 h-5" />
            </button>
            <img
              src={previewPhotoUrl}
              alt="Preview"
              className="w-full max-h-[75vh] object-contain rounded-3xl shadow-2xl border border-neutral-800"
            />
          </div>
        </div>
      )}
    </div>
  );
};
