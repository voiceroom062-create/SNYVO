import React, { useState } from 'react';
import { X, ShieldCheck, Crown, Sparkles, ChevronRight, Award } from 'lucide-react';
import { User } from '../../types';

interface ProfileAristocracyModalProps {
  currentUser: User;
  onClose: () => void;
  onToast: (msg: string) => void;
}

const NOBILITY_RANKS = [
  {
    name: 'Knight',
    title: 'Imperial Knight',
    icon: '⚔️',
    price: '10,000 Coins / Mo',
    perks: ['Bronze Shield Badge', 'Knight Mount Entrance', 'Highlighted Nickname'],
    color: 'from-amber-700 to-yellow-600',
  },
  {
    name: 'Baron',
    title: 'High Baron',
    icon: '🛡️',
    price: '50,000 Coins / Mo',
    perks: ['Silver Crest Badge', 'Pegasus Entrance Animation', 'Noble Chat Bubble'],
    color: 'from-blue-600 to-indigo-700',
  },
  {
    name: 'Viscount',
    title: 'Royal Viscount',
    icon: '⚜️',
    price: '150,000 Coins / Mo',
    perks: ['Golden Fleur-de-lis', 'Griffin Sky Chariot Entry', 'Exclusive Room Kick Immunity'],
    color: 'from-purple-600 to-pink-600',
  },
  {
    name: 'Count',
    title: 'Grand Count',
    icon: '🏰',
    price: '500,000 Coins / Mo',
    perks: ['Imperial Fortress Badge', 'Dragon Steed Entry', 'Monthly 30,000 Coin Grant'],
    color: 'from-rose-600 to-red-700',
  },
  {
    name: 'Duke',
    title: 'Sovereign Duke',
    icon: '👑',
    price: '2,000,000 Coins / Mo',
    perks: ['Diamond Crown Insignia', 'Golden Celestial Carriage', 'Full Room Broadcast Alert'],
    color: 'from-amber-500 to-yellow-300',
  },
  {
    name: 'Emperor',
    title: 'Supreme Emperor',
    icon: '☀️',
    price: '10,000,000 Coins / Mo',
    perks: ['Solar Emperor Halo', 'Cosmic Leviathan Entry Effect', 'App-wide Global Marquee Banner'],
    color: 'from-fuchsia-600 via-amber-400 to-cyan-400',
  },
];

export const ProfileAristocracyModal: React.FC<ProfileAristocracyModalProps> = ({
  currentUser,
  onClose,
  onToast,
}) => {
  const [selectedRank, setSelectedRank] = useState(NOBILITY_RANKS[0]);
  const [currentNobility, setCurrentNobility] = useState<string>(() => {
    try {
      return localStorage.getItem(`snyvo_aristocracy_${currentUser.id}`) || 'Knight';
    } catch {
      return 'Knight';
    }
  });

  const handleEquipNobility = (rankName: string) => {
    setCurrentNobility(rankName);
    localStorage.setItem(`snyvo_aristocracy_${currentUser.id}`, rankName);
    onToast(`⚜️ Equipped Nobility Rank: ${rankName}!`);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4 animate-fadeIn">
      <div
        className="w-full max-w-md bg-neutral-950 border border-purple-800/40 rounded-t-3xl sm:rounded-3xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="relative bg-gradient-to-r from-purple-800 via-indigo-900 to-neutral-900 p-5 text-white">
          <button
            type="button"
            onClick={onClose}
            className="absolute top-3 right-3 p-1.5 rounded-full bg-black/30 hover:bg-black/50 text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
          <div className="flex items-center space-x-3">
            <div className="w-12 h-12 rounded-2xl bg-purple-500/20 border border-purple-400/40 flex items-center justify-center text-2xl">
              ⚜️
            </div>
            <div>
              <h3 className="text-xl font-black tracking-tight">Aristocracy System</h3>
              <p className="text-xs text-purple-200/80">Imperial Nobility Ranks & Royal Privileges</p>
            </div>
          </div>
        </div>

        {/* Current Active Rank */}
        <div className="p-3.5 bg-neutral-900/90 border-b border-neutral-800 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <span className="text-xl">
              {NOBILITY_RANKS.find((r) => r.name === currentNobility)?.icon || '⚔️'}
            </span>
            <div>
              <span className="text-[10px] uppercase font-bold text-neutral-400 block">Your Nobility</span>
              <span className="text-xs font-black text-amber-300">{currentNobility}</span>
            </div>
          </div>
          <span className="text-[10px] px-2.5 py-1 rounded-full bg-purple-950 text-purple-300 border border-purple-700/50 font-bold">
            Active
          </span>
        </div>

        {/* Horizontal Rank Selector */}
        <div className="p-3 overflow-x-auto flex space-x-2 border-b border-neutral-800 scrollbar-none bg-neutral-950">
          {NOBILITY_RANKS.map((rank) => {
            const isSelected = selectedRank.name === rank.name;
            return (
              <button
                type="button"
                key={rank.name}
                onClick={() => setSelectedRank(rank)}
                className={`flex-shrink-0 px-3 py-2 rounded-2xl border text-center transition-all ${
                  isSelected
                    ? 'bg-purple-950/70 border-purple-500 text-white shadow-md'
                    : 'bg-neutral-900 border-neutral-800 text-neutral-400 hover:text-white'
                }`}
              >
                <div className="text-xl">{rank.icon}</div>
                <div className="text-[11px] font-bold mt-1">{rank.name}</div>
              </button>
            );
          })}
        </div>

        {/* Selected Rank Detail */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          <div className={`p-4 rounded-3xl bg-gradient-to-br ${selectedRank.color} text-white shadow-lg`}>
            <div className="flex items-center justify-between">
              <div>
                <span className="text-[10px] uppercase font-bold text-white/80">Nobility Tier</span>
                <h4 className="text-lg font-black">{selectedRank.title}</h4>
              </div>
              <div className="text-3xl">{selectedRank.icon}</div>
            </div>
            <p className="text-xs text-white/90 font-mono mt-1">{selectedRank.price}</p>
          </div>

          <div className="space-y-2">
            <h5 className="text-xs font-bold uppercase tracking-wider text-neutral-400">
              Rank Privileges
            </h5>
            {selectedRank.perks.map((perk) => (
              <div
                key={perk}
                className="p-2.5 rounded-xl bg-neutral-900 border border-neutral-800 flex items-center space-x-2 text-xs text-neutral-200"
              >
                <Sparkles className="w-3.5 h-3.5 text-purple-400 flex-shrink-0" />
                <span>{perk}</span>
              </div>
            ))}
          </div>

          <button
            type="button"
            onClick={() => handleEquipNobility(selectedRank.name)}
            className="w-full py-3 rounded-2xl bg-gradient-to-r from-purple-600 to-indigo-600 text-white font-bold text-xs shadow-lg shadow-purple-900/40 hover:opacity-90 active:scale-98 transition-all"
          >
            {currentNobility === selectedRank.name ? 'Equipped' : `Equip ${selectedRank.name} Crest`}
          </button>
        </div>
      </div>
    </div>
  );
};
