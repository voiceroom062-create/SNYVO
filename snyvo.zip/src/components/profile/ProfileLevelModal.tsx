import React, { useState, useEffect } from 'react';
import {
  X,
  TrendingUp,
  Sparkles,
  Flame,
  Crown,
  ChevronRight,
  ShieldCheck,
  CheckCircle2,
  RefreshCw,
  Zap,
} from 'lucide-react';
import { User } from '../../types';
import { levelService, UserLevelStats } from '../../services/levelService';

interface ProfileLevelModalProps {
  currentUser: User;
  onClose: () => void;
  onToast: (msg: string) => void;
}

export const ProfileLevelModal: React.FC<ProfileLevelModalProps> = ({
  currentUser,
  onClose,
  onToast,
}) => {
  const [activeTab, setActiveTab] = useState<'sending' | 'receiving' | 'milestones'>('sending');
  const [stats, setStats] = useState<UserLevelStats>(() =>
    levelService.getUserLevelStats(currentUser.id)
  );

  useEffect(() => {
    setStats(levelService.getUserLevelStats(currentUser.id));
  }, [currentUser.id]);

  const sendingBadge = levelService.getBadgeForLevel(stats.sendingLevel, 'sending');
  const receivingBadge = levelService.getBadgeForLevel(stats.receivingLevel, 'receiving');

  const sendingProgress = levelService.getProgressToNextLevel(stats.totalCoinsSent);
  const receivingProgress = levelService.getProgressToNextLevel(stats.totalCoinsReceived);

  // Quick milestone test action
  const handleTestMilestone = (type: 'sending' | 'receiving', coins: number, label: string) => {
    const updated = levelService.setCoinsForTesting(currentUser.id, type, coins);
    setStats({ ...updated });
    onToast(`Simulated ${label}: ${coins.toLocaleString()} Coins!`);
  };

  const handleResetToDefault = () => {
    const reset = levelService.resetToDefault(currentUser.id);
    setStats({ ...reset });
    onToast('Reset to Level 1 (0 Coins Sent/Received)');
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4 animate-fadeIn">
      <div
        className="w-full max-w-md bg-neutral-950 border border-neutral-800 rounded-t-3xl sm:rounded-3xl overflow-hidden shadow-2xl flex flex-col max-h-[92vh] h-[85vh] sm:h-auto text-white"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="relative bg-gradient-to-r from-violet-900 via-neutral-900 to-amber-950 p-4 border-b border-neutral-800 flex items-center justify-between">
          <div className="flex items-center space-x-2.5">
            <div className="w-10 h-10 rounded-2xl bg-white/10 flex items-center justify-center text-xl">
              ⚡
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h3 className="text-base font-black tracking-wide">SNYVO Level System</h3>
              </div>
              <p className="text-[11px] text-neutral-400">
                Lifetime Cumulative Sending & Receiving Progression
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-full bg-neutral-800/80 hover:bg-neutral-700 text-neutral-300 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Level Overview 2-Card Banner */}
        <div className="grid grid-cols-2 gap-2 p-3 bg-neutral-900/60 border-b border-neutral-800">
          {/* Sending Level Card */}
          <button
            type="button"
            onClick={() => setActiveTab('sending')}
            className={`p-3 rounded-2xl border text-left transition-all cursor-pointer ${
              activeTab === 'sending'
                ? 'bg-amber-950/40 border-amber-500/60 shadow-lg shadow-amber-500/10'
                : 'bg-neutral-900/40 border-neutral-800 hover:border-neutral-700'
            }`}
          >
            <div className="flex items-center justify-between">
              <span className="text-[10px] uppercase font-bold text-amber-400 flex items-center space-x-1">
                <Flame className="w-3 h-3 text-amber-400" />
                <span>Sending</span>
              </span>
              <span className="text-base">{sendingBadge.icon}</span>
            </div>
            <div className="text-lg font-black text-amber-300 font-mono mt-0.5">
              Lv. {stats.sendingLevel}
            </div>
            <div className="text-[10px] text-neutral-400 font-medium truncate">
              {sendingBadge.tierName}
            </div>
            <div className="text-[10px] font-mono text-neutral-500 mt-1">
              {stats.totalCoinsSent.toLocaleString()} 🪙
            </div>
          </button>

          {/* Receiving Level Card */}
          <button
            type="button"
            onClick={() => setActiveTab('receiving')}
            className={`p-3 rounded-2xl border text-left transition-all cursor-pointer ${
              activeTab === 'receiving'
                ? 'bg-pink-950/40 border-pink-500/60 shadow-lg shadow-pink-500/10'
                : 'bg-neutral-900/40 border-neutral-800 hover:border-neutral-700'
            }`}
          >
            <div className="flex items-center justify-between">
              <span className="text-[10px] uppercase font-bold text-pink-400 flex items-center space-x-1">
                <Crown className="w-3 h-3 text-pink-400" />
                <span>Receiving</span>
              </span>
              <span className="text-base">{receivingBadge.icon}</span>
            </div>
            <div className="text-lg font-black text-pink-300 font-mono mt-0.5">
              Lv. {stats.receivingLevel}
            </div>
            <div className="text-[10px] text-neutral-400 font-medium truncate">
              {receivingBadge.tierName}
            </div>
            <div className="text-[10px] font-mono text-neutral-500 mt-1">
              {stats.totalCoinsReceived.toLocaleString()} 🪙
            </div>
          </button>
        </div>

        {/* Tab Selector */}
        <div className="flex border-b border-neutral-800 bg-neutral-900/30 px-3 pt-2">
          <button
            type="button"
            onClick={() => setActiveTab('sending')}
            className={`flex-1 py-2 text-xs font-bold border-b-2 transition-colors cursor-pointer ${
              activeTab === 'sending'
                ? 'border-amber-400 text-amber-300'
                : 'border-transparent text-neutral-400 hover:text-white'
            }`}
          >
            🔥 Sending Level
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('receiving')}
            className={`flex-1 py-2 text-xs font-bold border-b-2 transition-colors cursor-pointer ${
              activeTab === 'receiving'
                ? 'border-pink-400 text-pink-300'
                : 'border-transparent text-neutral-400 hover:text-white'
            }`}
          >
            👑 Receiving Level
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('milestones')}
            className={`flex-1 py-2 text-xs font-bold border-b-2 transition-colors cursor-pointer ${
              activeTab === 'milestones'
                ? 'border-violet-400 text-violet-300'
                : 'border-transparent text-neutral-400 hover:text-white'
            }`}
          >
            🌟 Milestones
          </button>
        </div>

        {/* Body Content */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4 text-xs">
          {/* SENDING TAB */}
          {activeTab === 'sending' && (
            <div className="space-y-4">
              {/* Badge Preview Box */}
              <div className="p-4 rounded-3xl bg-gradient-to-b from-amber-950/40 via-neutral-900 to-neutral-950 border border-amber-500/30 text-center space-y-2">
                <div className="inline-block p-1 rounded-2xl bg-gradient-to-tr from-amber-500 via-orange-500 to-yellow-400 shadow-xl">
                  <div className="w-16 h-16 rounded-[14px] bg-neutral-950 flex flex-col items-center justify-center">
                    <span className="text-2xl">{sendingBadge.icon}</span>
                    <span className="text-xs font-black text-amber-300 font-mono">
                      Lv. {stats.sendingLevel}
                    </span>
                  </div>
                </div>
                <div>
                  <h4 className="text-base font-black text-white">{sendingBadge.tierName}</h4>
                  <p className="text-[11px] text-neutral-400">
                    Calculated solely from your lifetime successful coins sent.
                  </p>
                </div>
              </div>

              {/* Progress to Next Level */}
              <div className="p-4 rounded-2xl bg-neutral-900 border border-neutral-800 space-y-2.5">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-bold text-neutral-300">
                    Progress to Level {sendingProgress.nextLevel}
                  </span>
                  <span className="font-mono font-bold text-amber-400">
                    {sendingProgress.progressPercent}%
                  </span>
                </div>

                <div className="w-full h-2.5 rounded-full bg-neutral-950 border border-neutral-800 overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-amber-500 via-orange-500 to-yellow-400 rounded-full transition-all duration-500"
                    style={{ width: `${sendingProgress.progressPercent}%` }}
                  />
                </div>

                <div className="flex items-center justify-between text-[11px] font-mono text-neutral-400">
                  <span>Current: {stats.totalCoinsSent.toLocaleString()} 🪙</span>
                  <span>Target: {sendingProgress.nextLevelCoins.toLocaleString()} 🪙</span>
                </div>

                <p className="text-[10px] text-amber-300/90 pt-1">
                  Need {sendingProgress.coinsNeeded.toLocaleString()} more coins sent to unlock Level{' '}
                  {sendingProgress.nextLevel}!
                </p>
              </div>

              {/* Rule reminder */}
              <div className="p-3 rounded-xl bg-neutral-900/60 border border-neutral-800/80 text-[11px] text-neutral-400 flex items-start space-x-2">
                <ShieldCheck className="w-4 h-4 text-amber-400 flex-shrink-0 mt-0.5" />
                <span>
                  Sending Level increases sequentially (1 → 2 → 3 ... → 180 → 181 ...). Receiving coins
                  never alters your Sending Level.
                </span>
              </div>
            </div>
          )}

          {/* RECEIVING TAB */}
          {activeTab === 'receiving' && (
            <div className="space-y-4">
              {/* Badge Preview Box */}
              <div className="p-4 rounded-3xl bg-gradient-to-b from-pink-950/40 via-neutral-900 to-neutral-950 border border-pink-500/30 text-center space-y-2">
                <div className="inline-block p-1 rounded-2xl bg-gradient-to-tr from-pink-500 via-rose-500 to-purple-400 shadow-xl">
                  <div className="w-16 h-16 rounded-[14px] bg-neutral-950 flex flex-col items-center justify-center">
                    <span className="text-2xl">{receivingBadge.icon}</span>
                    <span className="text-xs font-black text-pink-300 font-mono">
                      Lv. {stats.receivingLevel}
                    </span>
                  </div>
                </div>
                <div>
                  <h4 className="text-base font-black text-white">{receivingBadge.tierName}</h4>
                  <p className="text-[11px] text-neutral-400">
                    Calculated solely from your lifetime successful gifts/coins received.
                  </p>
                </div>
              </div>

              {/* Progress to Next Level */}
              <div className="p-4 rounded-2xl bg-neutral-900 border border-neutral-800 space-y-2.5">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-bold text-neutral-300">
                    Progress to Level {receivingProgress.nextLevel}
                  </span>
                  <span className="font-mono font-bold text-pink-400">
                    {receivingProgress.progressPercent}%
                  </span>
                </div>

                <div className="w-full h-2.5 rounded-full bg-neutral-950 border border-neutral-800 overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-pink-500 via-rose-500 to-purple-400 rounded-full transition-all duration-500"
                    style={{ width: `${receivingProgress.progressPercent}%` }}
                  />
                </div>

                <div className="flex items-center justify-between text-[11px] font-mono text-neutral-400">
                  <span>Current: {stats.totalCoinsReceived.toLocaleString()} 🪙</span>
                  <span>Target: {receivingProgress.nextLevelCoins.toLocaleString()} 🪙</span>
                </div>

                <p className="text-[10px] text-pink-300/90 pt-1">
                  Need {receivingProgress.coinsNeeded.toLocaleString()} more coins received to unlock Level{' '}
                  {receivingProgress.nextLevel}!
                </p>
              </div>

              {/* Rule reminder */}
              <div className="p-3 rounded-xl bg-neutral-900/60 border border-neutral-800/80 text-[11px] text-neutral-400 flex items-start space-x-2">
                <ShieldCheck className="w-4 h-4 text-pink-400 flex-shrink-0 mt-0.5" />
                <span>
                  Receiving Level increases sequentially (1 → 2 → 3 ... → 180 → 181 ...). Sending coins
                  never alters your Receiving Level.
                </span>
              </div>
            </div>
          )}

          {/* MILESTONES & SIMULATOR TAB */}
          {activeTab === 'milestones' && (
            <div className="space-y-4">
              <div className="p-3 bg-neutral-900/90 border border-neutral-800 rounded-2xl space-y-1">
                <span className="text-xs font-bold text-violet-400 flex items-center space-x-1.5">
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Important Milestone Points</span>
                </span>
                <p className="text-[11px] text-neutral-400">
                  Levels increase sequentially with no fixed maximum cap. Level 180 is an important
                  milestone, not the maximum.
                </p>
              </div>

              {/* Exact Milestone List */}
              <div className="space-y-2">
                <div className="p-3 rounded-2xl bg-neutral-900 border border-neutral-800 flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <span className="text-xl">🥉</span>
                    <div>
                      <span className="font-bold text-white block">Level 3</span>
                      <span className="text-[10px] text-neutral-400">First major milestone</span>
                    </div>
                  </div>
                  <span className="font-mono text-amber-400 font-bold">300,000 Coins</span>
                </div>

                <div className="p-3 rounded-2xl bg-neutral-900 border border-neutral-800 flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <span className="text-xl">🥈</span>
                    <div>
                      <span className="font-bold text-white block">Level 10</span>
                      <span className="text-[10px] text-neutral-400">Silver stage performer</span>
                    </div>
                  </div>
                  <span className="font-mono text-amber-400 font-bold">50,000,000 Coins</span>
                </div>

                <div className="p-3 rounded-2xl bg-gradient-to-r from-amber-950/40 via-neutral-900 to-rose-950/40 border border-amber-500/50 flex items-center justify-between shadow-lg">
                  <div className="flex items-center space-x-3">
                    <span className="text-2xl">👑</span>
                    <div>
                      <span className="font-black text-amber-300 block">Level 180</span>
                      <span className="text-[10px] text-amber-200/70">
                        Legendary Milestone (Sun Emperor / Imperial)
                      </span>
                    </div>
                  </div>
                  <span className="font-mono text-amber-300 font-black">3,000,000,000 Coins</span>
                </div>

                <div className="p-3 rounded-2xl bg-neutral-900 border border-neutral-800 flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <span className="text-xl">🌌</span>
                    <div>
                      <span className="font-bold text-white block">Beyond Level 180</span>
                      <span className="text-[10px] text-neutral-400">
                        181 → 182 → 200 → 500 → 1000 → 5000+
                      </span>
                    </div>
                  </div>
                  <span className="font-mono text-cyan-400 font-bold">+21M Coins / Level</span>
                </div>
              </div>

              {/* Developer / QA Quick Test Station */}
              <div className="pt-2 border-t border-neutral-800 space-y-2">
                <span className="text-[10px] uppercase font-bold text-neutral-400 tracking-wider block">
                  Quick Milestone Simulator (Dev & QA)
                </span>
                <div className="grid grid-cols-2 gap-2 text-[11px]">
                  <button
                    type="button"
                    onClick={() => handleTestMilestone('sending', 300_000, 'Level 3')}
                    className="p-2 rounded-xl bg-neutral-900 hover:bg-amber-950/60 border border-neutral-800 hover:border-amber-500/60 text-neutral-200 font-bold cursor-pointer transition-colors"
                  >
                    Send 300K → Lv. 3
                  </button>
                  <button
                    type="button"
                    onClick={() => handleTestMilestone('receiving', 300_000, 'Level 3')}
                    className="p-2 rounded-xl bg-neutral-900 hover:bg-pink-950/60 border border-neutral-800 hover:border-pink-500/60 text-neutral-200 font-bold cursor-pointer transition-colors"
                  >
                    Recv 300K → Lv. 3
                  </button>
                  <button
                    type="button"
                    onClick={() => handleTestMilestone('sending', 50_000_000, 'Level 10')}
                    className="p-2 rounded-xl bg-neutral-900 hover:bg-amber-950/60 border border-neutral-800 hover:border-amber-500/60 text-neutral-200 font-bold cursor-pointer transition-colors"
                  >
                    Send 50M → Lv. 10
                  </button>
                  <button
                    type="button"
                    onClick={() => handleTestMilestone('receiving', 50_000_000, 'Level 10')}
                    className="p-2 rounded-xl bg-neutral-900 hover:bg-pink-950/60 border border-neutral-800 hover:border-pink-500/60 text-neutral-200 font-bold cursor-pointer transition-colors"
                  >
                    Recv 50M → Lv. 10
                  </button>
                  <button
                    type="button"
                    onClick={() => handleTestMilestone('sending', 3_000_000_000, 'Level 180')}
                    className="p-2 rounded-xl bg-amber-950/50 hover:bg-amber-900/60 border border-amber-500/60 text-amber-300 font-bold cursor-pointer transition-colors"
                  >
                    Send 3B → Lv. 180 👑
                  </button>
                  <button
                    type="button"
                    onClick={() => handleTestMilestone('receiving', 3_000_000_000, 'Level 180')}
                    className="p-2 rounded-xl bg-pink-950/50 hover:bg-pink-900/60 border border-pink-500/60 text-pink-300 font-bold cursor-pointer transition-colors"
                  >
                    Recv 3B → Lv. 180 👑
                  </button>
                  <button
                    type="button"
                    onClick={() => handleTestMilestone('sending', 3_021_000_000, 'Level 181')}
                    className="p-2 rounded-xl bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 text-cyan-300 font-bold cursor-pointer transition-colors"
                  >
                    Send 3.021B → Lv. 181
                  </button>
                  <button
                    type="button"
                    onClick={() => handleTestMilestone('sending', 9_720_000_000, 'Level 500')}
                    className="p-2 rounded-xl bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 text-purple-300 font-bold cursor-pointer transition-colors"
                  >
                    Send 9.72B → Lv. 500
                  </button>
                </div>

                <button
                  type="button"
                  onClick={handleResetToDefault}
                  className="w-full py-2 rounded-xl bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 text-neutral-400 hover:text-white text-xs font-semibold flex items-center justify-center space-x-1.5 cursor-pointer mt-1"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>Reset to Level 1 (New User Default)</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
