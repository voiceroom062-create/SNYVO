import React, { useState } from 'react';
import { X, Crown, Sparkles, Star, ChevronRight, Gift } from 'lucide-react';
import { User } from '../../types';
import { vipService } from '../../coins/vipService';
import { walletService } from '../../games/walletService';

interface ProfileVipModalProps {
  currentUser: User;
  onClose: () => void;
  onToast: (msg: string) => void;
  onOpenStore?: () => void;
}

const VIP_LEVELS = [
  { level: 1, exp: 10000, dailyCoins: 1000, perk: 'VIP Golden Crown & Room Message Flare' },
  { level: 2, exp: 30000, dailyCoins: 2000, perk: 'VIP Badge & Golden Stage Seat Halo' },
  { level: 3, exp: 80000, dailyCoins: 3500, perk: 'Golden Flare Entry & Exclusive Emotes' },
  { level: 4, exp: 200000, dailyCoins: 6000, perk: 'Custom Room Mic Aura & Voice Effects' },
  { level: 5, exp: 500000, dailyCoins: 10000, perk: 'VIP Flying Banner & 500 Friends Limit' },
  { level: 6, exp: 1200000, dailyCoins: 18000, perk: 'Starlight Trail Entry & Kick Protection' },
  { level: 7, exp: 3000000, dailyCoins: 30000, perk: 'Royal Purple Avatar Ring & Stage Priority' },
  { level: 8, exp: 7000000, dailyCoins: 50000, perk: 'Full Room Soundwave Broadcast & Concierge' },
  { level: 9, exp: 15000000, dailyCoins: 80000, perk: 'Golden Dragon Audio Halo & Exclusive Gifts' },
  { level: 10, exp: 30000000, dailyCoins: 150000, perk: 'Supreme Emperor Crown & Permanent VIP Halo' },
];

export const ProfileVipModal: React.FC<ProfileVipModalProps> = ({
  currentUser,
  onClose,
  onToast,
  onOpenStore,
}) => {
  const currentTier = vipService.getUserVipTier(currentUser.id);
  const [selectedVip, setSelectedVip] = useState(1);
  const [hasClaimedDaily, setHasClaimedDaily] = useState(() => {
    try {
      return localStorage.getItem(`snyvo_vip_daily_${currentUser.id}`) === new Date().toDateString();
    } catch {
      return false;
    }
  });

  const handleClaimDailyVip = () => {
    if (hasClaimedDaily) {
      onToast('You already claimed today’s VIP daily bonus!');
      return;
    }
    walletService.addCoins(currentUser.id, 1000, 'Daily VIP 1 Bonus');
    localStorage.setItem(`snyvo_vip_daily_${currentUser.id}`, new Date().toDateString());
    setHasClaimedDaily(true);
    onToast('👑 Claimed 🪙 +1,000 Daily VIP Coins!');
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4 animate-fadeIn">
      <div
        className="w-full max-w-md bg-neutral-950 border border-amber-500/30 rounded-t-3xl sm:rounded-3xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="relative bg-gradient-to-r from-amber-600 via-yellow-600 to-amber-700 p-5 text-neutral-950">
          <button
            type="button"
            onClick={onClose}
            className="absolute top-3 right-3 p-1.5 rounded-full bg-black/20 hover:bg-black/30 text-neutral-950 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
          <div className="flex items-center space-x-3">
            <div className="w-12 h-12 rounded-2xl bg-neutral-950 p-2 text-amber-400 flex items-center justify-center shadow-lg">
              <Crown className="w-8 h-8" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h3 className="text-xl font-black">VIP Center</h3>
                <span className="px-2 py-0.5 text-[10px] font-black uppercase rounded-full bg-neutral-950 text-amber-300">
                  VIP 1
                </span>
              </div>
              <p className="text-xs text-neutral-900/90 font-medium">Daily coin salary & stage entry privileges</p>
            </div>
          </div>
        </div>

        {/* VIP Status & Daily Claim */}
        <div className="p-4 bg-neutral-900 border-b border-neutral-800">
          <div className="flex items-center justify-between mb-2">
            <div>
              <span className="text-[10px] font-bold uppercase text-neutral-400">EXP Progress to VIP 2</span>
              <div className="text-xs font-black text-amber-300 font-mono mt-0.5">
                15,400 / 30,000 EXP
              </div>
            </div>
            <button
              type="button"
              onClick={handleClaimDailyVip}
              disabled={hasClaimedDaily}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                hasClaimedDaily
                  ? 'bg-neutral-800 text-neutral-500 cursor-not-allowed'
                  : 'bg-gradient-to-r from-amber-400 to-yellow-500 text-neutral-950 shadow-md font-extrabold cursor-pointer active:scale-95 animate-pulse'
              }`}
            >
              {hasClaimedDaily ? 'Claimed Today' : 'Claim 1,000 Coins'}
            </button>
          </div>

          <div className="w-full h-2 rounded-full bg-neutral-800 overflow-hidden">
            <div className="h-full bg-gradient-to-r from-amber-500 to-yellow-400 rounded-full w-[51%]"></div>
          </div>
        </div>

        {/* VIP Level Tiers Carousel */}
        <div className="p-3 bg-neutral-950 border-b border-neutral-800 overflow-x-auto flex space-x-2 scrollbar-none">
          {VIP_LEVELS.map((v) => {
            const isSelected = selectedVip === v.level;
            return (
              <button
                type="button"
                key={v.level}
                onClick={() => setSelectedVip(v.level)}
                className={`flex-shrink-0 px-3 py-2 rounded-2xl border text-center transition-all ${
                  isSelected
                    ? 'bg-amber-950/60 border-amber-400 text-amber-300 shadow-md'
                    : 'bg-neutral-900 border-neutral-800 text-neutral-400 hover:text-white'
                }`}
              >
                <div className="text-xs font-black">VIP {v.level}</div>
                <div className="text-[9px] font-mono text-neutral-500 mt-0.5">+{v.dailyCoins}/d</div>
              </button>
            );
          })}
        </div>

        {/* Selected Tier Details */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {VIP_LEVELS.filter((v) => v.level === selectedVip).map((v) => (
            <div key={v.level} className="space-y-3">
              <div className="p-4 rounded-3xl bg-neutral-900 border border-amber-500/30">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <span className="text-2xl">👑</span>
                    <h4 className="text-sm font-black text-amber-300">VIP {v.level} Privileges</h4>
                  </div>
                  <span className="text-xs font-mono font-bold text-neutral-400">
                    {v.exp.toLocaleString()} EXP
                  </span>
                </div>
                <p className="text-xs text-neutral-300 mt-2 leading-relaxed">{v.perk}</p>
                <div className="mt-3 flex items-center justify-between text-xs pt-3 border-t border-neutral-800 text-neutral-400">
                  <span>Daily Free Coins:</span>
                  <span className="font-bold text-amber-400 font-mono">🪙 +{v.dailyCoins.toLocaleString()} / day</span>
                </div>
              </div>

              <div className="p-3.5 rounded-2xl bg-neutral-900/60 border border-neutral-800 text-xs text-neutral-400 space-y-1.5">
                <p className="font-bold text-white">How to earn VIP EXP?</p>
                <p>• Send gifts to live voice room hosts (1 Coin = 1 EXP)</p>
                <p>• Active voice chat time on stage (10 EXP / minute)</p>
                <p>• Recharge coins via bKash or Nagad</p>
              </div>

              {onOpenStore && (
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onOpenStore();
                  }}
                  className="w-full py-3 rounded-2xl bg-gradient-to-r from-amber-500 to-yellow-400 text-neutral-950 font-black text-xs shadow-lg cursor-pointer hover:opacity-95 active:scale-98 transition-all"
                >
                  Recharge Coins to Level Up VIP
                </button>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
