import React, { useState, useEffect } from 'react';
import { X, Wallet, ArrowUpRight, ArrowDownLeft, Sparkles, RefreshCw, ChevronRight } from 'lucide-react';
import { User } from '../../types';
import { walletService } from '../../games/walletService';

interface ProfileWalletModalProps {
  currentUser: User;
  onClose: () => void;
  onOpenStore: () => void;
  onToast: (msg: string) => void;
}

export const ProfileWalletModal: React.FC<ProfileWalletModalProps> = ({
  currentUser,
  onClose,
  onOpenStore,
  onToast,
}) => {
  const [balance, setBalance] = useState(() => walletService.getBalance(currentUser.id));
  const [transactions, setTransactions] = useState(() => walletService.getTransactions(currentUser.id));

  useEffect(() => {
    const unsub = walletService.subscribe(() => {
      setBalance(walletService.getBalance(currentUser.id));
      setTransactions(walletService.getTransactions(currentUser.id));
    });
    return unsub;
  }, [currentUser.id]);

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4 animate-fadeIn">
      <div
        className="w-full max-w-md bg-neutral-950 border border-amber-500/30 rounded-t-3xl sm:rounded-3xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="relative bg-gradient-to-r from-amber-600 via-yellow-600 to-amber-700 p-5 text-neutral-950">
          <button
            type="button"
            onClick={onClose}
            className="absolute top-3 right-3 p-1.5 rounded-full bg-black/20 hover:bg-black/30 text-neutral-950 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
          <div className="flex items-center space-x-3">
            <div className="w-12 h-12 rounded-2xl bg-neutral-950 text-amber-400 flex items-center justify-center shadow-lg">
              <Wallet className="w-7 h-7" />
            </div>
            <div>
              <h3 className="text-xl font-black">Creator Wallet</h3>
              <p className="text-xs text-neutral-900/90 font-medium">Coin Balance & Gift Revenue</p>
            </div>
          </div>
        </div>

        {/* Balance Cards */}
        <div className="p-4 bg-neutral-900 border-b border-neutral-800 space-y-3">
          <div className="p-4 rounded-2xl bg-neutral-950 border border-amber-500/30 flex items-center justify-between">
            <div>
              <span className="text-[10px] uppercase font-bold text-neutral-400 block">Available Coins</span>
              <div className="text-2xl font-black text-amber-300 font-mono flex items-center space-x-1.5 mt-0.5">
                <span>🪙</span>
                <span>{balance.toLocaleString()}</span>
              </div>
            </div>

            <button
              type="button"
              onClick={() => {
                onClose();
                onOpenStore();
              }}
              className="px-4 py-2 rounded-xl bg-gradient-to-r from-amber-400 to-yellow-500 text-neutral-950 font-black text-xs shadow-md shadow-amber-950/40 hover:opacity-95 active:scale-95 transition-all"
            >
              + Top Up
            </button>
          </div>

          <div className="p-3 rounded-xl bg-neutral-950/60 border border-neutral-800 flex items-center justify-between text-xs">
            <div className="flex items-center space-x-2">
              <span className="text-lg">💎</span>
              <div>
                <span className="text-white font-bold block">Gift Earnings (30% Receiver Share)</span>
                <span className="text-[10px] text-neutral-400">Credited automatically upon receiving gifts</span>
              </div>
            </div>
            <span className="font-mono text-emerald-400 font-bold">Verified Active</span>
          </div>
        </div>

        {/* Transaction Records */}
        <div className="flex-1 overflow-y-auto p-4 space-y-2.5">
          <div className="flex items-center justify-between">
            <h4 className="text-xs font-bold uppercase tracking-wider text-neutral-400">
              Recent Transactions
            </h4>
            <span className="text-[10px] text-neutral-500 font-mono">Live Ledger</span>
          </div>

          {transactions.length === 0 ? (
            <div className="p-4 rounded-xl bg-neutral-900/60 text-center text-xs text-neutral-500">
              No recent transactions recorded yet.
            </div>
          ) : (
            transactions.slice(0, 10).map((tx) => (
              <div
                key={tx.id}
                className="p-3 rounded-2xl bg-neutral-900/80 border border-neutral-800 flex items-center justify-between text-xs"
              >
                <div className="flex items-center space-x-2.5">
                  <div className={`p-2 rounded-xl ${tx.type === 'debit' ? 'bg-rose-950/60 text-rose-400' : 'bg-emerald-950/60 text-emerald-400'}`}>
                    {tx.type === 'debit' ? <ArrowUpRight className="w-4 h-4" /> : <ArrowDownLeft className="w-4 h-4" />}
                  </div>
                  <div>
                    <span className="text-white font-bold block truncate max-w-[180px]">{tx.description}</span>
                    <span className="text-[10px] text-neutral-500">{new Date(tx.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                  </div>
                </div>
                <span className={`font-mono font-black ${tx.type === 'debit' ? 'text-rose-400' : 'text-emerald-400'}`}>
                  {tx.type === 'debit' ? '-' : '+'}🪙 {tx.amount.toLocaleString()}
                </span>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
