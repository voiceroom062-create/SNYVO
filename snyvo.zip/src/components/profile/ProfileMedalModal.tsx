import React, { useState } from 'react';
import { X, Medal, Award, Sparkles, Check, Lock } from 'lucide-react';
import { User } from '../../types';

interface ProfileMedalModalProps {
  currentUser: User;
  onClose: () => void;
  onToast: (msg: string) => void;
}

const MEDALS_DATA = [
  { id: 'm_voice', name: 'Voice Pioneer', icon: '🎙️', desc: 'Hosted over 20 live audio rooms on SNYVO', unlocked: true, date: 'Oct 2024' },
  { id: 'm_gifter', name: 'Generous Gifter', icon: '🎁', desc: 'Sent over 100,000 coins in gifts to community creators', unlocked: true, date: 'Nov 2024' },
  { id: 'm_streak', name: '30-Day Streak', icon: '🔥', desc: 'Maintained an active daily voice sign-in streak', unlocked: true, date: 'Dec 2024' },
  { id: 'm_gala', name: 'BD Gala Finalist', icon: '👑', desc: 'Competed in the SNYVO Bangladesh Voice Gala stage', unlocked: true, date: 'Jan 2025' },
  { id: 'm_game', name: 'Board Master', icon: '🏆', desc: 'Won 50+ matches in Ludo Star & Carrom', unlocked: true, date: 'Feb 2025' },
  { id: 'm_rocket', name: 'Rocket Pioneer', icon: '🚀', desc: 'Launched a full-screen Mega Rocket animation', unlocked: true, date: 'Recently' },
  { id: 'm_billionaire', name: 'Billionaire Club', icon: '💎', desc: 'Accumulate 10,000,000 coin transactions (48% done)', unlocked: false },
  { id: 'm_maestro', name: 'Sound Maestro', icon: '🎧', desc: 'Achieved 1,000 hours of stage speaking (75% done)', unlocked: false },
];

export const ProfileMedalModal: React.FC<ProfileMedalModalProps> = ({
  currentUser,
  onClose,
  onToast,
}) => {
  const [wornMedalId, setWornMedalId] = useState<string>(() => {
    try {
      return localStorage.getItem(`snyvo_worn_medal_${currentUser.id}`) || 'm_voice';
    } catch {
      return 'm_voice';
    }
  });

  const handleWearMedal = (m: typeof MEDALS_DATA[0]) => {
    if (!m.unlocked) {
      onToast(`Locked medal: ${m.desc}`);
      return;
    }
    setWornMedalId(m.id);
    localStorage.setItem(`snyvo_worn_medal_${currentUser.id}`, m.id);
    onToast(`🏅 Wearing "${m.name}" medal on profile!`);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4 animate-fadeIn">
      <div
        className="w-full max-w-md bg-neutral-950 border border-amber-500/30 rounded-t-3xl sm:rounded-3xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="relative bg-gradient-to-r from-amber-600 via-yellow-600 to-amber-700 p-5 text-neutral-950">
          <button
            type="button"
            onClick={onClose}
            className="absolute top-3 right-3 p-1.5 rounded-full bg-black/20 hover:bg-black/30 text-neutral-950 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
          <div className="flex items-center space-x-3">
            <div className="w-12 h-12 rounded-2xl bg-neutral-950 text-amber-400 flex items-center justify-center shadow-lg">
              <Medal className="w-7 h-7" />
            </div>
            <div>
              <h3 className="text-xl font-black">Medal Honor Wall</h3>
              <p className="text-xs text-neutral-900/90 font-medium">6 Unlocked Badges & Achievements</p>
            </div>
          </div>
        </div>

        {/* Medals Grid */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          <div className="grid grid-cols-2 gap-2.5">
            {MEDALS_DATA.map((m) => {
              const isWorn = wornMedalId === m.id;
              return (
                <div
                  key={m.id}
                  onClick={() => handleWearMedal(m)}
                  className={`p-3.5 rounded-2xl border flex flex-col justify-between transition-all cursor-pointer ${
                    m.unlocked
                      ? isWorn
                        ? 'bg-amber-950/60 border-amber-400 text-white shadow-lg'
                        : 'bg-neutral-900/80 border-neutral-800 text-white hover:border-neutral-700'
                      : 'bg-neutral-900/40 border-neutral-800/60 text-neutral-600 opacity-70'
                  }`}
                >
                  <div className="flex items-start justify-between">
                    <span className="text-3xl">{m.icon}</span>
                    {m.unlocked ? (
                      isWorn ? (
                        <span className="px-1.5 py-0.5 rounded text-[9px] font-black bg-amber-400 text-neutral-950">
                          WEARING
                        </span>
                      ) : (
                        <span className="text-[10px] text-emerald-400 font-bold">Unlocked</span>
                      )
                    ) : (
                      <Lock className="w-3.5 h-3.5 text-neutral-600" />
                    )}
                  </div>

                  <div className="mt-2">
                    <h5 className="text-xs font-bold truncate">{m.name}</h5>
                    <p className="text-[10px] text-neutral-400 mt-0.5 line-clamp-2 leading-tight">
                      {m.desc}
                    </p>
                    {m.date && (
                      <span className="text-[9px] text-neutral-500 font-mono mt-1 block">
                        {m.date}
                      </span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
