import React from 'react';
import { X, Users, Heart, Trophy, Crown, Sparkles, MessageCircle } from 'lucide-react';
import { User } from '../../types';

interface ProfileFamilyModalProps {
  currentUser: User;
  onClose: () => void;
  onToast: (msg: string) => void;
}

export const ProfileFamilyModal: React.FC<ProfileFamilyModalProps> = ({
  currentUser,
  onClose,
  onToast,
}) => {
  const members = [
    { name: 'Tanvir Ahmed 🇧🇩', role: 'Family Chief 👑', avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100' },
    { name: currentUser.name, role: 'Elite Member ⭐', avatar: currentUser.avatar },
    { name: 'Maya Lin', role: 'Elder ⚜️', avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100' },
    { name: 'Kofi Mensah', role: 'Ambassador 🛡️', avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100' },
  ];

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4 animate-fadeIn">
      <div
        className="w-full max-w-md bg-neutral-950 border border-rose-500/30 rounded-t-3xl sm:rounded-3xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="relative bg-gradient-to-r from-rose-600 via-pink-600 to-purple-800 p-5 text-white">
          <button
            type="button"
            onClick={onClose}
            className="absolute top-3 right-3 p-1.5 rounded-full bg-black/30 hover:bg-black/50 text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
          <div className="flex items-center space-x-3">
            <div className="w-12 h-12 rounded-2xl bg-white/10 backdrop-blur-md flex items-center justify-center text-2xl">
              🏰
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h3 className="text-xl font-black">Dhaka Royals 🇧🇩</h3>
                <span className="px-2 py-0.5 text-[10px] font-black uppercase rounded-full bg-rose-400 text-neutral-950">
                  Lv. 8
                </span>
              </div>
              <p className="text-xs text-rose-100/90 font-mono">Family ID: 8829104</p>
            </div>
          </div>
        </div>

        {/* Family Stats */}
        <div className="grid grid-cols-3 gap-2 p-4 bg-neutral-900 border-b border-neutral-800 text-center">
          <div>
            <span className="text-[10px] font-bold text-neutral-400 uppercase">Members</span>
            <div className="text-sm font-black text-white font-mono mt-0.5">48 / 100</div>
          </div>
          <div className="border-x border-neutral-800">
            <span className="text-[10px] font-bold text-neutral-400 uppercase">Weekly EXP</span>
            <div className="text-sm font-black text-rose-400 font-mono mt-0.5">184,200</div>
          </div>
          <div>
            <span className="text-[10px] font-bold text-neutral-400 uppercase">BD Rank</span>
            <div className="text-sm font-black text-amber-400 font-mono mt-0.5">#6 Top 🏆</div>
          </div>
        </div>

        {/* Members List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          <div className="flex items-center justify-between">
            <h4 className="text-xs font-bold uppercase tracking-wider text-neutral-400">
              Family Members
            </h4>
            <span className="text-[10px] text-neutral-500">4 Active in Voice</span>
          </div>

          <div className="space-y-2">
            {members.map((m) => (
              <div
                key={m.name}
                className="p-3 rounded-2xl bg-neutral-900/80 border border-neutral-800 flex items-center justify-between"
              >
                <div className="flex items-center space-x-2.5">
                  <img src={m.avatar} alt={m.name} className="w-9 h-9 rounded-full object-cover ring-1 ring-neutral-700" />
                  <div>
                    <h5 className="text-xs font-bold text-white">{m.name}</h5>
                    <p className="text-[10px] text-rose-300 font-medium">{m.role}</p>
                  </div>
                </div>
                <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
              </div>
            ))}
          </div>

          <button
            type="button"
            onClick={() => onToast('Joining Dhaka Royals Family Voice Room...')}
            className="w-full py-3 rounded-2xl bg-gradient-to-r from-rose-500 to-pink-500 text-white font-bold text-xs shadow-lg shadow-rose-950/40 hover:opacity-90 active:scale-98 transition-all flex items-center justify-center space-x-1.5"
          >
            <span>🎙️ Enter Family Room</span>
          </button>
        </div>
      </div>
    </div>
  );
};
