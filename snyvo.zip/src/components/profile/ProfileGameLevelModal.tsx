import React from 'react';
import { X, Gamepad2, Trophy, Flame, Target, Award } from 'lucide-react';
import { User } from '../../types';

interface ProfileGameLevelModalProps {
  currentUser: User;
  onClose: () => void;
  onToast: (msg: string) => void;
}

export const ProfileGameLevelModal: React.FC<ProfileGameLevelModalProps> = ({
  currentUser,
  onClose,
}) => {
  const gamesStats = [
    { name: 'Ludo Star 🎲', played: 74, winRate: '72%', tier: 'Grandmaster' },
    { name: 'Carrom Pro 🎯', played: 42, winRate: '64%', tier: 'Diamond' },
    { name: 'Snake & Ladder 🐍', played: 18, winRate: '78%', tier: 'Champion' },
    { name: 'Card Clash 🃏', played: 26, winRate: '69%', tier: 'Master' },
  ];

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4 animate-fadeIn">
      <div
        className="w-full max-w-md bg-neutral-950 border border-emerald-500/30 rounded-t-3xl sm:rounded-3xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="relative bg-gradient-to-r from-emerald-600 via-teal-700 to-indigo-800 p-5 text-white">
          <button
            type="button"
            onClick={onClose}
            className="absolute top-3 right-3 p-1.5 rounded-full bg-black/30 hover:bg-black/50 text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
          <div className="flex items-center space-x-3">
            <div className="w-12 h-12 rounded-2xl bg-white/10 backdrop-blur-md flex items-center justify-center">
              <Gamepad2 className="w-7 h-7 text-emerald-300" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h3 className="text-xl font-black">Game Level</h3>
                <span className="px-2 py-0.5 text-[10px] font-black uppercase rounded-full bg-emerald-400 text-neutral-950">
                  Lv. 14
                </span>
              </div>
              <p className="text-xs text-emerald-100/90">Ludo, Carrom, & Card Clash Rankings</p>
            </div>
          </div>
        </div>

        {/* Global Game Stats */}
        <div className="grid grid-cols-3 gap-2 p-4 bg-neutral-900 border-b border-neutral-800 text-center">
          <div>
            <span className="text-[10px] font-bold text-neutral-400 uppercase">Matches</span>
            <div className="text-base font-black text-white font-mono mt-0.5">160</div>
          </div>
          <div className="border-x border-neutral-800">
            <span className="text-[10px] font-bold text-neutral-400 uppercase">Win Rate</span>
            <div className="text-base font-black text-emerald-400 font-mono mt-0.5">71.2%</div>
          </div>
          <div>
            <span className="text-[10px] font-bold text-neutral-400 uppercase">Streak</span>
            <div className="text-base font-black text-amber-400 font-mono mt-0.5">7 Wins 🔥</div>
          </div>
        </div>

        {/* Game Breakdown */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          <h4 className="text-xs font-bold uppercase tracking-wider text-neutral-400">
            Game Performance
          </h4>
          <div className="space-y-2">
            {gamesStats.map((game) => (
              <div
                key={game.name}
                className="p-3.5 rounded-2xl bg-neutral-900/80 border border-neutral-800 flex items-center justify-between"
              >
                <div>
                  <h5 className="text-xs font-bold text-white">{game.name}</h5>
                  <p className="text-[10px] text-neutral-400 mt-0.5">
                    {game.played} matches played • {game.winRate} win rate
                  </p>
                </div>
                <span className="px-2.5 py-1 rounded-full text-[10px] font-black bg-emerald-950 text-emerald-300 border border-emerald-700/50">
                  {game.tier}
                </span>
              </div>
            ))}
          </div>

          <div className="p-3.5 rounded-2xl bg-neutral-900/60 border border-neutral-800 text-xs text-neutral-400 leading-relaxed">
            💡 Win games in voice rooms to level up your Game Badge and unlock golden game tables!
          </div>
        </div>
      </div>
    </div>
  );
};
