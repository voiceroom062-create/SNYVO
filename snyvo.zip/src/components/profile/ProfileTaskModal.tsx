import React, { useState } from 'react';
import { X, CheckCircle, Sparkles, Gift, Clock, Flame, Trophy } from 'lucide-react';
import { User } from '../../types';
import { walletService } from '../../games/walletService';

interface ProfileTaskModalProps {
  currentUser: User;
  onClose: () => void;
  onToast: (msg: string) => void;
}

const DAILY_CHECKIN = [
  { day: 1, coins: 500, label: 'Day 1' },
  { day: 2, coins: 1000, label: 'Day 2' },
  { day: 3, coins: 1500, label: 'Day 3' },
  { day: 4, coins: 2000, label: 'Day 4' },
  { day: 5, coins: 3000, label: 'Day 5' },
  { day: 6, coins: 5000, label: 'Day 6' },
  { day: 7, coins: 10000, label: 'Day 7 👑' },
];

export const ProfileTaskModal: React.FC<ProfileTaskModalProps> = ({
  currentUser,
  onClose,
  onToast,
}) => {
  const [activeTab, setActiveTab] = useState<'daily' | 'growth'>('daily');
  const [claimedTasks, setClaimedTasks] = useState<Record<string, boolean>>(() => {
    try {
      const saved = localStorage.getItem(`snyvo_claimed_tasks_${currentUser.id}`);
      return saved ? JSON.parse(saved) : {};
    } catch {
      return {};
    }
  });

  const [checkinDay, setCheckinDay] = useState<number>(() => {
    try {
      const saved = localStorage.getItem(`snyvo_checkin_day_${currentUser.id}`);
      return saved ? parseInt(saved, 10) : 3;
    } catch {
      return 3;
    }
  });

  const [hasCheckedInToday, setHasCheckedInToday] = useState<boolean>(() => {
    try {
      const lastCheck = localStorage.getItem(`snyvo_last_checkin_${currentUser.id}`);
      const today = new Date().toDateString();
      return lastCheck === today;
    } catch {
      return false;
    }
  });

  const handleClaimCheckin = (dayObj: typeof DAILY_CHECKIN[0]) => {
    if (hasCheckedInToday) {
      onToast('You have already claimed today’s check-in bonus!');
      return;
    }
    walletService.addCoins(currentUser.id, dayObj.coins, `Day ${dayObj.day} Check-in Reward`);
    const nextDay = Math.min(7, checkinDay + 1);
    setCheckinDay(nextDay);
    setHasCheckedInToday(true);
    localStorage.setItem(`snyvo_checkin_day_${currentUser.id}`, String(nextDay));
    localStorage.setItem(`snyvo_last_checkin_${currentUser.id}`, new Date().toDateString());
    onToast(`🎉 Claimed 🪙 +${dayObj.coins.toLocaleString()} Check-in Coins!`);
  };

  const handleClaimTask = (taskId: string, reward: number, title: string) => {
    if (claimedTasks[taskId]) return;
    walletService.addCoins(currentUser.id, reward, `Task: ${title}`);
    const updated = { ...claimedTasks, [taskId]: true };
    setClaimedTasks(updated);
    localStorage.setItem(`snyvo_claimed_tasks_${currentUser.id}`, JSON.stringify(updated));
    onToast(`🎉 Claimed 🪙 +${reward.toLocaleString()} for "${title}"!`);
  };

  const dailyTasks = [
    {
      id: 'task_listen_10m',
      title: 'Listen in Voice Room for 10 Mins',
      desc: 'Hang out in any live stage salon or music room',
      reward: 1500,
      progress: '10/10 min',
      isReady: true,
    },
    {
      id: 'task_send_gift',
      title: 'Send 1 Gift to Any Host',
      desc: 'Show love to your favorite Bangladeshi voice performer',
      reward: 2000,
      progress: '1/1 sent',
      isReady: true,
    },
    {
      id: 'task_room_chat',
      title: 'Send 5 Messages in Room Chat',
      desc: 'Interact and chat during live voice sessions',
      reward: 800,
      progress: '5/5 msgs',
      isReady: true,
    },
    {
      id: 'task_play_game',
      title: 'Play 1 Game in SNYVO Game Lobby',
      desc: 'Play Ludo Star, Carrom, or Snake & Ladder',
      reward: 2500,
      progress: '1/1 played',
      isReady: true,
    },
  ];

  const growthTasks = [
    {
      id: 'task_follow_3',
      title: 'Follow 3 Voice Performers',
      desc: 'Stay connected with top hosts and RJ stars',
      reward: 3000,
      progress: '3/3',
      isReady: true,
    },
    {
      id: 'task_bind_profile',
      title: 'Complete Profile Bio & Interests',
      desc: 'Help new friends discover your voice vibe',
      reward: 5000,
      progress: '100%',
      isReady: true,
    },
    {
      id: 'task_vip_trial',
      title: 'Experience VIP Level 1 Perks',
      desc: 'Unlock golden crowns & highlighted messages',
      reward: 10000,
      progress: 'Eligible',
      isReady: true,
    },
  ];

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4 animate-fadeIn">
      <div
        className="w-full max-w-md bg-neutral-950 border border-neutral-800 rounded-t-3xl sm:rounded-3xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="relative bg-gradient-to-r from-orange-600 via-amber-600 to-rose-600 p-4 text-white">
          <button
            type="button"
            onClick={onClose}
            className="absolute top-3 right-3 p-1.5 rounded-full bg-black/30 hover:bg-black/50 text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
          <div className="flex items-center space-x-2">
            <div className="p-2 rounded-xl bg-white/20 backdrop-blur-md">
              <Trophy className="w-6 h-6 text-yellow-300" />
            </div>
            <div>
              <h3 className="text-lg font-black tracking-tight">Reward Task Center</h3>
              <p className="text-xs text-white/80">Complete missions daily to earn free coins</p>
            </div>
          </div>
        </div>

        {/* 7-Day Check-in Strip */}
        <div className="p-4 bg-neutral-900/70 border-b border-neutral-800">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-bold text-white flex items-center space-x-1">
              <Flame className="w-4 h-4 text-orange-500" />
              <span>7-Day Sign-in Streak</span>
            </span>
            <span className="text-[11px] text-amber-400 font-semibold">
              Day {checkinDay} / 7
            </span>
          </div>

          <div className="grid grid-cols-7 gap-1.5">
            {DAILY_CHECKIN.map((item) => {
              const isPast = item.day < checkinDay;
              const isCurrent = item.day === checkinDay;
              return (
                <div
                  key={item.day}
                  onClick={() => isCurrent && handleClaimCheckin(item)}
                  className={`p-1.5 rounded-xl flex flex-col items-center justify-center text-center transition-all ${
                    isPast
                      ? 'bg-neutral-800/80 text-neutral-400 border border-neutral-700/50'
                      : isCurrent
                      ? hasCheckedInToday
                        ? 'bg-emerald-950/60 border border-emerald-500/50 text-emerald-400'
                        : 'bg-gradient-to-b from-amber-500/30 to-orange-500/30 border border-amber-400 text-amber-300 shadow-md cursor-pointer animate-pulse'
                      : 'bg-neutral-900 border border-neutral-800 text-neutral-500'
                  }`}
                >
                  <span className="text-[9px] font-bold">{item.label}</span>
                  <span className="text-sm my-0.5">🪙</span>
                  <span className="text-[9px] font-bold font-mono">+{item.coins}</span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-neutral-800 bg-neutral-950 px-4 pt-2">
          <button
            type="button"
            onClick={() => setActiveTab('daily')}
            className={`flex-1 py-2 text-xs font-bold text-center border-b-2 transition-colors ${
              activeTab === 'daily'
                ? 'border-orange-500 text-orange-400'
                : 'border-transparent text-neutral-400 hover:text-neutral-200'
            }`}
          >
            Daily Tasks
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('growth')}
            className={`flex-1 py-2 text-xs font-bold text-center border-b-2 transition-colors ${
              activeTab === 'growth'
                ? 'border-orange-500 text-orange-400'
                : 'border-transparent text-neutral-400 hover:text-neutral-200'
            }`}
          >
            Growth Missions
          </button>
        </div>

        {/* Task List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-2.5">
          {(activeTab === 'daily' ? dailyTasks : growthTasks).map((task) => {
            const isClaimed = !!claimedTasks[task.id];
            return (
              <div
                key={task.id}
                className="p-3 rounded-2xl bg-neutral-900/80 border border-neutral-800 flex items-center justify-between"
              >
                <div className="min-w-0 pr-2">
                  <h4 className="text-xs font-bold text-white truncate">{task.title}</h4>
                  <p className="text-[10px] text-neutral-400 mt-0.5">{task.desc}</p>
                  <div className="flex items-center space-x-2 mt-1">
                    <span className="text-[10px] font-bold text-amber-400">
                      🪙 +{task.reward.toLocaleString()} Coins
                    </span>
                    <span className="text-[10px] text-neutral-500">• {task.progress}</span>
                  </div>
                </div>

                <button
                  type="button"
                  disabled={isClaimed}
                  onClick={() => handleClaimTask(task.id, task.reward, task.title)}
                  className={`px-3.5 py-1.5 rounded-xl text-xs font-bold flex-shrink-0 transition-all ${
                    isClaimed
                      ? 'bg-neutral-800 text-neutral-500 cursor-not-allowed'
                      : 'bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-400 hover:to-amber-400 text-neutral-950 shadow-md shadow-orange-950/40 cursor-pointer active:scale-95'
                  }`}
                >
                  {isClaimed ? 'Claimed' : 'Claim'}
                </button>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
