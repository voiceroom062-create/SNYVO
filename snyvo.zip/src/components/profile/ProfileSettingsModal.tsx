import React, { useState, useEffect } from 'react';
import {
  X,
  Settings as SettingsIcon,
  User as UserIcon,
  Lock,
  Gift,
  Bell,
  UserX,
  Trash2,
  FileText,
  Star,
  ChevronRight,
  LogOut,
  Clock,
  AlertTriangle,
  ChevronLeft,
} from 'lucide-react';
import { User } from '../../types';
import { settingsService, UserSettings } from '../../services/settingsService';
import { AccountSettingsPage } from '../settings/AccountSettingsPage';
import { ChangePasswordPage } from '../settings/ChangePasswordPage';
import { MessageNotificationPage } from '../settings/MessageNotificationPage';
import { BlockedListPage } from '../settings/BlockedListPage';
import { PlatformPolicyPage } from '../settings/PlatformPolicyPage';
import { RateUsModal } from '../settings/RateUsModal';
import { ClearCacheDialog } from '../settings/ClearCacheDialog';

interface ProfileSettingsModalProps {
  currentUser: User;
  onClose: () => void;
  onLogout: () => void;
  onToast: (msg: string) => void;
  onOpenFirebaseModal?: () => void;
}

type ActiveView =
  | 'main'
  | 'account'
  | 'changePassword'
  | 'messageNotification'
  | 'blockedList'
  | 'platformPolicy';

export const ProfileSettingsModal: React.FC<ProfileSettingsModalProps> = ({
  currentUser,
  onClose,
  onLogout,
  onToast,
}) => {
  const [activeView, setActiveView] = useState<ActiveView>('main');
  const [settings, setSettings] = useState<UserSettings>(() =>
    settingsService.getUserSettings(currentUser.id)
  );
  const [cacheSize, setCacheSize] = useState<{ formatted: string; rawMB: number }>(() =>
    settingsService.getCacheSize(currentUser.id)
  );

  // Dialog states
  const [showClearCacheDialog, setShowClearCacheDialog] = useState(false);
  const [showRateUsModal, setShowRateUsModal] = useState(false);

  // Synchronize settings from storage on mount
  useEffect(() => {
    const s = settingsService.getUserSettings(currentUser.id);
    setSettings(s);
    setCacheSize(settingsService.getCacheSize(currentUser.id));
  }, [currentUser.id]);

  const deletionInfo = settingsService.getRemainingDeletionTime(settings.deletionScheduledAt);

  // Handle Gift Banner toggle directly on row 3
  const handleToggleGiftBanner = () => {
    const newVal = !settings.giftBannerEnabled;
    const updated = settingsService.saveUserSettings(currentUser.id, {
      giftBannerEnabled: newVal,
    });
    setSettings(updated);
    onToast(newVal ? 'Gift Banner enabled (ON)' : 'Gift Banner disabled (OFF)');
  };

  // Handle Clear Cache confirm
  const handleConfirmClearCache = () => {
    const newSize = settingsService.clearCache(currentUser.id);
    setCacheSize(newSize);
    setShowClearCacheDialog(false);
    onToast('Cache cleared successfully');
  };

  // Handle Cancel Deletion
  const handleCancelDeletion = () => {
    const updated = settingsService.cancelAccountDeletion(currentUser.id);
    setSettings(updated);
    onToast('Account deletion cancelled! Your account is active.');
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4 animate-fadeIn">
      <div
        className="w-full max-w-md bg-neutral-950 border border-neutral-800 rounded-t-3xl sm:rounded-3xl overflow-hidden shadow-2xl flex flex-col max-h-[92vh] h-[85vh] sm:h-auto"
        onClick={(e) => e.stopPropagation()}
      >
        {/* SUBPAGE ROUTING */}
        {activeView === 'account' && (
          <AccountSettingsPage
            currentUser={currentUser}
            settings={settings}
            onBack={() => setActiveView('main')}
            onUpdateSettings={setSettings}
            onToast={onToast}
          />
        )}

        {activeView === 'changePassword' && (
          <ChangePasswordPage
            currentUser={currentUser}
            onBack={() => setActiveView('main')}
            onToast={onToast}
          />
        )}

        {activeView === 'messageNotification' && (
          <MessageNotificationPage
            currentUser={currentUser}
            settings={settings}
            onBack={() => setActiveView('main')}
            onUpdateSettings={setSettings}
            onToast={onToast}
          />
        )}

        {activeView === 'blockedList' && (
          <BlockedListPage
            currentUser={currentUser}
            settings={settings}
            onBack={() => setActiveView('main')}
            onUpdateSettings={setSettings}
            onToast={onToast}
          />
        )}

        {activeView === 'platformPolicy' && (
          <PlatformPolicyPage onBack={() => setActiveView('main')} />
        )}

        {/* MAIN SETTINGS PAGE */}
        {activeView === 'main' && (
          <div className="flex flex-col h-full bg-neutral-950 text-white animate-fadeIn">
            {/* Header */}
            <div className="relative bg-neutral-900 p-4 text-white border-b border-neutral-800 flex items-center justify-between">
              <div className="flex items-center space-x-2.5">
                <div className="p-2 rounded-xl bg-neutral-800 text-neutral-300">
                  <SettingsIcon className="w-5 h-5 text-violet-400" />
                </div>
                <div>
                  <h3 className="text-base font-black text-white tracking-wide">Settings</h3>
                  <p className="text-[11px] text-neutral-400">Account, Security & App Preferences</p>
                </div>
              </div>
              <button
                type="button"
                onClick={onClose}
                className="p-1.5 rounded-full bg-neutral-800 hover:bg-neutral-700 text-neutral-300 hover:text-white transition-colors cursor-pointer"
                title="Close"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Scrollable Body */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4 text-xs">
              {/* Deletion Warning Banner if scheduled */}
              {deletionInfo.isScheduled && (
                <div className="p-3.5 bg-amber-500/10 border border-amber-500/40 rounded-2xl flex items-start space-x-3 text-xs">
                  <Clock className="w-5 h-5 text-amber-400 flex-shrink-0 mt-0.5" />
                  <div className="flex-1 min-w-0">
                    <span className="font-bold text-amber-300 block">
                      Account Deletion Scheduled ({deletionInfo.daysRemaining} days remaining)
                    </span>
                    <p className="text-[11px] text-neutral-300 mt-0.5">
                      Your account will be permanently wiped when the countdown ends.
                    </p>
                    <button
                      type="button"
                      onClick={handleCancelDeletion}
                      className="mt-2 px-3 py-1 rounded-xl bg-amber-500 text-neutral-950 font-bold text-[10px] hover:bg-amber-400 transition-colors shadow-md cursor-pointer"
                    >
                      Cancel Account Deletion
                    </button>
                  </div>
                </div>
              )}

              {/* 
                THE 8 EXACT MAIN OPTIONS IN PRECISE MANDATORY ORDER:
                1. Account >
                2. Change Password >
                3. Gift Banner [ ON / OFF ]
                4. Message Notification >
                5. Blocked List >
                6. Clear Cache     40.6 MB >
                7. Platform Policy >
                8. Rate Us >
              */}
              <div className="bg-white text-neutral-900 rounded-3xl shadow-xl border border-neutral-100 divide-y divide-neutral-100 overflow-hidden">
                {/* 1. Account > */}
                <button
                  type="button"
                  onClick={() => setActiveView('account')}
                  className="w-full flex items-center justify-between px-4 py-3.5 hover:bg-neutral-50 active:bg-neutral-100 transition-colors group cursor-pointer text-left"
                >
                  <div className="flex items-center space-x-3.5 min-w-0">
                    <div className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 bg-blue-50 text-blue-600 transition-transform group-hover:scale-105">
                      <UserIcon className="w-5 h-5" />
                    </div>
                    <span className="text-sm font-bold text-neutral-900 tracking-tight truncate">
                      Account
                    </span>
                  </div>
                  <div className="flex items-center space-x-2">
                    {deletionInfo.isScheduled && (
                      <span className="text-[10px] font-bold text-amber-600 bg-amber-50 px-2 py-0.5 rounded-full">
                        Pending
                      </span>
                    )}
                    <ChevronRight className="w-4 h-4 text-neutral-300 group-hover:text-neutral-500 transition-transform group-hover:translate-x-0.5" />
                  </div>
                </button>

                {/* 2. Change Password > */}
                <button
                  type="button"
                  onClick={() => setActiveView('changePassword')}
                  className="w-full flex items-center justify-between px-4 py-3.5 hover:bg-neutral-50 active:bg-neutral-100 transition-colors group cursor-pointer text-left"
                >
                  <div className="flex items-center space-x-3.5 min-w-0">
                    <div className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 bg-amber-50 text-amber-600 transition-transform group-hover:scale-105">
                      <Lock className="w-5 h-5" />
                    </div>
                    <span className="text-sm font-bold text-neutral-900 tracking-tight truncate">
                      Change Password
                    </span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <ChevronRight className="w-4 h-4 text-neutral-300 group-hover:text-neutral-500 transition-transform group-hover:translate-x-0.5" />
                  </div>
                </button>

                {/* 3. Gift Banner [ ON / OFF ] */}
                <div className="w-full flex items-center justify-between px-4 py-3.5 hover:bg-neutral-50 transition-colors">
                  <div className="flex items-center space-x-3.5 min-w-0">
                    <div className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 bg-pink-50 text-pink-600">
                      <Gift className="w-5 h-5" />
                    </div>
                    <div>
                      <span className="text-sm font-bold text-neutral-900 tracking-tight block">
                        Gift Banner
                      </span>
                      <span className="text-[10px] text-neutral-400 font-medium block leading-tight">
                        Show live gift animation banners in rooms
                      </span>
                    </div>
                  </div>
                  {/* ON/OFF Switch */}
                  <button
                    type="button"
                    onClick={handleToggleGiftBanner}
                    className={`w-11 h-6 rounded-full transition-colors relative flex-shrink-0 cursor-pointer ${
                      settings.giftBannerEnabled ? 'bg-pink-600' : 'bg-neutral-200'
                    }`}
                    title={settings.giftBannerEnabled ? 'Gift Banner ON' : 'Gift Banner OFF'}
                  >
                    <span
                      className={`absolute top-0.5 left-0.5 w-5 h-5 rounded-full bg-white shadow-md transition-transform ${
                        settings.giftBannerEnabled ? 'translate-x-5' : ''
                      }`}
                    />
                  </button>
                </div>

                {/* 4. Message Notification > */}
                <button
                  type="button"
                  onClick={() => setActiveView('messageNotification')}
                  className="w-full flex items-center justify-between px-4 py-3.5 hover:bg-neutral-50 active:bg-neutral-100 transition-colors group cursor-pointer text-left"
                >
                  <div className="flex items-center space-x-3.5 min-w-0">
                    <div className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 bg-violet-50 text-violet-600 transition-transform group-hover:scale-105">
                      <Bell className="w-5 h-5" />
                    </div>
                    <span className="text-sm font-bold text-neutral-900 tracking-tight truncate">
                      Message Notification
                    </span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <ChevronRight className="w-4 h-4 text-neutral-300 group-hover:text-neutral-500 transition-transform group-hover:translate-x-0.5" />
                  </div>
                </button>

                {/* 5. Blocked List > */}
                <button
                  type="button"
                  onClick={() => setActiveView('blockedList')}
                  className="w-full flex items-center justify-between px-4 py-3.5 hover:bg-neutral-50 active:bg-neutral-100 transition-colors group cursor-pointer text-left"
                >
                  <div className="flex items-center space-x-3.5 min-w-0">
                    <div className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 bg-rose-50 text-rose-600 transition-transform group-hover:scale-105">
                      <UserX className="w-5 h-5" />
                    </div>
                    <span className="text-sm font-bold text-neutral-900 tracking-tight truncate">
                      Blocked List
                    </span>
                  </div>
                  <div className="flex items-center space-x-2">
                    {settings.blockedUsers && settings.blockedUsers.length > 0 && (
                      <span className="text-[11px] font-semibold text-neutral-400 font-mono">
                        {settings.blockedUsers.length}
                      </span>
                    )}
                    <ChevronRight className="w-4 h-4 text-neutral-300 group-hover:text-neutral-500 transition-transform group-hover:translate-x-0.5" />
                  </div>
                </button>

                {/* 6. Clear Cache     40.6 MB > */}
                <button
                  type="button"
                  onClick={() => setShowClearCacheDialog(true)}
                  className="w-full flex items-center justify-between px-4 py-3.5 hover:bg-neutral-50 active:bg-neutral-100 transition-colors group cursor-pointer text-left"
                >
                  <div className="flex items-center space-x-3.5 min-w-0">
                    <div className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 bg-cyan-50 text-cyan-600 transition-transform group-hover:scale-105">
                      <Trash2 className="w-5 h-5" />
                    </div>
                    <span className="text-sm font-bold text-neutral-900 tracking-tight truncate">
                      Clear Cache
                    </span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className="text-[11px] font-bold text-neutral-500 font-mono">
                      {cacheSize.formatted}
                    </span>
                    <ChevronRight className="w-4 h-4 text-neutral-300 group-hover:text-neutral-500 transition-transform group-hover:translate-x-0.5" />
                  </div>
                </button>

                {/* 7. Platform Policy > */}
                <button
                  type="button"
                  onClick={() => setActiveView('platformPolicy')}
                  className="w-full flex items-center justify-between px-4 py-3.5 hover:bg-neutral-50 active:bg-neutral-100 transition-colors group cursor-pointer text-left"
                >
                  <div className="flex items-center space-x-3.5 min-w-0">
                    <div className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 bg-emerald-50 text-emerald-600 transition-transform group-hover:scale-105">
                      <FileText className="w-5 h-5" />
                    </div>
                    <span className="text-sm font-bold text-neutral-900 tracking-tight truncate">
                      Platform Policy
                    </span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <ChevronRight className="w-4 h-4 text-neutral-300 group-hover:text-neutral-500 transition-transform group-hover:translate-x-0.5" />
                  </div>
                </button>

                {/* 8. Rate Us > */}
                <button
                  type="button"
                  onClick={() => setShowRateUsModal(true)}
                  className="w-full flex items-center justify-between px-4 py-3.5 hover:bg-neutral-50 active:bg-neutral-100 transition-colors group cursor-pointer text-left"
                >
                  <div className="flex items-center space-x-3.5 min-w-0">
                    <div className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 bg-amber-50 text-amber-500 transition-transform group-hover:scale-105">
                      <Star className="w-5 h-5 fill-amber-500" />
                    </div>
                    <span className="text-sm font-bold text-neutral-900 tracking-tight truncate">
                      Rate Us
                    </span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <ChevronRight className="w-4 h-4 text-neutral-300 group-hover:text-neutral-500 transition-transform group-hover:translate-x-0.5" />
                  </div>
                </button>
              </div>

              {/* Sign Out Button to maintain existing functionality */}
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onLogout();
                }}
                className="w-full py-3 rounded-2xl bg-neutral-900 hover:bg-rose-950/40 border border-neutral-800 hover:border-rose-800/40 text-neutral-400 hover:text-rose-400 font-bold text-xs flex items-center justify-center space-x-2 transition-all cursor-pointer"
              >
                <LogOut className="w-4 h-4" />
                <span>Sign Out of SNYVO</span>
              </button>
            </div>
          </div>
        )}

        {/* CLEAR CACHE CONFIRMATION DIALOG */}
        {showClearCacheDialog && (
          <ClearCacheDialog
            currentCacheFormatted={cacheSize.formatted}
            onConfirm={handleConfirmClearCache}
            onCancel={() => setShowClearCacheDialog(false)}
          />
        )}

        {/* RATE US MODAL */}
        {showRateUsModal && (
          <RateUsModal
            currentUser={currentUser}
            onClose={() => setShowRateUsModal(false)}
            onToast={onToast}
          />
        )}
      </div>
    </div>
  );
};
