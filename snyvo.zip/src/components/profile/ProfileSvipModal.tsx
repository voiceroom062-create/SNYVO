import React, { useState } from 'react';
import { X, Diamond, Crown, Sparkles, Check, Flame, Shield, Star, Rocket } from 'lucide-react';
import { User } from '../../types';
import { vipService } from '../../coins/vipService';
import { walletService } from '../../games/walletService';

interface ProfileSvipModalProps {
  currentUser: User;
  onClose: () => void;
  onToast: (msg: string) => void;
}

export const ProfileSvipModal: React.FC<ProfileSvipModalProps> = ({
  currentUser,
  onClose,
  onToast,
}) => {
  const currentTier = vipService.getUserVipTier(currentUser.id);
  const isSvip = currentTier === 'SVIP';

  const [hasClaimedSalary, setHasClaimedSalary] = useState(() => {
    try {
      return localStorage.getItem(`snyvo_svip_salary_${currentUser.id}`) === new Date().toDateString();
    } catch {
      return false;
    }
  });

  const handleActivateSvip = () => {
    vipService.setUserVipTier(currentUser.id, 'SVIP');
    onToast('💎 SVIP Supreme Status Activated!');
  };

  const handleClaimSalary = () => {
    if (hasClaimedSalary) {
      onToast('You have already claimed your daily SVIP coin salary!');
      return;
    }
    walletService.addCoins(currentUser.id, 5000, 'Daily SVIP Coin Salary');
    localStorage.setItem(`snyvo_svip_salary_${currentUser.id}`, new Date().toDateString());
    setHasClaimedSalary(true);
    onToast('💎 Claimed 🪙 +5,000 SVIP Daily Coins!');
  };

  const perks = [
    {
      title: 'Galactic Dragon Portal Entry',
      desc: 'Full-screen cosmic animated entrance with sound waves when entering any voice room',
      icon: '🐉',
    },
    {
      title: '3D Iridescent SVIP Crown & Badge',
      desc: 'Glowing holographic crown displayed above your avatar and on stage seats',
      icon: '👑',
    },
    {
      title: 'Daily Coin Salary (5,000 Coins)',
      desc: 'Free coins credited directly to your creator wallet balance every 24 hours',
      icon: '🪙',
    },
    {
      title: 'Diamond Audio Wave Ring',
      desc: 'Animated iridescent aura radiating around your microphone while speaking',
      icon: '✨',
    },
    {
      title: 'Priority Stage Seat Access',
      desc: 'Never wait in line for open mic sessions and VIP guest panels',
      icon: '🎙️',
    },
    {
      title: '24/7 Dedicated SVIP Concierge',
      desc: 'Direct priority customer support and custom room theme creation',
      icon: '🛡️',
    },
  ];

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4 animate-fadeIn">
      <div
        className="w-full max-w-md bg-neutral-950 border border-cyan-500/30 rounded-t-3xl sm:rounded-3xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="relative bg-gradient-to-r from-cyan-600 via-blue-700 to-fuchsia-700 p-5 text-white overflow-hidden">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,rgba(255,255,255,0.2),transparent)]"></div>
          <button
            type="button"
            onClick={onClose}
            className="absolute top-3 right-3 p-1.5 rounded-full bg-black/30 hover:bg-black/50 text-white transition-colors z-10"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="relative z-10 flex items-center space-x-3">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-cyan-400 to-fuchsia-400 p-0.5 shadow-lg">
              <div className="w-full h-full bg-neutral-950 rounded-[14px] flex items-center justify-center">
                <Diamond className="w-7 h-7 text-cyan-300 animate-pulse" />
              </div>
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h3 className="text-xl font-black tracking-tight">Supreme SVIP</h3>
                <span className="px-2 py-0.5 text-[10px] font-black uppercase rounded-full bg-cyan-400 text-neutral-950 shadow-sm">
                  ROYAL TIER
                </span>
              </div>
              <p className="text-xs text-cyan-100/90">Exclusive privileges for elite voice hosts & supporters</p>
            </div>
          </div>
        </div>

        {/* Status Strip */}
        <div className="p-4 bg-neutral-900 border-b border-neutral-800 flex items-center justify-between">
          <div>
            <span className="text-[10px] uppercase font-bold text-neutral-400 block">Current Status</span>
            <span className="text-sm font-black text-white flex items-center space-x-1.5">
              <span>{isSvip ? '💎 Active SVIP Member' : 'Regular Member'}</span>
            </span>
          </div>

          <div className="flex items-center space-x-2">
            {isSvip ? (
              <button
                type="button"
                onClick={handleClaimSalary}
                disabled={hasClaimedSalary}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                  hasClaimedSalary
                    ? 'bg-neutral-800 text-neutral-500'
                    : 'bg-gradient-to-r from-amber-400 to-yellow-500 text-neutral-950 shadow-md animate-pulse cursor-pointer'
                }`}
              >
                {hasClaimedSalary ? 'Salary Claimed' : 'Claim 5,000 Coins'}
              </button>
            ) : (
              <button
                type="button"
                onClick={handleActivateSvip}
                className="px-4 py-1.5 rounded-xl text-xs font-black bg-gradient-to-r from-cyan-400 via-blue-500 to-fuchsia-500 text-white shadow-lg cursor-pointer hover:opacity-90 active:scale-95"
              >
                Activate SVIP
              </button>
            )}
          </div>
        </div>

        {/* Perks List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          <h4 className="text-xs font-bold text-neutral-400 uppercase tracking-wider">
            Supreme SVIP Privileges
          </h4>
          <div className="space-y-2.5">
            {perks.map((p) => (
              <div
                key={p.title}
                className="p-3 rounded-2xl bg-neutral-900/70 border border-neutral-800 flex items-start space-x-3"
              >
                <div className="text-2xl mt-0.5 flex-shrink-0">{p.icon}</div>
                <div>
                  <h5 className="text-xs font-bold text-white">{p.title}</h5>
                  <p className="text-[11px] text-neutral-400 mt-0.5 leading-relaxed">{p.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
