import React, { useState, useEffect } from 'react';
import {
  X,
  Copy,
  Check,
  UserPlus,
  UserCheck,
  MessageSquare,
  Gift,
  Radio,
  Crown,
  Shield,
  Sparkles,
  ArrowRight,
  Calendar,
  AlertTriangle,
  Lock,
  ChevronRight,
  ExternalLink,
  Users,
  Mic,
  Share2,
  Diamond
} from 'lucide-react';
import { User as UserType, VoiceRoom, ReceivedGift, SentGift } from '../types';
import { userService, getNumericUserId } from '../services/userService';
import { roomService } from '../services/roomService';
import { vipService, VIP_TIER_CONFIGS } from '../coins/vipService';
import { GiftHistoryModal } from './GiftHistoryModal';
import { DirectMessageModal } from './DirectMessageModal';

interface UserProfileModalProps {
  user: UserType;
  currentUser: UserType;
  currentRoom?: VoiceRoom | null;
  onClose: () => void;
  onJoinRoom?: (room: VoiceRoom) => void;
  onHostAction?: (action: 'demote' | 'move', targetUserId: string) => void;
  onUpdateCurrentUser?: (user: UserType) => void;
  onSendGift?: (targetUserId: string) => void;
  onOpenCoinShop?: () => void;
}

export const UserProfileModal: React.FC<UserProfileModalProps> = ({
  user,
  currentUser,
  currentRoom,
  onClose,
  onJoinRoom,
  onHostAction,
  onUpdateCurrentUser,
  onSendGift,
  onOpenCoinShop,
}) => {
  const isOwnProfile = user.id === currentUser.id ||
    (user.id === 'usr_me' && currentUser.id === 'usr_guest') ||
    (user.id === 'usr_guest' && currentUser.id === 'usr_me');

  const [isFollowing, setIsFollowing] = useState(userService.isFollowing(user.id));
  const [followerCount, setFollowerCount] = useState(userService.getFollowersCount(user));
  const [showUnfollowConfirm, setShowUnfollowConfirm] = useState(false);
  const [copiedId, setCopiedId] = useState(false);
  const [showGiftHistory, setShowGiftHistory] = useState(false);
  const [showDirectMessage, setShowDirectMessage] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Sync follow state
  const refreshFollowState = () => {
    setIsFollowing(userService.isFollowing(user.id));
    setFollowerCount(userService.getFollowersCount(user));
  };

  useEffect(() => {
    refreshFollowState();
    const unsub = userService.subscribe(() => {
      refreshFollowState();
    });
    return unsub;
  }, [user.id]);

  const userNumericId = user.numericId || getNumericUserId(user.id);
  const receivedGifts: ReceivedGift[] = userService.getReceivedGifts(user.id);
  const totalReceivedGifts = userService.getTotalReceivedGiftsCount(user.id);
  const sentGifts: SentGift[] = userService.getSentGifts(user.id, currentUser.id);

  // Voice room status for voice interaction
  const activeRoom = roomService.getUserActiveRoom(user.id);
  const isInCurrentRoom = currentRoom && (
    currentRoom.host.id === user.id ||
    currentRoom.speakers.some(s => s.id === user.id) ||
    currentRoom.listeners.some(l => l.id === user.id)
  );
  const isSpeakerInCurrentRoom = currentRoom && (
    currentRoom.host.id === user.id ||
    currentRoom.speakers.some(s => s.id === user.id)
  );

  const isHost = (currentRoom && currentRoom.host.id === user.id) || user.roomsHosted > 30;
  const userLevel = user.level || (user.roomsHosted ? Math.min(25, 5 + Math.floor(user.roomsHosted / 5)) : 8);
  const vipLevel = user.vipLevel !== undefined ? user.vipLevel : (user.roomsHosted > 50 ? 2 : (user.followers > 2000 ? 1 : null));

  // Authoritative VIP / SVIP Tier
  const userVipTier = vipService.getUserVipTier(user.id);
  const userTierInfo = VIP_TIER_CONFIGS[userVipTier];
  const isSvip = userVipTier === 'SVIP';
  const isVipPro = userVipTier === 'VIP_PRO';
  const isVip = userVipTier === 'VIP';
  const hasVipCrown = isSvip || isVipPro || isVip;

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 2500);
  };

  const handleCopyId = () => {
    navigator.clipboard.writeText(userNumericId);
    setCopiedId(true);
    showToast(`User ID ${userNumericId} copied to clipboard!`);
    setTimeout(() => setCopiedId(false), 2000);
  };

  const handleFollowClick = () => {
    if (isFollowing) {
      setShowUnfollowConfirm(true);
    } else {
      const ok = userService.followUser(user.id);
      if (ok) {
        showToast(`You are now following ${user.name}`);
      }
    }
  };

  const confirmUnfollow = () => {
    const ok = userService.unfollowUser(user.id);
    setShowUnfollowConfirm(false);
    if (ok) {
      showToast(`Unfollowed ${user.name}`);
    }
  };

  return (
    <>
      <div
        id="user-profile-modal"
        className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/85 backdrop-blur-md animate-fade-in"
      >
        <div className="w-full max-w-md bg-neutral-900 border border-neutral-800 rounded-t-3xl sm:rounded-3xl shadow-2xl shadow-violet-950/60 text-white max-h-[92vh] flex flex-col overflow-hidden">
          {/* Top Bar with Dismiss and Share */}
          <div className="px-5 py-3.5 border-b border-neutral-800/80 bg-neutral-950/80 backdrop-blur-md flex items-center justify-between flex-shrink-0">
            <span className="text-[11px] font-bold uppercase tracking-wider text-violet-400 flex items-center space-x-1.5">
              <Sparkles className="w-3.5 h-3.5" />
              <span>SNYVO User Profile</span>
            </span>

            <div className="flex items-center space-x-1.5">
              <button
                onClick={() => showToast(`Profile link copied: snyvo.me/id/${userNumericId}`)}
                className="p-1.5 text-neutral-400 hover:text-white rounded-full hover:bg-neutral-800 transition-colors"
                title="Share Profile"
              >
                <Share2 className="w-4 h-4" />
              </button>
              <button
                id="close-profile-modal-btn"
                onClick={onClose}
                className="p-1.5 text-neutral-400 hover:text-white rounded-full hover:bg-neutral-800 transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Scrollable Body */}
          <div className="overflow-y-auto flex-1 p-5 space-y-4 scrollbar-thin">
            {/* Header: Avatar, Name, Handle, User ID */}
            <div className="flex flex-col items-center text-center">
              <div className="relative mb-3">
                {/* Decorative Avatar Ring */}
                <div
                  className={`p-1 rounded-full ${
                    isSvip
                      ? 'bg-gradient-to-tr from-cyan-400 via-fuchsia-400 to-amber-300 shadow-xl shadow-cyan-500/40 ring-2 ring-cyan-300'
                      : isVipPro
                      ? 'bg-gradient-to-tr from-purple-500 via-pink-400 to-amber-300 shadow-lg shadow-purple-500/40 ring-2 ring-purple-400'
                      : isVip
                      ? 'bg-gradient-to-tr from-amber-500 via-yellow-300 to-amber-600 ring-2 ring-amber-400'
                      : isHost
                      ? 'bg-gradient-to-tr from-amber-500 via-yellow-300 to-amber-600 shadow-lg shadow-amber-500/20'
                      : 'bg-gradient-to-tr from-violet-600 via-indigo-500 to-fuchsia-500 shadow-xl shadow-violet-950/40'
                  }`}
                >
                  <img
                    src={user.avatar}
                    alt={user.name}
                    className="w-20 h-20 rounded-full object-cover block bg-neutral-900 border-2 border-neutral-950"
                  />
                </div>

                {/* VIP / SVIP Crown or Host Crown badge 👑 */}
                {hasVipCrown ? (
                  <div
                    className={`absolute -top-3 left-1/2 -translate-x-1/2 text-xl leading-none filter drop-shadow-md z-10 ${
                      isSvip ? 'animate-bounce' : ''
                    }`}
                    title={`${userTierInfo.title} Crown`}
                  >
                    {isSvip ? '💎👑' : '👑'}
                  </div>
                ) : isHost ? (
                  <div
                    className="absolute -top-1.5 -right-1.5 w-6 h-6 rounded-full bg-gradient-to-tr from-amber-400 to-yellow-300 text-neutral-950 flex items-center justify-center shadow-md border-2 border-neutral-950"
                    title="Room Host 👑"
                  >
                    <Crown className="w-3.5 h-3.5 stroke-[2.5]" />
                  </div>
                ) : null}

                {/* Online Status Dot */}
                <span className="absolute bottom-0 right-0 w-3.5 h-3.5 bg-emerald-500 rounded-full border-2 border-neutral-950" title="Online Now"></span>
              </div>

              {/* Name & Badges */}
              <div className="flex items-center justify-center space-x-1.5 flex-wrap gap-y-1">
                <h3 className="text-lg font-extrabold text-white tracking-tight">
                  {user.name}
                </h3>
                {isHost && (
                  <span className="text-[10px] font-bold px-1.5 py-0.2 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 flex items-center space-x-0.5">
                    <span>👑</span>
                    <span>Host</span>
                  </span>
                )}
                {hasVipCrown && (
                  <span
                    className={`text-[10px] font-black uppercase px-2 py-0.5 rounded-full border shadow-sm flex items-center space-x-1 ${
                      isSvip
                        ? 'bg-cyan-500/20 text-cyan-300 border-cyan-400/50 animate-pulse'
                        : isVipPro
                        ? 'bg-purple-500/20 text-purple-300 border-purple-400/50'
                        : 'bg-amber-500/20 text-amber-300 border-amber-400/50'
                    }`}
                  >
                    {isSvip && <Diamond className="w-2.5 h-2.5 fill-current inline" />}
                    <span>{userTierInfo.badgeLabel}</span>
                  </span>
                )}
              </div>

              {/* @Handle */}
              <span className="text-xs text-neutral-400 font-medium mt-0.5">
                {user.handle.startsWith('@') ? user.handle : `@${user.handle}`}
              </span>

              {/* Unique User ID (Clean, visible & 1-tap copy) */}
              <div className="mt-1.5 flex items-center space-x-2">
                <div
                  onClick={handleCopyId}
                  className="flex items-center space-x-1.5 px-3 py-1 bg-neutral-950/80 hover:bg-neutral-950 border border-neutral-800 hover:border-violet-500/60 rounded-full cursor-pointer transition-all group"
                  title="Click to copy User ID"
                >
                  <span className="text-[10px] font-bold uppercase text-neutral-500 group-hover:text-violet-400">ID:</span>
                  <span className="font-mono text-xs font-semibold text-violet-300 tracking-wide">
                    {userNumericId}
                  </span>
                  {copiedId ? (
                    <Check className="w-3 h-3 text-emerald-400 ml-0.5" />
                  ) : (
                    <Copy className="w-3 h-3 text-neutral-500 group-hover:text-neutral-300 ml-0.5" />
                  )}
                </div>

                <span className="text-[10px] text-emerald-400 bg-emerald-950/60 border border-emerald-800/40 px-2 py-0.5 rounded-full font-semibold flex items-center space-x-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                  <span>Online</span>
                </span>
              </div>

              {/* Bio */}
              {user.bio && (
                <p className="mt-2 text-xs text-neutral-300 max-w-[320px] leading-relaxed">
                  {user.bio}
                </p>
              )}

              {/* VIP / SVIP Membership Showcase */}
              {hasVipCrown ? (
                <div className="mt-2.5 w-full p-2.5 rounded-2xl bg-neutral-950/80 border border-neutral-800 text-left space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-bold text-neutral-400 uppercase tracking-wider flex items-center space-x-1">
                      <span>{userTierInfo.crown}</span>
                      <span className="text-neutral-200 font-extrabold">{userTierInfo.title}</span>
                    </span>
                    <span className="text-[10px] font-mono text-amber-400 font-bold bg-amber-500/10 px-2 py-0.2 rounded-full border border-amber-500/30">
                      Active
                    </span>
                  </div>
                  <p className="text-[11px] text-neutral-400 flex items-center space-x-1 truncate">
                    <Sparkles className="w-3 h-3 text-amber-400 flex-shrink-0" />
                    <span className="truncate">Board Entry: {userTierInfo.entryTitle}</span>
                  </p>
                </div>
              ) : isOwnProfile && onOpenCoinShop ? (
                <button
                  type="button"
                  onClick={onOpenCoinShop}
                  className="mt-2.5 w-full py-2 px-3 rounded-xl bg-amber-500/15 hover:bg-amber-500/25 border border-amber-500/40 text-amber-300 text-xs font-bold flex items-center justify-center space-x-1.5 transition-colors cursor-pointer"
                >
                  <span>👑 Get VIP / SVIP Membership & Coins</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              ) : null}
            </div>

            {/* Action Buttons Row: [ Follow ] [ Message ] */}
            <div className="flex items-center space-x-2 pt-1">
              {!isOwnProfile ? (
                <>
                  {/* Follow Button */}
                  <button
                    id="profile-follow-btn"
                    onClick={handleFollowClick}
                    className={`flex-1 py-2.5 px-4 rounded-xl text-xs font-bold flex items-center justify-center space-x-1.5 transition-all shadow-md ${
                      isFollowing
                        ? 'bg-neutral-800 hover:bg-rose-950/40 hover:text-rose-300 border border-neutral-700 text-neutral-200'
                        : 'bg-violet-600 hover:bg-violet-500 text-white shadow-violet-600/30'
                    }`}
                  >
                    {isFollowing ? (
                      <>
                        <UserCheck className="w-4 h-4 text-emerald-400" />
                        <span>Following</span>
                      </>
                    ) : (
                      <>
                        <UserPlus className="w-4 h-4" />
                        <span>Follow</span>
                      </>
                    )}
                  </button>

                  {/* Message Button */}
                  <button
                    id="profile-message-btn"
                    onClick={() => setShowDirectMessage(true)}
                    className="flex-1 py-2.5 px-4 rounded-xl bg-neutral-800 hover:bg-neutral-700/80 border border-neutral-700/80 text-white text-xs font-bold flex items-center justify-center space-x-1.5 transition-colors shadow-md cursor-pointer"
                  >
                    <MessageSquare className="w-4 h-4 text-violet-400" />
                    <span>Message</span>
                  </button>

                  {/* Send Gift Button */}
                  {onSendGift && (
                    <button
                      id="profile-send-gift-btn"
                      onClick={() => onSendGift(user.id)}
                      className="py-2.5 px-3.5 rounded-xl bg-gradient-to-r from-rose-600 to-amber-500 hover:brightness-110 text-white text-xs font-bold flex items-center justify-center space-x-1.5 transition-all shadow-md shadow-rose-600/30 active:scale-95 cursor-pointer"
                      title="Send Gift"
                    >
                      <Gift className="w-4 h-4" />
                      <span>Gift</span>
                    </button>
                  )}
                </>
              ) : (
                <div className="w-full py-2 px-3 rounded-xl bg-violet-950/40 border border-violet-800/40 text-center text-xs font-bold text-violet-300">
                  Your Personal Profile
                </div>
              )}
            </div>

            {/* Core Badges Row: 🎁 Gifts • ⭐ Level • 👑 VIP */}
            <div className="grid grid-cols-3 gap-2">
              <div
                onClick={() => setShowGiftHistory(true)}
                className="p-2.5 rounded-2xl bg-neutral-950/80 hover:bg-neutral-900 border border-neutral-800 hover:border-violet-500/50 cursor-pointer transition-all text-center group"
                title="Click to view gift history"
              >
                <div className="flex items-center justify-center space-x-1 text-xs font-bold text-violet-300 group-hover:text-violet-200">
                  <span>🎁</span>
                  <span>Gifts</span>
                </div>
                <span className="text-[11px] font-extrabold text-white mt-0.5 block">
                  {totalReceivedGifts} Received
                </span>
              </div>

              <div className="p-2.5 rounded-2xl bg-neutral-950/80 border border-neutral-800 text-center">
                <div className="flex items-center justify-center space-x-1 text-xs font-bold text-amber-300">
                  <span>⭐</span>
                  <span>Level</span>
                </div>
                <span className="text-[11px] font-extrabold text-violet-300 mt-0.5 block">
                  Lv.{userLevel}
                </span>
              </div>

              <div className="p-2.5 rounded-2xl bg-neutral-950/80 border border-neutral-800 text-center">
                <div className="flex items-center justify-center space-x-1 text-xs font-bold text-amber-400">
                  <span>👑</span>
                  <span>VIP</span>
                </div>
                {vipLevel ? (
                  <span className="text-[10px] font-black text-amber-300 mt-0.5 block">
                    VIP {vipLevel}
                  </span>
                ) : (
                  <span className="text-[11px] font-bold text-neutral-400 mt-0.5 block">
                    Standard
                  </span>
                )}
              </div>
            </div>

            {/* Stats Row: Followers & Following */}
            <div className="grid grid-cols-2 gap-2 p-2.5 rounded-2xl bg-neutral-950/70 border border-neutral-800/90 text-center">
              <div>
                <span className="text-[9px] text-neutral-500 uppercase font-bold block">Followers</span>
                <span className="text-sm font-extrabold text-white mt-0.5 inline-block">
                  {followerCount.toLocaleString()}
                </span>
              </div>
              <div>
                <span className="text-[9px] text-neutral-500 uppercase font-bold block">Following</span>
                <span className="text-sm font-extrabold text-white mt-0.5 inline-block">
                  {user.following.toLocaleString()}
                </span>
              </div>
            </div>

            {/* Voice Interaction Section */}
            <div className="p-3.5 rounded-2xl bg-gradient-to-br from-violet-950/40 via-neutral-950 to-neutral-900 border border-violet-800/40 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-bold uppercase tracking-wider text-violet-300 flex items-center space-x-1.5">
                  <Radio className="w-3.5 h-3.5 text-rose-500 animate-pulse" />
                  <span>Voice Stage Interaction</span>
                </span>
                {isInCurrentRoom && (
                  <span className="text-[9px] font-bold px-2 py-0.5 rounded-full bg-violet-900/60 text-violet-300 border border-violet-700/40">
                    In This Room
                  </span>
                )}
              </div>

              {activeRoom ? (
                <div className="space-y-2">
                  <div className="p-2.5 rounded-xl bg-neutral-900/80 border border-neutral-800 flex items-center justify-between">
                    <div className="min-w-0 pr-2">
                      <p className="text-xs font-bold text-white truncate">
                        {activeRoom.title}
                      </p>
                      <p className="text-[10px] text-neutral-400 flex items-center space-x-1 mt-0.5">
                        <Users className="w-3 h-3 text-neutral-500" />
                        <span>{activeRoom.listenerCount} listeners • {activeRoom.topic}</span>
                      </p>
                    </div>
                    {onJoinRoom && (
                      <button
                        onClick={() => {
                          onJoinRoom(activeRoom);
                          onClose();
                        }}
                        className="px-3 py-1.5 rounded-xl bg-violet-600 hover:bg-violet-500 text-white text-xs font-bold whitespace-nowrap shadow-md shadow-violet-600/30 flex items-center space-x-1"
                      >
                        <span>Join Stage</span>
                        <ArrowRight className="w-3 h-3" />
                      </button>
                    )}
                  </div>
                </div>
              ) : isInCurrentRoom ? (
                <div className="text-xs text-neutral-300 p-2 rounded-xl bg-neutral-900/60 border border-neutral-800 flex items-center justify-between">
                  <span>
                    {isSpeakerInCurrentRoom ? '🎙️ Currently on stage with you' : '🎧 Listening in audience'}
                  </span>
                  {currentRoom?.host.id === currentUser.id && user.id !== currentUser.id && onHostAction && (
                    <button
                      onClick={() => {
                        onHostAction('demote', user.id);
                        onClose();
                      }}
                      className="text-[10px] font-semibold text-amber-400 hover:underline"
                    >
                      Host Options
                    </button>
                  )}
                </div>
              ) : (
                <div className="p-2.5 rounded-xl bg-neutral-900/40 border border-neutral-800 text-[11px] text-neutral-400 flex items-center space-x-2">
                  <Mic className="w-3.5 h-3.5 text-neutral-500" />
                  <span>Not currently active in any Voice Room board</span>
                </div>
              )}
            </div>

            {/* Gifts Received Section */}
            <div className="p-3.5 rounded-2xl bg-neutral-950/70 border border-neutral-800/90 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Gift className="w-4 h-4 text-violet-400" />
                  <h4 className="text-xs font-bold text-white">
                    Gifts Received
                  </h4>
                  <span className="text-[10px] font-bold px-1.5 py-0.2 rounded-full bg-violet-950 text-violet-300 border border-violet-800/50">
                    {totalReceivedGifts}
                  </span>
                </div>

                <button
                  id="view-all-gifts-btn"
                  onClick={() => setShowGiftHistory(true)}
                  className="text-[11px] font-bold text-violet-400 hover:text-violet-300 flex items-center space-x-0.5 cursor-pointer"
                >
                  <span>View All Gifts</span>
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* Received Gifts Badges Preview */}
              {receivedGifts.length === 0 ? (
                <div className="py-4 text-center text-neutral-500 space-y-1">
                  <p className="text-xs font-medium text-neutral-400">No gifts received yet</p>
                  <p className="text-[10px]">Verified gift history will appear here once received.</p>
                </div>
              ) : (
                <div className="grid grid-cols-3 gap-2">
                  {receivedGifts.slice(0, 3).map(g => (
                    <div
                      key={g.id}
                      className="p-2 rounded-xl bg-neutral-900 border border-neutral-800 text-center flex flex-col items-center"
                    >
                      <span className="text-xl mb-0.5">{g.giftIcon}</span>
                      <span className="text-[11px] font-bold text-white truncate max-w-full">
                        {g.giftName}
                      </span>
                      <span className="text-[9px] font-extrabold text-violet-400 mt-0.5">
                        × {g.quantity}
                      </span>
                      {g.receiverCoins !== undefined && (
                        <span className="text-[9px] font-bold text-emerald-400 font-mono mt-0.5">
                          +🪙 {g.receiverCoins.toLocaleString()}
                        </span>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Sent Gifts Section (Profile Owner ONLY - Rule #7 & #9) */}
            {isOwnProfile && (
              <div className="p-3.5 rounded-2xl bg-neutral-950/70 border border-neutral-800/90 space-y-2.5">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Gift className="w-4 h-4 text-indigo-400" />
                    <h4 className="text-xs font-bold text-white">
                      Gifts Sent (Private to You)
                    </h4>
                  </div>
                  <span className="text-[9px] font-bold text-neutral-500 bg-neutral-900 px-2 py-0.5 rounded-full border border-neutral-800">
                    Owner Only
                  </span>
                </div>

                {sentGifts.length === 0 ? (
                  <p className="text-xs text-neutral-500 py-2 text-center">
                    You haven&apos;t sent any gifts yet.
                  </p>
                ) : (
                  <div className="space-y-1.5">
                    {sentGifts.map(s => (
                      <div
                        key={s.id}
                        className="p-2 rounded-xl bg-neutral-900/60 border border-neutral-800 flex items-center justify-between text-xs"
                      >
                        <div className="flex items-center space-x-2 min-w-0">
                          <span className="text-base">{s.giftIcon}</span>
                          <div className="min-w-0">
                            <span className="text-white font-medium truncate block">
                              {s.giftName} × {s.quantity}
                            </span>
                            <span className="text-[10px] text-neutral-400">
                              To {s.recipientName} (ID: {s.recipientNumericId})
                            </span>
                          </div>
                        </div>
                        <span className="text-[10px] text-neutral-500 flex-shrink-0">
                          {s.sentAt}
                        </span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* Communities & Clubs */}
            {user.clubs && user.clubs.length > 0 && (
              <div className="space-y-2">
                <span className="text-[10px] font-bold uppercase tracking-wider text-neutral-400">
                  Clubs & Communities
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {user.clubs.map(club => (
                    <span
                      key={club}
                      className="px-2.5 py-1 rounded-lg bg-neutral-950 border border-neutral-800 text-[11px] font-semibold text-neutral-300"
                    >
                      {club}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Unfollow Confirmation Dialog */}
      {showUnfollowConfirm && (
        <div
          id="unfollow-confirm-dialog"
          className="fixed inset-0 z-60 flex items-center justify-center bg-black/85 backdrop-blur-sm p-4 animate-fade-in"
        >
          <div className="w-full max-w-xs bg-neutral-900 border border-neutral-800 rounded-3xl p-5 shadow-2xl text-center space-y-3">
            <div className="w-12 h-12 rounded-full bg-rose-950/40 border border-rose-500/30 text-rose-400 flex items-center justify-center mx-auto">
              <AlertTriangle className="w-6 h-6" />
            </div>
            <h4 className="text-sm font-bold text-white">
              Unfollow {user.name}?
            </h4>
            <p className="text-xs text-neutral-400">
              You will no longer see their hosted voice rooms or audio updates in your personal feed.
            </p>
            <div className="grid grid-cols-2 gap-2 pt-2">
              <button
                onClick={() => setShowUnfollowConfirm(false)}
                className="py-2 rounded-xl bg-neutral-800 text-neutral-300 text-xs font-semibold hover:bg-neutral-700 transition-colors"
              >
                Cancel
              </button>
              <button
                id="confirm-unfollow-btn"
                onClick={confirmUnfollow}
                className="py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold transition-colors shadow-md shadow-rose-600/30"
              >
                Unfollow
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Gift History Modal */}
      {showGiftHistory && (
        <GiftHistoryModal
          user={user}
          onClose={() => setShowGiftHistory(false)}
        />
      )}

      {/* Direct Message 1-on-1 Modal */}
      {showDirectMessage && (
        <DirectMessageModal
          currentUser={currentUser}
          targetUser={user}
          onClose={() => setShowDirectMessage(false)}
        />
      )}

      {/* Floating Toast Feedback */}
      {toastMessage && (
        <div className="fixed bottom-20 left-1/2 -translate-x-1/2 z-70 px-4 py-2 bg-neutral-900 border border-violet-500/60 rounded-full shadow-xl text-xs font-semibold text-white animate-fade-in">
          {toastMessage}
        </div>
      )}
    </>
  );
};
