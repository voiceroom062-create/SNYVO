import React from 'react';
import { Mic, MicOff, LogOut, ChevronUp, Radio } from 'lucide-react';
import { VoiceRoom, User } from '../types';

interface ActiveRoomMiniPlayerProps {
  room: VoiceRoom;
  currentUser: User;
  isMuted: boolean;
  onMaximize: () => void;
  onToggleMute: () => void;
  onLeave: () => void;
}

export const ActiveRoomMiniPlayer: React.FC<ActiveRoomMiniPlayerProps> = ({
  room,
  isMuted,
  onMaximize,
  onToggleMute,
  onLeave,
}) => {
  const activeSpeaker = room.speakers.find(s => s.isSpeaking) || room.speakers[0];

  return (
    <div
      id="active-room-mini-player"
      className="mx-3 mb-2 bg-neutral-900/95 border border-violet-500/30 rounded-2xl p-2.5 shadow-xl shadow-black/60 backdrop-blur-xl flex items-center justify-between z-30 transition-all"
    >
      <div
        className="flex items-center space-x-3 flex-1 min-w-0 cursor-pointer pr-2"
        onClick={onMaximize}
      >
        <div className="relative flex-shrink-0">
          <img
            src={activeSpeaker?.avatar || room.host.avatar}
            alt={activeSpeaker?.name || 'Speaker'}
            className="w-10 h-10 rounded-full object-cover border border-violet-400"
          />
          <div className="absolute -bottom-0.5 -right-0.5 w-4 h-4 bg-emerald-500 rounded-full border-2 border-neutral-900 flex items-center justify-center">
            <Radio className="w-2.5 h-2.5 text-white animate-pulse" />
          </div>
        </div>

        <div className="min-w-0 flex-1">
          <div className="flex items-center space-x-1.5">
            <span className="inline-block w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping"></span>
            <span className="text-[10px] font-semibold uppercase tracking-wider text-violet-400 truncate">
              {room.clubName || 'Live Stage'}
            </span>
          </div>
          <p className="text-xs font-medium text-white truncate">{room.title}</p>
          <p className="text-[11px] text-neutral-400 truncate">
            Speaking: <span className="text-neutral-200">{activeSpeaker?.name}</span>
          </p>
        </div>
      </div>

      <div className="flex items-center space-x-1 flex-shrink-0">
        <button
          id="mini-toggle-mic-btn"
          onClick={onToggleMute}
          className={`p-2 rounded-full transition-colors ${
            isMuted ? 'bg-neutral-800 text-neutral-400 hover:text-white' : 'bg-violet-600 text-white shadow-md shadow-violet-600/30'
          }`}
          aria-label={isMuted ? 'Unmute microphone' : 'Mute microphone'}
        >
          {isMuted ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
        </button>

        <button
          id="mini-maximize-btn"
          onClick={onMaximize}
          className="p-2 text-neutral-400 hover:text-white rounded-full hover:bg-neutral-800 transition-colors"
          aria-label="Expand room"
        >
          <ChevronUp className="w-4 h-4" />
        </button>

        <button
          id="mini-leave-btn"
          onClick={onLeave}
          className="p-2 text-rose-400 hover:text-rose-300 rounded-full hover:bg-rose-950/40 transition-colors"
          aria-label="Leave room"
        >
          <LogOut className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
