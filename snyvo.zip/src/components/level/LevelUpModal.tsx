import React, { useEffect } from 'react';
import { Sparkles, Trophy, X, ArrowUpRight, Award, Flame, Crown } from 'lucide-react';
import { LevelUpEvent } from '../../types';

interface LevelUpModalProps {
  event: LevelUpEvent;
  onClose: () => void;
}

export const LevelUpModal: React.FC<LevelUpModalProps> = ({ event, onClose }) => {
  const isSending = event.type === 'sending';
  const badge = event.badge;

  // Optional: Play chime on mount
  useEffect(() => {
    try {
      const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const now = audioCtx.currentTime;
      // Harmonious major fanfare: C5, E5, G5, C6
      const notes = [523.25, 659.25, 783.99, 1046.5];
      notes.forEach((freq, idx) => {
        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(freq, now + idx * 0.12);
        gain.gain.setValueAtTime(0.2, now + idx * 0.12);
        gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.12 + 0.6);
        osc.connect(gain);
        gain.connect(audioCtx.destination);
        osc.start(now + idx * 0.12);
        osc.stop(now + idx * 0.12 + 0.65);
      });
    } catch (e) {
      // Audio context might be restricted before interaction
    }
  }, []);

  return (
    <div
      className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 animate-fadeIn select-none"
      onClick={onClose}
    >
      <div
        className="w-full max-w-sm bg-gradient-to-b from-neutral-900 via-neutral-950 to-black border-2 border-amber-500/40 rounded-3xl p-6 shadow-[0_0_50px_rgba(245,158,11,0.3)] text-center text-white relative overflow-hidden animate-scaleUp"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Confetti / Sparkles Background Ambient Elements */}
        <div className="absolute -top-10 -left-10 w-32 h-32 bg-amber-500/20 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-10 -right-10 w-32 h-32 bg-rose-500/20 rounded-full blur-3xl pointer-events-none" />

        {/* Close Button */}
        <button
          type="button"
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 rounded-full text-neutral-400 hover:text-white bg-neutral-800/80 hover:bg-neutral-700 transition-colors cursor-pointer"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Celebratory Header Tag */}
        <div className="inline-flex items-center space-x-1.5 px-3 py-1 rounded-full bg-gradient-to-r from-amber-500/20 to-yellow-500/20 border border-amber-400/40 text-amber-300 text-[11px] font-black uppercase tracking-wider mb-3">
          <Sparkles className="w-3.5 h-3.5 text-amber-400 animate-spin" />
          <span>🎉 LEVEL UP!</span>
        </div>

        {/* Level Up Type Tag: Sending Level Up vs Receiving Level Up */}
        <div className="mb-4">
          <span
            className={`inline-flex items-center space-x-1.5 px-3.5 py-1 rounded-full text-xs font-black uppercase tracking-wide border shadow-md ${
              isSending
                ? 'bg-amber-950/80 border-amber-500/60 text-amber-300 shadow-amber-500/20'
                : 'bg-pink-950/80 border-pink-500/60 text-pink-300 shadow-pink-500/20'
            }`}
          >
            {isSending ? <Flame className="w-3.5 h-3.5 text-amber-400" /> : <Crown className="w-3.5 h-3.5 text-pink-400" />}
            <span>{isSending ? 'Sending Level Up' : 'Receiving Level Up'}</span>
          </span>
        </div>

        {/* Large Animated Badge Visual */}
        <div className="relative my-4 flex items-center justify-center">
          <div className="w-24 h-24 rounded-3xl bg-gradient-to-tr from-amber-500 via-rose-500 to-violet-600 p-[3px] shadow-2xl animate-pulse">
            <div className="w-full h-full bg-neutral-950 rounded-[22px] flex flex-col items-center justify-center space-y-1">
              <span className="text-3xl filter drop-shadow">{badge.icon}</span>
              <span className="text-base font-black tracking-tight text-amber-300 font-mono">
                Lv. {event.newLevel}
              </span>
            </div>
          </div>
          <div className="absolute -top-1 -right-1 p-1 rounded-full bg-amber-400 text-neutral-950 shadow-lg">
            <ArrowUpRight className="w-4 h-4 font-black" />
          </div>
        </div>

        {/* Big Congratulations Heading */}
        <div className="space-y-1">
          <h3 className="text-xl font-black tracking-tight text-white">
            You have reached <span className="text-amber-400">Level {event.newLevel}!</span>
          </h3>
          <p className="text-xs text-neutral-300 font-semibold">
            Unlocked: <span className="text-amber-300 font-bold">{badge.tierName}</span>
          </p>
        </div>

        {/* Level Progression Comparison Pill */}
        <div className="my-4 p-3 bg-neutral-900/90 border border-neutral-800 rounded-2xl flex items-center justify-around text-xs">
          <div>
            <span className="text-[10px] text-neutral-500 block uppercase font-bold">Previous</span>
            <span className="text-sm font-bold text-neutral-400 font-mono">Lv. {event.oldLevel}</span>
          </div>
          <div className="text-amber-400 font-black">➔</div>
          <div>
            <span className="text-[10px] text-amber-400 block uppercase font-bold">New Level</span>
            <span className="text-base font-black text-amber-300 font-mono">Lv. {event.newLevel}</span>
          </div>
        </div>

        <p className="text-[11px] text-neutral-400 leading-relaxed mb-4">
          Lifetime Cumulative {isSending ? 'Sent' : 'Received'}:{' '}
          <strong className="text-white font-mono">{event.totalCoins.toLocaleString()} 🪙</strong>
        </p>

        {/* Claim / Dismiss Button */}
        <button
          type="button"
          onClick={onClose}
          className="w-full py-3 rounded-2xl bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 hover:from-amber-400 hover:to-orange-500 text-neutral-950 font-black text-xs uppercase tracking-wider shadow-lg shadow-amber-500/30 transition-all cursor-pointer active:scale-98"
        >
          Awesome! Continue
        </button>
      </div>
    </div>
  );
};
