import React, { useEffect, useState } from 'react';
import { BoardEntryEvent } from '../coins/types';
import { VIP_TIER_CONFIGS } from '../coins/vipService';
import { Sparkles, Crown, Diamond, Star, X } from 'lucide-react';

interface BoardEntryAnimationProps {
  event: BoardEntryEvent | null;
  onDismiss: () => void;
}

export const BoardEntryAnimation: React.FC<BoardEntryAnimationProps> = ({ event, onDismiss }) => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    if (event) {
      setVisible(true);
      const timer = setTimeout(() => {
        setVisible(false);
        setTimeout(onDismiss, 400); // allow transition out
      }, 4500);
      return () => clearTimeout(timer);
    }
  }, [event, onDismiss]);

  if (!event || !visible) return null;

  const tier = event.user.vipTier;
  const tierInfo = VIP_TIER_CONFIGS[tier] || VIP_TIER_CONFIGS.REGULAR;
  const isSvip = tier === 'SVIP';
  const isVipPro = tier === 'VIP_PRO';
  const isVip = tier === 'VIP';

  return (
    <div
      id="board-entry-animation-overlay"
      className="fixed inset-x-0 top-16 sm:top-20 z-50 pointer-events-none flex flex-col items-center justify-start px-3"
      aria-live="polite"
    >
      {/* 1. SVIP Full-Screen Grand Cosmic Portal & Dragon Aura (pointer-events-none) */}
      {isSvip && (
        <div className="absolute -top-12 inset-x-0 h-96 flex items-center justify-center overflow-hidden pointer-events-none">
          {/* Radial Cosmic Blast */}
          <div className="w-[500px] h-[500px] rounded-full bg-gradient-to-r from-cyan-500/20 via-blue-600/30 to-fuchsia-600/25 blur-3xl animate-pulse" />
          
          {/* Galactic Floating Diamonds */}
          <div className="absolute inset-0 flex items-center justify-around opacity-75">
            <span className="text-2xl animate-bounce delay-100">💎</span>
            <span className="text-3xl animate-ping delay-300">✨</span>
            <span className="text-2xl animate-bounce delay-200">💎</span>
            <span className="text-4xl animate-pulse">🐉</span>
            <span className="text-2xl animate-bounce delay-150">💎</span>
          </div>
        </div>
      )}

      {/* 2. VIP PRO Golden Starlight Trail */}
      {isVipPro && (
        <div className="absolute -top-10 inset-x-0 h-64 flex items-center justify-center overflow-hidden pointer-events-none">
          <div className="w-[420px] h-[260px] rounded-full bg-gradient-to-r from-purple-500/20 via-violet-600/25 to-amber-500/20 blur-2xl animate-pulse" />
          <div className="absolute inset-0 flex items-center justify-around opacity-60">
            <span className="text-xl animate-pulse">🌟</span>
            <span className="text-2xl animate-bounce">👑</span>
            <span className="text-xl animate-pulse">✨</span>
          </div>
        </div>
      )}

      {/* 3. VIP Golden Flare Aura */}
      {isVip && (
        <div className="absolute -top-8 inset-x-0 h-48 flex items-center justify-center overflow-hidden pointer-events-none">
          <div className="w-[360px] h-[180px] rounded-full bg-amber-500/20 blur-2xl animate-pulse" />
        </div>
      )}

      {/* Center Grand Entrance Banner */}
      <div
        className={`w-full max-w-sm rounded-3xl p-3 sm:p-3.5 shadow-2xl backdrop-blur-xl border transition-all transform duration-500 animate-in fade-in slide-in-from-top-6 ${
          isSvip
            ? 'bg-gradient-to-r from-cyan-950/95 via-blue-950/95 to-fuchsia-950/95 border-cyan-400/80 shadow-cyan-500/30'
            : isVipPro
            ? 'bg-gradient-to-r from-purple-950/95 via-neutral-950/95 to-violet-950/95 border-purple-400/80 shadow-purple-500/30'
            : isVip
            ? 'bg-gradient-to-r from-amber-950/95 via-neutral-950/95 to-yellow-950/95 border-amber-400/80 shadow-amber-500/30'
            : 'bg-neutral-900/90 border-neutral-700/80 shadow-black/50'
        }`}
      >
        <div className="flex items-center space-x-3">
          {/* Avatar with Animated VIP Ring & Crown */}
          <div className="relative flex-shrink-0">
            {/* Crown positioned over avatar */}
            <div className="absolute -top-3.5 left-1/2 -translate-x-1/2 text-base sm:text-lg z-10 filter drop-shadow-md animate-bounce">
              {tierInfo.crown || '🌟'}
            </div>

            <div
              className={`w-12 h-12 rounded-full p-0.5 transition-all ${
                isSvip
                  ? 'bg-gradient-to-tr from-cyan-400 via-fuchsia-400 to-amber-300 ring-2 ring-cyan-300 ring-offset-2 ring-offset-neutral-950 shadow-lg shadow-cyan-500/50'
                  : isVipPro
                  ? 'bg-gradient-to-tr from-purple-400 via-pink-400 to-amber-400 ring-2 ring-purple-400 ring-offset-1 ring-offset-neutral-950'
                  : isVip
                  ? 'bg-gradient-to-tr from-amber-400 via-yellow-300 to-amber-600 ring-2 ring-amber-400'
                  : 'bg-neutral-800'
              }`}
            >
              <img
                src={event.user.avatar}
                alt={event.user.name}
                className="w-full h-full rounded-full object-cover"
              />
            </div>

            {/* Glowing Aura Ring */}
            <div className="absolute inset-0 rounded-full bg-current opacity-20 animate-ping pointer-events-none" />
          </div>

          {/* User Details & Entrance Title */}
          <div className="min-w-0 flex-1">
            {/* Top Tier Badge & Tagline */}
            <div className="flex items-center space-x-1.5 mb-0.5">
              <span
                className={`text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded-full border shadow-sm flex items-center space-x-1 ${
                  isSvip
                    ? 'bg-gradient-to-r from-cyan-400 to-fuchsia-500 text-neutral-950 border-cyan-200'
                    : isVipPro
                    ? 'bg-gradient-to-r from-purple-500 to-pink-500 text-white border-purple-300'
                    : isVip
                    ? 'bg-gradient-to-r from-amber-400 to-yellow-500 text-neutral-950 border-amber-200'
                    : 'bg-neutral-800 text-neutral-300 border-neutral-700'
                }`}
              >
                {isSvip && <Diamond className="w-2.5 h-2.5 fill-current inline" />}
                {isVipPro && <Star className="w-2.5 h-2.5 fill-current inline" />}
                {isVip && <Crown className="w-2.5 h-2.5 fill-current inline" />}
                <span>{tierInfo.badgeLabel}</span>
              </span>

              <span className="text-[10px] text-neutral-400 truncate">
                ID: {event.user.numericId}
              </span>
            </div>

            {/* User Name */}
            <h4 className="text-xs sm:text-sm font-extrabold text-white truncate flex items-center space-x-1">
              <span>{event.user.name}</span>
              <span className="text-xs">{tierInfo.crown}</span>
            </h4>

            {/* Effect Description */}
            <p className="text-[11px] font-medium flex items-center space-x-1 text-neutral-300 truncate">
              <Sparkles className="w-3 h-3 text-amber-400 flex-shrink-0 animate-spin" />
              <span className="text-amber-200 font-semibold truncate">{event.entryEffectTitle}</span>
            </p>
          </div>

          {/* Right Status Emblem */}
          <div className="flex-shrink-0 text-right">
            <span
              className={`text-[10px] font-black px-2 py-1 rounded-xl border flex items-center space-x-1 ${
                isSvip
                  ? 'bg-cyan-500/20 text-cyan-300 border-cyan-400/50 shadow-sm shadow-cyan-500/30'
                  : isVipPro
                  ? 'bg-purple-500/20 text-purple-300 border-purple-400/50'
                  : isVip
                  ? 'bg-amber-500/20 text-amber-300 border-amber-400/50'
                  : 'bg-neutral-800 text-neutral-400 border-neutral-700'
              }`}
            >
              <span>ENTERED</span>
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
