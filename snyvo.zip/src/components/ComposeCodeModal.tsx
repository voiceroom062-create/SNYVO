import React, { useState } from 'react';
import { X, Copy, Check, Code2, Smartphone, Terminal } from 'lucide-react';
import { ScreenType } from '../types';

interface ComposeCodeModalProps {
  activeScreen: ScreenType;
  onClose: () => void;
}

export const ComposeCodeModal: React.FC<ComposeCodeModalProps> = ({
  activeScreen,
  onClose,
}) => {
  const [copied, setCopied] = useState(false);
  const [selectedFile, setSelectedFile] = useState<string>(
    activeScreen === 'room' ? 'VoiceRoomScreen.kt' :
    activeScreen === 'profile' ? 'ProfileScreen.kt' :
    activeScreen === 'login' ? 'LoginScreen.kt' :
    activeScreen === 'signup' ? 'SignUpScreen.kt' :
    activeScreen === 'splash' ? 'SplashScreen.kt' : 'HomeScreen.kt'
  );

  const codeSnippets: Record<string, string> = {
    'SnyvoNavigation.kt': `package com.snyvo.app.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.snyvo.app.ui.screens.*

sealed class Screen(val route: String) {
    object Splash : Screen("splash")
    object Login : Screen("login")
    object SignUp : Screen("signup")
    object Home : Screen("home")
    object VoiceRoom : Screen("room/{roomId}") {
        fun createRoute(roomId: String) = "room/$roomId"
    }
    object Profile : Screen("profile")
}

@Composable
fun SnyvoNavHost() {
    val navController = rememberNavController()

    NavHost(navController = navController, startDestination = Screen.Splash.route) {
        composable(Screen.Splash.route) {
            SplashScreen(
                onNavigateToHome = { navController.navigate(Screen.Home.route) },
                onNavigateToLogin = { navController.navigate(Screen.Login.route) },
                onNavigateToSignUp = { navController.navigate(Screen.SignUp.route) }
            )
        }
        composable(Screen.Login.route) {
            LoginScreen(
                onLoginSuccess = { navController.navigate(Screen.Home.route) },
                onNavigateToSignUp = { navController.navigate(Screen.SignUp.route) }
            )
        }
        composable(Screen.SignUp.route) {
            SignUpScreen(
                onSignUpSuccess = { navController.navigate(Screen.Home.route) },
                onNavigateToLogin = { navController.navigate(Screen.Login.route) }
            )
        }
        composable(Screen.Home.route) {
            HomeScreen(
                onJoinRoom = { roomId -> navController.navigate(Screen.VoiceRoom.createRoute(roomId)) },
                onNavigateToProfile = { navController.navigate(Screen.Profile.route) }
            )
        }
        composable(Screen.VoiceRoom.route) { backStackEntry ->
            val roomId = backStackEntry.arguments?.getString("roomId") ?: ""
            VoiceRoomScreen(
                roomId = roomId,
                onLeaveRoom = { navController.popBackStack() }
            )
        }
        composable(Screen.Profile.route) {
            ProfileScreen(
                onNavigateBack = { navController.popBackStack() },
                onSignOut = { navController.navigate(Screen.Login.route) }
            )
        }
    }
}`,

    'VoiceRoomScreen.kt': `package com.snyvo.app.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage

@Composable
fun VoiceRoomScreen(
    roomId: String,
    onLeaveRoom: () -> Unit
) {
    var isMuted by remember { mutableStateOf(true) }
    var hasRaisedHand by remember { mutableStateOf(false) }

    Scaffold(
        containerColor = Color(0xFF0A0D14),
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onLeaveRoom) {
                    Icon(Icons.Default.KeyboardArrowDown, contentDescription = "Minimize", tint = Color.White)
                }
                Text("Late Night Lo-Fi Stage", color = Color.White, fontSize = 16.sp)
                Button(
                    onClick = onLeaveRoom,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0x33F43F5E))
                ) {
                    Text("Leave quietly", color = Color(0xFFFB7185), fontSize = 12.sp)
                }
            }
        },
        bottomBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF0F1420))
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { hasRaisedHand = !hasRaisedHand }) {
                    Icon(
                        Icons.Default.FrontHand,
                        contentDescription = "Raise Hand",
                        tint = if (hasRaisedHand) Color(0xFFF59E0B) else Color.Gray
                    )
                }
                Button(
                    onClick = { isMuted = !isMuted },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isMuted) Color(0xFF1E293B) else Color(0xFF7C3AED)
                    ),
                    shape = RoundedCornerShape(24.dp)
                ) {
                    Icon(if (isMuted) Icons.Default.MicOff else Icons.Default.Mic, contentDescription = "Mic")
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(if (isMuted) "Muted" else "On Air")
                }
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp)
        ) {
            Text("Stage Speakers", color = Color.Gray, fontSize = 12.sp)
            Spacer(modifier = Modifier.height(12.dp))
            // Speaker Grid with Animated Pulse Rings
            // ... Full implementation connected to WebRTC/LiveKit SFU
        }
    }
}`,

    'HomeScreen.kt': `package com.snyvo.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.snyvo.app.data.models.VoiceRoom

@Composable
fun HomeScreen(
    onJoinRoom: (String) -> Unit,
    onNavigateToProfile: () -> Unit
) {
    Scaffold(
        containerColor = Color(0xFF090B10),
        topBar = {
            TopAppBar(
                title = { Text("SNYVO", color = Color.White, fontSize = 20.sp) },
                actions = {
                    IconButton(onClick = { /* Notifications */ }) {
                        Icon(Icons.Default.Notifications, contentDescription = "Alerts", tint = Color.LightGray)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF090B10))
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { /* Launch Create Room Dialog */ },
                containerColor = Color(0xFF7C3AED),
                shape = CircleShape
            ) {
                Icon(Icons.Default.Add, contentDescription = "Start Room", tint = Color.White)
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Text("Live Audio Rooms", color = Color.White, fontSize = 16.sp)
            }
            // Room Cards with real-time speaker states
        }
    }
}`,

    'FirebaseVoiceConfig.kt': `package com.snyvo.app.data

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

/**
 * Ready-to-inject Firebase & Real-Time Voice Configuration
 */
class FirebaseVoiceRepository(
    private val auth: FirebaseAuth = FirebaseAuth.getInstance(),
    private val firestore: FirebaseFirestore = FirebaseFirestore.getInstance()
) {
    fun getCurrentUserId(): String? = auth.currentUser?.uid

    suspend fun joinVoiceRoom(roomId: String, userId: String) {
        firestore.collection("rooms").document(roomId)
            .collection("participants").document(userId)
            .set(mapOf("isSpeaking" to false, "isMuted" to true, "joinedAt" to System.currentTimeMillis()))
    }
}`
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(codeSnippets[selectedFile] || '');
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-4 animate-fade-in">
      <div className="w-full max-w-2xl bg-neutral-900 border border-neutral-800 rounded-2xl shadow-2xl flex flex-col max-h-[85vh] text-white">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-neutral-800">
          <div className="flex items-center space-x-2">
            <div className="p-1.5 rounded-lg bg-emerald-500/20 text-emerald-400">
              <Smartphone className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white">Kotlin & Jetpack Compose Native Source</h3>
              <p className="text-[11px] text-neutral-400">Production Android Material 3 Architecture</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* File Tabs */}
        <div className="flex items-center space-x-1 px-5 pt-3 pb-2 border-b border-neutral-800/60 overflow-x-auto bg-neutral-950/50">
          {Object.keys(codeSnippets).map(fileName => (
            <button
              key={fileName}
              onClick={() => setSelectedFile(fileName)}
              className={`px-3 py-1.5 rounded-lg text-xs font-mono transition-colors whitespace-nowrap ${
                selectedFile === fileName
                  ? 'bg-violet-600/30 text-violet-300 border border-violet-500/40'
                  : 'text-neutral-400 hover:text-neutral-200'
              }`}
            >
              {fileName}
            </button>
          ))}
        </div>

        {/* Code Content */}
        <div className="flex-1 overflow-y-auto p-4 bg-neutral-950 font-mono text-xs leading-relaxed text-neutral-300 select-text">
          <pre className="whitespace-pre overflow-x-auto">{codeSnippets[selectedFile]}</pre>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between px-5 py-3 border-t border-neutral-800 bg-neutral-900">
          <span className="text-[11px] text-neutral-400 font-medium">
            Files mapped directly in <span className="text-violet-400">/android/app/src/main/java</span>
          </span>
          <button
            onClick={handleCopy}
            className="px-4 py-2 rounded-xl bg-violet-600 hover:bg-violet-500 text-white text-xs font-semibold flex items-center space-x-1.5 transition-all active:scale-95"
          >
            {copied ? <Check className="w-4 h-4 text-emerald-300" /> : <Copy className="w-4 h-4" />}
            <span>{copied ? 'Copied to Clipboard' : 'Copy Compose Code'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
