import React, { useState } from 'react';
import { X, Gift, ArrowLeft, Filter, Sparkles, User, Calendar, Copy, Check, Trophy, Gem, Star } from 'lucide-react';
import { User as UserType, ReceivedGift } from '../types';
import { userService, getNumericUserId } from '../services/userService';
import { ALL_GIFTS } from '../gifts/giftData';

interface GiftHistoryModalProps {
  user: UserType;
  onClose: () => void;
  onSelectUser?: (userId: string) => void;
}

export const GiftHistoryModal: React.FC<GiftHistoryModalProps> = ({
  user,
  onClose,
  onSelectUser,
}) => {
  const [activeTab, setActiveTab] = useState<'all' | 'recent' | 'most_received'>('all');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const gifts = userService.getReceivedGifts(user.id);
  const totalGiftUnits = userService.getTotalReceivedGiftsCount(user.id);
  const userNumericId = user.numericId || getNumericUserId(user.id);

  // Calculate Total Gift Value in Coins
  const totalGiftValue = gifts.reduce((sum, g) => {
    if (g.coinValue) return sum + g.coinValue;
    const catalogItem = ALL_GIFTS.find(item => item.id === g.giftId || item.name.toLowerCase() === g.giftName.toLowerCase());
    const unitPrice = catalogItem ? catalogItem.coins : 500;
    return sum + (unitPrice * g.quantity);
  }, 0);

  // Calculate Total 30% Receiver Credit in Coins
  const totalReceiverCredit = gifts.reduce((sum, g) => {
    if (g.receiverCoins !== undefined) return sum + g.receiverCoins;
    const catalogItem = ALL_GIFTS.find(item => item.id === g.giftId || item.name.toLowerCase() === g.giftName.toLowerCase());
    const unitPrice = catalogItem ? catalogItem.coins : 500;
    return sum + Math.floor((unitPrice * g.quantity * 30) / 100);
  }, 0);

  // Calculate Most Received Gift
  const giftCountsByName: Record<string, { giftName: string; giftIcon: string; quantity: number }> = {};
  gifts.forEach(g => {
    if (!giftCountsByName[g.giftName]) {
      giftCountsByName[g.giftName] = { giftName: g.giftName, giftIcon: g.giftIcon, quantity: 0 };
    }
    giftCountsByName[g.giftName].quantity += g.quantity;
  });

  const sortedGifts = Object.values(giftCountsByName).sort((a, b) => b.quantity - a.quantity);
  const mostReceivedGift = sortedGifts[0] || null;
  const topGiftsList = sortedGifts.slice(0, 3);

  const handleCopy = (idText: string) => {
    navigator.clipboard.writeText(idText);
    setCopiedId(idText);
    setTimeout(() => setCopiedId(null), 2000);
  };

  // Tab filtering logic
  let displayedGifts: ReceivedGift[] = [...gifts];
  if (activeTab === 'recent') {
    displayedGifts = [...gifts];
  } else if (activeTab === 'most_received') {
    displayedGifts.sort((a, b) => b.quantity - a.quantity);
  }

  return (
    <div
      id="gift-history-modal"
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/85 backdrop-blur-md animate-fade-in"
    >
      <div className="w-full max-w-md bg-neutral-900 border border-neutral-800 rounded-t-3xl sm:rounded-3xl p-5 shadow-2xl shadow-violet-950/40 text-white max-h-[88vh] flex flex-col">
        {/* Top Header */}
        <div className="flex items-center justify-between pb-3 border-b border-neutral-800 flex-shrink-0">
          <div className="flex items-center space-x-2.5">
            <button
              id="gift-history-back-btn"
              onClick={onClose}
              className="p-1.5 text-neutral-400 hover:text-white rounded-full hover:bg-neutral-800 transition-colors cursor-pointer"
              aria-label="Back"
            >
              <ArrowLeft className="w-4 h-4" />
            </button>
            <div>
              <h3 className="text-sm font-bold text-white flex items-center space-x-1.5">
                <Gift className="w-4 h-4 text-violet-400" />
                <span>Gift Ranking & History</span>
              </h3>
              <p className="text-[11px] text-neutral-400">
                {user.name} • <span className="font-mono text-violet-300">ID: {userNumericId}</span>
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-neutral-400 hover:text-white rounded-full hover:bg-neutral-800 transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* 🏆 GIFT STATS & 30% RECEIVER SHARE */}
        <div className="my-3 grid grid-cols-2 gap-2 flex-shrink-0">
          {/* 🎁 Received Gifts */}
          <div className="p-2.5 rounded-2xl bg-neutral-950/80 border border-neutral-800 flex items-center space-x-2.5">
            <div className="w-8 h-8 rounded-xl bg-violet-600/30 border border-violet-500/40 flex items-center justify-center text-base">
              🎁
            </div>
            <div className="overflow-hidden">
              <span className="text-[9px] font-bold uppercase tracking-wider text-neutral-400 block truncate">
                Received Gifts
              </span>
              <p className="text-xs font-black text-white">
                {totalGiftUnits} <span className="text-[10px] font-normal text-neutral-400">items</span>
              </p>
            </div>
          </div>

          {/* 💎 Total Gift Value (100%) */}
          <div className="p-2.5 rounded-2xl bg-neutral-950/80 border border-neutral-800 flex items-center space-x-2.5">
            <div className="w-8 h-8 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-base">
              💎
            </div>
            <div className="overflow-hidden">
              <span className="text-[9px] font-bold uppercase tracking-wider text-amber-300 block truncate">
                Gift Total Value
              </span>
              <p className="text-xs font-black text-amber-300 font-mono truncate">
                🪙 {totalGiftValue.toLocaleString()}
              </p>
            </div>
          </div>

          {/* 🪙 30% Receiver Credit */}
          <div className="p-2.5 rounded-2xl bg-emerald-950/40 border border-emerald-800/60 flex items-center space-x-2.5">
            <div className="w-8 h-8 rounded-xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-base">
              🪙
            </div>
            <div className="overflow-hidden">
              <span className="text-[9px] font-bold uppercase tracking-wider text-emerald-400 block truncate">
                Receiver Share (30%)
              </span>
              <p className="text-xs font-black text-emerald-300 font-mono truncate">
                +🪙 {totalReceiverCredit.toLocaleString()}
              </p>
            </div>
          </div>

          {/* 🌟 Most Received Gift */}
          <div className="p-2.5 rounded-2xl bg-neutral-950/80 border border-neutral-800 flex items-center space-x-2.5">
            <div className="w-8 h-8 rounded-xl bg-rose-500/20 border border-rose-500/40 flex items-center justify-center text-base">
              🌟
            </div>
            <div className="overflow-hidden">
              <span className="text-[9px] font-bold uppercase tracking-wider text-rose-300 block truncate">
                Most Received
              </span>
              <p className="text-xs font-bold text-white truncate">
                {mostReceivedGift ? `${mostReceivedGift.giftIcon} ${mostReceivedGift.giftName} (${mostReceivedGift.quantity})` : 'None'}
              </p>
            </div>
          </div>
        </div>

        {/* Filter Tabs */}
        <div className="flex items-center space-x-2 pb-3 border-b border-neutral-800/60 flex-shrink-0">
          <button
            id="gift-tab-all"
            onClick={() => setActiveTab('all')}
            className={`px-3 py-1.5 rounded-xl text-xs font-medium transition-colors cursor-pointer ${
              activeTab === 'all'
                ? 'bg-violet-600 text-white font-semibold shadow-md shadow-violet-600/30'
                : 'bg-neutral-800/60 text-neutral-400 hover:text-white'
            }`}
          >
            All Gifts ({gifts.length})
          </button>
          <button
            id="gift-tab-recent"
            onClick={() => setActiveTab('recent')}
            className={`px-3 py-1.5 rounded-xl text-xs font-medium transition-colors cursor-pointer ${
              activeTab === 'recent'
                ? 'bg-violet-600 text-white font-semibold shadow-md shadow-violet-600/30'
                : 'bg-neutral-800/60 text-neutral-400 hover:text-white'
            }`}
          >
            Recent
          </button>
          <button
            id="gift-tab-most"
            onClick={() => setActiveTab('most_received')}
            className={`px-3 py-1.5 rounded-xl text-xs font-medium transition-colors cursor-pointer ${
              activeTab === 'most_received'
                ? 'bg-violet-600 text-white font-semibold shadow-md shadow-violet-600/30'
                : 'bg-neutral-800/60 text-neutral-400 hover:text-white'
            }`}
          >
            Most Received
          </button>
        </div>

        {/* Gift List */}
        <div className="overflow-y-auto flex-1 py-2 space-y-2.5 pr-1 scrollbar-thin">
          {displayedGifts.length === 0 ? (
            <div className="py-12 text-center text-neutral-400 space-y-2">
              <div className="w-12 h-12 rounded-full bg-neutral-800/60 mx-auto flex items-center justify-center text-2xl">
                🎁
              </div>
              <p className="text-xs font-semibold text-neutral-300">No gifts received yet</p>
              <p className="text-[11px] text-neutral-500 max-w-[240px] mx-auto">
                When room listeners and friends send gifts, every verified transaction will appear here.
              </p>
            </div>
          ) : (
            displayedGifts.map(gift => {
              const catalogItem = ALL_GIFTS.find(
                item => item.id === gift.giftId || item.name.toLowerCase() === gift.giftName.toLowerCase()
              );
              const unitPrice = catalogItem ? catalogItem.coins : 500;
              const giftValue = gift.coinValue || (unitPrice * gift.quantity);
              const receiverShare = gift.receiverCoins !== undefined ? gift.receiverCoins : Math.floor((giftValue * 30) / 100);
              const receiverIdDisplay = gift.receiverNumericId || userNumericId;

              return (
                <div
                  key={gift.id}
                  className="p-3.5 rounded-2xl bg-neutral-950/80 border border-neutral-800/90 hover:border-violet-600/40 transition-all space-y-2.5"
                >
                  {/* Top Item Header */}
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2.5 min-w-0">
                      <div className="w-10 h-10 rounded-xl bg-neutral-900 border border-neutral-800 flex items-center justify-center text-2xl flex-shrink-0 shadow-sm">
                        {gift.giftIcon}
                      </div>
                      <div className="min-w-0">
                        <div className="flex items-center space-x-1.5">
                          <span className="text-xs font-bold text-white truncate">
                            {gift.giftName}
                          </span>
                          <span className="text-[10px] font-extrabold px-1.5 py-0.2 rounded bg-violet-950 text-violet-300 border border-violet-800/50">
                            × {gift.quantity}
                          </span>
                        </div>
                        <p className="text-[10px] text-neutral-400 mt-0.5 flex items-center space-x-1">
                          <Calendar className="w-3 h-3 text-neutral-500" />
                          <span>{gift.receivedAt}</span>
                        </p>
                      </div>
                    </div>

                    {/* Status Badge: Completed */}
                    <div className="flex-shrink-0">
                      <span className="text-[10px] font-bold text-emerald-400 bg-emerald-950/70 border border-emerald-800/50 px-2.5 py-1 rounded-full flex items-center space-x-1">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                        <span>{gift.status || 'Completed'}</span>
                      </span>
                    </div>
                  </div>

                  {/* 30% Receiver Credit Financial Ledger Card */}
                  <div className="p-2.5 rounded-xl bg-neutral-900/90 border border-neutral-800/80 grid grid-cols-2 gap-2 text-xs">
                    <div className="space-y-0.5">
                      <span className="text-[10px] font-medium text-neutral-400 block">
                        Gift Value (100%)
                      </span>
                      <span className="font-mono font-bold text-amber-300 text-xs">
                        🪙 {giftValue.toLocaleString()} Coins
                      </span>
                    </div>
                    <div className="space-y-0.5 border-l border-neutral-800 pl-2">
                      <span className="text-[10px] font-bold text-emerald-400 block">
                        Receiver Share (30%)
                      </span>
                      <span className="font-mono font-extrabold text-emerald-300 text-xs">
                        +🪙 {receiverShare.toLocaleString()} Coins
                      </span>
                    </div>
                  </div>

                  {/* Audit Verification Footer: Sender ID & Receiver ID */}
                  <div className="flex items-center justify-between text-[10px] text-neutral-400 pt-0.5">
                    <div className="flex items-center space-x-1 min-w-0">
                      <span className="text-neutral-500">Sender ID:</span>
                      <button
                        onClick={() => handleCopy(gift.senderNumericId)}
                        className="font-mono font-semibold text-violet-300 hover:text-white flex items-center space-x-0.5 bg-neutral-900 px-1 py-0.5 rounded border border-neutral-800"
                        title="Click to copy Sender ID"
                      >
                        <span>{gift.senderNumericId}</span>
                        {copiedId === gift.senderNumericId ? (
                          <Check className="w-2.5 h-2.5 text-emerald-400 ml-0.5" />
                        ) : (
                          <Copy className="w-2.5 h-2.5 ml-0.5 text-neutral-500" />
                        )}
                      </button>
                    </div>

                    <div className="flex items-center space-x-1 min-w-0">
                      <span className="text-neutral-500">Receiver ID:</span>
                      <span className="font-mono font-semibold text-neutral-300 bg-neutral-900 px-1 py-0.5 rounded border border-neutral-800">
                        {receiverIdDisplay}
                      </span>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Footer Note */}
        <div className="pt-3 border-t border-neutral-800 text-center flex-shrink-0">
          <p className="text-[10px] text-neutral-500">
            Real gift history recorded by SNYVO Audio Passport
          </p>
        </div>
      </div>
    </div>
  );
};
