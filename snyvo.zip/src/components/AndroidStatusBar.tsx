import React, { useState, useEffect } from 'react';
import { Wifi, Signal, BatteryMedium } from 'lucide-react';

export const AndroidStatusBar: React.FC = () => {
  const [time, setTime] = useState('9:41');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      const hours = now.getHours();
      const minutes = now.getMinutes().toString().padStart(2, '0');
      setTime(`${hours % 12 || 12}:${minutes}`);
    };
    updateTime();
    const interval = setInterval(updateTime, 30000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div id="android-status-bar" className="w-full flex items-center justify-between px-6 pt-3 pb-1 text-xs font-medium text-neutral-300 select-none z-30">
      <div className="flex items-center space-x-1">
        <span className="font-semibold text-[13px] tracking-tight text-white">{time}</span>
      </div>

      {/* Front camera punch hole simulation */}
      <div className="w-3.5 h-3.5 rounded-full bg-black/90 border border-neutral-800 shadow-inner flex items-center justify-center">
        <div className="w-1.5 h-1.5 rounded-full bg-neutral-900"></div>
      </div>

      <div className="flex items-center space-x-2 text-neutral-400">
        <Signal className="w-3.5 h-3.5" />
        <Wifi className="w-3.5 h-3.5" />
        <div className="flex items-center space-x-0.5">
          <span className="text-[10px] font-mono text-neutral-300">92%</span>
          <BatteryMedium className="w-4 h-4 text-emerald-400" />
        </div>
      </div>
    </div>
  );
};
