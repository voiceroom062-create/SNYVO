import React, { useState, useEffect, useRef } from 'react';
import {
  MessageSquare,
  ChevronDown,
  ChevronUp,
  Send,
  Smile,
  MoreHorizontal,
  Trash2,
  VolumeX,
  UserX,
  Flag,
  Shield,
  X,
  Crown,
  Sparkles,
  Mic,
} from 'lucide-react';
import { User, VoiceRoom } from '../../types';
import { RoomChatMessage, ChatRole } from '../../types/chat';
import { chatService } from '../../services/chatService';

interface RoomChatPanelProps {
  room: VoiceRoom;
  currentUser: User;
  currentUserRole: ChatRole;
  isExpanded: boolean;
  onToggleExpand: (expanded: boolean) => void;
  onOpenUserProfile: (user: Partial<User>) => void;
  onToast: (msg: string) => void;
}

// Curated emoji palette for voice room chatter & stage reactions
const POPULAR_EMOJIS = [
  '❤️', '🔥', '👏', '🎉', '🎙️', '✨', '😂', '😍',
  '🤩', '🚀', '💯', '👑', '👍', '🥳', '💬', '🌸',
  '⚡', '🌟', '🙌', '🎵', '🤝', '☕', '💡', '😎'
];

export const RoomChatPanel: React.FC<RoomChatPanelProps> = ({
  room,
  currentUser,
  currentUserRole,
  isExpanded,
  onToggleExpand,
  onOpenUserProfile,
  onToast,
}) => {
  const [messages, setMessages] = useState<RoomChatMessage[]>(() =>
    chatService.getRoomMessages(room.id, room.host)
  );
  const [inputText, setInputText] = useState('');
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const [activeMenuMessageId, setActiveMenuMessageId] = useState<string | null>(null);
  const [reportModalMsg, setReportModalMsg] = useState<RoomChatMessage | null>(null);
  const [reportReason, setReportReason] = useState('Inappropriate language or spam');

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Subscribe to room chat updates
  useEffect(() => {
    const unsub = chatService.subscribeRoomChat(room.id, () => {
      setMessages([...chatService.getRoomMessages(room.id, room.host)]);
    });

    return () => {
      unsub();
    };
  }, [room.id]);

  // Auto-scroll to bottom on new messages
  useEffect(() => {
    if (isExpanded) {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages.length, isExpanded]);

  const handleSendMessage = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!inputText.trim()) return;

    if (chatService.isUserMutedInRoom(room.id, currentUser.id)) {
      onToast('🔒 You are muted in this room chat by the moderator.');
      return;
    }

    try {
      await chatService.sendRoomMessage(room.id, {
        text: inputText.trim(),
        sender: currentUser,
        role: currentUserRole,
      });
      setInputText('');
      setShowEmojiPicker(false);
    } catch (err: any) {
      onToast(`Failed to send message: ${err?.message || err}`);
    }
  };

  const handleInsertEmoji = (emoji: string) => {
    setInputText(prev => prev + emoji);
    inputRef.current?.focus();
  };

  // Moderation Actions
  const handleDeleteMessage = async (msg: RoomChatMessage) => {
    setActiveMenuMessageId(null);
    const success = await chatService.deleteRoomMessage(room.id, msg.id, currentUser.id);
    if (success) {
      onToast('Message removed by moderator');
    }
  };

  const handleMuteUser = (msg: RoomChatMessage) => {
    setActiveMenuMessageId(null);
    chatService.muteUserInRoom(room.id, msg.senderId, currentUser.name);
    onToast(`Muted ${msg.senderName} from sending chat messages in this room`);
  };

  const handleBlockUser = (msg: RoomChatMessage) => {
    setActiveMenuMessageId(null);
    chatService.blockUser(msg.senderId, msg.senderName);
    onToast(`Blocked ${msg.senderName}. You will not see their messages.`);
  };

  const handleSubmitReport = () => {
    if (!reportModalMsg) return;
    chatService.reportUser({
      actorId: currentUser.id,
      actorName: currentUser.name,
      targetUserId: reportModalMsg.senderId,
      targetUserName: reportModalMsg.senderName,
      targetMessageId: reportModalMsg.id,
      reason: reportReason,
      roomId: room.id,
    });
    setReportModalMsg(null);
    onToast(`Report submitted for ${reportModalMsg.senderName}. Moderation team notified.`);
  };

  const isHostOrModerator =
    currentUserRole === 'host' || currentUserRole === 'cohost' || currentUserRole === 'moderator';

  // Latest message for preview in collapsed state
  const latestMessage = messages[messages.length - 1];

  return (
    <div id="snyvo-room-chat-wrapper" className="px-3 sm:px-4 pb-1 relative z-30">
      {isExpanded ? (
        /* ========================================================================= */
        /* 💬 EXPANDED ROOM CHAT PANEL                                               */
        /* ========================================================================= */
        <div
          id="room-chat-expanded-panel"
          className="rounded-2xl bg-neutral-950/95 border border-violet-800/40 shadow-2xl backdrop-blur-xl p-3 flex flex-col h-72 animate-fade-in"
        >
          {/* Header */}
          <div className="flex items-center justify-between pb-2 border-b border-neutral-800/80 flex-shrink-0">
            <div className="flex items-center space-x-2">
              <div className="w-5 h-5 rounded-lg bg-violet-600/20 border border-violet-500/40 flex items-center justify-center text-violet-300">
                <MessageSquare className="w-3 h-3" />
              </div>
              <span className="text-xs font-bold text-white uppercase tracking-wider">Room Chat</span>
              <span className="text-[10px] text-violet-300 bg-violet-950/70 border border-violet-700/50 px-1.5 py-0.2 rounded-full font-semibold">
                {messages.length}
              </span>
            </div>

            <div className="flex items-center space-x-1">
              <button
                id="close-room-chat-panel-btn"
                onClick={() => {
                  onToggleExpand(false);
                  setShowEmojiPicker(false);
                }}
                className="flex items-center space-x-1 text-[11px] text-neutral-400 hover:text-white px-2 py-1 rounded-lg hover:bg-neutral-850 transition-colors cursor-pointer"
                title="Collapse Chat"
              >
                <span>Close</span>
                <ChevronDown className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Messages Scroll Area */}
          <div
            id="room-chat-messages-container"
            className="flex-1 overflow-y-auto py-2.5 space-y-2.5 scrollbar-thin scrollbar-thumb-neutral-800 text-xs"
          >
            {messages.length === 0 ? (
              <div className="py-8 text-center text-neutral-500 space-y-1">
                <MessageSquare className="w-6 h-6 mx-auto text-neutral-700" />
                <p className="text-xs">No messages in this voice room yet.</p>
                <p className="text-[10px] text-neutral-600">Be the first to say hello to the stage!</p>
              </div>
            ) : (
              messages.map((msg) => {
                const isMe = msg.senderId === currentUser.id;
                const isHost = msg.senderRole === 'host';
                const isCoHost = msg.senderRole === 'cohost';
                const isMod = msg.senderRole === 'moderator';
                const isSpeaker = msg.senderRole === 'speaker';

                return (
                  <div
                    key={msg.id}
                    id={`room-chat-msg-${msg.id}`}
                    className="flex items-start space-x-2 group relative"
                  >
                    {/* User Avatar */}
                    <img
                      src={msg.senderAvatar}
                      alt={msg.senderName}
                      onClick={() =>
                        onOpenUserProfile({
                          id: msg.senderId,
                          name: msg.senderName,
                          handle: msg.senderHandle,
                          avatar: msg.senderAvatar,
                          level: msg.senderLevel,
                        })
                      }
                      className="w-7 h-7 rounded-full object-cover mt-0.5 ring-1 ring-violet-500/30 hover:ring-violet-400 cursor-pointer flex-shrink-0 transition-all"
                      title={`View ${msg.senderName}'s Profile`}
                    />

                    {/* Message Bubble Content */}
                    <div
                      className={`flex-1 rounded-2xl px-3 py-2 border transition-all ${
                        msg.isDeleted
                          ? 'bg-neutral-900/40 border-neutral-800 text-neutral-500 italic'
                          : isHost
                          ? 'bg-gradient-to-r from-amber-950/40 via-neutral-900/80 to-neutral-900/80 border-amber-500/40'
                          : isMod
                          ? 'bg-gradient-to-r from-cyan-950/40 via-neutral-900/80 to-neutral-900/80 border-cyan-500/40'
                          : isCoHost
                          ? 'bg-gradient-to-r from-violet-950/40 via-neutral-900/80 to-neutral-900/80 border-violet-500/40'
                          : isSpeaker
                          ? 'bg-gradient-to-r from-emerald-950/30 via-neutral-900/80 to-neutral-900/80 border-emerald-500/30'
                          : isMe
                          ? 'bg-neutral-900/90 border-violet-500/30'
                          : 'bg-neutral-900/80 border-neutral-800/80'
                      }`}
                    >
                      {/* Top row: Name, Role Badges, Level Badge, Time */}
                      <div className="flex items-center justify-between mb-1 gap-1 flex-wrap">
                        <div className="flex items-center space-x-1.5 min-w-0">
                          <span
                            onClick={() =>
                              onOpenUserProfile({
                                id: msg.senderId,
                                name: msg.senderName,
                                handle: msg.senderHandle,
                                avatar: msg.senderAvatar,
                                level: msg.senderLevel,
                              })
                            }
                            className="font-bold text-white text-[11px] truncate cursor-pointer hover:text-violet-300 transition-colors"
                          >
                            {msg.senderName}
                          </span>

                          {/* Host Badge */}
                          {isHost && (
                            <span
                              id={`chat-host-badge-${msg.id}`}
                              className="inline-flex items-center space-x-0.5 text-[8px] font-extrabold px-1.5 py-0.2 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow-xs"
                            >
                              <Crown className="w-2.5 h-2.5 text-amber-300" />
                              <span>Host</span>
                            </span>
                          )}

                          {/* Co-Host Badge */}
                          {isCoHost && (
                            <span
                              id={`chat-cohost-badge-${msg.id}`}
                              className="inline-flex items-center space-x-0.5 text-[8px] font-extrabold px-1.5 py-0.2 rounded-full bg-violet-500/20 text-violet-300 border border-violet-500/40 shadow-xs"
                            >
                              <Shield className="w-2.5 h-2.5 text-violet-300" />
                              <span>Co-Host</span>
                            </span>
                          )}

                          {/* Moderator Badge */}
                          {isMod && (
                            <span
                              id={`chat-mod-badge-${msg.id}`}
                              className="inline-flex items-center space-x-0.5 text-[8px] font-extrabold px-1.5 py-0.2 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-xs"
                            >
                              <Shield className="w-2.5 h-2.5 text-cyan-300" />
                              <span>Mod</span>
                            </span>
                          )}

                          {/* Speaker Badge */}
                          {isSpeaker && (
                            <span
                              id={`chat-speaker-badge-${msg.id}`}
                              className="inline-flex items-center space-x-0.5 text-[8px] font-extrabold px-1.5 py-0.2 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 shadow-xs"
                            >
                              <Mic className="w-2.5 h-2.5 text-emerald-400" />
                              <span>Speaker</span>
                            </span>
                          )}

                          {/* User Level Badge */}
                          {msg.senderLevel && (
                            <span
                              className="text-[8px] font-bold px-1.5 py-0.2 rounded-full bg-neutral-800 text-neutral-300 border border-neutral-700"
                              title={`User Level ${msg.senderLevel}`}
                            >
                              Lv.{msg.senderLevel}
                            </span>
                          )}
                        </div>

                        {/* Right: Time & Moderation Trigger Button */}
                        <div className="flex items-center space-x-1 flex-shrink-0">
                          <span className="text-[9px] text-neutral-400 font-mono">{msg.time}</span>
                          <button
                            id={`chat-msg-actions-btn-${msg.id}`}
                            onClick={() =>
                              setActiveMenuMessageId(
                                activeMenuMessageId === msg.id ? null : msg.id
                              )
                            }
                            className="p-1 text-neutral-400 hover:text-white rounded-md hover:bg-neutral-800 transition-colors cursor-pointer"
                            title="Message actions"
                          >
                            <MoreHorizontal className="w-3 h-3" />
                          </button>
                        </div>
                      </div>

                      {/* Text */}
                      <p className="text-[11px] text-neutral-100 leading-relaxed break-words whitespace-pre-wrap">
                        {msg.text}
                      </p>
                    </div>

                    {/* Moderation Actions Context Menu Popover */}
                    {activeMenuMessageId === msg.id && (
                      <div
                        id={`chat-moderation-menu-${msg.id}`}
                        className="absolute right-2 top-8 z-50 bg-neutral-900 border border-neutral-700/80 rounded-2xl shadow-2xl p-1.5 w-44 space-y-1 animate-fade-in backdrop-blur-xl"
                      >
                        {/* 1. Delete Message (Author or Host/Mod) */}
                        {(isMe || isHostOrModerator) && !msg.isDeleted && (
                          <button
                            id={`chat-action-delete-${msg.id}`}
                            onClick={() => handleDeleteMessage(msg)}
                            className="w-full text-left px-2.5 py-1.5 rounded-xl hover:bg-rose-950/60 text-rose-300 text-[11px] font-medium flex items-center space-x-2 transition-colors cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5 text-rose-400" />
                            <span>Delete Message</span>
                          </button>
                        )}

                        {/* 2. Mute User in Chat (Host/Mod only, not on themselves) */}
                        {isHostOrModerator && !isMe && (
                          <button
                            id={`chat-action-mute-${msg.id}`}
                            onClick={() => handleMuteUser(msg)}
                            className="w-full text-left px-2.5 py-1.5 rounded-xl hover:bg-amber-950/60 text-amber-300 text-[11px] font-medium flex items-center space-x-2 transition-colors cursor-pointer"
                          >
                            <VolumeX className="w-3.5 h-3.5 text-amber-400" />
                            <span>Mute User in Chat</span>
                          </button>
                        )}

                        {/* 3. Block User */}
                        {!isMe && (
                          <button
                            id={`chat-action-block-${msg.id}`}
                            onClick={() => handleBlockUser(msg)}
                            className="w-full text-left px-2.5 py-1.5 rounded-xl hover:bg-neutral-800 text-neutral-300 text-[11px] font-medium flex items-center space-x-2 transition-colors cursor-pointer"
                          >
                            <UserX className="w-3.5 h-3.5 text-neutral-400" />
                            <span>Block User</span>
                          </button>
                        )}

                        {/* 4. Report User */}
                        {!isMe && (
                          <button
                            id={`chat-action-report-${msg.id}`}
                            onClick={() => {
                              setActiveMenuMessageId(null);
                              setReportModalMsg(msg);
                            }}
                            className="w-full text-left px-2.5 py-1.5 rounded-xl hover:bg-neutral-800 text-amber-300 text-[11px] font-medium flex items-center space-x-2 transition-colors cursor-pointer"
                          >
                            <Flag className="w-3.5 h-3.5 text-amber-400" />
                            <span>Report User</span>
                          </button>
                        )}

                        {/* Cancel */}
                        <button
                          onClick={() => setActiveMenuMessageId(null)}
                          className="w-full text-center py-1 text-[10px] text-neutral-400 hover:text-white cursor-pointer"
                        >
                          Close
                        </button>
                      </div>
                    )}
                  </div>
                );
              })
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Emoji Picker Popover */}
          {showEmojiPicker && (
            <div
              id="chat-emoji-picker-panel"
              className="p-2.5 bg-neutral-900 border border-neutral-800 rounded-2xl mb-2 grid grid-cols-8 gap-1.5 shadow-2xl animate-fade-in flex-shrink-0"
            >
              {POPULAR_EMOJIS.map((emoji) => (
                <button
                  key={emoji}
                  type="button"
                  onClick={() => handleInsertEmoji(emoji)}
                  className="w-8 h-8 rounded-xl hover:bg-neutral-800 active:scale-95 flex items-center justify-center text-base cursor-pointer transition-transform"
                  title={`Insert ${emoji}`}
                >
                  {emoji}
                </button>
              ))}
            </div>
          )}

          {/* Bottom Input Field */}
          <form
            id="room-chat-input-form"
            onSubmit={handleSendMessage}
            className="pt-2 border-t border-neutral-800/80 flex items-center space-x-2 flex-shrink-0"
          >
            {/* Emoji Toggle Button */}
            <button
              id="room-chat-emoji-toggle-btn"
              type="button"
              onClick={() => setShowEmojiPicker(!showEmojiPicker)}
              className={`p-2 rounded-xl border transition-all cursor-pointer ${
                showEmojiPicker
                  ? 'bg-amber-500/20 border-amber-500/60 text-amber-300'
                  : 'bg-neutral-900 border-neutral-800 text-neutral-400 hover:text-white hover:bg-neutral-800'
              }`}
              title="Insert Emoji"
            >
              <Smile className="w-4 h-4" />
            </button>

            {/* Message Text Input */}
            <input
              id="room-chat-text-input"
              ref={inputRef}
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder="Send a message to voice room..."
              className="flex-1 bg-neutral-900 border border-neutral-800 rounded-xl px-3 py-2 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-violet-500 transition-colors"
            />

            {/* Send Button */}
            <button
              id="room-chat-send-btn"
              type="submit"
              disabled={!inputText.trim()}
              className={`p-2 rounded-xl text-white transition-all cursor-pointer ${
                inputText.trim()
                  ? 'bg-violet-600 hover:bg-violet-500 shadow-md shadow-violet-600/30 active:scale-95'
                  : 'bg-neutral-900 border border-neutral-800 text-neutral-600 cursor-not-allowed'
              }`}
              title="Send Message"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>
      ) : (
        /* ========================================================================= */
        /* 💬 COLLAPSED FLOATING CHAT STREAM BAR                                     */
        /* ========================================================================= */
        <div
          id="room-chat-collapsed-panel"
          className="rounded-2xl bg-neutral-950/80 hover:bg-neutral-900/90 border border-neutral-850 hover:border-violet-700/50 p-2.5 flex items-center justify-between backdrop-blur-md transition-all shadow-md cursor-pointer"
          onClick={() => onToggleExpand(true)}
        >
          <div className="flex items-center space-x-2.5 min-w-0 flex-1">
            <div className="w-7 h-7 rounded-xl bg-violet-600/20 border border-violet-500/40 flex items-center justify-center text-violet-300 flex-shrink-0">
              <MessageSquare className="w-3.5 h-3.5" />
            </div>

            <div className="min-w-0 flex-1">
              {latestMessage ? (
                <p className="text-xs text-neutral-300 truncate">
                  <span className="font-bold text-white mr-1.5">
                    {latestMessage.senderName}:
                  </span>
                  <span className="text-neutral-200">{latestMessage.text}</span>
                </p>
              ) : (
                <p className="text-xs text-neutral-400 italic">No messages yet. Tap to open chat...</p>
              )}
            </div>
          </div>

          <button
            id="expand-chat-panel-btn"
            onClick={(e) => {
              e.stopPropagation();
              onToggleExpand(true);
            }}
            className="ml-2 px-2.5 py-1 rounded-xl bg-violet-600/20 hover:bg-violet-600/30 text-violet-300 border border-violet-500/40 text-[11px] font-bold flex items-center space-x-1 flex-shrink-0 cursor-pointer transition-colors"
          >
            <span>Chat</span>
            <ChevronUp className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 🚩 MODERATION REPORT MODAL (UI preparation for report action)             */}
      {/* ========================================================================= */}
      {reportModalMsg && (
        <div
          id="chat-report-modal"
          className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fade-in"
          onClick={() => setReportModalMsg(null)}
        >
          <div
            className="bg-neutral-900 border border-neutral-800 rounded-3xl p-5 max-w-sm w-full space-y-4 shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-3 border-b border-neutral-800">
              <div className="flex items-center space-x-2 text-amber-300">
                <Flag className="w-4 h-4 text-amber-400" />
                <h3 className="text-sm font-bold text-white">Report User</h3>
              </div>
              <button
                onClick={() => setReportModalMsg(null)}
                className="p-1 text-neutral-400 hover:text-white rounded-full hover:bg-neutral-800"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-3 bg-neutral-950/70 border border-neutral-800/80 rounded-2xl space-y-1">
              <span className="text-[10px] text-neutral-400 uppercase font-semibold">Reporting:</span>
              <p className="text-xs font-bold text-white">{reportModalMsg.senderName}</p>
              <p className="text-[11px] text-neutral-300 italic line-clamp-2">
                &ldquo;{reportModalMsg.text}&rdquo;
              </p>
            </div>

            <div className="space-y-2">
              <label className="text-xs text-neutral-400 font-medium">Select Violation Reason:</label>
              <div className="space-y-1.5">
                {[
                  'Inappropriate language or spam',
                  'Harassment or hate speech',
                  'Disrupting voice room etiquette',
                  'Suspicious link or advertising'
                ].map((reason) => (
                  <label
                    key={reason}
                    className={`flex items-center space-x-2.5 p-2 rounded-xl border text-xs cursor-pointer transition-colors ${
                      reportReason === reason
                        ? 'bg-violet-950/40 border-violet-500 text-violet-200'
                        : 'bg-neutral-950/50 border-neutral-800 text-neutral-400 hover:bg-neutral-800/60'
                    }`}
                  >
                    <input
                      type="radio"
                      name="reportReason"
                      checked={reportReason === reason}
                      onChange={() => setReportReason(reason)}
                      className="text-violet-600 focus:ring-0"
                    />
                    <span>{reason}</span>
                  </label>
                ))}
              </div>
            </div>

            <div className="pt-2 flex items-center space-x-2">
              <button
                type="button"
                onClick={() => setReportModalMsg(null)}
                className="flex-1 py-2.5 rounded-xl bg-neutral-800 hover:bg-neutral-750 text-neutral-300 text-xs font-semibold cursor-pointer"
              >
                Cancel
              </button>
              <button
                id="submit-user-report-btn"
                type="button"
                onClick={handleSubmitReport}
                className="flex-1 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-500 text-white text-xs font-bold shadow-md shadow-amber-600/30 cursor-pointer transition-all"
              >
                Submit Report
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
