import React, { useState } from 'react';
import { ChevronLeft, UserX, ShieldCheck, Check } from 'lucide-react';
import { User } from '../../types';
import { settingsService, BlockedUser, UserSettings } from '../../services/settingsService';

interface BlockedListPageProps {
  currentUser: User;
  settings: UserSettings;
  onBack: () => void;
  onUpdateSettings: (updated: UserSettings) => void;
  onToast: (msg: string) => void;
}

export const BlockedListPage: React.FC<BlockedListPageProps> = ({
  currentUser,
  settings,
  onBack,
  onUpdateSettings,
  onToast,
}) => {
  const [blockedUsers, setBlockedUsers] = useState<BlockedUser[]>(settings.blockedUsers || []);

  const handleUnblock = (userIdToUnblock: string, nickname: string) => {
    const updatedList = settingsService.unblockUser(currentUser.id, userIdToUnblock);
    setBlockedUsers(updatedList);
    onUpdateSettings({
      ...settings,
      blockedUsers: updatedList,
    });
    onToast(`Unblocked ${nickname}`);
  };

  return (
    <div className="flex flex-col h-full bg-neutral-950 text-white animate-fadeIn">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3.5 bg-neutral-900/90 border-b border-neutral-800">
        <button
          type="button"
          onClick={onBack}
          className="flex items-center space-x-1.5 text-neutral-400 hover:text-white transition-colors cursor-pointer py-1"
        >
          <ChevronLeft className="w-5 h-5" />
          <span className="text-xs font-semibold">Settings</span>
        </button>
        <h3 className="text-sm font-black text-white tracking-wide">Blocked List</h3>
        <div className="w-8" />
      </div>

      {/* Body */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 max-w-md mx-auto w-full">
        <div className="p-3 bg-neutral-900/80 rounded-2xl border border-neutral-800 flex items-center space-x-2 text-xs text-neutral-400">
          <ShieldCheck className="w-4 h-4 text-emerald-400 flex-shrink-0" />
          <span>Blocked members cannot enter your voice stage seats or send private messages.</span>
        </div>

        {blockedUsers.length === 0 ? (
          <div className="p-8 text-center bg-neutral-900/50 rounded-3xl border border-neutral-800/80 space-y-2">
            <UserX className="w-10 h-10 text-neutral-600 mx-auto" />
            <h4 className="text-sm font-bold text-neutral-300">No Blocked Users</h4>
            <p className="text-xs text-neutral-500">
              Your blocked list is currently empty.
            </p>
          </div>
        ) : (
          <div className="bg-white text-neutral-900 rounded-3xl shadow-xl border border-neutral-100 divide-y divide-neutral-100 overflow-hidden">
            {blockedUsers.map((u) => (
              <div
                key={u.id}
                className="flex items-center justify-between px-4 py-3.5 hover:bg-neutral-50 transition-colors"
              >
                <div className="flex items-center space-x-3 min-w-0">
                  <img
                    src={u.avatar}
                    alt={u.name}
                    className="w-10 h-10 rounded-full object-cover border border-neutral-200"
                  />
                  <div className="min-w-0">
                    <span className="text-sm font-bold text-neutral-900 block truncate">
                      {u.name}
                    </span>
                    <span className="text-[11px] text-neutral-400 font-mono block">
                      ID: {u.numericId} ({u.handle})
                    </span>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => handleUnblock(u.id, u.name)}
                  className="px-3 py-1.5 rounded-xl bg-neutral-100 hover:bg-rose-50 text-neutral-700 hover:text-rose-600 text-xs font-bold transition-colors cursor-pointer border border-neutral-200"
                >
                  Unblock
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
