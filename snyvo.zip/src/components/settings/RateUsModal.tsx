import React, { useState } from 'react';
import { X, Star, Sparkles, Heart } from 'lucide-react';
import { User } from '../../types';
import { settingsService, APP_VERSION } from '../../services/settingsService';

interface RateUsModalProps {
  currentUser: User;
  onClose: () => void;
  onToast: (msg: string) => void;
}

export const RateUsModal: React.FC<RateUsModalProps> = ({ currentUser, onClose, onToast }) => {
  const [selectedRating, setSelectedRating] = useState<number>(5);
  const [hoverRating, setHoverRating] = useState<number | null>(null);
  const [feedback, setFeedback] = useState<string>('');
  const [submitted, setSubmitted] = useState<boolean>(false);

  const ratingDescriptions: Record<number, string> = {
    1: 'Needs Improvement 😕',
    2: 'Could Be Better 😐',
    3: 'Good Experience 🙂',
    4: 'Great App! 😃',
    5: 'Exceptional & Loving it! 🌟',
  };

  const handleRate = () => {
    settingsService.saveUserRating(currentUser.id, selectedRating, feedback);
    setSubmitted(true);
    onToast('Thank you for rating SNYVO! ⭐');
    setTimeout(() => {
      onClose();
    }, 1400);
  };

  const activeRating = hoverRating || selectedRating;

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 animate-fadeIn">
      <div
        className="w-full max-w-sm bg-neutral-900 border border-neutral-800 rounded-3xl p-5 shadow-2xl space-y-4 text-center text-white relative"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close button */}
        <button
          type="button"
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 rounded-full text-neutral-400 hover:text-white bg-neutral-800 hover:bg-neutral-700 transition-colors"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Brand Icon & Dynamic Version */}
        <div className="space-y-1.5 pt-2">
          <div className="w-14 h-14 mx-auto rounded-2xl bg-gradient-to-tr from-violet-600 via-purple-600 to-indigo-600 flex items-center justify-center shadow-xl ring-4 ring-violet-500/20">
            <Sparkles className="w-7 h-7 text-white" />
          </div>
          <h3 className="text-base font-black tracking-tight">SNYVO</h3>
          <div className="inline-block px-2.5 py-0.5 rounded-full bg-neutral-800 border border-neutral-700/60 text-[10px] font-mono text-violet-300">
            Current App Version: {APP_VERSION}
          </div>
        </div>

        {submitted ? (
          <div className="py-6 space-y-2">
            <Heart className="w-10 h-10 text-rose-500 fill-rose-500 mx-auto animate-bounce" />
            <h4 className="text-sm font-bold text-white">Feedback Submitted!</h4>
            <p className="text-xs text-neutral-400">
              Your rating helps us bring you better voice club experiences.
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            <div>
              <p className="text-xs font-bold text-neutral-300">How do you like SNYVO?</p>
              {/* Interactive Stars */}
              <div className="flex items-center justify-center space-x-2 mt-2.5">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    key={star}
                    type="button"
                    onMouseEnter={() => setHoverRating(star)}
                    onMouseLeave={() => setHoverRating(null)}
                    onClick={() => setSelectedRating(star)}
                    className="p-1 transition-transform hover:scale-125 cursor-pointer focus:outline-none"
                  >
                    <Star
                      className={`w-7 h-7 transition-colors ${
                        star <= activeRating
                          ? 'text-amber-400 fill-amber-400 drop-shadow-md'
                          : 'text-neutral-700'
                      }`}
                    />
                  </button>
                ))}
              </div>
              <div className="text-[11px] font-bold text-amber-400 mt-1 min-h-[16px]">
                {ratingDescriptions[activeRating]}
              </div>
            </div>

            {/* Optional feedback text */}
            <textarea
              value={feedback}
              onChange={(e) => setFeedback(e.target.value)}
              placeholder="Tell us what you love or what we should add... (Optional)"
              rows={2}
              className="w-full px-3 py-2 bg-neutral-950 border border-neutral-800 rounded-xl text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-violet-500 resize-none"
            />

            {/* Submit Button */}
            <button
              type="button"
              onClick={handleRate}
              className="w-full py-3 rounded-2xl bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-500 hover:to-indigo-500 text-white font-bold text-xs shadow-lg shadow-violet-600/20 transition-all cursor-pointer active:scale-98"
            >
              Rate SNYVO
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
