import React from 'react';
import { ChevronLeft, ShieldAlert, FileText, CheckCircle2 } from 'lucide-react';

interface PlatformPolicyPageProps {
  onBack: () => void;
}

export const PlatformPolicyPage: React.FC<PlatformPolicyPageProps> = ({ onBack }) => {
  return (
    <div className="flex flex-col h-full bg-neutral-950 text-white animate-fadeIn">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3.5 bg-neutral-900/90 border-b border-neutral-800">
        <button
          type="button"
          onClick={onBack}
          className="flex items-center space-x-1.5 text-neutral-400 hover:text-white transition-colors cursor-pointer py-1"
        >
          <ChevronLeft className="w-5 h-5" />
          <span className="text-xs font-semibold">Settings</span>
        </button>
        <h3 className="text-sm font-black text-white tracking-wide">Platform Policy</h3>
        <div className="w-8" />
      </div>

      {/* Body */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 max-w-md mx-auto w-full text-xs text-neutral-300 leading-relaxed">
        {/* Intro Card */}
        <div className="p-4 bg-neutral-900/90 rounded-3xl border border-neutral-800 space-y-2">
          <div className="flex items-center space-x-2 text-violet-400 font-bold">
            <FileText className="w-4 h-4" />
            <span>Official SNYVO Terms of Service & Code of Conduct</span>
          </div>
          <p className="text-[11px] text-neutral-400">
            Last Updated: September 2026. These regulations govern live voice streaming, virtual coin distribution, social etiquette, and account safeguards on SNYVO.
          </p>
        </div>

        {/* Policy Sections */}
        <div className="space-y-4 bg-neutral-900/60 p-4 rounded-3xl border border-neutral-800/80">
          <div>
            <h4 className="font-bold text-white text-sm mb-1.5 flex items-center space-x-1.5">
              <span className="text-violet-400">1.</span>
              <span>Live Voice Room Code of Conduct</span>
            </h4>
            <p className="text-[11px] text-neutral-400">
              SNYVO is dedicated to safe, vibrant, and welcoming social audio stages. Verbal abuse, hate speech, explicit sexual content, defamatory rhetoric, and harassment of speakers or listeners are strictly prohibited and result in immediate microphone revocation or room ban.
            </p>
          </div>

          <div className="pt-3 border-t border-neutral-800">
            <h4 className="font-bold text-white text-sm mb-1.5 flex items-center space-x-1.5">
              <span className="text-amber-400">2.</span>
              <span>Virtual Coins, Gifting & VIP Privileges</span>
            </h4>
            <p className="text-[11px] text-neutral-400">
              Coins purchased via verified payment methods (bKash, Nagad, or authorized channels) are virtual goods used for interactive gifting, VIP upgrades, and room gamification. Virtual gifts credit a 30% receiver coin bonus directly to the performer’s ID balance. Coins carry no legal tender value outside the SNYVO ecosystem.
            </p>
          </div>

          <div className="pt-3 border-t border-neutral-800">
            <h4 className="font-bold text-white text-sm mb-1.5 flex items-center space-x-1.5">
              <span className="text-emerald-400">3.</span>
              <span>User Safety, Anti-Harassment & Minor Protection</span>
            </h4>
            <p className="text-[11px] text-neutral-400">
              Users must be at least 13 years of age. Exploitation of minors, impersonation of community moderators, unauthorized automated scripts, and deceptive spam broadcasts violate platform integrity.
            </p>
          </div>

          <div className="pt-3 border-t border-neutral-800">
            <h4 className="font-bold text-white text-sm mb-1.5 flex items-center space-x-1.5">
              <span className="text-rose-400">4.</span>
              <span>Data Retention & 30-Day Deletion Grace Period</span>
            </h4>
            <p className="text-[11px] text-neutral-400">
              SNYVO respects your digital rights. When you request account deletion, a 30-day grace period is initiated. During this 30-day window, you may cancel deletion at any time by logging in. If not cancelled within 30 days, your account profile, recordings, and balances are permanently purged.
            </p>
          </div>

          <div className="pt-3 border-t border-neutral-800">
            <h4 className="font-bold text-white text-sm mb-1.5 flex items-center space-x-1.5">
              <span className="text-cyan-400">5.</span>
              <span>Fair Play in Interactive Games</span>
            </h4>
            <p className="text-[11px] text-neutral-400">
              Mini-games (Ludo, Snake & Ladder, Domino, Voice Trivia) utilize certified cryptographic randomizers. Tampering or collusion to manipulate coin payouts is strictly forbidden.
            </p>
          </div>
        </div>

        <div className="p-3 rounded-2xl bg-neutral-900 border border-neutral-800 text-center text-[10px] text-neutral-500">
          SNYVO Social Voice Club © 2026. All rights reserved.
        </div>
      </div>
    </div>
  );
};
