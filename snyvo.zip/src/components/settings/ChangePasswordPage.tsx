import React, { useState } from 'react';
import { ChevronLeft, Lock, Eye, EyeOff, CheckCircle2, AlertCircle } from 'lucide-react';
import { User } from '../../types';
import { settingsService } from '../../services/settingsService';

interface ChangePasswordPageProps {
  currentUser: User;
  onBack: () => void;
  onToast: (msg: string) => void;
}

export const ChangePasswordPage: React.FC<ChangePasswordPageProps> = ({
  currentUser,
  onBack,
  onToast,
}) => {
  const hasCustom = settingsService.hasCustomPassword(currentUser.id);

  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');

  const [showCurrent, setShowCurrent] = useState(false);
  const [showNew, setShowNew] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);

  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (hasCustom) {
      if (!currentPassword) {
        setError('Please enter your current password');
        return;
      }
      if (!settingsService.verifyPassword(currentUser.id, currentPassword)) {
        setError('Current password is incorrect. (Default demo pass: 123456)');
        return;
      }
    }

    if (!newPassword || newPassword.length < 6) {
      setError('New password must be at least 6 characters');
      return;
    }

    if (newPassword !== confirmPassword) {
      setError('New password and confirmation do not match');
      return;
    }

    // Save
    settingsService.changePassword(currentUser.id, newPassword);
    setSuccess(true);
    onToast('Password changed successfully!');
    setTimeout(() => {
      onBack();
    }, 1200);
  };

  return (
    <div className="flex flex-col h-full bg-neutral-950 text-white animate-fadeIn">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3.5 bg-neutral-900/90 border-b border-neutral-800">
        <button
          type="button"
          onClick={onBack}
          className="flex items-center space-x-1.5 text-neutral-400 hover:text-white transition-colors cursor-pointer py-1"
        >
          <ChevronLeft className="w-5 h-5" />
          <span className="text-xs font-semibold">Settings</span>
        </button>
        <h3 className="text-sm font-black text-white tracking-wide">Change Password</h3>
        <div className="w-8" />
      </div>

      {/* Body */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 max-w-md mx-auto w-full">
        <div className="p-4 bg-neutral-900/90 rounded-3xl border border-neutral-800 space-y-4">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-500/10 text-amber-400 flex items-center justify-center">
              <Lock className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-white">
                {hasCustom ? 'Update Password' : 'Create Account Password'}
              </h4>
              <p className="text-[11px] text-neutral-400">
                {hasCustom
                  ? 'Keep your account secure with a strong password'
                  : 'Your account was linked with social login. You can set a password here.'}
              </p>
            </div>
          </div>

          {error && (
            <div className="p-3 rounded-xl bg-rose-950/40 border border-rose-800/60 text-rose-300 text-xs flex items-center space-x-2">
              <AlertCircle className="w-4 h-4 flex-shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {success && (
            <div className="p-3 rounded-xl bg-emerald-950/40 border border-emerald-800/60 text-emerald-300 text-xs flex items-center space-x-2">
              <CheckCircle2 className="w-4 h-4 flex-shrink-0" />
              <span>Password updated securely! Redirecting...</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-3.5 text-xs">
            {hasCustom && (
              <div>
                <label className="block text-[10px] font-bold uppercase text-neutral-400 mb-1">
                  Current Password
                </label>
                <div className="relative">
                  <input
                    type={showCurrent ? 'text' : 'password'}
                    value={currentPassword}
                    onChange={(e) => setCurrentPassword(e.target.value)}
                    placeholder="Enter current password"
                    className="w-full px-3 py-2.5 bg-neutral-950 border border-neutral-800 rounded-xl text-white focus:outline-none focus:border-amber-500 pr-10"
                  />
                  <button
                    type="button"
                    onClick={() => setShowCurrent(!showCurrent)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-neutral-500 hover:text-neutral-300"
                  >
                    {showCurrent ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>
            )}

            <div>
              <label className="block text-[10px] font-bold uppercase text-neutral-400 mb-1">
                New Password
              </label>
              <div className="relative">
                <input
                  type={showNew ? 'text' : 'password'}
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  placeholder="Min. 6 characters"
                  className="w-full px-3 py-2.5 bg-neutral-950 border border-neutral-800 rounded-xl text-white focus:outline-none focus:border-amber-500 pr-10"
                />
                <button
                  type="button"
                  onClick={() => setShowNew(!showNew)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-neutral-500 hover:text-neutral-300"
                >
                  {showNew ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <div>
              <label className="block text-[10px] font-bold uppercase text-neutral-400 mb-1">
                Confirm New Password
              </label>
              <div className="relative">
                <input
                  type={showConfirm ? 'text' : 'password'}
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="Re-enter new password"
                  className="w-full px-3 py-2.5 bg-neutral-950 border border-neutral-800 rounded-xl text-white focus:outline-none focus:border-amber-500 pr-10"
                />
                <button
                  type="button"
                  onClick={() => setShowConfirm(!showConfirm)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-neutral-500 hover:text-neutral-300"
                >
                  {showConfirm ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-3 rounded-2xl bg-amber-500 hover:bg-amber-400 text-neutral-950 font-bold text-xs shadow-lg transition-colors cursor-pointer mt-2"
            >
              Change Password
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
