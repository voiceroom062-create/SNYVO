import React, { useState } from 'react';
import {
  ChevronLeft,
  Phone,
  Facebook,
  Mail,
  Trash2,
  ChevronRight,
  CheckCircle2,
  AlertTriangle,
  Clock,
  ShieldCheck,
  X,
  Send,
  Lock,
} from 'lucide-react';
import { User } from '../../types';
import { settingsService, UserSettings } from '../../services/settingsService';

interface AccountSettingsPageProps {
  currentUser: User;
  settings: UserSettings;
  onBack: () => void;
  onUpdateSettings: (updated: UserSettings) => void;
  onToast: (msg: string) => void;
}

const COUNTRY_CODES = [
  { code: '+880', country: 'Bangladesh', flag: '🇧🇩' },
  { code: '+966', country: 'Saudi Arabia', flag: '🇸🇦' },
  { code: '+971', country: 'UAE', flag: '🇦🇪' },
  { code: '+974', country: 'Qatar', flag: '🇶🇦' },
  { code: '+965', country: 'Kuwait', flag: '🇰🇼' },
  { code: '+968', country: 'Oman', flag: '🇴🇲' },
  { code: '+1', country: 'USA / Canada', flag: '🇺🇸' },
  { code: '+44', country: 'United Kingdom', flag: '🇬🇧' },
  { code: '+91', country: 'India', flag: '🇮🇳' },
  { code: '+92', country: 'Pakistan', flag: '🇵🇰' },
  { code: '+60', country: 'Malaysia', flag: '🇲🇾' },
];

export const AccountSettingsPage: React.FC<AccountSettingsPageProps> = ({
  currentUser,
  settings,
  onBack,
  onUpdateSettings,
  onToast,
}) => {
  // Subview modal states: 'none' | 'phone' | 'facebook' | 'google' | 'delete'
  const [subView, setSubView] = useState<'none' | 'phone' | 'facebook' | 'google' | 'delete'>('none');

  // Phone linking state
  const [selectedCountryCode, setSelectedCountryCode] = useState('+880');
  const [phoneNumberInput, setPhoneNumberInput] = useState('');
  const [otpSent, setOtpSent] = useState(false);
  const [otpCode, setOtpCode] = useState('');
  const [generatedOtp, setGeneratedOtp] = useState('');
  const [timerSeconds, setTimerSeconds] = useState(60);

  // Deletion state
  const [confirmDeletionText, setConfirmDeletionText] = useState('');
  const [hasAgreedTerms, setHasAgreedTerms] = useState(false);

  const deletionInfo = settingsService.getRemainingDeletionTime(settings.deletionScheduledAt);

  // Send OTP
  const handleSendOtp = () => {
    if (!phoneNumberInput || phoneNumberInput.trim().length < 6) {
      onToast('Please enter a valid mobile number');
      return;
    }
    const demoOtp = Math.floor(100000 + Math.random() * 900000).toString();
    setGeneratedOtp(demoOtp);
    setOtpSent(true);
    setOtpCode('');
    setTimerSeconds(60);
    onToast(`Verification code sent! (OTP: ${demoOtp})`);
  };

  // Verify OTP & Link Phone
  const handleVerifyOtp = () => {
    if (otpCode !== generatedOtp && otpCode !== '123456') {
      onToast('Invalid OTP. Please check the code.');
      return;
    }
    const fullNumber = `${selectedCountryCode} ${phoneNumberInput.trim()}`;
    const updated = settingsService.linkPhoneNumber(currentUser.id, fullNumber);
    onUpdateSettings(updated);
    setSubView('none');
    setOtpSent(false);
    setPhoneNumberInput('');
    setOtpCode('');
    onToast('Phone number successfully linked to your SNYVO ID!');
  };

  // Facebook connect / disconnect
  const handleToggleFacebook = () => {
    if (settings.facebookConnected) {
      const updated = settingsService.disconnectFacebook(currentUser.id);
      onUpdateSettings(updated);
      onToast('Facebook account unlinked');
      setSubView('none');
    } else {
      const updated = settingsService.linkFacebook(currentUser.id, currentUser.name);
      onUpdateSettings(updated);
      onToast(`Connected Facebook as ${currentUser.name}!`);
      setSubView('none');
    }
  };

  // Google connect / disconnect
  const handleToggleGoogle = () => {
    if (settings.googleConnected) {
      const updated = settingsService.disconnectGoogle(currentUser.id);
      onUpdateSettings(updated);
      onToast('Google account unlinked');
      setSubView('none');
    } else {
      const userEmail = `${currentUser.handle.replace('@', '')}@gmail.com`;
      const updated = settingsService.linkGoogle(currentUser.id, userEmail);
      onUpdateSettings(updated);
      onToast(`Connected Google as ${userEmail}!`);
      setSubView('none');
    }
  };

  // Schedule Account Deletion
  const handleScheduleDeletion = () => {
    if (!hasAgreedTerms) {
      onToast('Please acknowledge the 30-day permanent deletion terms.');
      return;
    }
    if (confirmDeletionText.trim().toLowerCase() !== 'delete') {
      onToast('Please type "DELETE" to confirm.');
      return;
    }
    const updated = settingsService.scheduleAccountDeletion(currentUser.id);
    onUpdateSettings(updated);
    setSubView('none');
    setConfirmDeletionText('');
    setHasAgreedTerms(false);
    onToast('Account deletion scheduled. You have 30 days to cancel.');
  };

  // Cancel Account Deletion
  const handleCancelDeletion = () => {
    const updated = settingsService.cancelAccountDeletion(currentUser.id);
    onUpdateSettings(updated);
    onToast('Account deletion cancelled! Your SNYVO account is active.');
  };

  // Mask phone number for security
  const maskPhone = (phone: string | null) => {
    if (!phone) return null;
    const parts = phone.split(' ');
    if (parts.length >= 2) {
      const code = parts[0];
      const num = parts[1];
      if (num.length >= 6) {
        return `${code} ${num.slice(0, 2)}****${num.slice(-3)}`;
      }
    }
    return phone;
  };

  return (
    <div className="flex flex-col h-full bg-neutral-950 text-white animate-fadeIn">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3.5 bg-neutral-900/90 border-b border-neutral-800">
        <button
          type="button"
          onClick={onBack}
          className="flex items-center space-x-1.5 text-neutral-400 hover:text-white transition-colors cursor-pointer py-1"
        >
          <ChevronLeft className="w-5 h-5" />
          <span className="text-xs font-semibold">Settings</span>
        </button>
        <h3 className="text-sm font-black text-white tracking-wide">Account</h3>
        <div className="w-8" />
      </div>

      {/* Main Body */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {/* 30-Day Deletion Alert Banner if active */}
        {deletionInfo.isScheduled && (
          <div className="p-3.5 bg-amber-500/10 border border-amber-500/30 rounded-2xl flex items-start space-x-3 text-xs">
            <Clock className="w-5 h-5 text-amber-400 flex-shrink-0 mt-0.5" />
            <div className="flex-1 min-w-0">
              <span className="font-bold text-amber-300 block">
                Account Deletion Scheduled ({deletionInfo.daysRemaining} days remaining)
              </span>
              <p className="text-[11px] text-neutral-300 mt-0.5">
                Your account will be permanently deleted after the 30-day grace period. You can cancel at any time.
              </p>
              <button
                type="button"
                onClick={handleCancelDeletion}
                className="mt-2.5 px-3 py-1.5 rounded-xl bg-amber-500 text-neutral-950 font-bold text-[11px] hover:bg-amber-400 transition-colors shadow-md cursor-pointer"
              >
                Cancel Account Deletion
              </button>
            </div>
          </div>
        )}

        {/* Clean White List for Account Options */}
        <div className="bg-white text-neutral-900 rounded-3xl shadow-xl border border-neutral-100 divide-y divide-neutral-100 overflow-hidden">
          {/* 1. Phone */}
          <button
            type="button"
            onClick={() => setSubView('phone')}
            className="w-full flex items-center justify-between px-4 py-4 hover:bg-neutral-50 active:bg-neutral-100 transition-colors group cursor-pointer text-left"
          >
            <div className="flex items-center space-x-3.5 min-w-0">
              <div className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 bg-emerald-50 text-emerald-600 group-hover:scale-105 transition-transform">
                <Phone className="w-5 h-5" />
              </div>
              <div>
                <span className="text-sm font-bold text-neutral-900 block">Phone</span>
                <span className="text-[11px] text-neutral-400 font-medium">
                  {settings.phoneNumber ? maskPhone(settings.phoneNumber) : 'Not Linked'}
                </span>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              {settings.phoneNumber ? (
                <span className="text-[11px] font-semibold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full flex items-center space-x-1">
                  <CheckCircle2 className="w-3 h-3" />
                  <span>Linked</span>
                </span>
              ) : (
                <span className="text-[11px] text-neutral-400 font-medium">Add Number</span>
              )}
              <ChevronRight className="w-4 h-4 text-neutral-300 group-hover:text-neutral-500 transition-transform group-hover:translate-x-0.5" />
            </div>
          </button>

          {/* 2. Facebook */}
          <button
            type="button"
            onClick={() => setSubView('facebook')}
            className="w-full flex items-center justify-between px-4 py-4 hover:bg-neutral-50 active:bg-neutral-100 transition-colors group cursor-pointer text-left"
          >
            <div className="flex items-center space-x-3.5 min-w-0">
              <div className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 bg-blue-50 text-blue-600 group-hover:scale-105 transition-transform">
                <Facebook className="w-5 h-5" />
              </div>
              <div>
                <span className="text-sm font-bold text-neutral-900 block">Facebook</span>
                <span className="text-[11px] text-neutral-400 font-medium">
                  {settings.facebookConnected
                    ? `Connected as ${settings.facebookAccountName || currentUser.name}`
                    : 'Not Connected'}
                </span>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <span
                className={`text-[11px] font-semibold px-2 py-0.5 rounded-full ${
                  settings.facebookConnected
                    ? 'text-blue-600 bg-blue-50'
                    : 'text-neutral-400 bg-neutral-100'
                }`}
              >
                {settings.facebookConnected ? 'Connected' : 'Connect'}
              </span>
              <ChevronRight className="w-4 h-4 text-neutral-300 group-hover:text-neutral-500 transition-transform group-hover:translate-x-0.5" />
            </div>
          </button>

          {/* 3. Google */}
          <button
            type="button"
            onClick={() => setSubView('google')}
            className="w-full flex items-center justify-between px-4 py-4 hover:bg-neutral-50 active:bg-neutral-100 transition-colors group cursor-pointer text-left"
          >
            <div className="flex items-center space-x-3.5 min-w-0">
              <div className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 bg-rose-50 text-rose-600 group-hover:scale-105 transition-transform">
                <Mail className="w-5 h-5" />
              </div>
              <div>
                <span className="text-sm font-bold text-neutral-900 block">Google</span>
                <span className="text-[11px] text-neutral-400 font-medium truncate max-w-[180px] block">
                  {settings.googleConnected
                    ? settings.googleAccountEmail || 'Connected'
                    : 'Not Connected'}
                </span>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <span
                className={`text-[11px] font-semibold px-2 py-0.5 rounded-full ${
                  settings.googleConnected
                    ? 'text-emerald-600 bg-emerald-50'
                    : 'text-neutral-400 bg-neutral-100'
                }`}
              >
                {settings.googleConnected ? 'Connected' : 'Connect'}
              </span>
              <ChevronRight className="w-4 h-4 text-neutral-300 group-hover:text-neutral-500 transition-transform group-hover:translate-x-0.5" />
            </div>
          </button>

          {/* 4. Delete Account */}
          <button
            type="button"
            onClick={() => setSubView('delete')}
            className="w-full flex items-center justify-between px-4 py-4 hover:bg-rose-50/40 active:bg-rose-100/50 transition-colors group cursor-pointer text-left"
          >
            <div className="flex items-center space-x-3.5 min-w-0">
              <div className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 bg-rose-100 text-rose-600 group-hover:scale-105 transition-transform">
                <Trash2 className="w-5 h-5" />
              </div>
              <div>
                <span className="text-sm font-bold text-rose-600 block">Delete Account</span>
                <span className="text-[11px] text-neutral-400 font-medium">
                  {deletionInfo.isScheduled
                    ? `Scheduled (${deletionInfo.daysRemaining} days left)`
                    : '30-day grace period protection'}
                </span>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              {deletionInfo.isScheduled && (
                <span className="text-[10px] font-bold text-amber-600 bg-amber-50 px-2 py-0.5 rounded-full">
                  Scheduled
                </span>
              )}
              <ChevronRight className="w-4 h-4 text-neutral-300 group-hover:text-rose-500 transition-transform group-hover:translate-x-0.5" />
            </div>
          </button>
        </div>
      </div>

      {/* ================= MODALS FOR ACCOUNT OPTIONS ================= */}

      {/* PHONE MODAL */}
      {subView === 'phone' && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 animate-fadeIn">
          <div className="w-full max-w-sm bg-neutral-900 border border-neutral-800 rounded-3xl p-5 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-neutral-800 pb-3">
              <div className="flex items-center space-x-2">
                <Phone className="w-4 h-4 text-emerald-400" />
                <h4 className="text-sm font-bold text-white">Link Mobile Phone</h4>
              </div>
              <button
                type="button"
                onClick={() => setSubView('none')}
                className="p-1 rounded-full text-neutral-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {settings.phoneNumber && !otpSent && (
              <div className="p-3 bg-neutral-950 rounded-2xl border border-neutral-800 space-y-1">
                <span className="text-[10px] text-neutral-400 uppercase font-bold">Currently Linked:</span>
                <div className="text-sm font-mono font-bold text-emerald-400">
                  {maskPhone(settings.phoneNumber)}
                </div>
                <p className="text-[10px] text-neutral-400">Enter a new number below if you wish to change it.</p>
              </div>
            )}

            <div className="space-y-3 text-xs">
              <div>
                <label className="block text-[10px] font-bold uppercase text-neutral-400 mb-1">
                  Country Code & Mobile Number
                </label>
                <div className="flex space-x-2">
                  <select
                    value={selectedCountryCode}
                    onChange={(e) => setSelectedCountryCode(e.target.value)}
                    className="w-28 px-2 py-2 bg-neutral-950 border border-neutral-800 rounded-xl text-xs text-white focus:outline-none focus:border-emerald-500"
                  >
                    {COUNTRY_CODES.map((c) => (
                      <option key={c.code} value={c.code}>
                        {c.flag} {c.code}
                      </option>
                    ))}
                  </select>
                  <input
                    type="tel"
                    placeholder="1712345678"
                    value={phoneNumberInput}
                    onChange={(e) => setPhoneNumberInput(e.target.value)}
                    className="flex-1 px-3 py-2 bg-neutral-950 border border-neutral-800 rounded-xl text-xs text-white focus:outline-none focus:border-emerald-500 font-mono"
                  />
                </div>
              </div>

              {!otpSent ? (
                <button
                  type="button"
                  onClick={handleSendOtp}
                  className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center justify-center space-x-2 transition-colors shadow-lg cursor-pointer"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Send Verification Code (OTP)</span>
                </button>
              ) : (
                <div className="space-y-3 pt-2">
                  <div className="p-2.5 bg-emerald-950/40 border border-emerald-800/60 rounded-xl text-[11px] text-emerald-300">
                    Verification code sent to {selectedCountryCode} {phoneNumberInput}. (Demo OTP: <strong className="font-mono">{generatedOtp}</strong>)
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold uppercase text-neutral-400 mb-1">
                      Enter 6-Digit Code
                    </label>
                    <input
                      type="text"
                      maxLength={6}
                      placeholder="e.g. 123456"
                      value={otpCode}
                      onChange={(e) => setOtpCode(e.target.value)}
                      className="w-full px-3 py-2 bg-neutral-950 border border-neutral-800 rounded-xl text-center text-base tracking-widest text-emerald-300 font-mono focus:outline-none focus:border-emerald-500"
                    />
                  </div>

                  <div className="flex space-x-2">
                    <button
                      type="button"
                      onClick={handleVerifyOtp}
                      className="flex-1 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-md cursor-pointer"
                    >
                      Verify & Link
                    </button>
                    <button
                      type="button"
                      onClick={handleSendOtp}
                      className="px-3 py-2 rounded-xl bg-neutral-800 text-neutral-300 hover:text-white text-xs font-semibold cursor-pointer"
                    >
                      Resend
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* FACEBOOK MODAL */}
      {subView === 'facebook' && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 animate-fadeIn">
          <div className="w-full max-w-sm bg-neutral-900 border border-neutral-800 rounded-3xl p-5 shadow-2xl space-y-4 text-xs">
            <div className="flex items-center justify-between border-b border-neutral-800 pb-3">
              <div className="flex items-center space-x-2">
                <Facebook className="w-4 h-4 text-blue-400" />
                <h4 className="text-sm font-bold text-white">Facebook Account</h4>
              </div>
              <button
                type="button"
                onClick={() => setSubView('none')}
                className="p-1 rounded-full text-neutral-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-3 bg-neutral-950 rounded-2xl border border-neutral-800 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-neutral-400">Connection Status:</span>
                <span
                  className={`font-bold ${
                    settings.facebookConnected ? 'text-blue-400' : 'text-neutral-500'
                  }`}
                >
                  {settings.facebookConnected ? 'Connected' : 'Not Connected'}
                </span>
              </div>
              {settings.facebookConnected && (
                <div className="flex items-center justify-between pt-1 border-t border-neutral-800/80">
                  <span className="text-neutral-400">Linked Profile:</span>
                  <span className="font-bold text-white">
                    {settings.facebookAccountName || currentUser.name}
                  </span>
                </div>
              )}
            </div>

            <p className="text-[11px] text-neutral-400 leading-relaxed">
              Linking your Facebook profile allows quick recovery and verification without altering your SNYVO ID.
            </p>

            <button
              type="button"
              onClick={handleToggleFacebook}
              className={`w-full py-2.5 rounded-xl font-bold text-xs shadow-md transition-all cursor-pointer flex items-center justify-center space-x-2 ${
                settings.facebookConnected
                  ? 'bg-neutral-800 hover:bg-neutral-700 text-neutral-200'
                  : 'bg-blue-600 hover:bg-blue-500 text-white'
              }`}
            >
              <Facebook className="w-4 h-4" />
              <span>{settings.facebookConnected ? 'Disconnect Facebook' : 'Connect Facebook'}</span>
            </button>
          </div>
        </div>
      )}

      {/* GOOGLE MODAL */}
      {subView === 'google' && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 animate-fadeIn">
          <div className="w-full max-w-sm bg-neutral-900 border border-neutral-800 rounded-3xl p-5 shadow-2xl space-y-4 text-xs">
            <div className="flex items-center justify-between border-b border-neutral-800 pb-3">
              <div className="flex items-center space-x-2">
                <Mail className="w-4 h-4 text-rose-400" />
                <h4 className="text-sm font-bold text-white">Google Account</h4>
              </div>
              <button
                type="button"
                onClick={() => setSubView('none')}
                className="p-1 rounded-full text-neutral-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-3 bg-neutral-950 rounded-2xl border border-neutral-800 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-neutral-400">Connection Status:</span>
                <span
                  className={`font-bold ${
                    settings.googleConnected ? 'text-emerald-400' : 'text-neutral-500'
                  }`}
                >
                  {settings.googleConnected ? 'Connected' : 'Not Connected'}
                </span>
              </div>
              {settings.googleConnected && (
                <div className="flex items-center justify-between pt-1 border-t border-neutral-800/80">
                  <span className="text-neutral-400">Linked Email:</span>
                  <span className="font-bold text-white truncate max-w-[170px]">
                    {settings.googleAccountEmail || 'user@snyvo.me'}
                  </span>
                </div>
              )}
            </div>

            <p className="text-[11px] text-neutral-400 leading-relaxed">
              Google Account linking enables unified authentication and prevents account duplication.
            </p>

            <button
              type="button"
              onClick={handleToggleGoogle}
              className={`w-full py-2.5 rounded-xl font-bold text-xs shadow-md transition-all cursor-pointer flex items-center justify-center space-x-2 ${
                settings.googleConnected
                  ? 'bg-neutral-800 hover:bg-neutral-700 text-neutral-200'
                  : 'bg-rose-600 hover:bg-rose-500 text-white'
              }`}
            >
              <Mail className="w-4 h-4" />
              <span>{settings.googleConnected ? 'Disconnect Google' : 'Connect Google'}</span>
            </button>
          </div>
        </div>
      )}

      {/* DELETE ACCOUNT MODAL / FLOW */}
      {subView === 'delete' && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 animate-fadeIn">
          <div className="w-full max-w-md bg-neutral-900 border border-rose-900/50 rounded-3xl p-5 shadow-2xl space-y-4 text-xs">
            <div className="flex items-center justify-between border-b border-neutral-800 pb-3">
              <div className="flex items-center space-x-2 text-rose-500">
                <AlertTriangle className="w-5 h-5" />
                <h4 className="text-sm font-bold">Delete SNYVO Account</h4>
              </div>
              <button
                type="button"
                onClick={() => setSubView('none')}
                className="p-1 rounded-full text-neutral-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {deletionInfo.isScheduled ? (
              /* Already scheduled: show remaining countdown & Cancel button */
              <div className="space-y-4">
                <div className="p-4 bg-amber-500/10 border border-amber-500/30 rounded-2xl text-center space-y-2">
                  <Clock className="w-8 h-8 text-amber-400 mx-auto" />
                  <div className="text-base font-black text-white">
                    Account Deletion Scheduled
                  </div>
                  <div className="text-xs font-mono font-bold text-amber-300">
                    {deletionInfo.daysRemaining} days {deletionInfo.hoursRemaining} hours remaining
                  </div>
                  <p className="text-[11px] text-neutral-400 max-w-xs mx-auto">
                    Your account is in the 30-day grace period. You can cancel this request at any time to keep your SNYVO account.
                  </p>
                </div>

                <button
                  type="button"
                  onClick={handleCancelDeletion}
                  className="w-full py-3 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-lg cursor-pointer transition-colors"
                >
                  Cancel Account Deletion & Restore
                </button>
              </div>
            ) : (
              /* Confirmation flow */
              <div className="space-y-3">
                <div className="p-3.5 bg-rose-950/30 border border-rose-800/40 rounded-2xl space-y-2">
                  <span className="font-bold text-rose-300 block">30-Day Protected Deletion System</span>
                  <p className="text-[11px] text-neutral-300 leading-relaxed">
                    “Your account is scheduled for permanent deletion. You have 30 days to cancel the deletion request.”
                  </p>
                  <ul className="text-[10px] text-neutral-400 list-disc list-inside space-y-0.5 pt-1">
                    <li>Your ID, coins, badges, and voice rooms remain reserved during the 30 days.</li>
                    <li>You can log in anytime to cancel the deletion and restore full access.</li>
                    <li>If not cancelled within 30 days, your data will be permanently wiped.</li>
                  </ul>
                </div>

                <label className="flex items-start space-x-2 cursor-pointer pt-1">
                  <input
                    type="checkbox"
                    checked={hasAgreedTerms}
                    onChange={(e) => setHasAgreedTerms(e.target.checked)}
                    className="mt-0.5 rounded text-rose-600 focus:ring-rose-500"
                  />
                  <span className="text-[11px] text-neutral-300">
                    I understand that my account will enter a 30-day deletion countdown.
                  </span>
                </label>

                <div>
                  <label className="block text-[10px] font-bold uppercase text-neutral-400 mb-1">
                    Type "DELETE" to confirm:
                  </label>
                  <input
                    type="text"
                    value={confirmDeletionText}
                    onChange={(e) => setConfirmDeletionText(e.target.value)}
                    placeholder="DELETE"
                    className="w-full px-3 py-2 bg-neutral-950 border border-neutral-800 rounded-xl text-xs text-white focus:outline-none focus:border-rose-500 font-mono tracking-widest"
                  />
                </div>

                <div className="flex space-x-2 pt-2">
                  <button
                    type="button"
                    onClick={handleScheduleDeletion}
                    disabled={!hasAgreedTerms || confirmDeletionText.trim().toLowerCase() !== 'delete'}
                    className="flex-1 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 disabled:opacity-50 disabled:cursor-not-allowed text-white font-bold text-xs shadow-lg cursor-pointer transition-colors"
                  >
                    Confirm 30-Day Deletion
                  </button>
                  <button
                    type="button"
                    onClick={() => setSubView('none')}
                    className="px-4 py-2.5 rounded-xl bg-neutral-800 text-neutral-300 hover:text-white text-xs font-semibold cursor-pointer"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
