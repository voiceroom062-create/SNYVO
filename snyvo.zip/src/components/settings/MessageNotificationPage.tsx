import React, { useState } from 'react';
import { ChevronLeft, MessageSquare, Bell, Volume2, Vibrate, Moon } from 'lucide-react';
import { User } from '../../types';
import { settingsService, UserSettings } from '../../services/settingsService';

interface MessageNotificationPageProps {
  currentUser: User;
  settings: UserSettings;
  onBack: () => void;
  onUpdateSettings: (updated: UserSettings) => void;
  onToast: (msg: string) => void;
}

export const MessageNotificationPage: React.FC<MessageNotificationPageProps> = ({
  currentUser,
  settings,
  onBack,
  onUpdateSettings,
  onToast,
}) => {
  const notifs = settings.messageNotifications;

  const handleToggle = (key: keyof UserSettings['messageNotifications']) => {
    const updatedNotifs = {
      ...notifs,
      [key]: !notifs[key],
    };
    const updated = settingsService.saveUserSettings(currentUser.id, {
      messageNotifications: updatedNotifs,
    });
    onUpdateSettings(updated);
    onToast('Notification preferences updated');
  };

  const notificationItems = [
    {
      key: 'directMessages' as const,
      title: 'Direct Messages',
      desc: 'Receive alerts when friends send you private voice or text messages',
      icon: <MessageSquare className="w-5 h-5 text-violet-600" />,
      iconBg: 'bg-violet-50',
      value: notifs.directMessages,
    },
    {
      key: 'roomInvites' as const,
      title: 'Room Invites',
      desc: 'Get notified when hosts or friends invite you to join live voice stages',
      icon: <Bell className="w-5 h-5 text-amber-600" />,
      iconBg: 'bg-amber-50',
      value: notifs.roomInvites,
    },
    {
      key: 'soundEnabled' as const,
      title: 'Sound on New Message',
      desc: 'Play audio chimes when new messages or stage announcements arrive',
      icon: <Volume2 className="w-5 h-5 text-emerald-600" />,
      iconBg: 'bg-emerald-50',
      value: notifs.soundEnabled,
    },
    {
      key: 'vibrationEnabled' as const,
      title: 'Vibrate on New Message',
      desc: 'Vibration haptics on receiving incoming notifications',
      icon: <Vibrate className="w-5 h-5 text-cyan-600" />,
      iconBg: 'bg-cyan-50',
      value: notifs.vibrationEnabled,
    },
    {
      key: 'dndMode' as const,
      title: 'Do Not Disturb (DND)',
      desc: 'Mute alerts automatically during quiet hours (11:00 PM – 07:00 AM)',
      icon: <Moon className="w-5 h-5 text-indigo-600" />,
      iconBg: 'bg-indigo-50',
      value: notifs.dndMode,
    },
  ];

  return (
    <div className="flex flex-col h-full bg-neutral-950 text-white animate-fadeIn">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3.5 bg-neutral-900/90 border-b border-neutral-800">
        <button
          type="button"
          onClick={onBack}
          className="flex items-center space-x-1.5 text-neutral-400 hover:text-white transition-colors cursor-pointer py-1"
        >
          <ChevronLeft className="w-5 h-5" />
          <span className="text-xs font-semibold">Settings</span>
        </button>
        <h3 className="text-sm font-black text-white tracking-wide">Message Notification</h3>
        <div className="w-8" />
      </div>

      {/* Body */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 max-w-md mx-auto w-full">
        <div className="bg-white text-neutral-900 rounded-3xl shadow-xl border border-neutral-100 divide-y divide-neutral-100 overflow-hidden">
          {notificationItems.map((item) => (
            <div
              key={item.key}
              className="w-full flex items-center justify-between px-4 py-3.5 hover:bg-neutral-50 transition-colors"
            >
              <div className="flex items-center space-x-3.5 min-w-0 pr-2">
                <div
                  className={`w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 ${item.iconBg}`}
                >
                  {item.icon}
                </div>
                <div className="min-w-0">
                  <span className="text-sm font-bold text-neutral-900 block truncate">
                    {item.title}
                  </span>
                  <span className="text-[11px] text-neutral-400 font-medium block leading-tight">
                    {item.desc}
                  </span>
                </div>
              </div>

              {/* ON/OFF Switch */}
              <button
                type="button"
                onClick={() => handleToggle(item.key)}
                className={`w-11 h-6 rounded-full transition-colors relative flex-shrink-0 cursor-pointer ${
                  item.value ? 'bg-violet-600' : 'bg-neutral-200'
                }`}
              >
                <span
                  className={`absolute top-0.5 left-0.5 w-5 h-5 rounded-full bg-white shadow-md transition-transform ${
                    item.value ? 'translate-x-5' : ''
                  }`}
                />
              </button>
            </div>
          ))}
        </div>

        <p className="text-[11px] text-neutral-500 text-center px-4">
          All message notifications are saved individually for your SNYVO ID.
        </p>
      </div>
    </div>
  );
};
