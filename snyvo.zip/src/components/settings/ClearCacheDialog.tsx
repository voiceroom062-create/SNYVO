import React from 'react';
import { Trash2, AlertCircle, Check } from 'lucide-react';

interface ClearCacheDialogProps {
  currentCacheFormatted: string;
  onConfirm: () => void;
  onCancel: () => void;
}

export const ClearCacheDialog: React.FC<ClearCacheDialogProps> = ({
  currentCacheFormatted,
  onConfirm,
  onCancel,
}) => {
  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 animate-fadeIn">
      <div
        className="w-full max-w-sm bg-neutral-900 border border-neutral-800 rounded-3xl p-5 shadow-2xl space-y-4 text-white text-center"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="w-12 h-12 rounded-2xl bg-cyan-500/10 text-cyan-400 flex items-center justify-center mx-auto">
          <Trash2 className="w-6 h-6" />
        </div>

        <div className="space-y-1">
          <h4 className="text-base font-black text-white">Clear cached data?</h4>
          <p className="text-xs text-neutral-400 leading-relaxed">
            This will remove temporary voice audio packets, room thumbnail caches, and cached promotional banners ({currentCacheFormatted}).
          </p>
        </div>

        <div className="p-3 rounded-2xl bg-neutral-950 border border-neutral-800/80 text-[11px] text-neutral-400 text-left space-y-1">
          <span className="font-bold text-emerald-400 block flex items-center space-x-1">
            <Check className="w-3.5 h-3.5" />
            <span>Guaranteed Safe</span>
          </span>
          <p className="text-[10px] text-neutral-400">
            Your account, profile pictures, coin wallet, VIP rank, and saved settings will NOT be deleted.
          </p>
        </div>

        <div className="flex space-x-2.5 pt-1">
          <button
            type="button"
            onClick={onCancel}
            className="flex-1 py-2.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-300 font-semibold text-xs transition-colors cursor-pointer"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={onConfirm}
            className="flex-1 py-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs shadow-lg transition-colors cursor-pointer"
          >
            Clear
          </button>
        </div>
      </div>
    </div>
  );
};
