import React, { useState } from 'react';
import { Zap, Users, Gamepad2, Radio, MessageCircle, Sparkles, X, Trophy, Dices } from 'lucide-react';
import { ScreenType } from '../types';

interface AndroidNavBarProps {
  activeScreen: ScreenType;
  onNavigate: (screen: ScreenType) => void;
  onOpenCreateRoom?: () => void;
  unreadCount?: number;
}

export type BottomNavSection = 'match' | 'group' | 'game' | 'plaza' | 'chat';

export const AndroidNavBar: React.FC<AndroidNavBarProps> = ({
  activeScreen,
  onNavigate,
  onOpenCreateRoom,
  unreadCount = 2,
}) => {
  const [activeModal, setActiveModal] = useState<'match' | 'game' | null>(null);

  // Map active screen to bottom nav tab
  const getActiveTab = (): BottomNavSection => {
    if (activeScreen === 'home') return 'plaza';
    if (activeScreen === 'activity' || activeScreen === 'chat') return 'chat';
    if (activeScreen === 'explore') return 'group';
    return 'plaza';
  };

  const currentTab = getActiveTab();

  const handleNavClick = (section: BottomNavSection) => {
    if (section === 'plaza') {
      onNavigate('home');
    } else if (section === 'chat') {
      onNavigate('chat');
    } else if (section === 'group') {
      onNavigate('explore');
    } else if (section === 'match') {
      setActiveModal('match');
    } else if (section === 'game') {
      setActiveModal('game');
    }
  };

  const navSections = [
    {
      id: 'match' as BottomNavSection,
      label: 'Match',
      icon: Zap,
    },
    {
      id: 'group' as BottomNavSection,
      label: 'Group',
      icon: Users,
    },
    {
      id: 'game' as BottomNavSection,
      label: 'Game',
      icon: Gamepad2,
    },
    {
      id: 'plaza' as BottomNavSection,
      label: 'Plaza',
      icon: Radio,
    },
    {
      id: 'chat' as BottomNavSection,
      label: 'Chat',
      icon: MessageCircle,
      badge: unreadCount,
    },
  ];

  return (
    <>
      <nav
        id="android-bottom-nav"
        className="w-full bg-neutral-950/95 backdrop-blur-xl border-t border-neutral-900/90 px-2 pt-2 pb-1.5 z-30 select-none"
        aria-label="Bottom Navigation"
      >
        <div className="flex items-center justify-around max-w-md mx-auto">
          {navSections.map((item) => {
            const Icon = item.icon;
            const isActive = currentTab === item.id;

            return (
              <button
                key={item.id}
                id={`nav-item-${item.id}`}
                onClick={() => handleNavClick(item.id)}
                className="flex-1 flex flex-col items-center py-1 relative group transition-all duration-200 cursor-pointer focus:outline-none"
              >
                <div
                  className={`relative p-1.5 rounded-2xl transition-all duration-200 ${
                    isActive
                      ? 'bg-gradient-to-tr from-violet-600/30 to-indigo-500/20 text-violet-400 scale-105 shadow-md shadow-violet-950/50'
                      : 'text-neutral-400 group-hover:text-neutral-200'
                  }`}
                >
                  <Icon
                    className={`w-5 h-5 transition-transform duration-200 ${
                      isActive ? 'stroke-[2.5] text-violet-400' : 'stroke-[1.8]'
                    }`}
                  />
                  {item.badge && item.badge > 0 && !isActive && (
                    <span className="absolute -top-0.5 -right-0.5 w-2 h-2 bg-rose-500 rounded-full ring-2 ring-neutral-950"></span>
                  )}
                  {isActive && item.id === 'plaza' && (
                    <span className="absolute top-1 right-1 w-1.5 h-1.5 bg-emerald-400 rounded-full animate-pulse"></span>
                  )}
                </div>
                <span
                  className={`text-[11px] mt-0.5 font-medium tracking-tight transition-colors ${
                    isActive ? 'text-violet-400 font-bold' : 'text-neutral-400'
                  }`}
                >
                  {item.label}
                </span>
              </button>
            );
          })}
        </div>

        {/* Android navigation gesture indicator bar */}
        <div className="w-28 h-1 bg-neutral-700/60 rounded-full mx-auto mt-2"></div>
      </nav>

      {/* Interactive Quick Match Modal */}
      {activeModal === 'match' && (
        <div
          className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4 animate-fadeIn"
          onClick={() => setActiveModal(null)}
        >
          <div
            className="w-full max-w-sm bg-neutral-900 border border-neutral-800 rounded-t-3xl sm:rounded-3xl p-5 space-y-4 shadow-2xl text-left"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <div className="p-2 rounded-xl bg-violet-600/20 text-violet-400 border border-violet-500/30">
                  <Zap className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white">Voice Match</h3>
                  <p className="text-xs text-neutral-400">Match with live voice rooms & friends</p>
                </div>
              </div>
              <button
                onClick={() => setActiveModal(null)}
                className="p-1.5 rounded-full bg-neutral-800 hover:bg-neutral-700 text-neutral-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-4 rounded-2xl bg-gradient-to-br from-violet-950/40 via-neutral-950 to-indigo-950/30 border border-violet-800/30 text-center space-y-2">
              <div className="w-14 h-14 mx-auto rounded-full bg-violet-600/20 border-2 border-violet-500/50 flex items-center justify-center text-violet-300 animate-pulse">
                <Sparkles className="w-7 h-7 text-violet-400" />
              </div>
              <h4 className="text-sm font-bold text-white">Instant Voice Radar</h4>
              <p className="text-xs text-neutral-400 max-w-xs mx-auto">
                Discover live speakers in Bangladesh chatting about music, tech, and late-night adda.
              </p>
              <button
                onClick={() => {
                  setActiveModal(null);
                  onNavigate('home');
                }}
                className="mt-2 w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-500 hover:to-indigo-500 text-white font-bold text-xs shadow-lg shadow-violet-900/40 transition-all cursor-pointer"
              >
                Find Active Match Room
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Interactive Quick Game Modal */}
      {activeModal === 'game' && (
        <div
          className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4 animate-fadeIn"
          onClick={() => setActiveModal(null)}
        >
          <div
            className="w-full max-w-sm bg-neutral-900 border border-neutral-800 rounded-t-3xl sm:rounded-3xl p-5 space-y-4 shadow-2xl text-left"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <div className="p-2 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/30">
                  <Gamepad2 className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white">SNYVO Games</h3>
                  <p className="text-xs text-neutral-400">Play while listening to voice rooms</p>
                </div>
              </div>
              <button
                onClick={() => setActiveModal(null)}
                className="p-1.5 rounded-full bg-neutral-800 hover:bg-neutral-700 text-neutral-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="grid grid-cols-2 gap-2.5">
              <div className="p-3 rounded-xl bg-neutral-950 border border-neutral-800 hover:border-amber-500/40 transition-colors cursor-pointer group">
                <div className="flex items-center space-x-2 mb-1">
                  <Dices className="w-4 h-4 text-amber-400 group-hover:rotate-12 transition-transform" />
                  <span className="text-xs font-bold text-white">Ludo Star Live</span>
                </div>
                <p className="text-[10px] text-neutral-400">Multiplayer board voice game</p>
              </div>

              <div className="p-3 rounded-xl bg-neutral-950 border border-neutral-800 hover:border-violet-500/40 transition-colors cursor-pointer group">
                <div className="flex items-center space-x-2 mb-1">
                  <Trophy className="w-4 h-4 text-violet-400 group-hover:scale-110 transition-transform" />
                  <span className="text-xs font-bold text-white">Voice Trivia</span>
                </div>
                <p className="text-[10px] text-neutral-400">Answer audio trivia for coins</p>
              </div>
            </div>

            <button
              onClick={() => {
                setActiveModal(null);
                onNavigate('home');
              }}
              className="w-full py-2.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-300 hover:text-white text-xs font-semibold transition-colors"
            >
              Back to Plaza Rooms
            </button>
          </div>
        </div>
      )}
    </>
  );
};

