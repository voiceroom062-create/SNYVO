import React from 'react';
import {
  Mic,
  MicOff,
  Plus,
  ArrowRightLeft,
  Crown as CrownIcon,
  Diamond,
  Lock,
  AlertTriangle,
  Shield
} from 'lucide-react';
import { Speaker, MicrophoneState, SeatStatus, UserRoomRole } from '../types';
import { vipService, VIP_TIER_CONFIGS } from '../coins/vipService';

export interface VoiceRoomSeatProps {
  seatIndex: number;
  speaker?: Speaker;
  isCurrentUser: boolean;
  isCurrentUserSpeaker: boolean;
  isActingHost: boolean;
  isLocalMuted?: boolean;
  micState?: MicrophoneState;
  seatStatus?: SeatStatus;
  userRole?: UserRoomRole;
  userPendingRequest?: boolean;
  hasCandidate?: boolean;
  isLocked?: boolean;
  onSelectSeat: (seatIndex: number, speaker?: Speaker) => void;
  onTakeSeat?: (seatIndex: number) => void;
  onLeaveSeat?: () => void;
}

export const VoiceRoomSeat: React.FC<VoiceRoomSeatProps> = ({
  seatIndex,
  speaker,
  isCurrentUser,
  isCurrentUserSpeaker,
  isActingHost,
  isLocalMuted = false,
  micState,
  seatStatus,
  userRole,
  userPendingRequest = false,
  hasCandidate = false,
  isLocked = false,
  onSelectSeat,
  onTakeSeat,
  onLeaveSeat,
}) => {
  const seatNumber = seatIndex + 1;

  if (speaker) {
    // Determine effective mic state and speaking/muted indicators
    const currentMicState: MicrophoneState = isCurrentUser
      ? (micState || (isLocalMuted ? 'off' : 'on'))
      : (speaker.micState || (speaker.isMuted ? 'off' : 'on'));

    const isHostMuted = currentMicState === 'muted_by_host';
    const isPermissionDenied = currentMicState === 'permission_denied';
    const isMicOn = currentMicState === 'on';
    const currentlySpeaking = isMicOn && (isCurrentUser ? true : speaker.isSpeaking);
    const muted = !isMicOn;
    
    // Get VIP tier from vipService
    const vipTier = vipService.getUserVipTier(speaker.id);
    const tierInfo = VIP_TIER_CONFIGS[vipTier];
    const isSvip = vipTier === 'SVIP';
    const isVipPro = vipTier === 'VIP_PRO';
    const isVip = vipTier === 'VIP';
    const hasVipCrown = isSvip || isVipPro || isVip;

    return (
      <div
        id={`speaker-seat-${seatNumber}`}
        data-seat-id={`voice-room-seat-${seatNumber}`}
        data-seat-status={seatStatus || (currentlySpeaking ? 'speaking' : muted ? 'muted' : 'occupied')}
        onClick={() => onSelectSeat(seatIndex, speaker)}
        className="flex flex-col items-center justify-start group cursor-pointer relative select-none w-full min-w-0 transition-transform active:scale-95"
      >
        {/* Seat Number Tag */}
        <div className="flex items-center space-x-0.5 mb-1">
          <span className="text-[9px] font-bold text-violet-300/80 bg-violet-950/60 border border-violet-800/40 px-1.5 py-0.2 rounded-full leading-tight">
            #{seatNumber}
          </span>
        </div>

        {/* 1. 👤 Circular Profile Photo with Galaxy Neon Border */}
        <div
          id={`seat-avatar-container-${seatNumber}`}
          className="relative flex items-center justify-center"
        >
          {/* Speaking Pulse Ring */}
          {currentlySpeaking && (
            <>
              <span className="absolute -inset-1.5 rounded-full bg-emerald-400/40 animate-ping pointer-events-none" />
              <span className="absolute -inset-1 rounded-full bg-emerald-500/30 animate-pulse pointer-events-none shadow-[0_0_12px_rgba(16,185,129,0.8)]" />
            </>
          )}

          {/* SVIP / VIP / Host Crown / Co-Host Shield Positioned over Avatar */}
          {speaker.isHost || userRole === 'host' || seatIndex === 0 ? (
            <div
              className="absolute -top-3.5 left-1/2 -translate-x-1/2 z-20 text-[11px] leading-none filter drop-shadow-[0_2px_4px_rgba(245,158,11,0.8)] select-none animate-pulse"
              title="Room Host"
            >
              👑
            </div>
          ) : speaker.isCoHost || userRole === 'cohost' || (speaker.isModerator && !speaker.isHost) || userRole === 'moderator' || seatIndex === 1 ? (
            <div
              className="absolute -top-3.5 left-1/2 -translate-x-1/2 z-20 text-[10px] leading-none filter drop-shadow-[0_2px_4px_rgba(99,102,241,0.8)] select-none"
              title="Co-Host / Moderator"
            >
              🛡️
            </div>
          ) : hasVipCrown ? (
            <div
              className={`absolute -top-3.5 left-1/2 -translate-x-1/2 z-20 text-[11px] leading-none filter drop-shadow-md select-none ${
                isSvip ? 'animate-bounce' : ''
              }`}
              title={`${tierInfo.title} Crown`}
            >
              {isSvip ? '💎👑' : '👑'}
            </div>
          ) : null}

          {/* Circular Frame */}
          <div
            className={`p-0.5 rounded-full transition-all duration-300 relative ${
              isSvip
                ? 'bg-gradient-to-tr from-cyan-400 via-fuchsia-400 to-amber-300 shadow-md shadow-cyan-500/40 ring-2 ring-cyan-300'
                : isVipPro
                ? 'bg-gradient-to-tr from-purple-500 via-pink-400 to-amber-300 shadow-md shadow-purple-500/30 ring-2 ring-purple-400'
                : isVip
                ? 'bg-gradient-to-tr from-amber-500 via-yellow-300 to-amber-600 ring-1 ring-amber-400'
                : (speaker.isHost || userRole === 'host' || seatIndex === 0)
                ? 'bg-gradient-to-tr from-amber-400 via-yellow-300 to-amber-600 shadow-[0_0_12px_rgba(245,158,11,0.6)] ring-2 ring-amber-400'
                : (speaker.isCoHost || userRole === 'cohost' || userRole === 'moderator' || seatIndex === 1)
                ? 'bg-gradient-to-tr from-indigo-500 via-violet-400 to-purple-500 shadow-[0_0_10px_rgba(99,102,241,0.5)] ring-1.5 ring-indigo-400'
                : currentlySpeaking
                ? 'bg-gradient-to-tr from-emerald-400 via-teal-300 to-emerald-500 shadow-[0_0_12px_rgba(16,185,129,0.7)] ring-2 ring-emerald-400'
                : isHostMuted
                ? 'bg-gradient-to-tr from-amber-600 via-rose-600 to-orange-500 shadow-[0_0_10px_rgba(245,158,11,0.5)] ring-1.5 ring-amber-400'
                : isPermissionDenied
                ? 'bg-gradient-to-tr from-rose-600 via-red-600 to-rose-700 shadow-[0_0_10px_rgba(225,29,72,0.5)] ring-1.5 ring-rose-400'
                : 'bg-gradient-to-b from-violet-600/60 to-purple-800/40 border border-violet-500/40 shadow-[0_0_8px_rgba(168,85,247,0.25)] group-hover:border-violet-400'
            }`}
          >
            <img
              id={`seat-avatar-img-${seatNumber}`}
              src={speaker.avatar}
              alt={speaker.name}
              className={`w-11 h-11 sm:w-12 sm:h-12 rounded-full object-cover block bg-neutral-900 transition-transform group-hover:scale-105 ${
                currentlySpeaking ? 'brightness-105' : ''
              }`}
            />

            {/* 🎤 Microphone Status Mini Bubble positioned on bottom right */}
            <div
              id={`seat-mic-status-${seatNumber}`}
              className={`absolute -bottom-0.5 -right-0.5 w-4 h-4 rounded-full flex items-center justify-center shadow-md transition-all ${
                isHostMuted
                  ? 'bg-amber-600 text-white border border-amber-300 shadow-amber-950/60'
                  : isPermissionDenied
                  ? 'bg-rose-700 text-white border border-rose-300 shadow-rose-950/60'
                  : muted
                  ? 'bg-rose-600/90 text-white border border-rose-300/80 shadow-rose-950/60'
                  : 'bg-emerald-500 text-neutral-950 border border-emerald-200 shadow-[0_0_6px_rgba(16,185,129,0.8)]'
              }`}
              title={
                isHostMuted
                  ? 'Muted by Host'
                  : isPermissionDenied
                  ? 'Mic Permission Denied'
                  : muted
                  ? 'Muted'
                  : 'Speaking'
              }
            >
              {isHostMuted ? (
                <Lock className="w-2.5 h-2.5 stroke-[2.5]" />
              ) : isPermissionDenied ? (
                <AlertTriangle className="w-2.5 h-2.5 stroke-[2.5]" />
              ) : muted ? (
                <MicOff className="w-2.5 h-2.5 stroke-[2.5]" />
              ) : (
                <Mic className="w-2.5 h-2.5 stroke-[2.5]" />
              )}
            </div>
          </div>
        </div>

        {/* User Display Name */}
        <span
          id={`seat-name-${seatNumber}`}
          className={`text-[11px] sm:text-xs font-semibold truncate max-w-[68px] sm:max-w-[76px] text-center leading-tight transition-colors group-hover:text-violet-200 mt-1 ${
            (speaker.isHost || userRole === 'host' || seatIndex === 0)
              ? 'text-amber-200 font-bold'
              : (speaker.isCoHost || userRole === 'cohost' || userRole === 'moderator' || seatIndex === 1)
              ? 'text-indigo-200 font-bold'
              : isCurrentUser
              ? 'text-violet-200 font-bold'
              : 'text-neutral-100'
          }`}
          title={speaker.name}
        >
          {speaker.name.split(' ')[0]}
          {isCurrentUser && ' (You)'}
        </span>

        {/* Role or VIP / Level Badge */}
        <div className="flex items-center justify-center space-x-0.5 mt-0.5">
          {speaker.isHost || userRole === 'host' || seatIndex === 0 ? (
            <span className="text-[8px] bg-amber-500/20 border border-amber-400/50 text-amber-300 font-extrabold px-1.5 py-0.2 rounded-full">
              👑 HOST
            </span>
          ) : speaker.isCoHost || userRole === 'cohost' || seatIndex === 1 ? (
            <span className="text-[8px] bg-indigo-500/20 border border-indigo-400/50 text-indigo-300 font-extrabold px-1.5 py-0.2 rounded-full">
              🛡️ CO-HOST
            </span>
          ) : userRole === 'moderator' || speaker.isModerator ? (
            <span className="text-[8px] bg-sky-500/20 border border-sky-400/50 text-sky-300 font-extrabold px-1.5 py-0.2 rounded-full">
              MOD
            </span>
          ) : hasVipCrown ? (
            <span
              className={`text-[8px] font-black uppercase px-1 py-0.2 rounded-full border shadow-sm flex items-center space-x-0.5 ${
                isSvip
                  ? 'bg-cyan-500/20 text-cyan-300 border-cyan-400/50'
                  : isVipPro
                  ? 'bg-purple-500/20 text-purple-300 border-purple-400/50'
                  : 'bg-amber-500/20 text-amber-300 border-amber-400/50'
              }`}
            >
              {isSvip && <Diamond className="w-1.5 h-1.5 fill-current inline" />}
              <span>{tierInfo.badgeLabel}</span>
            </span>
          ) : (
            <span className="text-[8px] text-violet-300/80 font-semibold bg-violet-950/40 border border-violet-800/30 px-1.5 py-0.2 rounded-full">
              SPEAKER
            </span>
          )}
        </div>
      </div>
    );
  }

  // ==========================================
  // Empty / Open Voice Seat Component
  // ==========================================
  return (
    <div
      id={`stage-seat-${seatNumber}`}
      data-seat-id={`voice-room-seat-${seatNumber}`}
      onClick={() => onSelectSeat(seatIndex, undefined)}
      className="flex flex-col items-center justify-start group cursor-pointer select-none w-full min-w-0 transition-transform active:scale-95"
    >
      {/* Seat Number Tag */}
      <div className="flex items-center space-x-0.5 mb-1">
        <span className="text-[9px] font-bold text-violet-400/70 group-hover:text-violet-300 bg-violet-950/40 px-1.5 py-0.2 rounded-full border border-violet-800/30 transition-colors">
          #{seatNumber}
        </span>
      </div>

      {/* Circular Empty Seat with Glowing Purple Neon Border & White Mic */}
      <div className="relative flex items-center justify-center">
        {/* Soft neon glow halo */}
        <div className="absolute inset-0 rounded-full bg-violet-600/10 blur-sm group-hover:bg-violet-600/20 transition-all pointer-events-none" />

        <div
          className={`w-11 h-11 sm:w-12 sm:h-12 rounded-full border-1.5 transition-all duration-300 flex items-center justify-center group-hover:scale-105 shadow-inner backdrop-blur-md relative ${
            isLocked
              ? 'border-neutral-700/60 bg-neutral-900/50 text-neutral-500 cursor-not-allowed'
              : isCurrentUserSpeaker
              ? 'border-violet-400/70 bg-violet-950/40 group-hover:bg-violet-900/50 group-hover:border-violet-300 text-violet-200 shadow-[0_0_12px_rgba(168,85,247,0.3)]'
              : userPendingRequest
              ? 'border-amber-400/60 bg-amber-950/30 text-amber-200 shadow-[0_0_10px_rgba(245,158,11,0.25)]'
              : 'border-violet-500/40 group-hover:border-violet-300/80 bg-gradient-to-b from-white/[0.07] to-violet-950/40 text-white shadow-[0_0_14px_rgba(139,92,246,0.18)] group-hover:shadow-[0_0_20px_rgba(168,85,247,0.45)]'
          }`}
        >
          {isLocked ? (
            <Lock className="w-4 h-4 text-neutral-400 stroke-[2]" />
          ) : isCurrentUserSpeaker ? (
            <ArrowRightLeft className="w-4 h-4 text-violet-300 group-hover:text-white transition-colors" />
          ) : (
            /* Subtle "+" empty seat design */
            <div className="flex flex-col items-center justify-center">
              <Plus className="w-5 h-5 text-violet-300/80 group-hover:text-white group-hover:scale-110 transition-all stroke-[2.5]" />
            </div>
          )}
        </div>
      </div>

      {/* Seat Label */}
      <span className="text-[10px] sm:text-[11px] font-medium text-neutral-400 group-hover:text-violet-200 mt-1 text-center truncate max-w-[68px]">
        Seat {seatNumber}
      </span>

      {/* Obvious "+ Sit" Action Tag / Status Button */}
      <div className="mt-0.5 flex items-center justify-center">
        {isLocked ? (
          <span className="text-[8px] font-bold text-neutral-400 bg-neutral-900/80 border border-neutral-700/60 px-1.5 py-0.2 rounded-full">
            Locked
          </span>
        ) : isCurrentUserSpeaker ? (
          <span className="text-[8px] font-bold text-violet-300 bg-violet-950/70 border border-violet-500/40 px-1.5 py-0.2 rounded-full group-hover:bg-violet-900/80">
            Switch
          </span>
        ) : userPendingRequest ? (
          <span className="text-[8px] font-bold text-amber-300 bg-amber-950/80 border border-amber-500/50 px-1.5 py-0.2 rounded-full animate-pulse">
            Wait...
          </span>
        ) : (
          <span
            id={`seat-sit-action-${seatNumber}`}
            className="text-[9px] font-bold text-violet-100 bg-gradient-to-r from-violet-600/70 to-fuchsia-600/70 hover:from-violet-500 hover:to-fuchsia-500 border border-violet-400/50 px-2 py-0.2 rounded-full shadow-[0_0_8px_rgba(168,85,247,0.3)] group-hover:shadow-[0_0_12px_rgba(168,85,247,0.6)] flex items-center space-x-0.5 transition-all"
          >
            <Plus className="w-2.5 h-2.5 stroke-[3] -ml-0.5" />
            <span>Sit</span>
          </span>
        )}
      </div>
    </div>
  );
};
