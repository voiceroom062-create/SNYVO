import React, { useState } from 'react';
import { X, Mic, Radio, Globe, Lock, Sparkles, ArrowRight, AlertTriangle, RotateCcw } from 'lucide-react';
import { User, VoiceRoom } from '../types';
import { roomService } from '../services/roomService';
import { availableTopics } from '../data/mockData';

interface CreateRoomModalProps {
  currentUser: User;
  onClose: () => void;
  onRoomCreated: (room: VoiceRoom) => void;
  onReturnToActiveRoom?: (room: VoiceRoom) => void;
}

export const CreateRoomModal: React.FC<CreateRoomModalProps> = ({
  currentUser,
  onClose,
  onRoomCreated,
  onReturnToActiveRoom,
}) => {
  const [title, setTitle] = useState('');
  const [selectedTopic, setSelectedTopic] = useState('Tech & AI');
  const [roomType, setRoomType] = useState<'open' | 'social' | 'club'>('open');
  const [selectedClub, setSelectedClub] = useState(currentUser.clubs[0] || 'Open Stage');

  // Check if current user already has an active room board
  const existingActiveRoom = roomService.getUserActiveRoom(currentUser.id);
  const [showActiveRoomWarning, setShowActiveRoomWarning] = useState(!!existingActiveRoom);

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    const clubName = roomType === 'club' ? selectedClub : (roomType === 'social' ? 'Social Circle' : 'Public Stage');
    const newRoom = roomService.createRoom(title.trim(), selectedTopic, clubName, currentUser);
    onRoomCreated(newRoom);
  };

  const handleReturnToExisting = () => {
    if (existingActiveRoom && onReturnToActiveRoom) {
      onReturnToActiveRoom(existingActiveRoom);
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/85 backdrop-blur-sm animate-fade-in">
      <div className="w-full max-w-md bg-neutral-900 border border-neutral-800 rounded-t-3xl sm:rounded-3xl p-6 shadow-2xl shadow-violet-950/40 text-white max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-neutral-800">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 rounded-xl bg-violet-600/20 border border-violet-500/30 flex items-center justify-center text-violet-400">
              <Mic className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white">Start a Voice Room</h3>
              <p className="text-[11px] text-neutral-400">Host a live salon on SNYVO</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* One ID = One Room Board Notification Banner */}
        {showActiveRoomWarning && existingActiveRoom && (
          <div className="mt-4 p-4 rounded-2xl bg-amber-950/40 border border-amber-500/40 space-y-2.5">
            <div className="flex items-start space-x-2.5 text-amber-300">
              <AlertTriangle className="w-5 h-5 flex-shrink-0 mt-0.5 text-amber-400" />
              <div>
                <p className="text-xs font-bold text-white">
                  Active Room Board in Progress
                </p>
                <p className="text-[11px] text-amber-200/90 leading-relaxed mt-0.5">
                  Your ID ({currentUser.name}) is currently hosting or on stage in &quot;{existingActiveRoom.title}&quot;. (One ID = One Room Board rule).
                </p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2 pt-1">
              <button
                type="button"
                onClick={handleReturnToExisting}
                className="py-2 px-3 rounded-xl bg-violet-600 hover:bg-violet-500 text-white text-xs font-bold flex items-center justify-center space-x-1 shadow-md shadow-violet-600/30 cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Return to Board</span>
              </button>
              <button
                type="button"
                onClick={() => setShowActiveRoomWarning(false)}
                className="py-2 px-3 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-300 text-xs font-semibold cursor-pointer"
              >
                Close &amp; Create New
              </button>
            </div>
          </div>
        )}

        <form onSubmit={handleCreate} className="mt-4 space-y-4">
          {/* Room Title */}
          <div>
            <label className="block text-xs font-semibold text-neutral-300 mb-1.5">
              Room Topic / Title
            </label>
            <input
              type="text"
              value={title}
              onChange={e => setTitle(e.target.value)}
              placeholder="What do you want to talk about?"
              autoFocus
              className="w-full px-4 py-3 bg-neutral-950 border border-neutral-800 rounded-xl text-sm text-white placeholder-neutral-500 focus:outline-none focus:border-violet-500"
            />
          </div>

          {/* Access Type */}
          <div>
            <label className="block text-xs font-semibold text-neutral-300 mb-1.5">
              Room Access
            </label>
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => setRoomType('open')}
                className={`p-2.5 rounded-xl border text-center transition-all cursor-pointer ${
                  roomType === 'open'
                    ? 'bg-violet-950/40 border-violet-500 text-white font-semibold'
                    : 'bg-neutral-950/60 border-neutral-800 text-neutral-400 hover:text-neutral-200'
                }`}
              >
                <Globe className="w-4 h-4 mx-auto mb-1 text-violet-400" />
                <span className="text-xs block">Public</span>
              </button>

              <button
                type="button"
                onClick={() => setRoomType('social')}
                className={`p-2.5 rounded-xl border text-center transition-all cursor-pointer ${
                  roomType === 'social'
                    ? 'bg-violet-950/40 border-violet-500 text-white font-semibold'
                    : 'bg-neutral-950/60 border-neutral-800 text-neutral-400 hover:text-neutral-200'
                }`}
              >
                <Radio className="w-4 h-4 mx-auto mb-1 text-indigo-400" />
                <span className="text-xs block">Social</span>
              </button>

              <button
                type="button"
                onClick={() => setRoomType('club')}
                className={`p-2.5 rounded-xl border text-center transition-all cursor-pointer ${
                  roomType === 'club'
                    ? 'bg-violet-950/40 border-violet-500 text-white font-semibold'
                    : 'bg-neutral-950/60 border-neutral-800 text-neutral-400 hover:text-neutral-200'
                }`}
              >
                <Lock className="w-4 h-4 mx-auto mb-1 text-amber-400" />
                <span className="text-xs block">Club Only</span>
              </button>
            </div>
          </div>

          {/* Topic Picker */}
          <div>
            <label className="block text-xs font-semibold text-neutral-300 mb-1.5">
              Category
            </label>
            <div className="flex flex-wrap gap-1.5 max-h-28 overflow-y-auto p-1 bg-neutral-950/60 rounded-xl border border-neutral-800">
              {availableTopics.map(topic => (
                <button
                  key={topic}
                  type="button"
                  onClick={() => setSelectedTopic(topic)}
                  className={`px-3 py-1 rounded-lg text-xs font-medium transition-all cursor-pointer ${
                    selectedTopic === topic
                      ? 'bg-violet-600 text-white shadow-sm'
                      : 'bg-neutral-900 text-neutral-400 hover:text-white'
                  }`}
                >
                  {topic}
                </button>
              ))}
            </div>
          </div>

          {/* Launch Button */}
          <button
            type="submit"
            disabled={!title.trim()}
            className="w-full mt-2 py-3.5 px-4 rounded-xl bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-500 hover:to-indigo-500 text-white font-semibold text-sm shadow-lg shadow-violet-600/30 flex items-center justify-center space-x-2 transition-all active:scale-[0.98] disabled:opacity-50 cursor-pointer"
          >
            <span>Let&apos;s Go Live</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  );
};
