import React, { useState, useEffect } from 'react';
import {
  X,
  ShieldCheck,
  CheckCircle2,
  XCircle,
  Clock,
  Coins,
  Package,
  Settings,
  Plus,
  Trash2,
  Edit2,
  Save,
  AlertCircle,
  RefreshCw,
  Search,
  Check,
  Filter,
} from 'lucide-react';
import { CoinPackage, PurchaseOrder, AdminPaymentConfig, VipTier, EntryEffectType } from '../coins/types';
import { coinConfigService } from '../coins/coinConfigService';
import { purchaseService } from '../coins/purchaseService';
import { walletService } from '../games/walletService';

interface AdminPanelModalProps {
  onClose: () => void;
}

export const AdminPanelModal: React.FC<AdminPanelModalProps> = ({ onClose }) => {
  const [activeTab, setActiveTab] = useState<'verification' | 'packages' | 'contact' | 'stats'>('verification');
  const [orders, setOrders] = useState<PurchaseOrder[]>(() => purchaseService.getAllOrders());
  const [packages, setPackages] = useState<CoinPackage[]>(() => coinConfigService.getPackages(true));
  const [adminConfig, setAdminConfig] = useState<AdminPaymentConfig>(() => coinConfigService.getAdminConfig());
  
  // Filter for orders
  const [statusFilter, setStatusFilter] = useState<'ALL' | 'PENDING' | 'APPROVED' | 'REJECTED'>('ALL');
  const [searchQuery, setSearchQuery] = useState('');
  
  // Package editing state
  const [editingPackage, setEditingPackage] = useState<CoinPackage | null>(null);
  const [isAddingPackage, setIsAddingPackage] = useState(false);
  const [newPkgData, setNewPkgData] = useState<Omit<CoinPackage, 'id'>>({
    name: '',
    coins: 1000000,
    priceBdt: 100,
    vipTier: 'VIP',
    badge: 'Special',
    description: '',
    vipCrown: '👑',
    entryEffectTitle: 'VIP Golden Flare',
    entryEffectType: 'vip',
    active: true,
  });

  // Action status message
  const [feedbackMsg, setFeedbackMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Config form state
  const [configForm, setConfigForm] = useState<AdminPaymentConfig>({ ...adminConfig });

  useEffect(() => {
    const unsubOrders = purchaseService.subscribe(() => {
      setOrders(purchaseService.getAllOrders());
    });
    const unsubConfig = coinConfigService.subscribe(() => {
      setPackages(coinConfigService.getPackages(true));
      setAdminConfig(coinConfigService.getAdminConfig());
    });

    return () => {
      unsubOrders();
      unsubConfig();
    };
  }, []);

  const showFeedback = (type: 'success' | 'error', text: string) => {
    setFeedbackMsg({ type, text });
    setTimeout(() => setFeedbackMsg(null), 3500);
  };

  // Verification actions
  const handleApproveOrder = (orderId: string) => {
    const res = purchaseService.approveOrder(orderId, 'App Owner/Admin');
    if (res.success && res.order) {
      showFeedback(
        'success',
        `Approved order ${orderId}! Credited ${res.order.coins.toLocaleString()} Coins to user ${res.order.userName} (ID: ${res.order.userNumericId}) with ${res.order.vipTierReward} rank.`
      );
    } else {
      showFeedback('error', res.error || 'Failed to approve order.');
    }
  };

  const handleRejectOrder = (orderId: string) => {
    const reason = prompt('অর্ডার বাতিলের কারণ লিখুন (Reason for rejection):', 'Invalid TrxID or payment not received');
    if (reason === null) return; // cancelled prompt

    const res = purchaseService.rejectOrder(orderId, reason || 'Payment not verified', 'App Owner/Admin');
    if (res.success) {
      showFeedback('success', `Rejected order ${orderId}. Zero coins credited.`);
    } else {
      showFeedback('error', res.error || 'Failed to reject order.');
    }
  };

  // Package Management actions
  const handleSaveNewPackage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPkgData.name || newPkgData.coins <= 0 || newPkgData.priceBdt <= 0) {
      showFeedback('error', 'Please provide valid package details.');
      return;
    }

    const created = coinConfigService.addPackage({
      ...newPkgData,
      isSvipPackage: newPkgData.vipTier === 'SVIP',
    });

    setIsAddingPackage(false);
    showFeedback('success', `Added new package: ${created.name} (৳${created.priceBdt})`);
  };

  const handleUpdatePackage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingPackage) return;

    coinConfigService.updatePackage(editingPackage.id, {
      ...editingPackage,
      isSvipPackage: editingPackage.vipTier === 'SVIP',
    });

    setEditingPackage(null);
    showFeedback('success', `Updated package: ${editingPackage.name}`);
  };

  const handleDeletePackage = (id: string, name: string) => {
    if (confirm(`Are you sure you want to delete package "${name}"?`)) {
      coinConfigService.deletePackage(id);
      showFeedback('success', `Deleted package "${name}"`);
    }
  };

  const handleTogglePackageActive = (pkg: CoinPackage) => {
    coinConfigService.updatePackage(pkg.id, { active: !pkg.active });
  };

  // Contact Config actions
  const handleSaveContactConfig = (e: React.FormEvent) => {
    e.preventDefault();
    coinConfigService.updateAdminConfig(configForm);
    showFeedback('success', 'Admin Contact & Payment Information updated successfully!');
  };

  // Computed orders
  const filteredOrders = orders.filter(o => {
    const matchesStatus = statusFilter === 'ALL' || o.status === statusFilter;
    const matchesSearch =
      o.transactionId.toLowerCase().includes(searchQuery.toLowerCase()) ||
      o.userNumericId.includes(searchQuery) ||
      o.userName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      o.senderPhone.includes(searchQuery);
    return matchesStatus && matchesSearch;
  });

  const pendingCount = orders.filter(o => o.status === 'PENDING').length;
  const approvedOrders = orders.filter(o => o.status === 'APPROVED');
  const totalRevenueBdt = approvedOrders.reduce((sum, o) => sum + o.amountBdt, 0);
  const totalCoinsDistributed = approvedOrders.reduce((sum, o) => sum + o.coins, 0);

  return (
    <div
      id="admin-panel-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-2 sm:p-4 overflow-y-auto"
    >
      <div
        id="admin-panel-modal-card"
        className="w-full max-w-2xl max-h-[94vh] flex flex-col rounded-[32px] bg-neutral-950 border border-neutral-800 shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200"
      >
        {/* Header */}
        <div className="p-4 border-b border-neutral-800/80 bg-neutral-900/90 flex items-center justify-between flex-shrink-0">
          <div className="flex items-center space-x-2.5">
            <div className="w-10 h-10 rounded-2xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-xl text-amber-400">
              🛡️
            </div>
            <div>
              <h2 className="text-base font-extrabold text-white flex items-center space-x-2">
                <span>SNYVO Admin Control</span>
                <span className="text-[10px] uppercase font-black px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40">
                  Owner
                </span>
              </h2>
              <p className="text-[11px] text-neutral-400">
                Coin Purchases, VIP Tiers, bKash/Nagad Verification & Package Management
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-neutral-800 hover:bg-neutral-700 flex items-center justify-center text-neutral-400 hover:text-white transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Global Feedback Banner */}
        {feedbackMsg && (
          <div
            className={`px-4 py-2 text-xs font-bold flex items-center space-x-2 flex-shrink-0 ${
              feedbackMsg.type === 'success'
                ? 'bg-emerald-950 text-emerald-300 border-b border-emerald-800'
                : 'bg-rose-950 text-rose-300 border-b border-rose-800'
            }`}
          >
            {feedbackMsg.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 flex-shrink-0" />
            ) : (
              <AlertCircle className="w-4 h-4 flex-shrink-0" />
            )}
            <span>{feedbackMsg.text}</span>
          </div>
        )}

        {/* Tabs Bar */}
        <div className="px-4 py-2.5 bg-neutral-950 border-b border-neutral-800 flex items-center space-x-2 flex-shrink-0 overflow-x-auto">
          <button
            onClick={() => setActiveTab('verification')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center space-x-1.5 flex-shrink-0 ${
              activeTab === 'verification'
                ? 'bg-amber-500 text-neutral-950 shadow-md shadow-amber-500/20'
                : 'bg-neutral-900 text-neutral-400 hover:text-white border border-neutral-800'
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Verification</span>
            {pendingCount > 0 && (
              <span className="w-4 h-4 rounded-full bg-rose-600 text-white text-[10px] font-black flex items-center justify-center">
                {pendingCount}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab('packages')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center space-x-1.5 flex-shrink-0 ${
              activeTab === 'packages'
                ? 'bg-amber-500 text-neutral-950 shadow-md shadow-amber-500/20'
                : 'bg-neutral-900 text-neutral-400 hover:text-white border border-neutral-800'
            }`}
          >
            <Package className="w-3.5 h-3.5" />
            <span>Packages ({packages.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('contact')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center space-x-1.5 flex-shrink-0 ${
              activeTab === 'contact'
                ? 'bg-amber-500 text-neutral-950 shadow-md shadow-amber-500/20'
                : 'bg-neutral-900 text-neutral-400 hover:text-white border border-neutral-800'
            }`}
          >
            <Settings className="w-3.5 h-3.5" />
            <span>Payment Info & Notice</span>
          </button>

          <button
            onClick={() => setActiveTab('stats')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center space-x-1.5 flex-shrink-0 ${
              activeTab === 'stats'
                ? 'bg-amber-500 text-neutral-950 shadow-md shadow-amber-500/20'
                : 'bg-neutral-900 text-neutral-400 hover:text-white border border-neutral-800'
            }`}
          >
            <Coins className="w-3.5 h-3.5" />
            <span>Ledger & Revenue</span>
          </button>
        </div>

        {/* Tab 1: Payment Verification */}
        {activeTab === 'verification' && (
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {/* Filter Controls */}
            <div className="flex flex-col sm:flex-row items-center justify-between gap-2 bg-neutral-900/60 p-2.5 rounded-2xl border border-neutral-800">
              <div className="flex items-center space-x-1 w-full sm:w-auto">
                {(['ALL', 'PENDING', 'APPROVED', 'REJECTED'] as const).map(status => (
                  <button
                    key={status}
                    onClick={() => setStatusFilter(status)}
                    className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition-all ${
                      statusFilter === status
                        ? 'bg-neutral-800 text-amber-300 border border-amber-500/40'
                        : 'text-neutral-400 hover:text-white'
                    }`}
                  >
                    {status}
                    {status === 'PENDING' && pendingCount > 0 && ` (${pendingCount})`}
                  </button>
                ))}
              </div>

              <div className="relative w-full sm:w-48">
                <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-neutral-500" />
                <input
                  type="text"
                  placeholder="Search TrxID / User ID..."
                  value={searchQuery}
                  onChange={e => setSearchQuery(e.target.value)}
                  className="w-full pl-8 pr-2.5 py-1 rounded-xl bg-neutral-950 border border-neutral-800 text-xs text-white placeholder-neutral-600 focus:outline-none focus:border-amber-500"
                />
              </div>
            </div>

            {/* Orders List */}
            {filteredOrders.length === 0 ? (
              <div className="text-center py-12 space-y-2 text-neutral-500">
                <ShieldCheck className="w-10 h-10 mx-auto opacity-40" />
                <p className="text-xs">No orders found matching filter.</p>
              </div>
            ) : (
              filteredOrders.map(order => {
                const isPending = order.status === 'PENDING';
                const isApproved = order.status === 'APPROVED';
                const isRejected = order.status === 'REJECTED';

                return (
                  <div
                    key={order.id}
                    className={`p-4 rounded-2xl border space-y-3 transition-all ${
                      isPending
                        ? 'bg-amber-950/20 border-amber-500/60 shadow-lg shadow-amber-950/20'
                        : isApproved
                        ? 'bg-neutral-900/80 border-emerald-900/60'
                        : 'bg-neutral-950 border-neutral-800 opacity-80'
                    }`}
                  >
                    {/* Top Row: User & Status */}
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2.5 min-w-0">
                        <img
                          src={order.userAvatar}
                          alt={order.userName}
                          className="w-9 h-9 rounded-full object-cover border border-neutral-700"
                        />
                        <div className="min-w-0">
                          <h4 className="text-xs font-bold text-white truncate flex items-center space-x-1.5">
                            <span>{order.userName}</span>
                            <span className="text-[10px] text-neutral-400 font-mono">
                              (ID: {order.userNumericId})
                            </span>
                          </h4>
                          <p className="text-[10px] text-neutral-400 truncate">
                            {order.packageName} • {order.displayTime}
                          </p>
                        </div>
                      </div>

                      <span
                        className={`text-[10px] font-black px-2.5 py-1 rounded-full border flex items-center space-x-1 ${
                          isApproved
                            ? 'bg-emerald-950 border-emerald-600 text-emerald-300'
                            : isPending
                            ? 'bg-amber-950 border-amber-500 text-amber-300 animate-pulse'
                            : 'bg-rose-950 border-rose-700 text-rose-400'
                        }`}
                      >
                        {isPending && <Clock className="w-3 h-3" />}
                        {isApproved && <Check className="w-3 h-3" />}
                        {isRejected && <X className="w-3 h-3" />}
                        <span>{order.status}</span>
                      </span>
                    </div>

                    {/* Financial & Payment Details Grid */}
                    <div className="p-2.5 rounded-xl bg-neutral-950/90 border border-neutral-800/80 grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
                      <div>
                        <span className="text-[10px] text-neutral-400 block">Amount:</span>
                        <span className="font-mono font-bold text-emerald-400">
                          ৳{order.amountBdt} ({order.paymentMethod})
                        </span>
                      </div>
                      <div>
                        <span className="text-[10px] text-neutral-400 block">Coins to Credit:</span>
                        <span className="font-mono font-bold text-amber-300">
                          🪙 {order.coins.toLocaleString()}
                        </span>
                      </div>
                      <div>
                        <span className="text-[10px] text-neutral-400 block">VIP Rank:</span>
                        <span className="font-bold text-violet-300">
                          {order.vipTierReward}
                        </span>
                      </div>
                      <div>
                        <span className="text-[10px] text-neutral-400 block">Sender Phone:</span>
                        <span className="font-mono font-bold text-neutral-200">
                          {order.senderPhone}
                        </span>
                      </div>
                    </div>

                    {/* TrxID & Verification Note */}
                    <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between text-[11px] gap-1 pt-1 border-t border-neutral-900">
                      <div className="flex items-center space-x-1.5">
                        <span className="text-neutral-400 font-semibold">Transaction ID:</span>
                        <span className="font-mono font-extrabold text-amber-300 bg-neutral-900 px-2 py-0.5 rounded border border-neutral-800 select-all">
                          {order.transactionId}
                        </span>
                      </div>

                      {order.adminNote && (
                        <span className="text-neutral-400 italic text-[10px] truncate max-w-xs">
                          Note: {order.adminNote}
                        </span>
                      )}
                    </div>

                    {/* Action Buttons for Pending Orders */}
                    {isPending && (
                      <div className="pt-2 flex items-center space-x-2">
                        <button
                          type="button"
                          onClick={() => handleApproveOrder(order.id)}
                          className="flex-1 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-neutral-950 font-black text-xs flex items-center justify-center space-x-1.5 transition-all shadow-md shadow-emerald-950/40 cursor-pointer"
                        >
                          <CheckCircle2 className="w-4 h-4" />
                          <span>Approve & Credit Coins ({order.coins.toLocaleString()} 🪙)</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => handleRejectOrder(order.id)}
                          className="px-3 py-2 rounded-xl bg-rose-950/80 hover:bg-rose-900 border border-rose-800 text-rose-300 font-bold text-xs flex items-center space-x-1 transition-colors cursor-pointer"
                        >
                          <XCircle className="w-3.5 h-3.5" />
                          <span>Reject</span>
                        </button>
                      </div>
                    )}
                  </div>
                );
              })
            )}
          </div>
        )}

        {/* Tab 2: Packages Management */}
        {activeTab === 'packages' && (
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-xs font-black uppercase tracking-wider text-neutral-300">
                  Manage Coin & VIP Packages
                </h3>
                <p className="text-[11px] text-neutral-400">
                  Configure coin amounts, ৳ prices, VIP rewards, and entry animations.
                </p>
              </div>

              {!isAddingPackage && !editingPackage && (
                <button
                  onClick={() => setIsAddingPackage(true)}
                  className="px-3 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-neutral-950 text-xs font-black flex items-center space-x-1 shadow-md shadow-amber-500/20"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Add Package</span>
                </button>
              )}
            </div>

            {/* Add New Package Form */}
            {isAddingPackage && (
              <form onSubmit={handleSaveNewPackage} className="p-4 rounded-2xl bg-neutral-900 border border-amber-500/50 space-y-3">
                <div className="flex items-center justify-between border-b border-neutral-800 pb-2">
                  <h4 className="text-xs font-black text-amber-300">New Coin Package</h4>
                  <button
                    type="button"
                    onClick={() => setIsAddingPackage(false)}
                    className="text-xs text-neutral-400 hover:text-white"
                  >
                    Cancel
                  </button>
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div>
                    <label className="text-[10px] text-neutral-400 block mb-0.5">Package Name</label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Starter Pack"
                      value={newPkgData.name}
                      onChange={e => setNewPkgData({ ...newPkgData, name: e.target.value })}
                      className="w-full px-2.5 py-1.5 rounded-lg bg-neutral-950 border border-neutral-800 text-white"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] text-neutral-400 block mb-0.5">Price in BDT (৳)</label>
                    <input
                      type="number"
                      required
                      min={10}
                      placeholder="120"
                      value={newPkgData.priceBdt}
                      onChange={e => setNewPkgData({ ...newPkgData, priceBdt: Number(e.target.value) })}
                      className="w-full px-2.5 py-1.5 rounded-lg bg-neutral-950 border border-neutral-800 text-white font-mono"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] text-neutral-400 block mb-0.5">Coin Amount</label>
                    <input
                      type="number"
                      required
                      min={1000}
                      placeholder="2000000"
                      value={newPkgData.coins}
                      onChange={e => setNewPkgData({ ...newPkgData, coins: Number(e.target.value) })}
                      className="w-full px-2.5 py-1.5 rounded-lg bg-neutral-950 border border-neutral-800 text-white font-mono"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] text-neutral-400 block mb-0.5">VIP Tier Reward</label>
                    <select
                      value={newPkgData.vipTier}
                      onChange={e => {
                        const tier = e.target.value as VipTier;
                        setNewPkgData({
                          ...newPkgData,
                          vipTier: tier,
                          vipCrown: tier === 'SVIP' ? '💎👑' : '👑',
                          entryEffectType: tier === 'SVIP' ? 'svip' : tier === 'VIP_PRO' ? 'vip_pro' : 'vip',
                        });
                      }}
                      className="w-full px-2.5 py-1.5 rounded-lg bg-neutral-950 border border-neutral-800 text-white"
                    >
                      <option value="VIP">👑 VIP</option>
                      <option value="VIP_PRO">🌟 VIP PRO</option>
                      <option value="SVIP">💎 SVIP (Supreme)</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="text-[10px] text-neutral-400 block mb-0.5">Description</label>
                  <input
                    type="text"
                    placeholder="Short description of perks..."
                    value={newPkgData.description}
                    onChange={e => setNewPkgData({ ...newPkgData, description: e.target.value })}
                    className="w-full px-2.5 py-1.5 rounded-lg bg-neutral-950 border border-neutral-800 text-white text-xs"
                  />
                </div>

                <div className="flex justify-end space-x-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setIsAddingPackage(false)}
                    className="px-3 py-1.5 rounded-xl bg-neutral-800 text-neutral-300 text-xs"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-1.5 rounded-xl bg-amber-500 text-neutral-950 text-xs font-black shadow-md"
                  >
                    Save Package
                  </button>
                </div>
              </form>
            )}

            {/* Edit Package Form */}
            {editingPackage && (
              <form onSubmit={handleUpdatePackage} className="p-4 rounded-2xl bg-neutral-900 border border-violet-500/50 space-y-3">
                <div className="flex items-center justify-between border-b border-neutral-800 pb-2">
                  <h4 className="text-xs font-black text-violet-300">Edit Package: {editingPackage.name}</h4>
                  <button
                    type="button"
                    onClick={() => setEditingPackage(null)}
                    className="text-xs text-neutral-400 hover:text-white"
                  >
                    Cancel
                  </button>
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div>
                    <label className="text-[10px] text-neutral-400 block mb-0.5">Package Name</label>
                    <input
                      type="text"
                      required
                      value={editingPackage.name}
                      onChange={e => setEditingPackage({ ...editingPackage, name: e.target.value })}
                      className="w-full px-2.5 py-1.5 rounded-lg bg-neutral-950 border border-neutral-800 text-white"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] text-neutral-400 block mb-0.5">Price in BDT (৳)</label>
                    <input
                      type="number"
                      required
                      value={editingPackage.priceBdt}
                      onChange={e => setEditingPackage({ ...editingPackage, priceBdt: Number(e.target.value) })}
                      className="w-full px-2.5 py-1.5 rounded-lg bg-neutral-950 border border-neutral-800 text-white font-mono"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] text-neutral-400 block mb-0.5">Coin Amount</label>
                    <input
                      type="number"
                      required
                      value={editingPackage.coins}
                      onChange={e => setEditingPackage({ ...editingPackage, coins: Number(e.target.value) })}
                      className="w-full px-2.5 py-1.5 rounded-lg bg-neutral-950 border border-neutral-800 text-white font-mono"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] text-neutral-400 block mb-0.5">VIP Tier Reward</label>
                    <select
                      value={editingPackage.vipTier}
                      onChange={e => {
                        const tier = e.target.value as VipTier;
                        setEditingPackage({
                          ...editingPackage,
                          vipTier: tier,
                          vipCrown: tier === 'SVIP' ? '💎👑' : '👑',
                          entryEffectType: tier === 'SVIP' ? 'svip' : tier === 'VIP_PRO' ? 'vip_pro' : 'vip',
                        });
                      }}
                      className="w-full px-2.5 py-1.5 rounded-lg bg-neutral-950 border border-neutral-800 text-white"
                    >
                      <option value="VIP">👑 VIP</option>
                      <option value="VIP_PRO">🌟 VIP PRO</option>
                      <option value="SVIP">💎 SVIP (Supreme)</option>
                    </select>
                  </div>
                </div>

                <div className="flex justify-end space-x-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setEditingPackage(null)}
                    className="px-3 py-1.5 rounded-xl bg-neutral-800 text-neutral-300 text-xs"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-1.5 rounded-xl bg-violet-600 text-white text-xs font-black shadow-md"
                  >
                    Update Package
                  </button>
                </div>
              </form>
            )}

            {/* Packages Grid */}
            <div className="space-y-2">
              {packages.map(pkg => (
                <div
                  key={pkg.id}
                  className="p-3.5 rounded-2xl bg-neutral-900 border border-neutral-800 flex items-center justify-between"
                >
                  <div className="space-y-1 min-w-0 flex-1 pr-3">
                    <div className="flex items-center space-x-2">
                      <h4 className="text-xs font-bold text-white truncate">{pkg.name}</h4>
                      <span className="text-[10px] font-mono font-bold text-emerald-400">
                        ৳{pkg.priceBdt}
                      </span>
                      <span className="text-[10px] font-black text-amber-300">
                        ({pkg.vipTier})
                      </span>
                    </div>
                    <p className="text-[10px] text-neutral-400 truncate">
                      🪙 {pkg.coins.toLocaleString()} Coins • Entry: {pkg.entryEffectTitle}
                    </p>
                  </div>

                  <div className="flex items-center space-x-1.5 flex-shrink-0">
                    <button
                      onClick={() => handleTogglePackageActive(pkg)}
                      className={`px-2 py-1 rounded-lg text-[10px] font-bold ${
                        pkg.active ? 'bg-emerald-950 text-emerald-300' : 'bg-neutral-800 text-neutral-500'
                      }`}
                      title={pkg.active ? 'Active' : 'Disabled'}
                    >
                      {pkg.active ? 'Active' : 'Disabled'}
                    </button>
                    <button
                      onClick={() => {
                        setEditingPackage(pkg);
                        setIsAddingPackage(false);
                      }}
                      className="p-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-300"
                      title="Edit Package"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => handleDeletePackage(pkg.id, pkg.name)}
                      className="p-1.5 rounded-lg bg-neutral-800 hover:bg-rose-900 text-rose-400"
                      title="Delete Package"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Tab 3: Admin Payment Info & Notice Config */}
        {activeTab === 'contact' && (
          <form onSubmit={handleSaveContactConfig} className="flex-1 overflow-y-auto p-4 space-y-4">
            <div>
              <h3 className="text-xs font-black uppercase tracking-wider text-neutral-300">
                Admin Payment & Contact Configuration
              </h3>
              <p className="text-[11px] text-neutral-400">
                The phone numbers, notice message, and payment instructions shown to users in the Coin Shop.
              </p>
            </div>

            {/* Admin Notice */}
            <div className="space-y-1">
              <label className="text-[11px] text-neutral-300 font-bold block">
                User Notice (Coins কিনতে App Owner/Admin-এর সঙ্গে যোগাযোগ করুন।) *
              </label>
              <input
                type="text"
                required
                value={configForm.adminNotice}
                onChange={e => setConfigForm({ ...configForm, adminNotice: e.target.value })}
                className="w-full px-3 py-2 rounded-xl bg-neutral-900 border border-neutral-800 text-white text-xs focus:outline-none focus:border-amber-500 font-medium"
              />
            </div>

            {/* bKash Details */}
            <div className="grid grid-cols-2 gap-2">
              <div className="space-y-1">
                <label className="text-[11px] text-rose-400 font-bold block">bKash Number *</label>
                <input
                  type="text"
                  required
                  value={configForm.bkashNumber}
                  onChange={e => setConfigForm({ ...configForm, bkashNumber: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-neutral-900 border border-neutral-800 text-white text-xs font-mono"
                />
              </div>
              <div className="space-y-1">
                <label className="text-[11px] text-rose-400 font-bold block">bKash Type</label>
                <select
                  value={configForm.bkashType}
                  onChange={e => setConfigForm({ ...configForm, bkashType: e.target.value as 'Personal' | 'Merchant' })}
                  className="w-full px-3 py-2 rounded-xl bg-neutral-900 border border-neutral-800 text-white text-xs"
                >
                  <option value="Personal">Personal (Send Money)</option>
                  <option value="Merchant">Merchant (Payment)</option>
                </select>
              </div>
            </div>

            {/* Nagad Details */}
            <div className="grid grid-cols-2 gap-2">
              <div className="space-y-1">
                <label className="text-[11px] text-amber-400 font-bold block">Nagad Number *</label>
                <input
                  type="text"
                  required
                  value={configForm.nagadNumber}
                  onChange={e => setConfigForm({ ...configForm, nagadNumber: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-neutral-900 border border-neutral-800 text-white text-xs font-mono"
                />
              </div>
              <div className="space-y-1">
                <label className="text-[11px] text-amber-400 font-bold block">Nagad Type</label>
                <select
                  value={configForm.nagadType}
                  onChange={e => setConfigForm({ ...configForm, nagadType: e.target.value as 'Personal' | 'Merchant' })}
                  className="w-full px-3 py-2 rounded-xl bg-neutral-900 border border-neutral-800 text-white text-xs"
                >
                  <option value="Personal">Personal (Send Money)</option>
                  <option value="Merchant">Merchant (Payment)</option>
                </select>
              </div>
            </div>

            {/* WhatsApp & Telegram */}
            <div className="grid grid-cols-2 gap-2">
              <div className="space-y-1">
                <label className="text-[11px] text-emerald-400 font-bold block">WhatsApp Contact *</label>
                <input
                  type="text"
                  required
                  value={configForm.whatsappNumber}
                  onChange={e => setConfigForm({ ...configForm, whatsappNumber: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-neutral-900 border border-neutral-800 text-white text-xs font-mono"
                />
              </div>
              <div className="space-y-1">
                <label className="text-[11px] text-neutral-300 font-bold block">Telegram Handle</label>
                <input
                  type="text"
                  value={configForm.telegramContact}
                  onChange={e => setConfigForm({ ...configForm, telegramContact: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-neutral-900 border border-neutral-800 text-white text-xs font-mono"
                />
              </div>
            </div>

            {/* Payment Instructions Bengali */}
            <div className="space-y-1">
              <label className="text-[11px] text-neutral-300 font-bold block">Payment Instructions (Bengali)</label>
              <textarea
                rows={3}
                value={configForm.paymentInstructions}
                onChange={e => setConfigForm({ ...configForm, paymentInstructions: e.target.value })}
                className="w-full px-3 py-2 rounded-xl bg-neutral-900 border border-neutral-800 text-white text-xs leading-relaxed"
              />
            </div>

            <button
              type="submit"
              className="w-full py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-neutral-950 font-black text-xs shadow-lg shadow-amber-500/20 transition-all flex items-center justify-center space-x-1.5 cursor-pointer"
            >
              <Save className="w-4 h-4" />
              <span>Save Contact Information & Settings</span>
            </button>
          </form>
        )}

        {/* Tab 4: Financial Ledger & Stats */}
        {activeTab === 'stats' && (
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            <h3 className="text-xs font-black uppercase tracking-wider text-neutral-300">
              Coin Purchase Ledger & Platform Financials
            </h3>

            {/* Top Metric Cards */}
            <div className="grid grid-cols-2 gap-2.5">
              <div className="p-3 rounded-2xl bg-emerald-950/40 border border-emerald-800/60 space-y-1">
                <span className="text-[10px] text-emerald-400 font-bold uppercase tracking-wider block">
                  Total BDT Revenue
                </span>
                <span className="text-lg font-black text-emerald-300 font-mono">
                  ৳{totalRevenueBdt.toLocaleString()}
                </span>
                <p className="text-[10px] text-neutral-400">{approvedOrders.length} verified orders</p>
              </div>

              <div className="p-3 rounded-2xl bg-amber-950/40 border border-amber-800/60 space-y-1">
                <span className="text-[10px] text-amber-400 font-bold uppercase tracking-wider block">
                  Purchased Coins Issued
                </span>
                <span className="text-lg font-black text-amber-300 font-mono">
                  🪙 {totalCoinsDistributed.toLocaleString()}
                </span>
                <p className="text-[10px] text-neutral-400">Strictly verified & credited</p>
              </div>
            </div>

            {/* Audit Notice */}
            <div className="p-3 rounded-xl bg-neutral-900 border border-neutral-800 text-xs text-neutral-400 space-y-1">
              <span className="text-white font-bold block">Authoritative Ledger Guarantee:</span>
              <p className="text-[11px] leading-relaxed">
                Coin balances cannot be spoofed or modified from client-side code. Every coin purchase transaction is strictly anchored to a unique Transaction ID and must be signed off by the Owner/Admin.
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
