import React, { useState } from 'react';
import { User, AtSign, Mail, Lock, Sparkles, ArrowLeft, ArrowRight, Check } from 'lucide-react';
import { authService } from '../services/firebaseService';
import { availableTopics } from '../data/mockData';

interface SignUpScreenProps {
  onSuccess: () => void;
  onNavigateToLogin: () => void;
  onBack: () => void;
}

export const SignUpScreen: React.FC<SignUpScreenProps> = ({
  onSuccess,
  onNavigateToLogin,
  onBack,
}) => {
  const [name, setName] = useState('');
  const [handle, setHandle] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [selectedTopics, setSelectedTopics] = useState<string[]>(['Tech & AI', 'Music & Lo-Fi']);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const toggleTopic = (topic: string) => {
    if (selectedTopics.includes(topic)) {
      setSelectedTopics(selectedTopics.filter(t => t !== topic));
    } else {
      setSelectedTopics([...selectedTopics, topic]);
    }
  };

  const handleSignUp = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setError('Please enter your full name');
      return;
    }
    if (!handle.trim()) {
      setError('Please choose a handle / username');
      return;
    }
    if (!email.trim() || !password.trim()) {
      setError('Please provide an email and password');
      return;
    }

    try {
      setIsLoading(true);
      setError(null);
      await authService.signUpWithEmail(name, handle, email, selectedTopics);
      onSuccess();
    } catch (err: any) {
      setError(err?.message || 'Sign up failed');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div id="signup-screen" className="flex flex-col h-full w-full px-6 py-6 bg-neutral-950 overflow-y-auto">
      {/* Top App Bar */}
      <div className="flex items-center justify-between pt-2 pb-5">
        <button
          id="signup-back-btn"
          onClick={onBack}
          className="p-2 -ml-2 rounded-full text-neutral-400 hover:text-white hover:bg-neutral-900 transition-colors"
          aria-label="Back"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
        <span className="text-xs font-semibold tracking-wider text-violet-400 uppercase">
          New Member
        </span>
        <div className="w-9"></div>
      </div>

      {/* Header */}
      <div className="mb-5">
        <h2 className="text-2xl font-bold text-white tracking-tight">
          Create your Voice Profile
        </h2>
        <p className="text-xs text-neutral-400 mt-1">
          Pick your username and interests to personalize your stages.
        </p>
      </div>

      {error && (
        <div className="mb-4 p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs">
          {error}
        </div>
      )}

      {/* Form */}
      <form onSubmit={handleSignUp} className="space-y-3.5">
        <div>
          <label className="block text-xs font-medium text-neutral-300 mb-1">
            Display Name
          </label>
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-neutral-500">
              <User className="w-4 h-4" />
            </div>
            <input
              id="signup-name-input"
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Jordan Miller"
              className="w-full pl-10 pr-4 py-2.5 bg-neutral-900/90 border border-neutral-800 rounded-xl text-white text-sm placeholder-neutral-500 focus:outline-none focus:border-violet-500 focus:ring-1 focus:ring-violet-500 transition-all"
            />
          </div>
        </div>

        <div>
          <label className="block text-xs font-medium text-neutral-300 mb-1">
            Voice Handle
          </label>
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-neutral-500">
              <AtSign className="w-4 h-4" />
            </div>
            <input
              id="signup-handle-input"
              type="text"
              value={handle}
              onChange={(e) => setHandle(e.target.value)}
              placeholder="jordan_voice"
              className="w-full pl-10 pr-4 py-2.5 bg-neutral-900/90 border border-neutral-800 rounded-xl text-white text-sm placeholder-neutral-500 focus:outline-none focus:border-violet-500 focus:ring-1 focus:ring-violet-500 transition-all"
            />
          </div>
        </div>

        <div>
          <label className="block text-xs font-medium text-neutral-300 mb-1">
            Email
          </label>
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-neutral-500">
              <Mail className="w-4 h-4" />
            </div>
            <input
              id="signup-email-input"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="jordan@example.com"
              className="w-full pl-10 pr-4 py-2.5 bg-neutral-900/90 border border-neutral-800 rounded-xl text-white text-sm placeholder-neutral-500 focus:outline-none focus:border-violet-500 focus:ring-1 focus:ring-violet-500 transition-all"
            />
          </div>
        </div>

        <div>
          <label className="block text-xs font-medium text-neutral-300 mb-1">
            Password
          </label>
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-neutral-500">
              <Lock className="w-4 h-4" />
            </div>
            <input
              id="signup-password-input"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Create strong password"
              className="w-full pl-10 pr-4 py-2.5 bg-neutral-900/90 border border-neutral-800 rounded-xl text-white text-sm placeholder-neutral-500 focus:outline-none focus:border-violet-500 focus:ring-1 focus:ring-violet-500 transition-all"
            />
          </div>
        </div>

        {/* Interests & Topics Selector */}
        <div className="pt-2">
          <div className="flex items-center space-x-1.5 mb-2">
            <Sparkles className="w-3.5 h-3.5 text-violet-400" />
            <label className="text-xs font-semibold text-neutral-200">
              Choose Interests to Follow
            </label>
          </div>
          <div className="flex flex-wrap gap-1.5 max-h-32 overflow-y-auto p-1 bg-neutral-900/50 rounded-xl border border-neutral-800/80">
            {availableTopics.map(topic => {
              const isSelected = selectedTopics.includes(topic);
              return (
                <button
                  key={topic}
                  type="button"
                  onClick={() => toggleTopic(topic)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all flex items-center space-x-1 ${
                    isSelected
                      ? 'bg-violet-600 text-white shadow-sm shadow-violet-600/40'
                      : 'bg-neutral-800/80 text-neutral-300 hover:bg-neutral-800'
                  }`}
                >
                  {isSelected && <Check className="w-3 h-3 stroke-[3]" />}
                  <span>{topic}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Action Button */}
        <button
          id="signup-submit-btn"
          type="submit"
          disabled={isLoading}
          className="w-full mt-4 py-3.5 px-4 rounded-xl bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-500 hover:to-indigo-500 text-white font-semibold text-sm shadow-md shadow-violet-600/30 flex items-center justify-center space-x-2 active:scale-[0.98] transition-all disabled:opacity-50"
        >
          {isLoading ? (
            <span className="inline-block w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></span>
          ) : (
            <>
              <span>Join SNYVO Club</span>
              <ArrowRight className="w-4 h-4" />
            </>
          )}
        </button>
      </form>

      {/* Footer */}
      <div className="mt-auto pt-6 pb-4 text-center">
        <p className="text-xs text-neutral-400">
          Already have an account?{' '}
          <button
            id="signup-goto-login-btn"
            onClick={onNavigateToLogin}
            className="text-violet-400 hover:underline font-medium"
          >
            Sign in
          </button>
        </p>
      </div>
    </div>
  );
};
