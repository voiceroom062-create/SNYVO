import React, { useEffect, useState } from 'react';
import { Radio, Sparkles, ArrowRight } from 'lucide-react';

interface SplashScreenProps {
  onContinue: () => void;
  onLoginClick: () => void;
  onSignUpClick: () => void;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({
  onContinue,
  onLoginClick,
  onSignUpClick,
}) => {
  const [pulse, setPulse] = useState(false);

  useEffect(() => {
    const timer = setInterval(() => {
      setPulse(p => !p);
    }, 1200);
    return () => clearInterval(timer);
  }, []);

  return (
    <div
      id="splash-screen"
      className="relative flex flex-col justify-between items-center h-full w-full px-6 py-12 bg-gradient-to-b from-neutral-950 via-neutral-900 to-neutral-950 overflow-hidden text-center select-none"
    >
      {/* Ambient background glow */}
      <div className="absolute top-1/4 -left-20 w-72 h-72 bg-violet-600/20 rounded-full blur-3xl pointer-events-none"></div>
      <div className="absolute bottom-1/4 -right-20 w-72 h-72 bg-indigo-600/20 rounded-full blur-3xl pointer-events-none"></div>

      {/* Top Branding Tag */}
      <div className="pt-6 flex items-center space-x-2 text-xs font-semibold tracking-widest text-violet-400 uppercase">
        <Sparkles className="w-3.5 h-3.5" />
        <span>Next-Gen Audio Social</span>
      </div>

      {/* Center Soundwave Emblem */}
      <div className="relative flex flex-col items-center justify-center my-auto">
        <div className="relative flex items-center justify-center">
          {/* Animated acoustic concentric ripples */}
          <div className={`absolute w-44 h-44 rounded-full border border-violet-500/20 transition-all duration-1000 ${pulse ? 'scale-125 opacity-40' : 'scale-100 opacity-20'}`}></div>
          <div className={`absolute w-36 h-36 rounded-full border border-violet-500/30 transition-all duration-1000 ${pulse ? 'scale-115 opacity-60' : 'scale-95 opacity-30'}`}></div>
          <div className={`absolute w-28 h-28 rounded-full bg-violet-600/10 transition-all duration-700 ${pulse ? 'scale-105' : 'scale-90'}`}></div>

          {/* Logo Icon Core */}
          <div className="relative w-20 h-20 rounded-3xl bg-gradient-to-tr from-violet-600 to-indigo-500 p-0.5 shadow-2xl shadow-violet-600/50 flex items-center justify-center">
            <div className="w-full h-full bg-neutral-950 rounded-[22px] flex items-center justify-center">
              <div className="flex items-center space-x-1">
                <span className="w-1 h-5 bg-violet-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></span>
                <span className="w-1 h-8 bg-violet-300 rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></span>
                <span className="w-1 h-10 bg-indigo-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></span>
                <span className="w-1 h-6 bg-violet-300 rounded-full animate-bounce" style={{ animationDelay: '450ms' }}></span>
                <span className="w-1 h-4 bg-violet-500 rounded-full animate-bounce" style={{ animationDelay: '600ms' }}></span>
              </div>
            </div>
          </div>
        </div>

        <h1 className="mt-8 text-4xl font-extrabold tracking-tight text-white font-sans">
          SNYVO
        </h1>
        <p className="mt-2 text-sm text-neutral-400 max-w-xs font-normal">
          Real-time conversations, live stage salons & audio clubs for thoughtful minds.
        </p>

        {/* Live indicator tag */}
        <div className="mt-4 inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-neutral-800/80 border border-neutral-700/60 text-xs text-neutral-300">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
          <span>1,840+ Voice Rooms Active</span>
        </div>
      </div>

      {/* Bottom Action CTAs */}
      <div className="w-full space-y-3 pb-4">
        <button
          id="splash-get-started-btn"
          onClick={onSignUpClick}
          className="w-full py-3.5 px-6 rounded-2xl bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-500 hover:to-indigo-500 text-white font-semibold text-sm shadow-lg shadow-violet-600/30 flex items-center justify-center space-x-2 active:scale-[0.98] transition-all"
        >
          <span>Join the Club</span>
          <ArrowRight className="w-4 h-4" />
        </button>

        <button
          id="splash-login-btn"
          onClick={onLoginClick}
          className="w-full py-3.5 px-6 rounded-2xl bg-neutral-900/80 hover:bg-neutral-800 border border-neutral-800 text-neutral-200 font-medium text-sm transition-colors active:scale-[0.98]"
        >
          I already have an account
        </button>

        <button
          id="splash-guest-btn"
          onClick={onContinue}
          className="text-xs text-neutral-400 hover:text-violet-400 pt-1 transition-colors"
        >
          Explore Live Stages as Guest →
        </button>
      </div>
    </div>
  );
};
