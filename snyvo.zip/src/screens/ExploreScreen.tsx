import React, { useState } from 'react';
import { Search, Hash, Sparkles, Flame, Mic, Radio, Users, ChevronRight } from 'lucide-react';
import { VoiceRoom, User } from '../types';

interface ExploreScreenProps {
  rooms: VoiceRoom[];
  onJoinRoom: (room: VoiceRoom) => void;
}

export const ExploreScreen: React.FC<ExploreScreenProps> = ({
  rooms,
  onJoinRoom,
}) => {
  const [query, setQuery] = useState('');

  const trendingClubs = [
    { name: 'Midnight Thinkers', members: '14.2k members', topic: 'Philosophy & Late Chill' },
    { name: 'Future of AI', members: '28.9k members', topic: 'Conversational Voice & LLMs' },
    { name: 'Indie Builders Club', members: '9.4k members', topic: 'SaaS, Apps & Bootstrapping' },
    { name: 'Tokyo Ambient Sound', members: '6.1k members', topic: 'Field recordings & beats' },
  ];

  return (
    <div id="explore-screen" className="flex flex-col h-full w-full bg-neutral-950 text-white overflow-y-auto pb-24 px-5 pt-3">
      <div className="pb-3 border-b border-neutral-900">
        <h2 className="text-xl font-bold text-white">Discover & Clubs</h2>
        <p className="text-xs text-neutral-400 mt-0.5">Find new voice salons, hosts, and topic clubs</p>
      </div>

      <div className="pt-4">
        <div className="relative">
          <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-neutral-500">
            <Search className="w-4 h-4" />
          </div>
          <input
            type="text"
            value={query}
            onChange={e => setQuery(e.target.value)}
            placeholder="Search audio channels, clubs, creators..."
            className="w-full pl-10 pr-4 py-2.5 bg-neutral-900 border border-neutral-800 rounded-xl text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-violet-500"
          />
        </div>
      </div>

      {/* Trending Clubs */}
      <div className="pt-6">
        <div className="flex items-center space-x-1.5 mb-3">
          <Flame className="w-4 h-4 text-amber-500" />
          <h3 className="text-xs font-bold uppercase tracking-wider text-neutral-300">
            Trending Voice Clubs
          </h3>
        </div>

        <div className="space-y-2.5">
          {trendingClubs.map(club => (
            <div
              key={club.name}
              className="p-3.5 rounded-2xl bg-neutral-900/60 border border-neutral-800/80 flex items-center justify-between hover:border-violet-500/30 transition-all"
            >
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-violet-600/30 to-indigo-600/30 border border-violet-500/30 flex items-center justify-center text-sm font-bold text-violet-300">
                  {club.name.charAt(0)}
                </div>
                <div>
                  <h4 className="text-xs font-bold text-white">{club.name}</h4>
                  <p className="text-[11px] text-neutral-400">{club.topic}</p>
                  <span className="text-[10px] text-violet-400 font-medium">{club.members}</span>
                </div>
              </div>
              <button className="px-3 py-1.5 rounded-xl bg-neutral-800 hover:bg-violet-600 text-neutral-200 hover:text-white text-xs font-semibold transition-colors">
                Join
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Active rooms in explore */}
      <div className="pt-6">
        <div className="flex items-center space-x-1.5 mb-3">
          <Radio className="w-4 h-4 text-emerald-400 animate-pulse" />
          <h3 className="text-xs font-bold uppercase tracking-wider text-neutral-300">
            Active Stage Salons
          </h3>
        </div>

        <div className="space-y-2.5">
          {rooms.map(room => (
            <div
              key={`exp-${room.id}`}
              onClick={() => onJoinRoom(room)}
              className="p-3.5 rounded-2xl bg-neutral-900/40 border border-neutral-800/60 hover:border-violet-500/40 cursor-pointer flex items-center justify-between"
            >
              <div className="min-w-0 flex-1 pr-2">
                <span className="text-[10px] font-bold text-violet-400 uppercase tracking-wider">{room.clubName}</span>
                <h5 className="text-xs font-bold text-white truncate">{room.title}</h5>
                <p className="text-[10px] text-neutral-400">{room.listenerCount} listeners • {room.speakers.length} speakers</p>
              </div>
              <ChevronRight className="w-4 h-4 text-neutral-500" />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
