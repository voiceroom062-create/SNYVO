import React, { useState, useMemo, useEffect } from 'react';
import {
  Search,
  Users,
  Radio,
  Sparkles,
  ChevronRight,
  Mic,
  Gift,
  Flame,
  Volume2,
  X,
  Trophy,
  ArrowUpRight,
  TrendingUp,
  Music2,
  Crown,
  Diamond,
  Zap,
  Gamepad2,
  MessageCircle
} from 'lucide-react';
import { VoiceRoom, User, ScreenType } from '../types';
import { vipService, VIP_TIER_CONFIGS } from '../coins/vipService';
import { getNumericUserId } from '../services/userService';

interface HomeScreenProps {
  currentUser: User;
  rooms: VoiceRoom[];
  onJoinRoom: (room: VoiceRoom) => void;
  onNavigate: (screen: ScreenType) => void;
  onOpenCreateRoom: () => void;
  onOpenProfile?: (user: User) => void;
  showBottomNav?: boolean;
}

export type CategoryTab = 'Related' | 'Popular' | 'Discover' | 'New';
export type HomeBottomNavSection = 'match' | 'group' | 'game' | 'plaza' | 'chat';

interface PromotionalBanner {
  id: string;
  badge: string;
  badgeBg: string;
  title: string;
  subtitle: string;
  tagline: string;
  gradient: string;
  actionText: string;
  icon: React.ReactNode;
}

const PROMO_BANNERS: PromotionalBanner[] = [
  {
    id: 'b1',
    badge: '🔥 SNYVO GALA',
    badgeBg: 'bg-gradient-to-r from-amber-500 to-rose-500 text-white',
    title: 'SNYVO Cosmic Voice Gala 🎙️',
    subtitle: 'Top Audio Creators, Singers & RJ Stage Live Tonight',
    tagline: '🪙 50,000,000 Coin Rewards Pool',
    gradient: 'from-violet-950/90 via-purple-950/70 to-neutral-900',
    actionText: 'Join Stage',
    icon: <Radio className="w-5 h-5 text-amber-300 animate-pulse" />,
  },
  {
    id: 'b2',
    badge: '💎 VIP PERKS',
    badgeBg: 'bg-gradient-to-r from-cyan-400 to-fuchsia-500 text-neutral-950 font-black',
    title: 'SNYVO VIP 1–10 & SVIP Crown System 👑',
    subtitle: 'Daily Free Coins, Elite Badges & Custom Stage Effects',
    tagline: '✨ Exclusive Crown Perks & Profile Flair',
    gradient: 'from-neutral-900 via-indigo-950/80 to-purple-950/90',
    actionText: 'Explore VIP',
    icon: <Crown className="w-5 h-5 text-amber-400" />,
  },
  {
    id: 'b3',
    badge: '🎙️ GO LIVE',
    badgeBg: 'bg-gradient-to-r from-emerald-500 to-teal-400 text-neutral-950 font-black',
    title: 'Host Your SNYVO Voice Salon 🚀',
    subtitle: 'Share live audio, invite guests & receive interactive gifts',
    tagline: '✨ 30% Receiver Share Directly Credited',
    gradient: 'from-emerald-950/70 via-neutral-950 to-violet-950/80',
    actionText: 'Go Live',
    icon: <Mic className="w-5 h-5 text-emerald-400" />,
  },
];

export const HomeScreen: React.FC<HomeScreenProps> = ({
  currentUser,
  rooms,
  onJoinRoom,
  onNavigate,
  onOpenCreateRoom,
  onOpenProfile,
  showBottomNav,
}) => {
  // Requirement 1: Make "Related" selected by default
  const [selectedTab, setSelectedTab] = useState<CategoryTab>('Related');
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [currentBannerIndex, setCurrentBannerIndex] = useState(0);
  const [hasGlobalNavBar, setHasGlobalNavBar] = useState(false);
  const [activeBottomTab, setActiveBottomTab] = useState<HomeBottomNavSection>('plaza');

  const tabs: CategoryTab[] = ['Related', 'Popular', 'Discover', 'New'];

  // Check if App shell already renders AndroidNavBar at container level
  useEffect(() => {
    if (typeof document !== 'undefined' && document.getElementById('android-bottom-nav')) {
      setHasGlobalNavBar(true);
    }
  }, []);

  // Determine if standalone bottom nav should be rendered
  const shouldRenderBottomNav = showBottomNav === true || (showBottomNav === undefined && !hasGlobalNavBar);

  // Rotate banner automatically
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentBannerIndex((prev) => (prev + 1) % PROMO_BANNERS.length);
    }, 4500);
    return () => clearInterval(timer);
  }, []);

  // Format coins into readable K/M suffix
  const formatCoinDisplay = (coins: number) => {
    if (!coins) return '0';
    if (coins >= 1000000) return `${(coins / 1000000).toFixed(1)}M`;
    if (coins >= 1000) return `${Math.round(coins / 1000)}K`;
    return coins.toLocaleString();
  };

  /**
   * ROOM RANKING LOGIC:
   * Dynamically prioritize rooms based on:
   * 1. High real-time activity (active speakers, speaking audio signals)
   * 2. High number of active users (listeners)
   * 3. High amount of coins/gifts received (roomCoins)
   * 4. High gifting activity (giftsReceivedCount)
   * 5. Recent engagement (startedAt recency)
   * 6. Trending/popular status (isHot flag)
   *
   * Ready for real-time ranking data from the backend.
   */
  const computeRoomScore = (room: VoiceRoom): number => {
    let score = 0;

    // 1. Real-time activity (speakers speaking + total speakers)
    const speakingSpeakers = room.speakers?.filter((s) => s.isSpeaking).length || 0;
    score += speakingSpeakers * 120;
    score += (room.speakers?.length || 0) * 35;

    // 2. High number of active users (listener count)
    score += (room.listenerCount || 0) * 12;

    // 3. High amount of coins/gifts received
    const coinPoints = Math.min((room.roomCoins || 0) / 10000, 500);
    score += coinPoints;

    // 4. High gifting activity
    score += (room.giftsReceivedCount || 0) * 10;

    // 5. Trending / popular status
    if (room.isHot || (room.listenerCount || 0) >= 300) {
      score += 450;
    }

    return score;
  };

  // Rank and filter rooms based on active tab and search query
  const rankedRooms = useMemo(() => {
    // 1. Filter by search query if user typed anything
    let pool = rooms.filter((r) => {
      if (!searchQuery.trim()) return true;
      const query = searchQuery.toLowerCase();
      return (
        r.title.toLowerCase().includes(query) ||
        r.host.name.toLowerCase().includes(query) ||
        (r.clubName && r.clubName.toLowerCase().includes(query)) ||
        r.tags.some((t) => t.toLowerCase().includes(query)) ||
        (r.country && r.country.toLowerCase().includes(query))
      );
    });

    // 2. Sort dynamically according to the selected Category Tab
    const sorted = [...pool].sort((a, b) => {
      const scoreA = computeRoomScore(a);
      const scoreB = computeRoomScore(b);

      if (selectedTab === 'Popular') {
        // Pure high engagement & activity ranking
        return scoreB - scoreA;
      }

      if (selectedTab === 'Related') {
        // Prioritize rooms matching current user's clubs, interests, or host connections
        const matchesUserInterestA =
          currentUser.interests?.some((i) => a.tags.includes(i) || a.topic.includes(i)) ||
          currentUser.clubs?.some((c) => a.clubName === c);
        const matchesUserInterestB =
          currentUser.interests?.some((i) => b.tags.includes(i) || b.topic.includes(i)) ||
          currentUser.clubs?.some((c) => b.clubName === c);

        if (matchesUserInterestA && !matchesUserInterestB) return -1;
        if (!matchesUserInterestA && matchesUserInterestB) return 1;
        return scoreB - scoreA;
      }

      if (selectedTab === 'New') {
        // Most recently started rooms first
        const isMinAgoA = a.startedAt.includes('m ago');
        const isMinAgoB = b.startedAt.includes('m ago');
        if (isMinAgoA && !isMinAgoB) return -1;
        if (!isMinAgoA && isMinAgoB) return 1;
        return scoreB - scoreA;
      }

      if (selectedTab === 'Discover') {
        // Diverse mix balancing high engagement and discovery freshness
        return scoreB - scoreA;
      }

      return scoreB - scoreA;
    });

    return sorted;
  }, [rooms, selectedTab, searchQuery, currentUser]);

  const activeBanner = PROMO_BANNERS[currentBannerIndex];

  return (
    <div
      id="snyvo-home-screen"
      className="flex flex-col h-full w-full bg-neutral-950 text-white overflow-y-auto pb-28 select-none scrollbar-none"
    >
      {/* ========================================================================= */}
      {/* TOP SECTION: Avatar, Horizontal Tabs (Related, Popular, Discover, New), Search */}
      {/* ========================================================================= */}
      <header
        id="home-top-section"
        className="sticky top-0 bg-neutral-950/95 backdrop-blur-xl border-b border-neutral-900/80 px-3.5 pt-3 pb-2.5 z-20"
      >
        <div className="flex items-center justify-between gap-2">
          {/* Top-Left: User's circular profile avatar */}
          <button
            type="button"
            id="top-profile-avatar-btn"
            onClick={() => {
              if (onOpenProfile) {
                onOpenProfile(currentUser);
              } else {
                onNavigate('profile');
              }
            }}
            className="relative flex-shrink-0 group cursor-pointer focus:outline-none"
            aria-label="Open User Profile"
            title="Open Profile"
          >
            <div className="w-10 h-10 rounded-full p-0.5 bg-gradient-to-tr from-violet-600 via-indigo-500 to-fuchsia-500 ring-1 ring-violet-400/40 group-hover:ring-violet-400 transition-all shadow-md shadow-violet-950/40">
              <img
                src={currentUser.avatar}
                alt={currentUser.name}
                className="w-full h-full rounded-full object-cover border border-neutral-950"
              />
            </div>
            {/* Online green indicator */}
            <span
              className="absolute bottom-0 right-0 w-3 h-3 bg-emerald-500 rounded-full border-2 border-neutral-950 shadow-sm"
              title="Online"
            />
          </button>

          {/* Immediately beside avatar: Horizontal category tabs */}
          <div
            id="home-category-tabs"
            className="flex-1 overflow-x-auto scrollbar-none flex items-center space-x-1.5 px-1"
          >
            {tabs.map((tab) => {
              const isSelected = selectedTab === tab;
              return (
                <button
                  key={tab}
                  type="button"
                  id={`tab-${tab.toLowerCase()}`}
                  onClick={() => setSelectedTab(tab)}
                  className={`px-3.5 py-1.5 rounded-full text-xs font-bold transition-all duration-200 whitespace-nowrap cursor-pointer flex-shrink-0 focus:outline-none ${
                    isSelected
                      ? 'bg-gradient-to-r from-violet-600 to-indigo-600 text-white shadow-lg shadow-violet-900/40 border border-violet-400/30 scale-105'
                      : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-900/60 font-medium'
                  }`}
                >
                  {tab}
                </button>
              );
            })}
          </div>

          {/* Top-Right: Search icon */}
          <button
            type="button"
            id="home-search-toggle-btn"
            onClick={() => setIsSearchOpen((prev) => !prev)}
            className={`p-2 rounded-full transition-colors flex-shrink-0 cursor-pointer ${
              isSearchOpen
                ? 'bg-violet-600/30 text-violet-300 border border-violet-500/40'
                : 'text-neutral-400 hover:text-white hover:bg-neutral-900'
            }`}
            aria-label="Toggle Search"
            title="Search voice rooms"
          >
            {isSearchOpen ? <X className="w-5 h-5" /> : <Search className="w-5 h-5" />}
          </button>
        </div>

        {/* Expandable Search Input Bar */}
        {isSearchOpen && (
          <div className="mt-2.5 pt-1 animate-fadeIn">
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-neutral-500">
                <Search className="w-4 h-4" />
              </div>
              <input
                id="home-search-bar"
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                autoFocus
                placeholder="Search rooms, Bangladeshi singers, clubs, hosts..."
                className="w-full pl-9 pr-8 py-2 bg-neutral-900/90 border border-violet-800/40 rounded-xl text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-violet-500 transition-colors"
              />
              {searchQuery && (
                <button
                  type="button"
                  onClick={() => setSearchQuery('')}
                  className="absolute inset-y-0 right-0 pr-2.5 flex items-center text-xs text-neutral-400 hover:text-white"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          </div>
        )}
      </header>

      {/* ========================================================================= */}
      {/* BANNER SECTION: Large Rounded Promotional Banner */}
      {/* ========================================================================= */}
      <section id="home-banner-section" className="px-3.5 pt-3 pb-1">
        <div
          id="promo-banner-card"
          className={`relative rounded-3xl overflow-hidden border border-neutral-800/80 bg-gradient-to-br ${activeBanner.gradient} p-4 sm:p-5 shadow-2xl transition-all duration-300`}
        >
          {/* Subtle decorative glow */}
          <div className="absolute -top-10 -right-10 w-36 h-36 bg-violet-600/20 rounded-full blur-2xl pointer-events-none" />
          <div className="absolute -bottom-10 -left-10 w-32 h-32 bg-fuchsia-600/15 rounded-full blur-2xl pointer-events-none" />

          {/* Banner content */}
          <div className="relative z-10 flex flex-col justify-between space-y-3">
            <div className="flex items-center justify-between">
              <span
                className={`text-[10px] font-black uppercase tracking-wider px-2.5 py-0.5 rounded-full border border-white/20 shadow-sm ${activeBanner.badgeBg}`}
              >
                {activeBanner.badge}
              </span>
              <div className="flex items-center space-x-1.5 text-xs text-neutral-300 font-medium">
                {activeBanner.icon}
                <span className="text-[11px] text-violet-300 font-bold">SNYVO Live</span>
              </div>
            </div>

            <div>
              <h2 className="text-base sm:text-lg font-black text-white tracking-tight leading-tight">
                {activeBanner.title}
              </h2>
              <p className="text-xs text-neutral-300 font-medium mt-1 leading-relaxed">
                {activeBanner.subtitle}
              </p>
              <div className="flex items-center space-x-1 mt-1 text-[11px] text-amber-300 font-semibold">
                <Sparkles className="w-3.5 h-3.5 text-amber-400 flex-shrink-0" />
                <span>{activeBanner.tagline}</span>
              </div>
            </div>

            {/* Action Row & Carousel Indicators */}
            <div className="flex items-center justify-between pt-1">
              <button
                type="button"
                onClick={() => {
                  if (activeBanner.id === 'b3') {
                    onOpenCreateRoom();
                  } else if (rankedRooms.length > 0) {
                    onJoinRoom(rankedRooms[0]);
                  }
                }}
                className="px-4 py-1.5 rounded-xl bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-500 hover:to-indigo-500 text-white text-xs font-extrabold shadow-md shadow-violet-950/60 flex items-center space-x-1 transition-all active:scale-95 cursor-pointer"
              >
                <span>{activeBanner.actionText}</span>
                <ChevronRight className="w-3.5 h-3.5 stroke-[2.5]" />
              </button>

              {/* Dot Indicators */}
              <div className="flex items-center space-x-1.5">
                {PROMO_BANNERS.map((_, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => setCurrentBannerIndex(idx)}
                    className={`h-1.5 rounded-full transition-all duration-200 cursor-pointer ${
                      currentBannerIndex === idx
                        ? 'w-5 bg-gradient-to-r from-violet-400 to-indigo-400'
                        : 'w-1.5 bg-neutral-700 hover:bg-neutral-600'
                    }`}
                    aria-label={`Slide ${idx + 1}`}
                  />
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ========================================================================= */}
      {/* LIVE HOSTS QUICK STRIP (Preserved & Enhanced) */}
      {/* ========================================================================= */}
      <section className="px-3.5 pt-3 pb-1">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center space-x-1.5 text-xs font-bold text-neutral-300">
            <Radio className="w-3.5 h-3.5 text-rose-500 animate-pulse" />
            <span>Live Voice Hosts</span>
            <span className="text-[10px] text-neutral-500 font-normal">
              ({rankedRooms.length} active)
            </span>
          </div>

          <button
            type="button"
            onClick={onOpenCreateRoom}
            className="text-[11px] text-violet-400 hover:text-violet-300 font-bold flex items-center space-x-0.5 cursor-pointer"
          >
            <span>+ Go Live</span>
          </button>
        </div>

        <div className="flex items-center space-x-3 overflow-x-auto scrollbar-none py-1">
          {/* Start Room Quick Bubble */}
          <div
            onClick={onOpenCreateRoom}
            className="flex flex-col items-center flex-shrink-0 cursor-pointer group"
          >
            <div className="w-13 h-13 rounded-full border-2 border-dashed border-violet-500/70 group-hover:border-violet-400 flex items-center justify-center bg-violet-950/30 group-hover:bg-violet-900/40 transition-all">
              <Mic className="w-5 h-5 text-violet-400 group-hover:scale-110 transition-transform" />
            </div>
            <span className="text-[10px] mt-1 text-neutral-300 font-medium">Start</span>
          </div>

          {rankedRooms.slice(0, 7).map((room) => {
            const speaker = room.speakers.find((s) => s.isSpeaking) || room.host;
            return (
              <div
                key={`host-bubble-${room.id}`}
                onClick={() => onJoinRoom(room)}
                className="flex flex-col items-center flex-shrink-0 cursor-pointer group"
              >
                <div className="relative">
                  <div className="w-13 h-13 rounded-full p-0.5 bg-gradient-to-tr from-rose-500 via-violet-500 to-indigo-500 group-hover:ring-2 group-hover:ring-violet-400 transition-all">
                    <img
                      src={speaker.avatar}
                      alt={speaker.name}
                      className="w-full h-full rounded-full object-cover border-2 border-neutral-950"
                    />
                  </div>
                  <span className="absolute -bottom-0.5 -right-0.5 px-1 py-0.2 bg-rose-600 text-[8px] font-black text-white uppercase rounded-full border border-neutral-950">
                    LIVE
                  </span>
                </div>
                <span className="text-[10px] mt-1 text-neutral-300 font-medium truncate max-w-[58px]">
                  {speaker.name.split(' ')[0]}
                </span>
              </div>
            );
          })}
        </div>
      </section>

      {/* ========================================================================= */}
      {/* VOICE ROOM LIST: Vertically Scrollable List of Live Voice Rooms */}
      {/* ========================================================================= */}
      <section id="home-room-list" className="px-3.5 pt-3 space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <h3 className="text-sm font-black text-white tracking-tight flex items-center space-x-1.5">
              <span>{selectedTab} Voice Rooms</span>
            </h3>
            <span className="px-2 py-0.5 rounded-full bg-violet-950/60 border border-violet-800/40 text-[10px] font-bold text-violet-300">
              {rankedRooms.length} Live
            </span>
          </div>

          <span className="text-[11px] text-neutral-400 font-medium flex items-center space-x-1">
            <TrendingUp className="w-3.5 h-3.5 text-emerald-400" />
            <span>Ranked by Activity</span>
          </span>
        </div>

        {/* Empty State if no rooms match */}
        {rankedRooms.length === 0 ? (
          <div className="py-12 text-center bg-neutral-900/40 rounded-3xl border border-neutral-800/70 p-6 space-y-3">
            <Volume2 className="w-10 h-10 text-neutral-500 mx-auto" />
            <h4 className="text-sm font-bold text-neutral-200">No active rooms found</h4>
            <p className="text-xs text-neutral-400 max-w-xs mx-auto">
              No live voice rooms match your current search. Start your own live salon!
            </p>
            <button
              type="button"
              onClick={onOpenCreateRoom}
              className="mt-2 px-5 py-2 rounded-xl bg-gradient-to-r from-violet-600 to-indigo-600 text-white text-xs font-bold shadow-lg shadow-violet-950/50 cursor-pointer"
            >
              Start Room Now
            </button>
          </div>
        ) : (
          rankedRooms.map((room) => {
            // Determine host info and badges
            const hostLevel =
              room.host.level ||
              (room.host.roomsHosted ? Math.min(35, 5 + Math.floor(room.host.roomsHosted / 5)) : 10);
            const hostVipTier = vipService.getUserVipTier(room.host.id);
            const isSvip = hostVipTier === 'SVIP';
            const isVipPro = hostVipTier === 'VIP_PRO';
            const isVip = hostVipTier === 'VIP';
            
            // Real active-user count (listeners in audience + speakers on stage)
            const activeUserCount = (room.listenerCount || 0) + (room.speakers?.length || 0);
            const isTrending =
              room.isHot || activeUserCount >= 250 || (room.roomCoins || 0) >= 2000000;

            // Cover image fallback
            const coverImage =
              room.coverImage ||
              (room.topic.includes('Music')
                ? 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=400&auto=format&fit=crop&q=80'
                : room.topic.includes('Tech') || room.topic.includes('AI')
                ? 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=400&auto=format&fit=crop&q=80'
                : room.topic.includes('Game')
                ? 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=400&auto=format&fit=crop&q=80'
                : 'https://images.unsplash.com/photo-1465847899084-d164df4dedc6?w=400&auto=format&fit=crop&q=80');

            // Country indicator (Defaults to Bangladesh 🇧🇩 for Bangladeshi rooms)
            const isBangladesh =
              room.countryCode === 'BD' ||
              room.country?.toLowerCase().includes('bangladesh') ||
              room.title.toLowerCase().includes('dhaka') ||
              room.title.toLowerCase().includes('bangla') ||
              room.tags.some((t) => t.toLowerCase() === 'bd' || t.toLowerCase() === 'bangla');

            return (
              <div
                key={room.id}
                id={`voice-room-card-${room.id}`}
                onClick={() => onJoinRoom(room)}
                className="relative bg-gradient-to-b from-neutral-900/90 to-neutral-900/50 hover:from-neutral-850 hover:to-neutral-900/90 border border-neutral-800/80 hover:border-violet-600/50 rounded-2xl p-3 sm:p-3.5 transition-all duration-200 cursor-pointer shadow-lg shadow-black/30 group active:scale-[0.99]"
              >
                <div className="flex items-start space-x-3">
                  {/* ========================================================= */}
                  {/* Left Column: Room cover / avatar image + HOT Badge overlay */}
                  {/* ========================================================= */}
                  <div className="relative w-22 h-22 sm:w-24 sm:h-24 rounded-2xl overflow-hidden flex-shrink-0 shadow-md border border-neutral-800">
                    <img
                      src={coverImage}
                      alt={room.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />

                    {/* Dark gradient overlay on bottom of cover */}
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent pointer-events-none" />

                    {/* HOT Badge when trending or highly active */}
                    {isTrending && (
                      <div className="absolute top-1.5 left-1.5 z-10 flex items-center space-x-0.5 bg-gradient-to-r from-amber-500 to-rose-600 text-white text-[9px] font-black uppercase px-1.5 py-0.5 rounded-md shadow-md">
                        <Flame className="w-2.5 h-2.5 fill-current animate-pulse" />
                        <span>HOT</span>
                      </div>
                    )}

                    {/* Sound Waves & Live count overlay on bottom of thumbnail */}
                    <div className="absolute bottom-1.5 left-1.5 right-1.5 z-10 flex items-center justify-between text-[10px] text-white font-bold">
                      <div className="flex items-end space-x-0.5 h-2.5">
                        <span className="w-0.5 h-2 bg-emerald-400 rounded-full animate-bounce" />
                        <span className="w-0.5 h-3 bg-emerald-400 rounded-full animate-bounce [animation-delay:0.2s]" />
                        <span className="w-0.5 h-1.5 bg-emerald-400 rounded-full animate-bounce [animation-delay:0.4s]" />
                      </div>
                      <span className="text-[10px] font-mono text-neutral-200" title={`${activeUserCount} total active`}>
                        {activeUserCount}
                      </span>
                    </div>
                  </div>

                  {/* ========================================================= */}
                  {/* Right Column: Room Name, Host, Badges, Activity, Gifts    */}
                  {/* ========================================================= */}
                  <div className="flex-1 min-w-0 flex flex-col justify-between space-y-1.5">
                    {/* Header Row: Room Name & Country Flag Badge */}
                    <div className="flex items-start justify-between gap-1.5">
                      <h4 className="text-sm font-bold text-white group-hover:text-violet-200 transition-colors line-clamp-1 leading-snug">
                        {room.title}
                      </h4>

                      {/* Bangladesh flag or user's country indicator */}
                      <span
                        className="inline-flex items-center space-x-1 text-[10px] font-bold px-1.5 py-0.5 rounded-md bg-emerald-950/80 border border-emerald-700/50 text-emerald-300 flex-shrink-0"
                        title={isBangladesh ? 'Bangladesh Voice Club' : 'International'}
                      >
                        <span>{isBangladesh ? '🇧🇩 BD' : '🌐 Global'}</span>
                      </span>
                    </div>

                    {/* Host info row: Avatar, Host name, Host level, VIP Badge */}
                    <div className="flex items-center space-x-1.5 flex-wrap gap-y-1">
                      {/* Host avatar */}
                      <img
                        src={room.host.avatar}
                        alt={room.host.name}
                        className="w-4 h-4 rounded-full object-cover ring-1 ring-neutral-700 flex-shrink-0"
                      />

                      {/* Host name */}
                      <span className="text-xs text-neutral-300 font-semibold truncate max-w-[100px]">
                        {room.host.name}
                      </span>

                      {/* Host Level Badge */}
                      <span className="text-[9px] font-black px-1.5 py-0.2 rounded-full bg-gradient-to-r from-violet-600 to-indigo-600 text-white border border-violet-400/40">
                        Lv.{hostLevel}
                      </span>

                      {/* VIP / SVIP Badge if applicable */}
                      {isSvip ? (
                        <span className="text-[9px] font-black uppercase px-1.5 py-0.2 rounded-full bg-gradient-to-r from-cyan-500 to-fuchsia-500 text-neutral-950 shadow-sm flex items-center space-x-0.5">
                          <Diamond className="w-2.5 h-2.5 fill-current" />
                          <span>SVIP</span>
                        </span>
                      ) : isVipPro ? (
                        <span className="text-[9px] font-black uppercase px-1.5 py-0.2 rounded-full bg-gradient-to-r from-purple-500 to-pink-500 text-white shadow-sm flex items-center space-x-0.5">
                          <span>👑 PRO</span>
                        </span>
                      ) : isVip ? (
                        <span className="text-[9px] font-black uppercase px-1.5 py-0.2 rounded-full bg-gradient-to-r from-amber-500 to-yellow-400 text-neutral-950 shadow-sm">
                          👑 VIP
                        </span>
                      ) : null}
                    </div>

                    {/* Short room description */}
                    <p className="text-xs text-neutral-400 line-clamp-1 leading-relaxed">
                      {room.description || 'Join live stage discussion, chat, and acoustic vibes.'}
                    </p>

                    {/* Bottom Row: Active-User Count, Gift/Activity Indicator, Visual Badges */}
                    <div className="flex items-center justify-between pt-1 border-t border-neutral-800/60 text-xs">
                      <div className="flex items-center space-x-3">
                        {/* Current room active-user count (audience + speakers) */}
                        <div
                          className="flex items-center space-x-1 text-neutral-300 font-medium"
                          title={`${activeUserCount} active in room (${room.speakers?.length || 0} on stage, ${room.listenerCount || 0} listening)`}
                        >
                          <Users className="w-3.5 h-3.5 text-violet-400" />
                          <span className="font-semibold text-white">{activeUserCount}</span>
                          <span className="text-[10px] text-neutral-400 font-normal">active</span>
                        </div>

                        {/* Gift / Activity Indicator */}
                        <div
                          className="flex items-center space-x-1 text-amber-300 font-bold"
                          title="Real-time gift and coin activity"
                        >
                          <Gift className="w-3.5 h-3.5 text-amber-400" />
                          <span>
                            {room.roomCoins && room.roomCoins > 0
                              ? formatCoinDisplay(room.roomCoins)
                              : `${room.giftsReceivedCount || 0} gifts`}
                          </span>
                        </div>
                      </div>

                      {/* Attractive Premium Visual Badges: Topic pill or club */}
                      <div className="flex items-center space-x-1">
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-neutral-800/90 text-neutral-300 border border-neutral-700/60 max-w-[90px] truncate">
                          {room.clubName || room.topic}
                        </span>

                        <span className="w-6 h-6 rounded-full bg-violet-600/20 text-violet-300 flex items-center justify-center group-hover:bg-violet-600 group-hover:text-white transition-colors">
                          <ArrowUpRight className="w-3.5 h-3.5" />
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </section>

      {/* ========================================================================= */}
      {/* 5. FIXED BOTTOM NAVIGATION BAR (Match, Group, Game, Plaza, Chat)          */}
      {/* ========================================================================= */}
      {shouldRenderBottomNav && (
        <nav
          id="home-fixed-bottom-nav"
          className="fixed bottom-0 left-0 right-0 max-w-md mx-auto bg-neutral-950/95 backdrop-blur-xl border-t border-neutral-900/90 px-3 pt-2 pb-2 z-40 select-none shadow-2xl"
          aria-label="Home Bottom Navigation"
        >
          <div className="flex items-center justify-around">
            {[
              { id: 'match' as HomeBottomNavSection, label: 'Match', icon: Zap },
              { id: 'group' as HomeBottomNavSection, label: 'Group', icon: Users },
              { id: 'game' as HomeBottomNavSection, label: 'Game', icon: Gamepad2 },
              { id: 'plaza' as HomeBottomNavSection, label: 'Plaza', icon: Radio },
              { id: 'chat' as HomeBottomNavSection, label: 'Chat', icon: MessageCircle },
            ].map((item) => {
              const Icon = item.icon;
              const isActive = activeBottomTab === item.id;
              return (
                <button
                  key={item.id}
                  id={`home-nav-item-${item.id}`}
                  type="button"
                  onClick={() => {
                    setActiveBottomTab(item.id);
                    if (item.id === 'plaza') {
                      onNavigate('home');
                    } else if (item.id === 'group') {
                      onNavigate('explore');
                    } else if (item.id === 'chat') {
                      onNavigate('activity');
                    }
                  }}
                  className="flex-1 flex flex-col items-center py-0.5 relative group transition-all duration-200 cursor-pointer focus:outline-none"
                >
                  <div
                    className={`relative p-1.5 rounded-2xl transition-all duration-200 ${
                      isActive
                        ? 'bg-gradient-to-tr from-violet-600/30 to-indigo-500/20 text-violet-400 scale-105 shadow-md shadow-violet-950/50'
                        : 'text-neutral-400 group-hover:text-neutral-200'
                    }`}
                  >
                    <Icon
                      className={`w-5 h-5 transition-transform duration-200 ${
                        isActive ? 'stroke-[2.5] text-violet-400' : 'stroke-[1.8]'
                      }`}
                    />
                    {isActive && (
                      <span className="absolute top-1 right-1 w-1.5 h-1.5 bg-emerald-400 rounded-full animate-pulse" />
                    )}
                  </div>
                  <span
                    className={`text-[11px] mt-0.5 font-medium tracking-tight transition-colors ${
                      isActive ? 'text-violet-400 font-bold' : 'text-neutral-400'
                    }`}
                  >
                    {item.label}
                  </span>
                </button>
              );
            })}
          </div>
          <div className="w-24 h-1 bg-neutral-800 rounded-full mx-auto mt-1.5" />
        </nav>
      )}
    </div>
  );
};

