import React, { useState, useEffect } from 'react';
import {
  ArrowLeft,
  ChevronDown,
  ChevronUp,
  LogOut,
  Mic,
  MicOff,
  Hand,
  MessageSquare,
  Share2,
  Crown,
  Shield,
  Radio,
  Send,
  Sparkles,
  Users,
  MoreVertical,
  Sliders,
  X,
  Plus,
  Check,
  AlertCircle,
  UserCheck,
  UserX,
  ArrowRightLeft,
  Gamepad2,
  Gift,
  Lock,
  Unlock,
  Trophy,
  Volume2,
  VolumeX,
  Smile,
  Info,
  FileText,
  Bell,
  Copy,
  CheckCircle2,
  Eye,
  Maximize2,
  Minimize2,
  Heart,
  WifiOff,
  AlertTriangle,
  Server
} from 'lucide-react';
import { VoiceRoom, User, ReactionParticle, Speaker, MicrophoneState, MicrophonePermissionStatus, UserRoomRole, SeatStatus } from '../types';
import { roomService } from '../services/roomService';
import { voiceAudioService } from '../services/audio/voiceAudioService';
import { AudioServiceError } from '../services/audio/voiceTypes';
import { VoiceRoomSeat } from '../components/VoiceRoomSeat';
import { UserProfileModal } from '../components/UserProfileModal';
import { GamesLobby } from '../games/components/GamesLobby';
import { ActiveGameContainer } from '../games/components/ActiveGameContainer';
import { gameService, AVAILABLE_GAMES } from '../games/gameService';
import { GameDefinition, GamePlayer, ActiveMatchState } from '../games/types';
import { walletService } from '../games/walletService';
import { GiftBoxModal } from '../gifts/components/GiftBoxModal';
import { GiftAnimationOverlay } from '../gifts/components/GiftAnimationOverlay';
import { TopGiftersModal } from '../gifts/components/TopGiftersModal';
import { giftService } from '../gifts/giftService';
import { GiftAnimationEvent, GiftTransaction } from '../gifts/types';
import { RocketCornerPanel } from '../rocket/components/RocketCornerPanel';
import { RocketLaunchAnimation } from '../rocket/components/RocketLaunchAnimation';
import { rocketService } from '../rocket/rocketService';
import { RocketRoomState, RocketLaunchEvent } from '../rocket/types';
import { RoomChatPanel } from '../components/chat/RoomChatPanel';
import { chatService } from '../services/chatService';
import { ChatRole } from '../types/chat';

interface VoiceRoomScreenProps {
  room: VoiceRoom;
  currentUser: User;
  onMinimize: () => void;
  onLeaveRoom: () => void;
  onJoinRoom?: (room: VoiceRoom) => void;
}

interface ChatMessage {
  id: string;
  senderId?: string;
  senderName: string;
  senderAvatar: string;
  senderRole?: 'host' | 'cohost' | 'speaker' | 'listener' | 'vip';
  text: string;
  time: string;
}

export const VoiceRoomScreen: React.FC<VoiceRoomScreenProps> = ({
  room,
  currentUser,
  onMinimize,
  onLeaveRoom,
  onJoinRoom,
}) => {
  const [isMuted, setIsMuted] = useState(roomService.isUserMuted());
  const [hasRaisedHand, setHasRaisedHand] = useState(roomService.userHasRaisedHand());
  const [userRequestStatus, setUserRequestStatus] = useState<'idle' | 'pending' | 'accepted' | 'declined'>(roomService.getUserRequestStatus());
  const [reactions, setReactions] = useState<ReactionParticle[]>([]);
  const [showOptionsMenu, setShowOptionsMenu] = useState(false);
  const [showRequestsSheet, setShowRequestsSheet] = useState(false);
  const [testHostMode, setTestHostMode] = useState(false);
  const [selectedSpeakerForAction, setSelectedSpeakerForAction] = useState<string | null>(null);

  const [seatChangeTarget, setSeatChangeTarget] = useState<{
    speakerId: string;
    speakerName: string;
    speakerAvatar: string;
    currentSeatIndex: number;
  } | null>(null);
  const [confirmMoveSeat, setConfirmMoveSeat] = useState<number | null>(null);
  const [showCoinFoundationModal, setShowCoinFoundationModal] = useState(false);
  const [selectedUserProfile, setSelectedUserProfile] = useState<User | null>(null);
  const [showGamesLobby, setShowGamesLobby] = useState(false);
  const [activeMatch, setActiveMatch] = useState<ActiveMatchState | null>(() => gameService.getActiveMatch());
  const [showGiftBox, setShowGiftBox] = useState(false);
  const [showTopGifters, setShowTopGifters] = useState(false);
  const [selectedGiftReceiverId, setSelectedGiftReceiverId] = useState<string | undefined>(undefined);
  const [activeGiftAnimation, setActiveGiftAnimation] = useState<GiftAnimationEvent | null>(() => giftService.getActiveAnimation());
  const [rocketState, setRocketState] = useState<RocketRoomState>(() =>
    rocketService.getRoomState(room.id, room.roomCoins || 0)
  );
  const [activeRocketLaunch, setActiveRocketLaunch] = useState<RocketLaunchEvent | null>(() =>
    rocketService.getActiveLaunch()
  );
  const [showMySeatActions, setShowMySeatActions] = useState(false);
  const [selectedEmptySeat, setSelectedEmptySeat] = useState<number | null>(null);
  const [chatTab, setChatTab] = useState<'all' | 'chat'>('all');
  const [showReactionsBar, setShowReactionsBar] = useState(false);

  // Real-Time Audio & Microphone States
  const [micState, setMicState] = useState<MicrophoneState>(() => voiceAudioService.getMicState());
  const [permissionStatus, setPermissionStatus] = useState<MicrophonePermissionStatus>(() => voiceAudioService.getPermissionStatus());
  const [showPermissionModal, setShowPermissionModal] = useState(false);
  const [showAudioEngineModal, setShowAudioEngineModal] = useState(false);
  const [connectionStatus, setConnectionStatus] = useState<'connected' | 'reconnecting' | 'disconnected'>(
    room.connectionState || 'connected'
  );

  // New Voice Room UI States
  const [isSpeakerAudioEnabled, setIsSpeakerAudioEnabled] = useState(true);
  const [showRoomInfoModal, setShowRoomInfoModal] = useState(false);
  const [isChatPanelExpanded, setIsChatPanelExpanded] = useState(false);
  const [showGiftArea, setShowGiftArea] = useState(false);
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const [hasFollowedHost, setHasFollowedHost] = useState(false);
  const [selectedGiftTarget, setSelectedGiftTarget] = useState<'host' | 'speakers' | 'all'>('host');
  const [selectedGiftItemId, setSelectedGiftItemId] = useState('gift_rose');

  const openUserProfile = (userData: {
    id: string;
    name: string;
    handle: string;
    avatar: string;
    bio?: string;
    followers?: number;
    following?: number;
    roomsHosted?: number;
    clubs?: string[];
    interests?: string[];
    isVerified?: boolean;
    level?: number;
    vipLevel?: number;
  }) => {
    const isHost = userData.id === room.host.id;
    const isMe = userData.id === currentUser.id;

    const fullUser: User = {
      id: userData.id,
      name: userData.name,
      handle: userData.handle,
      avatar: userData.avatar,
      bio: userData.bio || (isHost ? room.host.bio : (isMe ? currentUser.bio : 'Audio enthusiast & voice stage participant in SNYVO 🎙️')),
      followers: userData.followers ?? (isHost ? room.host.followers : (isMe ? currentUser.followers : 1850)),
      following: userData.following ?? (isHost ? room.host.following : (isMe ? currentUser.following : 340)),
      roomsHosted: userData.roomsHosted ?? (isHost ? room.host.roomsHosted : (isMe ? currentUser.roomsHosted : 15)),
      clubs: userData.clubs || (isHost ? room.host.clubs : (isMe ? currentUser.clubs : ['Voice Explorers'])),
      interests: userData.interests || (isHost ? room.host.interests : (isMe ? currentUser.interests : ['Social Audio', 'Music'])),
      isVerified: userData.isVerified ?? (isHost ? room.host.isVerified : (isMe ? currentUser.isVerified : false)),
      level: userData.level,
      vipLevel: userData.vipLevel,
    };
    setSelectedUserProfile(fullUser);
  };

  // Room chat messages count (powered by chatService repository)
  const [chatMessagesCount, setChatMessagesCount] = useState<number>(() =>
    chatService.getRoomMessages(room.id, room.host).length
  );
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [stageWarning, setStageWarning] = useState<string | null>(null);
  const [recentGiftBanner, setRecentGiftBanner] = useState<{
    id: string;
    senderName: string;
    senderAvatar: string;
    receiverName: string;
    receiverAvatar: string;
    giftIcon: string;
    giftName: string;
    quantity: number;
  } | null>(null);

  // Subscribe to roomService updates & reactions
  useEffect(() => {
    const unsubRoom = roomService.subscribe(() => {
      setIsMuted(roomService.isUserMuted());
      setHasRaisedHand(roomService.userHasRaisedHand());
      setUserRequestStatus(roomService.getUserRequestStatus());
    });

    const unsubReaction = roomService.onReaction((reaction) => {
      setReactions(prev => [...prev.slice(-15), reaction]);
      setTimeout(() => {
        setReactions(prev => prev.filter(r => r.id !== reaction.id));
      }, 3500);
    });

    const unsubGame = gameService.subscribe(() => {
      setActiveMatch(gameService.getActiveMatch());
    });

    const unsubGift = giftService.subscribeAnimation((anim) => {
      setActiveGiftAnimation(anim);
    });

    const unsubGiftTx = giftService.subscribeTransactions(() => {
      const allTx = giftService.getTransactions(room.id);
      if (allTx.length > 0) {
        const latest = allTx[0];
        setRecentGiftBanner({
          id: latest.id,
          senderName: latest.senderName,
          senderAvatar: latest.senderAvatar,
          receiverName: latest.receiverName,
          receiverAvatar: latest.receiverAvatar,
          giftIcon: latest.giftIcon,
          giftName: latest.giftName,
          quantity: latest.quantity,
        });
        setTimeout(() => {
          setRecentGiftBanner(curr => (curr?.id === latest.id ? null : curr));
        }, 4000);
      }
    });

    const unsubRocketState = rocketService.subscribe(() => {
      setRocketState(rocketService.getRoomState(room.id, room.roomCoins || 0));
    });

    const unsubRocketLaunch = rocketService.subscribeLaunch((event) => {
      setActiveRocketLaunch(event);
    });

    const unsubAudio = voiceAudioService.subscribe(() => {
      const state = voiceAudioService.getMicState();
      setMicState(state);
      setPermissionStatus(voiceAudioService.getPermissionStatus());
      setIsMuted(state !== 'on');
    });

    const unsubChat = chatService.subscribeRoomChat(room.id, () => {
      setChatMessagesCount(chatService.getRoomMessages(room.id, room.host).length);
    });

    return () => {
      unsubRoom();
      unsubReaction();
      unsubGame();
      unsubGift();
      unsubGiftTx();
      unsubRocketState();
      unsubRocketLaunch();
      unsubAudio();
      unsubChat();
    };
  }, []);

  const handleGiftSent = (tx: GiftTransaction) => {
    // Post chat message announcement via chatService
    chatService.sendRoomMessage(room.id, {
      text: `🎁 Sent ${tx.quantity > 1 ? `${tx.quantity}x ` : ''}${tx.giftName} to ${tx.receiverName}! (🪙 ${tx.totalCoins.toLocaleString()} Coins)`,
      sender: currentUser,
      role: (currentUserRole as ChatRole) || 'listener',
    });
    room.roomCoins = (room.roomCoins || 0) + tx.totalCoins;
    setRecentGiftBanner({
      id: tx.id,
      senderName: tx.senderName,
      senderAvatar: tx.senderAvatar,
      receiverName: tx.receiverName,
      receiverAvatar: tx.receiverAvatar,
      giftIcon: tx.giftIcon,
      giftName: tx.giftName,
      quantity: tx.quantity,
    });
    setTimeout(() => {
      setRecentGiftBanner(curr => (curr?.id === tx.id ? null : curr));
    }, 4000);
    showToast(`🎁 ${tx.giftName} sent to ${tx.receiverName}!`);
  };

  const handleLaunchGame = (game: GameDefinition, players: GamePlayer[]) => {
    const match = gameService.createMatch(game, room.id, players);
    setActiveMatch(match);
    setShowGamesLobby(false);
    showToast(`🎮 ${game.title} started! Voice & Chat remain active.`);
  };

  const handleExitGame = () => {
    setActiveMatch(null);
    showToast('Game ended. Returned to Voice Room Board.');
  };

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  const handleToggleMute = async () => {
    if (micState === 'permission_denied') {
      setShowPermissionModal(true);
      return;
    }
    if (micState === 'muted_by_host') {
      showToast('🔒 You were muted by the Room Host. You cannot unmute yourself until the host allows speaking.');
      return;
    }

    try {
      const res = await roomService.toggleMicrophone(currentUser);
      setMicState(res.state);
      setIsMuted(res.state !== 'on');
      if (!res.success && res.error) {
        if (res.error.type === 'permission_denied') {
          setShowPermissionModal(true);
        } else {
          showToast(`⚠️ ${res.error.message}`);
        }
      } else if (res.state === 'on') {
        showToast('🎤 Microphone is LIVE');
      } else if (res.state === 'off') {
        showToast('Microphone muted');
      }
    } catch (err: any) {
      showToast(`⚠️ ${err.message || err}`);
    }
  };

  const handleTurnMicOn = async () => {
    if (micState === 'muted_by_host') {
      showToast('🔒 You were muted by the Host. You cannot turn your mic ON until allowed by Host or Moderator.');
      return;
    }

    try {
      const res = await roomService.setMicrophoneOn(currentUser);
      setMicState(res.state);
      setIsMuted(res.state !== 'on');
      if (!res.success && res.error) {
        if (res.error.type === 'permission_denied') {
          showToast('⚠️ Microphone permission was denied. Please allow microphone access to speak.');
          setShowPermissionModal(true);
        } else {
          showToast(`⚠️ ${res.error.message}`);
        }
      } else if (res.state === 'on') {
        showToast('🎤 Microphone is ON');
      }
    } catch (err: any) {
      showToast(`⚠️ ${err.message || err}`);
    }
  };

  const handleTurnMicOff = async () => {
    try {
      const res = await roomService.setMicrophoneOff(currentUser);
      setMicState(res.state);
      setIsMuted(true);
      showToast('Microphone turned OFF');
    } catch (err: any) {
      showToast(`⚠️ ${err.message || err}`);
    }
  };

  const handleToggleRaiseHand = () => {
    const userIsSpeaker = room.speakers.some(s => s.id === currentUser.id);
    if (userIsSpeaker) {
      showToast('You are already on stage as a speaker');
      return;
    }

    const pendingReq = room.speakerRequests?.find(r => r.userId === currentUser.id && r.status === 'pending');
    if (pendingReq || hasRaisedHand) {
      roomService.cancelSpeakerRequest(currentUser.id);
      setHasRaisedHand(false);
      showToast('Speaker request cancelled');
    } else {
      const res = roomService.requestToSpeak(currentUser);
      setHasRaisedHand(true);
      showToast(res.message);
    }
  };

  const handleApproveRequest = (userId: string) => {
    const res = roomService.approveSpeakerRequest(room.id, userId);
    if (res.success) {
      setStageWarning(null);
      if (userId === currentUser.id) {
        showToast('🎉 Your request was accepted! You are now live on stage.');
      } else {
        showToast(res.message);
      }
    } else {
      setStageWarning(res.message);
      showToast(`⚠️ ${res.message}`);
      setTimeout(() => setStageWarning(null), 5000);
    }
  };

  const handleDeclineRequest = (userId: string) => {
    const res = roomService.declineSpeakerRequest(room.id, userId);
    if (userId === currentUser.id) {
      showToast('Your request to speak was declined by the host.');
    } else {
      showToast(res.message);
    }
  };

  const handleDemoteSpeaker = (speakerId: string) => {
    const res = roomService.demoteToListener(room.id, speakerId);
    showToast(res.message);
    setSelectedSpeakerForAction(null);
  };

  const handleMoveSpeaker = (speakerId: string, targetSeatIndex: number) => {
    const res = roomService.moveSpeakerSeat(room.id, speakerId, targetSeatIndex);
    if (res.success) {
      showToast(res.message);
      setSeatChangeTarget(null);
      setSelectedSpeakerForAction(null);
      setConfirmMoveSeat(null);
    } else {
      showToast(`⚠️ ${res.message}`);
    }
  };

  const handleTakeSeat = (seatIndex?: number) => {
    const res = roomService.takeSeat(room.id, currentUser, seatIndex);
    if (res.success) {
      showToast(res.message);
    } else {
      showToast(`⚠️ ${res.message}`);
    }
  };

  const handleLeaveSeat = () => {
    const res = roomService.leaveSeat(room.id, currentUser.id);
    if (res.success) {
      showToast(res.message);
      setShowMySeatActions(false);
    } else {
      showToast(`⚠️ ${res.message}`);
    }
  };

  const handleToggleLockSeat = (seatIndex: number) => {
    const res = roomService.toggleLockSeat(room.id, seatIndex);
    showToast(res.message);
  };

  const handleSimulateRequest = () => {
    const res = roomService.simulateListenerRequest(room.id);
    showToast(res.message);
  };

  const handleSendReaction = (emoji: string) => {
    roomService.sendReaction(emoji, currentUser.name);
  };

  // State calculations
  const currentUserSpeaker = room.speakers.find(s => s.id === currentUser.id);
  const isUserSpeaker = !!currentUserSpeaker;
  const isUserHost = room.host.id === currentUser.id;
  const isActingHost = isUserHost || testHostMode;
  const currentUserRole = roomService.getUserRole(room.id, currentUser.id);
  const isHostOrModerator = isActingHost || currentUserRole === 'host' || currentUserRole === 'cohost' || currentUserRole === 'moderator';
  
  const pendingRequests = room.speakerRequests?.filter(r => r.status === 'pending') || [];
  const userPendingRequest = pendingRequests.find(r => r.userId === currentUser.id);

  const maxStageSeats = 10;
  const emptySeatCount = Math.max(0, maxStageSeats - room.speakers.length);
  const isStageFull = emptySeatCount === 0;

  return (
    <div
      id="voice-room-screen"
      className="relative flex flex-col h-full w-full bg-gradient-to-b from-neutral-950 via-neutral-900 to-neutral-950 text-white overflow-hidden select-none"
    >
      {/* Floating Reaction Particles Layer */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden z-40">
        {reactions.map(r => (
          <div
            key={r.id}
            className="absolute bottom-24 transition-all duration-1000 ease-out text-3xl"
            style={{
              left: `${r.x}%`,
              animation: 'floatUp 3.2s cubic-bezier(0.2, 0.8, 0.2, 1) forwards'
            }}
          >
            {r.emoji}
          </div>
        ))}
      </div>

      {/* Floating Toast Notification */}
      {toastMessage && (
        <div className="absolute top-16 left-1/2 -translate-x-1/2 px-4 py-2 bg-neutral-900/95 border border-violet-500/50 text-white text-xs font-semibold rounded-full shadow-2xl z-50 flex items-center space-x-2 animate-fade-in max-w-[90%] text-center">
          <Sparkles className="w-3.5 h-3.5 text-violet-400 flex-shrink-0" />
          <span className="truncate">{toastMessage}</span>
        </div>
      )}

      {/* 🎁 Live Room Gift Activity Floating Banner ("User A sent Rose to User B") */}
      {recentGiftBanner && (
        <div
          id="room-gift-activity-banner"
          className="absolute top-16 left-1/2 -translate-x-1/2 z-50 max-w-[92%] sm:max-w-md w-full px-3 py-2 rounded-2xl bg-black/85 border border-pink-500/50 shadow-2xl backdrop-blur-md flex items-center justify-between text-xs text-white animate-bounce-short select-none"
        >
          <div className="flex items-center space-x-2.5 min-w-0">
            <div className="flex items-center -space-x-2 flex-shrink-0">
              <img
                src={recentGiftBanner.senderAvatar}
                alt={recentGiftBanner.senderName}
                className="w-7 h-7 rounded-full object-cover border-2 border-violet-400"
              />
              <img
                src={recentGiftBanner.receiverAvatar}
                alt={recentGiftBanner.receiverName}
                className="w-7 h-7 rounded-full object-cover border-2 border-rose-400"
              />
            </div>
            <div className="truncate">
              <p className="font-semibold text-white leading-tight truncate">
                <span className="text-violet-300 font-bold">{recentGiftBanner.senderName}</span>
                <span className="text-neutral-300"> sent </span>
                <span className="text-amber-300 font-bold">
                  {recentGiftBanner.quantity > 1 ? `${recentGiftBanner.quantity}x ` : ''}{recentGiftBanner.giftName}
                </span>
                <span className="text-neutral-300"> to </span>
                <span className="text-rose-300 font-bold">{recentGiftBanner.receiverName}</span>
              </p>
              <p className="text-[10px] text-neutral-400">Recent Room Gift Activity</p>
            </div>
          </div>
          <span className="text-2xl flex-shrink-0 ml-2 animate-pulse">{recentGiftBanner.giftIcon}</span>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 🔝 SNYVO VOICE ROOM TOP AREA                                              */}
      {/* Back button, Room cover/avatar, Room name, Room ID, Host info, Users, More */}
      {/* ========================================================================= */}
      <div className="px-3.5 py-2.5 flex items-center justify-between border-b border-neutral-800/80 bg-neutral-950/95 backdrop-blur-xl z-30 sticky top-0">
        {/* Left Side: Back button on top-left + Room Cover + Room Name & ID */}
        <div className="flex items-center space-x-2.5 min-w-0 flex-1 mr-2">
          {/* Back button on top-left */}
          <button
            id="room-back-btn"
            onClick={onMinimize}
            className="p-1.5 -ml-1 text-neutral-300 hover:text-white rounded-full hover:bg-neutral-800/80 active:scale-95 transition-all cursor-pointer flex-shrink-0"
            aria-label="Back to Home Screen"
            title="Back to Home"
          >
            <ArrowLeft className="w-5 h-5 stroke-[2.5]" />
          </button>

          {/* Room Cover / Avatar */}
          <div className="relative flex-shrink-0">
            <img
              id="room-cover-avatar"
              src={room.coverImage || room.host.avatar}
              alt={room.title}
              className="w-9 h-9 sm:w-10 sm:h-10 rounded-2xl object-cover ring-1.5 ring-violet-500/40 shadow-md shadow-violet-950/50"
            />
            <span className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full bg-emerald-500 ring-2 ring-neutral-950 animate-pulse" />
          </div>

          {/* Room Name & Room ID */}
          <div className="flex flex-col min-w-0 flex-1">
            <h1
              id="room-name-heading"
              className="text-xs sm:text-sm font-bold text-white truncate leading-tight tracking-tight hover:text-violet-200 transition-colors"
              title={room.title}
            >
              {room.title}
            </h1>
            <div className="flex items-center space-x-1.5 mt-0.5">
              <span className="text-[10px] font-medium text-neutral-400">
                ID: {room.id.replace(/\D/g, '').slice(0, 6) || '849201'}
              </span>
              <button
                onClick={() => {
                  const idToCopy = room.id.replace(/\D/g, '').slice(0, 6) || '849201';
                  navigator.clipboard?.writeText(idToCopy);
                  showToast(`Room ID ${idToCopy} copied to clipboard!`);
                }}
                className="text-[9px] text-violet-400 hover:text-violet-300 p-0.5 cursor-pointer transition-colors"
                title="Copy Room ID"
              >
                <Copy className="w-2.5 h-2.5 inline" />
              </button>
            </div>
          </div>
        </div>

        {/* Right Side: Host Name & Badge, Online Participant Count, More/Options Button */}
        <div className="flex items-center space-x-1.5 sm:space-x-2 flex-shrink-0">
          {/* Host Name & Badge Pill */}
          <div
            id="room-host-header-badge"
            onClick={() => openUserProfile(room.host)}
            className="flex items-center space-x-1 sm:space-x-1.5 px-2 py-1 rounded-full bg-amber-950/40 hover:bg-amber-900/50 border border-amber-500/40 cursor-pointer transition-all active:scale-95 select-none"
            title={`Host: ${room.host.name}`}
          >
            <div className="relative flex-shrink-0">
              <img
                src={room.host.avatar}
                alt={room.host.name}
                className="w-4 h-4 sm:w-5 sm:h-5 rounded-full object-cover ring-1 ring-amber-400"
              />
              <span className="absolute -top-1 -right-1 text-[7px] sm:text-[8px] leading-none">👑</span>
            </div>
            <span className="text-[10px] sm:text-[11px] font-bold text-amber-200 truncate max-w-[50px] sm:max-w-[75px]">
              {room.host.name.split(' ')[0]}
            </span>
            <span className="text-[8px] font-extrabold uppercase text-amber-300 bg-amber-500/20 px-1 py-0.2 rounded-full hidden xs:inline">
              Host
            </span>
          </div>

          {/* Online Participant Count */}
          <div
            id="room-online-participants-badge"
            className="flex items-center space-x-1 px-2 py-1 rounded-full bg-neutral-900/90 border border-neutral-800 text-neutral-200 text-xs font-semibold select-none shadow-xs"
            title="Online Participants"
          >
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
            <Users className="w-3.5 h-3.5 text-violet-400" />
            <span className="font-bold text-white text-[11px]">{room.listenerCount + room.speakers.length}</span>
          </div>

          {/* More / Options Button on top-right */}
          <button
            id="room-more-options-btn"
            onClick={() => setShowOptionsMenu(true)}
            className="p-1.5 sm:p-2 text-neutral-300 hover:text-white rounded-full hover:bg-neutral-800 transition-colors cursor-pointer active:scale-95"
            aria-label="Room options and settings"
            title="More Options"
          >
            <MoreVertical className="w-4 h-4 sm:w-5 sm:h-5" />
          </button>
        </div>
      </div>

      {/* ⚠️ Real-Time Connection Alert Banner */}
      {connectionStatus !== 'connected' && (
        <div
          id="room-connection-status-banner"
          className="bg-amber-950/95 border-b border-amber-500/50 px-4 py-2 flex items-center justify-between text-xs text-amber-200 z-30 animate-fade-in"
        >
          <div className="flex items-center space-x-2">
            <WifiOff className="w-4 h-4 text-amber-400 animate-pulse flex-shrink-0" />
            <span className="font-medium">
              {connectionStatus === 'reconnecting'
                ? 'Connecting to real-time voice stage...'
                : 'Connection unavailable. Audio paused.'}
            </span>
          </div>
          <button
            onClick={() => {
              setConnectionStatus('reconnecting');
              setTimeout(() => {
                setConnectionStatus('connected');
                showToast('Reconnected to voice room');
              }, 1000);
            }}
            className="px-2.5 py-1 bg-amber-500/20 hover:bg-amber-500/30 border border-amber-400/40 text-amber-200 text-[11px] font-bold rounded-lg cursor-pointer transition-colors"
          >
            Retry
          </button>
        </div>
      )}

      {/* 🛑 Microphone Permission Denied Alert Banner */}
      {isUserSpeaker && micState === 'permission_denied' && (
        <div
          id="mic-permission-denied-banner"
          onClick={() => setShowPermissionModal(true)}
          className="bg-rose-950/95 border-b border-rose-500/60 px-4 py-2 flex items-center justify-between text-xs text-rose-200 z-30 cursor-pointer hover:bg-rose-900/95 transition-colors animate-fade-in"
        >
          <div className="flex items-center space-x-2 min-w-0">
            <AlertCircle className="w-4 h-4 text-rose-400 flex-shrink-0" />
            <span className="truncate font-medium">Microphone permission denied. Tap here to enable Android/Browser access.</span>
          </div>
          <span className="font-bold text-rose-300 underline ml-2 whitespace-nowrap text-[11px]">Fix Permission</span>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 📢 ROOM INFORMATION SECTION (Announcement, Rules, Host Bio)               */}
      {/* ========================================================================= */}
      <div className="px-4 pt-2.5 pb-1">
        <div
          id="room-info-banner"
          onClick={() => setShowRoomInfoModal(true)}
          className="p-2.5 rounded-2xl bg-gradient-to-r from-violet-950/60 via-purple-950/40 to-neutral-900/80 border border-violet-800/40 hover:border-violet-600/60 transition-all cursor-pointer flex items-center justify-between group shadow-sm shadow-violet-950/30"
        >
          <div className="flex items-center space-x-2 min-w-0 flex-1">
            <span className="p-1 rounded-lg bg-violet-500/20 text-violet-300 group-hover:bg-violet-500/30 transition-colors flex-shrink-0">
              <Bell className="w-3.5 h-3.5 animate-pulse" />
            </span>
            <div className="min-w-0 flex-1">
              <p className="text-xs text-neutral-200 truncate">
                <span className="font-bold text-violet-300 mr-1.5">Announcement:</span>
                {room.description || 'Welcome to SNYVO Voice Lounge! Tap to view Room Rules & Host details.'}
              </p>
            </div>
          </div>
          <div className="flex items-center space-x-1 ml-2 flex-shrink-0 text-violet-300 group-hover:text-white transition-colors">
            <span className="text-[10px] font-bold bg-violet-900/60 px-2 py-0.5 rounded-full border border-violet-700/50">
              Rules & Bio
            </span>
            <Info className="w-3.5 h-3.5" />
          </div>
        </div>
      </div>

      {/* Listener Status Banner (When current user is waiting for approval) */}
      {userPendingRequest && !isUserSpeaker && (
        <div
          id="listener-pending-request-banner"
          className="mx-5 my-1.5 px-3 py-2 rounded-xl bg-amber-950/40 border border-amber-500/40 flex items-center justify-between animate-pulse"
        >
          <div className="flex items-center space-x-2">
            <Hand className="w-4 h-4 text-amber-400" />
            <div>
              <div className="flex items-center space-x-2">
                <p className="text-xs font-semibold text-amber-200">
                  Request to speak sent to host
                </p>
                <span className="text-[9px] px-1.5 py-0.5 rounded-full bg-amber-500/30 text-amber-300 font-semibold border border-amber-500/40">
                  Request pending
                </span>
              </div>
              <p className="text-[10px] text-amber-400/80">
                Waiting for host approval to move to stage seat...
              </p>
            </div>
          </div>
          <button
            id="listener-cancel-request-btn"
            onClick={handleToggleRaiseHand}
            className="px-2.5 py-1 bg-neutral-900/80 hover:bg-neutral-800 text-neutral-300 border border-neutral-700/60 rounded-lg text-[11px] font-medium cursor-pointer"
          >
            Cancel
          </button>
        </div>
      )}

      {/* Listener Declined Request Banner */}
      {userRequestStatus === 'declined' && !isUserSpeaker && (
        <div
          id="listener-declined-request-banner"
          className="mx-5 my-1.5 px-3 py-2 rounded-xl bg-rose-950/50 border border-rose-500/50 flex items-center justify-between animate-fade-in"
        >
          <div className="flex items-center space-x-2">
            <UserX className="w-4 h-4 text-rose-400 flex-shrink-0" />
            <div>
              <div className="flex items-center space-x-2">
                <p className="text-xs font-semibold text-rose-200">
                  Request to speak was declined
                </p>
                <span className="text-[9px] px-1.5 py-0.5 rounded-full bg-rose-500/30 text-rose-300 font-semibold border border-rose-500/40">
                  Declined
                </span>
              </div>
              <p className="text-[10px] text-rose-300/80">
                The host was unable to seat you at this time. You can request again.
              </p>
            </div>
          </div>
          <button
            id="listener-request-again-btn"
            onClick={() => {
              roomService.clearUserRequestStatus();
              handleToggleRaiseHand();
            }}
            className="px-2.5 py-1 bg-violet-600 hover:bg-violet-500 text-white rounded-lg text-[11px] font-semibold cursor-pointer whitespace-nowrap"
          >
            Request Again
          </button>
        </div>
      )}

      {/* Listener Accepted Banner */}
      {userRequestStatus === 'accepted' && isUserSpeaker && (
        <div
          id="listener-accepted-request-banner"
          className="mx-5 my-1.5 px-3 py-2 rounded-xl bg-emerald-950/50 border border-emerald-500/50 flex items-center justify-between animate-fade-in"
        >
          <div className="flex items-center space-x-2">
            <UserCheck className="w-4 h-4 text-emerald-400 flex-shrink-0" />
            <div>
              <div className="flex items-center space-x-2">
                <p className="text-xs font-bold text-emerald-200">
                  Request Accepted! You are now in Seat #{(currentUserSpeaker?.seatIndex ?? 0) + 1}
                </p>
                <span className="text-[9px] px-1.5 py-0.5 rounded-full bg-emerald-500/30 text-emerald-300 font-semibold border border-emerald-500/40">
                  On Stage
                </span>
              </div>
              <p className="text-[10px] text-emerald-300/80">
                Your microphone is ready. Tap your seat anytime if you wish to change position.
              </p>
            </div>
          </div>
          <button
            onClick={() => roomService.clearUserRequestStatus()}
            className="p-1 text-emerald-400 hover:text-white cursor-pointer"
            aria-label="Dismiss banner"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Stage Full Capacity Alert Banner */}
      {stageWarning && (
        <div
          id="stage-full-warning-banner"
          className="mx-5 my-1.5 px-3.5 py-2.5 rounded-xl bg-rose-950/70 border border-rose-500/60 text-rose-200 text-xs font-medium flex items-center space-x-2 shadow-lg"
        >
          <AlertCircle className="w-4 h-4 text-rose-400 flex-shrink-0" />
          <span className="flex-1">{stageWarning}</span>
          <button
            onClick={() => setStageWarning(null)}
            className="p-1 text-rose-400 hover:text-white"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Host Pending Speaker Requests Banner (Visible to Host) */}
      {isActingHost && pendingRequests.length > 0 && (
        <div
          id="host-speaker-requests-banner"
          className="mx-5 my-1.5 p-3 rounded-2xl bg-gradient-to-r from-violet-950/60 to-indigo-950/60 border border-violet-500/50 shadow-lg shadow-violet-950/30"
        >
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center space-x-2">
              <span className="relative flex h-2.5 w-2.5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-amber-500"></span>
              </span>
              <span className="text-xs font-bold text-white uppercase tracking-wider">
                Speaker Requests ({pendingRequests.length})
              </span>
            </div>
            <div className="flex items-center space-x-2">
              <span className="text-[10px] font-semibold text-violet-300">
                {emptySeatCount > 0 ? `${emptySeatCount} seats open` : 'Stage full (6/6)'}
              </span>
              {pendingRequests.length > 2 && (
                <button
                  id="view-all-requests-btn"
                  onClick={() => setShowRequestsSheet(true)}
                  className="text-[10px] font-bold text-violet-300 hover:text-white underline cursor-pointer"
                >
                  View All
                </button>
              )}
            </div>
          </div>

          {/* Quick Request Items */}
          <div className="space-y-2">
            {pendingRequests.slice(0, 2).map(req => (
              <div
                key={req.id}
                id={`pending-request-item-${req.userId}`}
                className="flex items-center justify-between bg-neutral-950/50 p-2 rounded-xl border border-violet-900/40"
              >
                <div className="flex items-center space-x-2 min-w-0">
                  <img
                    src={req.userAvatar}
                    alt={req.userName}
                    className="w-7 h-7 rounded-full object-cover border border-violet-400 flex-shrink-0"
                  />
                  <div className="min-w-0">
                    <div className="flex items-center space-x-1.5">
                      <span className="text-xs font-semibold text-white truncate">{req.userName}</span>
                      {req.userId === currentUser.id && (
                        <span className="text-[9px] text-violet-300 font-bold bg-violet-950 px-1 rounded">(You)</span>
                      )}
                      <span className="text-[8px] px-1.5 py-0.5 rounded-full bg-amber-500/20 text-amber-300 font-bold border border-amber-500/30">
                        Pending
                      </span>
                    </div>
                    <p className="text-[10px] text-neutral-400 truncate">{req.userHandle} • {req.requestedAt}</p>
                  </div>
                </div>

                <div className="flex items-center space-x-1.5 flex-shrink-0">
                  {/* Approve / Accept Button */}
                  <button
                    id={`host-approve-btn-${req.userId}`}
                    onClick={() => handleApproveRequest(req.userId)}
                    disabled={isStageFull}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center space-x-1 transition-all cursor-pointer shadow-sm ${
                      isStageFull
                        ? 'bg-neutral-800 text-neutral-500 border border-neutral-700 cursor-not-allowed'
                        : 'bg-violet-600 hover:bg-violet-500 active:scale-95 text-white shadow-violet-600/30'
                    }`}
                  >
                    <Check className="w-3.5 h-3.5 stroke-[2.5]" />
                    <span>{isStageFull ? 'Stage Full' : 'Accept'}</span>
                  </button>

                  {/* Decline Button */}
                  <button
                    id={`host-decline-btn-${req.userId}`}
                    onClick={() => handleDeclineRequest(req.userId)}
                    className="px-2.5 py-1.5 bg-neutral-900/80 hover:bg-rose-950/60 hover:text-rose-300 text-neutral-400 border border-neutral-800 rounded-lg text-xs font-medium flex items-center space-x-1 transition-colors cursor-pointer"
                  >
                    <X className="w-3.5 h-3.5" />
                    <span>Decline</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Host Information Card */}
      <div className="mx-5 my-1.5 px-3 py-2 rounded-xl bg-neutral-900/60 border border-neutral-800/80 flex items-center justify-between shadow-sm">
        <div className="flex items-center space-x-2.5 min-w-0">
          <div className="relative flex-shrink-0">
            <img
              src={room.host.avatar}
              alt={room.host.name}
              className="w-9 h-9 rounded-full object-cover border-2 border-amber-400/80"
            />
            <div className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-amber-400 text-neutral-950 flex items-center justify-center shadow">
              <Crown className="w-2.5 h-2.5 stroke-[3]" />
            </div>
          </div>
          <div className="min-w-0">
            <div className="flex items-center space-x-1.5">
              <span className="text-xs font-bold text-white truncate">{room.host.name}</span>
              <span className="text-[9px] font-semibold text-amber-300 bg-amber-950/60 border border-amber-500/30 px-1.5 py-0.2 rounded-full flex-shrink-0">
                Host
              </span>
            </div>
            <p className="text-[10px] text-neutral-400 font-medium truncate">{room.topic || 'Voice Room Stage'}</p>
          </div>
        </div>

        <div className="flex items-center space-x-2 flex-shrink-0">
          {/* Host moderation shortcut button */}
          {isActingHost && (
            <button
              id="host-manage-requests-btn"
              onClick={() => setShowRequestsSheet(true)}
              className="px-2.5 py-1 bg-violet-950/60 hover:bg-violet-900/60 border border-violet-700/50 text-violet-300 rounded-lg text-[11px] font-semibold flex items-center space-x-1 cursor-pointer transition-colors"
            >
              <Hand className="w-3 h-3 text-amber-400" />
              <span>Requests ({pendingRequests.length})</span>
            </button>
          )}

          <div className="flex items-center space-x-1 text-[11px] text-neutral-400">
            <Users className="w-3.5 h-3.5 text-neutral-400" />
            <span>{room.listenerCount + room.speakers.length}</span>
          </div>
        </div>
      </div>

      {/* Main Scrollable Audio Stage Canvas */}
      <div className="flex-1 overflow-y-auto px-5 py-2 space-y-5 scrollbar-none">
        {/* Active Multiplayer Game in Room Board */}
        {activeMatch && (
          <div className="mb-2">
            <ActiveGameContainer
              game={AVAILABLE_GAMES.find(g => g.id === activeMatch.gameId) || AVAILABLE_GAMES[0]}
              match={activeMatch}
              roomTitle={room.title}
              onExitGame={handleExitGame}
            />
          </div>
        )}

        {/* Social Voice Room Board (Compact Social-Room Board Layout) */}
        <div
          id="social-room-board-container"
          className="bg-neutral-900/35 border border-violet-900/25 rounded-3xl p-3.5 sm:p-4 shadow-xl backdrop-blur-sm relative"
        >
          {/* Room Board Header with Capacity & Coins Foundation */}
          <div className="flex items-center justify-between mb-3.5 px-1">
            <div className="flex items-center space-x-2">
              <span className="text-xs font-bold uppercase tracking-wider text-neutral-300 flex items-center space-x-1.5">
                <Radio className="w-3.5 h-3.5 text-violet-400 animate-pulse" />
                <span>Room Board</span>
                <span className="text-violet-400 font-bold">({room.speakers.length}/{maxStageSeats})</span>
              </span>

              {/* Voice Room Games Button */}
              <button
                id="room-board-games-badge"
                onClick={() => setShowGamesLobby(true)}
                className="flex items-center space-x-1.5 text-[10px] text-white bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-500 hover:to-indigo-500 px-2.5 py-1 rounded-full border border-violet-400/40 cursor-pointer transition-all shadow-md shadow-violet-600/30 active:scale-95 font-bold"
                title="Play Voice Room Multiplayer Games"
              >
                <Gamepad2 className="w-3.5 h-3.5" />
                <span>🎮 Games ({AVAILABLE_GAMES.length})</span>
              </button>

              {/* SNYVO Gifts Badge */}
              <button
                id="room-board-gifts-badge"
                onClick={() => {
                  setSelectedGiftReceiverId(undefined);
                  setShowGiftBox(true);
                }}
                className="flex items-center space-x-1 text-[10px] text-white bg-gradient-to-r from-rose-600 to-amber-500 hover:brightness-110 px-2.5 py-1 rounded-full border border-rose-400/40 cursor-pointer transition-all shadow-md shadow-rose-600/30 active:scale-95 font-bold"
                title="Open SNYVO Gift World"
              >
                <Gift className="w-3 h-3" />
                <span>🎁 Gifts</span>
              </button>

              {/* Top Gifters Ranking button */}
              <button
                id="room-board-top-gifters-badge"
                onClick={() => setShowTopGifters(true)}
                className="flex items-center space-x-1 text-[10px] text-amber-300 bg-amber-950/60 hover:bg-amber-900/60 px-2 py-0.5 rounded-full border border-amber-500/30 cursor-pointer transition-colors shadow-xs"
                title="View Top Gifters Leaderboard"
              >
                <span>🏆 Top Gifters</span>
              </button>

              {/* Coin System Status Foundation */}
              <div
                id="room-coin-status-badge"
                onClick={() => setShowCoinFoundationModal(true)}
                className="flex items-center space-x-1 text-[10px] text-amber-300 bg-amber-950/50 hover:bg-amber-900/50 px-2 py-0.5 rounded-full border border-amber-500/30 hover:border-amber-400/60 cursor-pointer transition-colors shadow-xs"
                title="Total Verified Room Coins"
              >
                <span>🪙</span>
                <span className="font-semibold">{rocketService.formatCoins(rocketState.currentCoins)} Coins</span>
              </div>
            </div>

            <div className="flex items-center space-x-1.5">
              {emptySeatCount > 0 ? (
                <span className="text-[10px] text-emerald-400 bg-emerald-950/40 border border-emerald-800/30 px-2 py-0.5 rounded-full font-medium">
                  {emptySeatCount} open seat{emptySeatCount === 1 ? '' : 's'}
                </span>
              ) : (
                <span className="text-[10px] text-amber-400 bg-amber-950/40 border border-amber-800/30 px-2 py-0.5 rounded-full font-medium">
                  Board Full ({maxStageSeats}/{maxStageSeats})
                </span>
              )}
            </div>
          </div>

          {/* 🚀 SNYVO Rocket Live Coin Progress Corner Panel */}
          <div className="mb-3.5">
            <RocketCornerPanel
              roomId={room.id}
              rocketState={rocketState}
              onOpenGiftBox={() => {
                setSelectedGiftReceiverId(undefined);
                setShowGiftBox(true);
              }}
            />
          </div>

          {/* Social Room Board Grid: Multi-Row Grid of Circular Profile Seats (10 Seats, 2 Rows of 5) */}
          <div
            id="room-board-seats-grid"
            className="grid grid-cols-5 gap-y-3.5 gap-x-1 sm:gap-x-2 place-items-center"
          >
            {Array.from({ length: 10 }).map((_, seatIndex) => {
              const speaker = room.speakers.find(s => (s.seatIndex ?? -1) === seatIndex);
              const isLocked = room.lockedSeats?.includes(seatIndex) || false;

              return (
                <VoiceRoomSeat
                  key={`seat-pos-${seatIndex}`}
                  seatIndex={seatIndex}
                  speaker={speaker}
                  isCurrentUser={speaker ? speaker.id === currentUser.id : false}
                  isCurrentUserSpeaker={isUserSpeaker}
                  isActingHost={isActingHost}
                  isLocalMuted={isMuted}
                  micState={speaker ? (speaker.id === currentUser.id ? micState : speaker.micState) : undefined}
                  seatStatus={speaker ? (speaker.id === currentUser.id ? (micState === 'on' ? 'speaking' : isMuted ? 'muted' : 'occupied') : speaker.seatStatus) : undefined}
                  userRole={speaker ? (speaker.role || roomService.getUserRole(room.id, speaker.id)) : undefined}
                  isLocked={isLocked}
                  userPendingRequest={!!userPendingRequest}
                  hasCandidate={pendingRequests.length > 0}
                  onSelectSeat={(idx, spk) => {
                    if (spk) {
                      if (spk.id === currentUser.id) {
                        // User tapped their own seat: open Voice-Control Menu
                        setShowMySeatActions(true);
                      } else if (isHostOrModerator) {
                        // Host or Moderator: open moderation controls (Mute, Remove, View)
                        setSelectedSpeakerForAction(spk.id);
                      } else {
                        // Normal listener/speaker: view user profile only (cannot control other's mic)
                        openUserProfile(spk);
                      }
                    } else {
                      // Empty seat tapped: open seat modal (Take Seat) without turning on mic
                      setSelectedEmptySeat(idx);
                    }
                  }}
                  onTakeSeat={handleTakeSeat}
                  onLeaveSeat={handleLeaveSeat}
                />
              );
            })}
          </div>
        </div>

        {/* Listeners Section */}
        <div>
          <div className="flex items-center justify-between mb-2.5 px-1">
            <span className="text-xs font-bold uppercase tracking-wider text-neutral-400 flex items-center space-x-1">
              <Users className="w-3.5 h-3.5 mr-1 text-neutral-400" />
              <span>Listeners in Room</span>
              <span className="text-neutral-400 font-medium">({room.listenerCount})</span>
            </span>
            <span className="text-[10px] text-neutral-500 font-medium">
              {isActingHost ? 'Tap hand to approve speaker' : 'Audience'}
            </span>
          </div>

          <div className="grid grid-cols-4 gap-2.5">
            {room.listeners.map(listener => {
              const isCurrentUser = listener.id === currentUser.id;
              const hasHandRaised = isCurrentUser ? (hasRaisedHand || !!userPendingRequest) : listener.raisedHand;

              return (
                <div
                  key={listener.id}
                  id={`listener-avatar-${listener.id}`}
                  onClick={() => {
                    if (isActingHost && hasHandRaised) {
                      handleApproveRequest(listener.id);
                    } else {
                      openUserProfile(listener);
                    }
                  }}
                  className={`flex flex-col items-center p-2 rounded-xl bg-neutral-900/30 hover:bg-neutral-900/60 border border-neutral-800/40 relative group cursor-pointer transition-colors ${
                    hasHandRaised ? 'border-amber-500/50 bg-amber-950/20' : ''
                  }`}
                >
                  <div className="relative">
                    <img
                      src={listener.avatar}
                      alt={listener.name}
                      className={`w-11 h-11 rounded-full object-cover border ${
                        hasHandRaised ? 'border-amber-400' : 'border-neutral-800'
                      }`}
                    />
                    {hasHandRaised && (
                      <div className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-amber-500 text-neutral-950 flex items-center justify-center shadow-lg animate-bounce">
                        <Hand className="w-2.5 h-2.5" />
                      </div>
                    )}
                  </div>
                  <span className="mt-1 text-[10px] font-medium text-neutral-300 truncate max-w-full text-center">
                    {listener.name.split(' ')[0]}
                    {isCurrentUser && ' (You)'}
                  </span>
                  {hasHandRaised && (
                    <span className="text-[8px] font-bold text-amber-400 truncate max-w-full">
                      {isActingHost ? 'Approve' : 'Requested'}
                    </span>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Host Speaker Requests Modal / Drawer */}
      {showRequestsSheet && (
        <div
          id="host-requests-modal"
          className="absolute inset-0 bg-black/80 backdrop-blur-md z-50 flex flex-col justify-end animate-fade-in"
        >
          <div className="bg-neutral-900 border-t border-neutral-800 rounded-t-3xl p-5 space-y-4 shadow-2xl max-h-[85%] overflow-y-auto">
            <div className="flex items-center justify-between pb-2 border-b border-neutral-800">
              <div className="flex items-center space-x-2">
                <Hand className="w-5 h-5 text-amber-400" />
                <div>
                  <h3 className="text-sm font-bold text-white">Stage Speaker Requests</h3>
                  <p className="text-[10px] text-neutral-400">
                    Stage Capacity: {room.speakers.length} / {maxStageSeats} seats ({emptySeatCount} open)
                  </p>
                </div>
              </div>
              <button
                onClick={() => setShowRequestsSheet(false)}
                className="p-1 text-neutral-400 hover:text-white rounded-full hover:bg-neutral-800 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* If Stage is Full Warning */}
            {isStageFull && (
              <div className="p-3 bg-amber-950/40 border border-amber-500/40 rounded-xl text-xs text-amber-200 flex items-start space-x-2">
                <AlertCircle className="w-4 h-4 text-amber-400 flex-shrink-0 mt-0.5" />
                <div>
                  <span className="font-bold">Stage is full (6/6 seats occupied)</span>
                  <p className="text-[11px] text-amber-300/80 mt-0.5">
                    You cannot accept new speakers until an existing speaker is moved to the audience or leaves.
                  </p>
                </div>
              </div>
            )}

            {/* List of pending requests */}
            <div className="space-y-2.5">
              {pendingRequests.length === 0 ? (
                <div className="py-8 text-center text-neutral-400 space-y-2">
                  <UserCheck className="w-8 h-8 mx-auto text-neutral-600" />
                  <p className="text-xs font-semibold">No pending requests to speak</p>
                  <p className="text-[11px] text-neutral-500">
                    Audience members can tap &quot;Request to Speak&quot; to join the queue.
                  </p>
                </div>
              ) : (
                pendingRequests.map(req => (
                  <div
                    key={req.id}
                    className="p-3 rounded-xl bg-neutral-950/70 border border-neutral-800 flex items-center justify-between"
                  >
                    <div
                      className="flex items-center space-x-3 min-w-0 flex-1 cursor-pointer"
                      onClick={() => openUserProfile({
                        id: req.userId,
                        name: req.userName,
                        handle: req.userHandle,
                        avatar: req.userAvatar,
                      })}
                    >
                      <img
                        src={req.userAvatar}
                        alt={req.userName}
                        className="w-10 h-10 rounded-full object-cover border border-violet-400 flex-shrink-0"
                      />
                      <div className="min-w-0">
                        <div className="flex items-center space-x-1.5">
                          <span className="text-xs font-bold text-white truncate">{req.userName}</span>
                          {req.userId === currentUser.id && (
                            <span className="text-[9px] bg-violet-950 text-violet-300 font-bold px-1 rounded">You</span>
                          )}
                          <span className="text-[8px] px-1.5 py-0.5 rounded-full bg-amber-500/20 text-amber-300 font-bold border border-amber-500/30">
                            Pending
                          </span>
                        </div>
                        <p className="text-[10px] text-neutral-400 font-mono truncate">{req.userHandle}</p>
                        <p className="text-[9px] text-amber-400 font-medium">Requested {req.requestedAt}</p>
                      </div>
                    </div>

                    <div className="flex items-center space-x-2 flex-shrink-0">
                      <button
                        id={`modal-approve-btn-${req.userId}`}
                        onClick={() => handleApproveRequest(req.userId)}
                        disabled={isStageFull}
                        className={`px-3.5 py-1.5 rounded-xl text-xs font-bold flex items-center space-x-1 transition-all cursor-pointer ${
                          isStageFull
                            ? 'bg-neutral-800 text-neutral-500 border border-neutral-700 cursor-not-allowed'
                            : 'bg-violet-600 hover:bg-violet-500 text-white shadow-md shadow-violet-600/30 active:scale-95'
                        }`}
                      >
                        <Check className="w-3.5 h-3.5 stroke-[2.5]" />
                        <span>{isStageFull ? 'Stage Full' : 'Accept'}</span>
                      </button>

                      <button
                        id={`modal-decline-btn-${req.userId}`}
                        onClick={() => handleDeclineRequest(req.userId)}
                        className="px-3 py-1.5 rounded-xl text-xs font-medium text-neutral-300 hover:text-rose-400 bg-neutral-800 hover:bg-rose-950/60 transition-colors cursor-pointer"
                      >
                        <X className="w-3.5 h-3.5" />
                        <span>Decline</span>
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>

            {/* Test Helper to Simulate Request */}
            <div className="pt-2 border-t border-neutral-800 flex items-center justify-between">
              <button
                onClick={handleSimulateRequest}
                className="px-3 py-1.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-300 text-xs font-medium flex items-center space-x-1.5 transition-colors cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5 text-violet-400" />
                <span>+ Simulate Listener Request</span>
              </button>

              <button
                onClick={() => setShowRequestsSheet(false)}
                className="px-4 py-1.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-white text-xs font-semibold cursor-pointer"
              >
                Done
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Room Options Sheet */}
      {showOptionsMenu && (
        <div className="absolute inset-0 bg-black/75 backdrop-blur-sm z-50 flex flex-col justify-end">
          <div className="bg-neutral-900 border-t border-neutral-800 rounded-t-3xl p-5 space-y-4 shadow-2xl max-h-[80%] overflow-y-auto">
            <div className="flex items-center justify-between pb-2 border-b border-neutral-800">
              <div className="flex items-center space-x-2">
                <Sliders className="w-4 h-4 text-violet-400" />
                <span className="text-sm font-bold text-white">Stage Options & Etiquette</span>
              </div>
              <button
                onClick={() => setShowOptionsMenu(false)}
                className="p-1 text-neutral-400 hover:text-white rounded-full hover:bg-neutral-800 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-2 text-xs">
              <div className="p-3 bg-neutral-950/60 rounded-xl border border-neutral-800/80 space-y-1">
                <span className="font-semibold text-neutral-200">Room Details</span>
                <p className="text-neutral-400">ID: {room.id} • Club: {room.clubName || 'Open Stage'}</p>
                <p className="text-neutral-400">Topic: {room.topic}</p>
                <p className="text-neutral-400 line-clamp-2">{room.description}</p>
              </div>

              <div className="p-3 bg-neutral-950/60 rounded-xl border border-neutral-800/80 space-y-1">
                <span className="font-semibold text-neutral-200">Host Moderation Actions</span>
                <button
                  onClick={() => {
                    setShowOptionsMenu(false);
                    setShowRequestsSheet(true);
                  }}
                  className="w-full mt-1 py-2 bg-violet-600/30 hover:bg-violet-600/50 border border-violet-500/40 text-violet-200 rounded-lg text-xs font-semibold flex items-center justify-center space-x-1.5 cursor-pointer"
                >
                  <Hand className="w-3.5 h-3.5 text-amber-400" />
                  <span>Review Speaker Requests ({pendingRequests.length})</span>
                </button>
              </div>

              <div className="p-3 bg-neutral-950/60 rounded-xl border border-neutral-800/80 space-y-1">
                <span className="font-semibold text-neutral-200">Stage Etiquette</span>
                <p className="text-neutral-400">• Keep microphone muted when not speaking.</p>
                <p className="text-neutral-400">• Tap open seats or Raise Hand to request speaking access.</p>
                <p className="text-neutral-400">• The host approves requests when seats are available.</p>
              </div>

              <div className="p-3 bg-violet-950/20 rounded-xl border border-violet-800/30">
                <p className="text-[11px] text-violet-300">
                  🎙️ SNYVO Voice Club Stage — Connected to room lounge.
                </p>
              </div>
            </div>

            <div className="pt-2 space-y-2">
              <button
                id="options-audio-engine-btn"
                onClick={() => {
                  setShowOptionsMenu(false);
                  setShowAudioEngineModal(true);
                }}
                className="w-full py-2.5 rounded-xl bg-violet-950/40 hover:bg-violet-900/50 text-violet-200 border border-violet-700/40 text-xs font-semibold flex items-center justify-center space-x-2 transition-colors cursor-pointer"
              >
                <Server className="w-3.5 h-3.5 text-violet-400" />
                <span>Voice Engine Architecture & Status</span>
              </button>

              <button
                id="options-mic-permission-btn"
                onClick={() => {
                  setShowOptionsMenu(false);
                  setShowPermissionModal(true);
                }}
                className="w-full py-2.5 rounded-xl bg-neutral-800 hover:bg-neutral-750 text-neutral-200 text-xs font-semibold flex items-center justify-center space-x-2 transition-colors cursor-pointer"
              >
                <Mic className="w-3.5 h-3.5 text-emerald-400" />
                <span>Microphone Permissions Guide</span>
              </button>

              <button
                onClick={() => {
                  setShowOptionsMenu(false);
                  showToast('Room link copied to clipboard!');
                }}
                className="w-full py-2.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-white text-xs font-semibold flex items-center justify-center space-x-2 transition-colors cursor-pointer"
              >
                <Share2 className="w-3.5 h-3.5" />
                <span>Share Stage Link</span>
              </button>

              <button
                onClick={() => {
                  setShowOptionsMenu(false);
                  onLeaveRoom();
                }}
                className="w-full py-2.5 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/30 text-xs font-semibold flex items-center justify-center space-x-2 transition-colors cursor-pointer"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Leave Room</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Change Speaker Seat Modal */}
      {seatChangeTarget && (
        <div
          id="change-seat-modal"
          className="absolute inset-0 bg-black/80 backdrop-blur-md z-50 flex flex-col justify-end animate-fade-in"
        >
          <div className="bg-neutral-900 border-t border-neutral-800 rounded-t-3xl p-5 space-y-4 shadow-2xl max-h-[85%] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-neutral-800">
              <div className="flex items-center space-x-2.5">
                <div className="w-9 h-9 rounded-full bg-violet-600/20 border border-violet-500/40 flex items-center justify-center text-violet-400">
                  <ArrowRightLeft className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-white">Change Speaker Seat</h3>
                  <p className="text-[11px] text-neutral-400">
                    Moving <span className="text-white font-medium">{seatChangeTarget.speakerName}</span> • Currently in Seat #{seatChangeTarget.currentSeatIndex + 1}
                  </p>
                </div>
              </div>
              <button
                id="cancel-seat-change-btn"
                onClick={() => setSeatChangeTarget(null)}
                className="p-1 text-neutral-400 hover:text-white rounded-full hover:bg-neutral-800 cursor-pointer"
                aria-label="Close"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Check if no empty seats available */}
            {emptySeatCount === 0 ? (
              <div className="p-4 bg-amber-950/40 border border-amber-500/40 rounded-2xl text-center space-y-2">
                <AlertCircle className="w-8 h-8 text-amber-400 mx-auto" />
                <p className="text-xs font-bold text-amber-200">No empty seats available</p>
                <p className="text-[11px] text-amber-300/80">
                  All {maxStageSeats} stage seats are currently occupied. Another speaker must vacate a seat or move to the audience before you can move.
                </p>
              </div>
            ) : (
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <p className="text-xs text-neutral-300 font-medium">
                    Select an open seat to move into:
                  </p>
                  <span className="text-[10px] text-emerald-400 bg-emerald-950/50 border border-emerald-500/30 px-2 py-0.5 rounded-full font-bold">
                    {emptySeatCount} open
                  </span>
                </div>

                <div className="grid grid-cols-5 gap-1.5 sm:gap-2">
                  {Array.from({ length: 10 }).map((_, idx) => {
                    const seatNum = idx + 1;
                    const isCurrent = idx === seatChangeTarget.currentSeatIndex;
                    const occupant = room.speakers.find(s => (s.seatIndex ?? -1) === idx);
                    const isLocked = room.lockedSeats?.includes(idx);

                    if (isCurrent) {
                      return (
                        <div
                          key={`target-seat-${idx}`}
                          id={`change-seat-option-${seatNum}-current`}
                          className="p-2 rounded-xl bg-violet-950/40 border-2 border-violet-500 flex flex-col items-center justify-center space-y-1 relative"
                        >
                          <span className="text-[11px] font-bold text-violet-200">Seat #{seatNum}</span>
                          <span className="text-[8px] font-semibold text-violet-300 bg-violet-900/80 px-1 py-0.5 rounded-full">
                            Current
                          </span>
                        </div>
                      );
                    }

                    if (occupant) {
                      return (
                        <div
                          key={`target-seat-${idx}`}
                          id={`change-seat-option-${seatNum}-occupied`}
                          className="p-2 rounded-xl bg-neutral-950/60 border border-neutral-800/80 opacity-60 flex flex-col items-center justify-center space-y-0.5 cursor-not-allowed"
                        >
                          <span className="text-[11px] font-bold text-neutral-400">Seat #{seatNum}</span>
                          <span className="text-[8px] text-neutral-500 truncate max-w-full text-center">
                            Occupied
                          </span>
                        </div>
                      );
                    }

                    if (isLocked) {
                      return (
                        <div
                          key={`target-seat-${idx}`}
                          id={`change-seat-option-${seatNum}-locked`}
                          className="p-2 rounded-xl bg-neutral-950/40 border border-neutral-800/50 opacity-40 flex flex-col items-center justify-center space-y-0.5 cursor-not-allowed"
                        >
                          <span className="text-[11px] font-bold text-neutral-500">Seat #{seatNum}</span>
                          <span className="text-[8px] text-neutral-500">Locked</span>
                        </div>
                      );
                    }

                    // Empty / Available seat
                    return (
                      <button
                        key={`target-seat-${idx}`}
                        id={`change-seat-option-${seatNum}-available`}
                        onClick={() => handleMoveSpeaker(seatChangeTarget.speakerId, idx)}
                        className="p-2 rounded-xl bg-violet-950/20 hover:bg-violet-600/30 border-2 border-dashed border-violet-500/60 hover:border-violet-400 flex flex-col items-center justify-center space-y-1 transition-all cursor-pointer group active:scale-95 shadow-md shadow-violet-950/30"
                      >
                        <span className="text-[11px] font-bold text-white group-hover:text-violet-200">Seat #{seatNum}</span>
                        <span className="text-[8px] font-bold text-emerald-400 bg-emerald-950/60 border border-emerald-500/30 px-1 py-0.5 rounded-full">
                          Move
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Cancel action */}
            <div className="pt-2 border-t border-neutral-800 flex justify-end">
              <button
                id="close-seat-change-btn"
                onClick={() => setSeatChangeTarget(null)}
                className="px-4 py-2 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-300 text-xs font-semibold cursor-pointer transition-colors"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Quick Move Confirmation Dialog */}
      {confirmMoveSeat !== null && currentUserSpeaker && (
        <div
          id="quick-move-confirm-dialog"
          className="absolute inset-0 bg-black/75 backdrop-blur-sm z-50 flex items-center justify-center p-6 animate-fade-in"
        >
          <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-5 max-w-sm w-full space-y-4 shadow-2xl">
            <div className="flex items-center space-x-2.5">
              <div className="w-8 h-8 rounded-full bg-violet-600/20 border border-violet-500/40 flex items-center justify-center text-violet-400">
                <ArrowRightLeft className="w-4 h-4" />
              </div>
              <h4 className="text-sm font-bold text-white">Move to Seat #{confirmMoveSeat + 1}?</h4>
            </div>
            <p className="text-xs text-neutral-300 leading-relaxed">
              You are currently in <span className="font-semibold text-white">Seat #{(currentUserSpeaker.seatIndex ?? 0) + 1}</span>. Do you want to move your speaker seat to <span className="font-semibold text-violet-300">Seat #{confirmMoveSeat + 1}</span>?
            </p>
            <div className="flex items-center space-x-2 justify-end pt-2">
              <button
                id="cancel-quick-move-btn"
                onClick={() => setConfirmMoveSeat(null)}
                className="px-3.5 py-1.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-300 text-xs font-medium cursor-pointer transition-colors"
              >
                Cancel
              </button>
              <button
                id="confirm-quick-move-btn"
                onClick={() => {
                  handleMoveSpeaker(currentUser.id, confirmMoveSeat);
                  setConfirmMoveSeat(null);
                }}
                className="px-4 py-1.5 rounded-xl bg-violet-600 hover:bg-violet-500 text-white text-xs font-bold shadow-md shadow-violet-600/30 cursor-pointer transition-colors active:scale-95"
              >
                Confirm Move
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Host Speaker Action Modal */}
      {selectedSpeakerForAction && (() => {
        const speaker = room.speakers.find(s => s.id === selectedSpeakerForAction);
        if (!speaker) return null;
        const seatNumber = (speaker.seatIndex ?? 0) + 1;
        return (
          <div
            id="host-speaker-action-modal"
            className="absolute inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fade-in"
          >
            <div className="bg-neutral-900 border border-violet-900/40 rounded-3xl p-5 max-w-sm w-full space-y-4 shadow-2xl">
              <div className="flex items-center space-x-3 pb-3 border-b border-neutral-800">
                <div className="relative">
                  <img
                    src={speaker.avatar}
                    alt={speaker.name}
                    className="w-12 h-12 rounded-full object-cover border-2 border-violet-500/50"
                  />
                  {speaker.isHost && (
                    <div className="absolute -top-2 left-1/2 -translate-x-1/2 text-xs">👑</div>
                  )}
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center space-x-1">
                    <h4 className="text-sm font-bold text-white truncate">{speaker.name}</h4>
                    {speaker.isHost && (
                      <span className="text-[9px] font-bold text-amber-400 bg-amber-950/70 border border-amber-500/40 px-1 rounded">Host</span>
                    )}
                  </div>
                  <p className="text-xs text-neutral-400 truncate">{speaker.isHost ? 'Room Host' : 'Stage Speaker'}</p>
                  <span className="text-[10px] text-violet-300 font-medium">Currently in Seat #{seatNumber}</span>
                </div>
                <button
                  onClick={() => setSelectedSpeakerForAction(null)}
                  className="p-1.5 text-neutral-400 hover:text-white rounded-full hover:bg-neutral-800 cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Action Buttons */}
              <div className="space-y-2 pt-1">
                <button
                  id={`host-move-speaker-btn-${speaker.id}`}
                  onClick={() => {
                    const currentIdx = speaker.seatIndex ?? 0;
                    setSelectedSpeakerForAction(null);
                    setSeatChangeTarget({
                      speakerId: speaker.id,
                      speakerName: speaker.name,
                      speakerAvatar: speaker.avatar,
                      currentSeatIndex: currentIdx
                    });
                  }}
                  className="w-full py-2.5 bg-violet-600 hover:bg-violet-500 text-white text-xs font-bold rounded-xl flex items-center justify-center space-x-2 transition-colors cursor-pointer shadow-md shadow-violet-600/30"
                >
                  <ArrowRightLeft className="w-4 h-4" />
                  <span>Move to Another Seat</span>
                </button>

                {isActingHost && (
                  <button
                    id={`host-toggle-lock-btn-${speaker.id}`}
                    onClick={() => {
                      const currentIdx = speaker.seatIndex ?? 0;
                      handleToggleLockSeat(currentIdx);
                      setSelectedSpeakerForAction(null);
                    }}
                    className="w-full py-2.5 bg-neutral-800 hover:bg-neutral-750 border border-neutral-700 text-neutral-200 text-xs font-semibold rounded-xl transition-colors cursor-pointer flex items-center justify-center space-x-2"
                  >
                    {room.lockedSeats?.includes(speaker.seatIndex ?? -1) ? (
                      <>
                        <Unlock className="w-4 h-4 text-amber-400" />
                        <span>Unlock Seat #{seatNumber}</span>
                      </>
                    ) : (
                      <>
                        <Lock className="w-4 h-4 text-violet-400" />
                        <span>Lock Seat #{seatNumber}</span>
                      </>
                    )}
                  </button>
                )}

                {/* 1. Mute User Control */}
                {isHostOrModerator && !speaker.isHost && (
                  <button
                    id={`host-mute-user-btn-${speaker.id}`}
                    onClick={() => {
                      if (speaker.micState === 'muted_by_host') {
                        roomService.unmuteSpeakerByHost(room.id, speaker.id, currentUser.id);
                        showToast(`Allowed ${speaker.name} to speak`);
                      } else {
                        roomService.muteSpeakerByHost(room.id, speaker.id, currentUser.id);
                        showToast(`Muted ${speaker.name} on stage`);
                      }
                      setSelectedSpeakerForAction(null);
                    }}
                    className={`w-full py-2.5 text-xs font-bold rounded-xl transition-colors cursor-pointer flex items-center justify-center space-x-2 ${
                      speaker.micState === 'muted_by_host'
                        ? 'bg-emerald-950/60 hover:bg-emerald-900/80 border border-emerald-500/40 text-emerald-200'
                        : 'bg-amber-950/60 hover:bg-amber-900/80 border border-amber-500/40 text-amber-200'
                    }`}
                  >
                    {speaker.micState === 'muted_by_host' ? (
                      <>
                        <Mic className="w-4 h-4 text-emerald-400" />
                        <span>Allow to Speak (Unmute User)</span>
                      </>
                    ) : (
                      <>
                        <MicOff className="w-4 h-4 text-amber-400" />
                        <span>Mute User</span>
                      </>
                    )}
                  </button>
                )}

                {/* 2. Remove User from Seat */}
                {isHostOrModerator && !speaker.isHost && (
                  <button
                    id={`host-remove-speaker-btn-${speaker.id}`}
                    onClick={() => {
                      handleDemoteSpeaker(speaker.id);
                      setSelectedSpeakerForAction(null);
                    }}
                    className="w-full py-2.5 bg-rose-950/60 hover:bg-rose-900/80 border border-rose-500/40 text-rose-200 text-xs font-bold rounded-xl transition-colors cursor-pointer flex items-center justify-center space-x-2"
                  >
                    <UserX className="w-4 h-4 text-rose-400" />
                    <span>Remove User from Seat</span>
                  </button>
                )}

                {/* 3. View User */}
                <button
                  id={`host-view-user-btn-${speaker.id}`}
                  onClick={() => {
                    setSelectedSpeakerForAction(null);
                    openUserProfile(speaker);
                  }}
                  className="w-full py-2.5 bg-neutral-800/90 hover:bg-neutral-750 text-neutral-200 text-xs font-semibold rounded-xl transition-colors cursor-pointer flex items-center justify-center space-x-2"
                >
                  <Eye className="w-4 h-4 text-violet-400" />
                  <span>View User</span>
                </button>

                {/* Host Assign Co-Host / Moderator Control */}
                {isActingHost && !speaker.isHost && (
                  <button
                    id={`host-toggle-cohost-${speaker.id}`}
                    onClick={() => {
                      const isCurrentlyCohost = speaker.role === 'cohost';
                      const newRole: UserRoomRole = isCurrentlyCohost ? 'speaker' : 'cohost';
                      roomService.setUserRole(room.id, speaker.id, newRole, currentUser.id);
                      showToast(isCurrentlyCohost ? `Removed Co-Host role from ${speaker.name}` : `Made ${speaker.name} a Co-Host`);
                      setSelectedSpeakerForAction(null);
                    }}
                    className="w-full py-2.5 bg-neutral-800 hover:bg-neutral-750 border border-neutral-700 text-neutral-200 text-xs font-semibold rounded-xl transition-colors cursor-pointer flex items-center justify-center space-x-2"
                  >
                    <Shield className="w-4 h-4 text-violet-400" />
                    <span>{speaker.role === 'cohost' ? 'Demote from Co-Host' : 'Assign Co-Host Role'}</span>
                  </button>
                )}

                <button
                  onClick={() => setSelectedSpeakerForAction(null)}
                  className="w-full py-2 text-xs text-neutral-400 hover:text-white text-center cursor-pointer transition-colors"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        );
      })()}

      {/* Comprehensive User Profile Modal (Flow: Voice Room → User Seat → User Profile → Follow/Message/Voice/Gifts) */}
      {selectedUserProfile && (
        <UserProfileModal
          user={selectedUserProfile}
          currentUser={currentUser}
          currentRoom={room}
          onClose={() => setSelectedUserProfile(null)}
          onJoinRoom={onJoinRoom}
          onHostAction={(action, targetUserId) => {
            if (action === 'demote') {
              handleDemoteSpeaker(targetUserId);
            }
          }}
          onSendGift={(targetUserId) => {
            setSelectedUserProfile(null);
            setSelectedGiftReceiverId(targetUserId);
            setShowGiftBox(true);
          }}
        />
      )}

      {/* Coin System Foundation Info Modal */}
      {showCoinFoundationModal && (
        <div
          id="coin-foundation-modal"
          className="absolute inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-5 animate-fade-in"
        >
          <div className="bg-neutral-900 border border-amber-500/30 rounded-3xl p-5 max-w-sm w-full space-y-4 shadow-2xl">
            <div className="flex items-center justify-between pb-2 border-b border-neutral-800">
              <div className="flex items-center space-x-2">
                <span className="text-xl">🪙</span>
                <h3 className="text-sm font-bold text-white">SNYVO Coin System</h3>
              </div>
              <button
                onClick={() => setShowCoinFoundationModal(false)}
                className="p-1 text-neutral-400 hover:text-white rounded-full hover:bg-neutral-800 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-2.5 text-xs text-neutral-300">
              <div className="p-3 bg-amber-950/30 border border-amber-500/30 rounded-2xl flex items-center justify-between">
                <span className="font-medium text-amber-200">Current Room Coins</span>
                <span className="text-base font-extrabold text-amber-300">🪙 {room.roomCoins ?? 0}</span>
              </div>

              <div className="p-3 bg-neutral-950/60 border border-neutral-800 rounded-2xl space-y-1.5">
                <span className="text-xs font-bold text-white flex items-center space-x-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                  <span>UI Foundation Active</span>
                </span>
                <p className="text-[11px] text-neutral-400 leading-relaxed">
                  This status indicator provides the UI and data foundation for SNYVO's future coin gifting and creator rewards system.
                </p>
                <p className="text-[11px] text-neutral-400 leading-relaxed">
                  Real payment transactions and wallet balances will be enabled in a future release.
                </p>
              </div>
            </div>

            <div className="pt-1">
              <button
                onClick={() => setShowCoinFoundationModal(false)}
                className="w-full py-2.5 bg-gradient-to-r from-amber-600 to-yellow-600 hover:from-amber-500 hover:to-yellow-500 text-neutral-950 text-xs font-bold rounded-xl cursor-pointer transition-colors shadow-md shadow-amber-600/20"
              >
                Understood
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Voice Room Games Lobby Modal */}
      {showGamesLobby && (
        <GamesLobby
          room={room}
          currentUser={currentUser}
          onClose={() => setShowGamesLobby(false)}
          onLaunchGame={handleLaunchGame}
        />
      )}

      {/* ========================================================================= */}
      {/* 💬 COLLAPSIBLE / EXPANDABLE ROOM CHAT PANEL                               */}
      {/* ========================================================================= */}
      <RoomChatPanel
        room={room}
        currentUser={currentUser}
        currentUserRole={(currentUserRole as ChatRole) || 'listener'}
        isExpanded={isChatPanelExpanded}
        onToggleExpand={setIsChatPanelExpanded}
        onOpenUserProfile={openUserProfile}
        onToast={showToast}
      />

      {/* Floating Quick Reaction Emoji Bar */}
      {showEmojiPicker && (
        <div
          id="floating-emoji-bar"
          className="mx-4 mb-2 px-4 py-2 rounded-2xl bg-neutral-900/95 border border-violet-800/40 backdrop-blur-xl flex items-center justify-around shadow-xl animate-fade-in z-30"
        >
          {['❤️', '🔥', '👏', '🎉', '🎙️', '✨'].map(emoji => (
            <button
              key={emoji}
              onClick={() => {
                handleSendReaction(emoji);
                showToast(`Reacted with ${emoji}`);
              }}
              className="p-1 hover:scale-130 active:scale-95 transition-transform text-xl cursor-pointer"
              aria-label={`React with ${emoji}`}
            >
              {emoji}
            </button>
          ))}
          <button
            onClick={() => setShowEmojiPicker(false)}
            className="p-1 text-neutral-400 hover:text-white rounded-full ml-1"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Contextual Stage Action Pill (Leave Seat / Take Seat helper) */}
      <div className="px-4 pb-1.5 flex items-center justify-between z-20 text-[11px]">
        {isUserSpeaker ? (
          <div className="w-full flex items-center justify-between px-3 py-1.5 rounded-xl bg-neutral-900/60 border border-neutral-800/70">
            <span className="text-violet-300 font-medium flex items-center space-x-1">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span>You are on Stage #{((currentUserSpeaker?.seatIndex ?? 0) + 1)}</span>
            </span>
            <button
              id="stage-leave-seat-quick-btn"
              onClick={handleLeaveSeat}
              className="px-2 py-0.5 rounded-lg bg-rose-950/60 hover:bg-rose-900/70 border border-rose-500/40 text-rose-300 font-semibold cursor-pointer transition-colors"
            >
              Get Down
            </button>
          </div>
        ) : (
          <div className="w-full flex items-center justify-between px-3 py-1.5 rounded-xl bg-neutral-900/40 border border-neutral-800/50">
            <span className="text-neutral-400">
              {emptySeatCount > 0 ? `${emptySeatCount} seats available on stage` : 'Stage is currently full'}
            </span>
            {emptySeatCount > 0 && (
              <button
                id="stage-take-seat-quick-btn"
                onClick={() => handleTakeSeat()}
                className="px-2.5 py-0.5 rounded-lg bg-violet-600/30 hover:bg-violet-600/50 border border-violet-500/40 text-violet-200 font-semibold cursor-pointer transition-colors"
              >
                + Take Seat
              </button>
            )}
          </div>
        )}
      </div>

      {/* ========================================================================= */}
      {/* 🎮 MODERN BOTTOM CONTROL BAR (7 REQUIRED BUTTONS)                          */}
      {/* 1. Mic, 2. Sound, 3. Emoji, 4. Gift, 5. Chat, 6. Options, 7. Leave        */}
      {/* ========================================================================= */}
      <div
        id="voice-room-control-bar"
        className="px-3 sm:px-5 py-2.5 bg-neutral-950/98 border-t border-neutral-850 flex items-center justify-around z-30 shadow-2xl backdrop-blur-md"
      >
        {/* 1. Microphone Button with 5 State System */}
        <button
          id="control-bar-mic-btn"
          onClick={() => {
            if (isUserSpeaker) {
              handleToggleMute();
            } else {
              handleTakeSeat();
            }
          }}
          className={`flex flex-col items-center space-y-1 p-1.5 rounded-2xl transition-all cursor-pointer active:scale-95 ${
            isUserSpeaker
              ? micState === 'on'
                ? 'text-emerald-400 hover:text-emerald-300'
                : micState === 'muted_by_host'
                ? 'text-amber-400 hover:text-amber-300'
                : micState === 'permission_denied'
                ? 'text-rose-400 hover:text-rose-300'
                : micState === 'permission_granted'
                ? 'text-violet-300 hover:text-violet-200'
                : 'text-neutral-400 hover:text-white'
              : 'text-neutral-400 hover:text-violet-300'
          }`}
          title={
            isUserSpeaker
              ? micState === 'on'
                ? 'Mic ON (Tap to mute)'
                : micState === 'muted_by_host'
                ? 'Muted by Host / Moderator'
                : micState === 'permission_denied'
                ? 'Microphone Permission Denied (Tap to fix)'
                : micState === 'permission_granted'
                ? 'Permission Granted (Tap to speak)'
                : 'Mic OFF (Tap to unmute)'
              : 'Take Seat / Request Mic'
          }
        >
          <div
            className={`w-10 h-10 rounded-2xl flex items-center justify-center transition-all ${
              isUserSpeaker
                ? micState === 'on'
                  ? 'bg-emerald-500/20 border border-emerald-500/60 shadow-md shadow-emerald-500/30 ring-2 ring-emerald-500/40 text-emerald-300'
                  : micState === 'muted_by_host'
                  ? 'bg-amber-950/60 border border-amber-500/60 shadow-md shadow-amber-950/40 text-amber-300'
                  : micState === 'permission_denied'
                  ? 'bg-rose-950/60 border border-rose-500/70 shadow-md shadow-rose-950/40 text-rose-300'
                  : micState === 'permission_granted'
                  ? 'bg-violet-950/50 border border-violet-500/50 shadow-md shadow-violet-950/40 text-violet-300'
                  : 'bg-neutral-850 border border-neutral-700/60 text-neutral-300'
                : 'bg-neutral-850 border border-neutral-700/60 text-neutral-400'
            }`}
          >
            {isUserSpeaker ? (
              micState === 'on' ? (
                <Mic className="w-5 h-5 text-emerald-400 animate-pulse" />
              ) : micState === 'muted_by_host' ? (
                <div className="relative">
                  <MicOff className="w-5 h-5 text-amber-400" />
                  <Lock className="w-2.5 h-2.5 text-amber-300 absolute -bottom-1 -right-1" />
                </div>
              ) : micState === 'permission_denied' ? (
                <AlertCircle className="w-5 h-5 text-rose-400" />
              ) : micState === 'permission_granted' ? (
                <Mic className="w-5 h-5 text-violet-300" />
              ) : (
                <MicOff className="w-5 h-5 text-rose-400" />
              )
            ) : (
              <Mic className="w-5 h-5 text-neutral-400" />
            )}
          </div>
          <span className="text-[10px] font-medium leading-none">
            {isUserSpeaker
              ? micState === 'on'
                ? 'Mic ON'
                : micState === 'muted_by_host'
                ? 'Host Muted'
                : micState === 'permission_denied'
                ? 'Mic Denied'
                : micState === 'permission_granted'
                ? 'Ready'
                : 'Mic OFF'
              : 'Mic'}
          </span>
        </button>

        {/* 2. Speaker/Audio Button */}
        <button
          id="control-bar-audio-btn"
          onClick={() => {
            const next = !isSpeakerAudioEnabled;
            setIsSpeakerAudioEnabled(next);
            showToast(next ? 'Room audio unmuted' : 'Room audio muted');
          }}
          className="flex flex-col items-center space-y-1 p-1.5 rounded-2xl text-neutral-400 hover:text-white transition-all cursor-pointer active:scale-95"
          title={isSpeakerAudioEnabled ? 'Mute Room Speaker' : 'Unmute Room Speaker'}
        >
          <div
            className={`w-10 h-10 rounded-2xl flex items-center justify-center border transition-all ${
              isSpeakerAudioEnabled
                ? 'bg-neutral-850 border-neutral-700/60 text-violet-300'
                : 'bg-neutral-900 border-neutral-800 text-neutral-500'
            }`}
          >
            {isSpeakerAudioEnabled ? (
              <Volume2 className="w-5 h-5 text-violet-300" />
            ) : (
              <VolumeX className="w-5 h-5 text-neutral-500" />
            )}
          </div>
          <span className="text-[10px] font-medium leading-none">Sound</span>
        </button>

        {/* 3. Emoji Button */}
        <button
          id="control-bar-emoji-btn"
          onClick={() => setShowEmojiPicker(!showEmojiPicker)}
          className={`flex flex-col items-center space-y-1 p-1.5 rounded-2xl transition-all cursor-pointer active:scale-95 ${
            showEmojiPicker ? 'text-amber-300' : 'text-neutral-400 hover:text-white'
          }`}
          title="Reactions & Emojis"
        >
          <div
            className={`w-10 h-10 rounded-2xl flex items-center justify-center border transition-all ${
              showEmojiPicker
                ? 'bg-amber-950/40 border-amber-500/50 text-amber-300 shadow-md shadow-amber-950/40'
                : 'bg-neutral-850 border-neutral-700/60'
            }`}
          >
            <Smile className="w-5 h-5" />
          </div>
          <span className="text-[10px] font-medium leading-none">Emoji</span>
        </button>

        {/* 4. Gift Button */}
        <button
          id="control-bar-gift-btn"
          onClick={() => setShowGiftArea(true)}
          className="flex flex-col items-center space-y-1 p-1.5 rounded-2xl text-rose-300 hover:text-rose-200 transition-all cursor-pointer active:scale-95 group"
          title="Send Virtual Gift"
        >
          <div className="w-10 h-10 rounded-2xl flex items-center justify-center bg-gradient-to-tr from-rose-600 via-pink-600 to-amber-500 text-white shadow-lg shadow-rose-600/30 group-hover:brightness-110 group-active:scale-95 border border-rose-400/40">
            <Gift className="w-5 h-5 animate-pulse" />
          </div>
          <span className="text-[10px] font-bold leading-none text-rose-300">Gift</span>
        </button>

        {/* 5. Chat Button */}
        <button
          id="control-bar-chat-btn"
          onClick={() => setIsChatPanelExpanded(!isChatPanelExpanded)}
          className={`flex flex-col items-center space-y-1 p-1.5 rounded-2xl transition-all cursor-pointer active:scale-95 relative ${
            isChatPanelExpanded ? 'text-violet-300' : 'text-neutral-400 hover:text-white'
          }`}
          title="Toggle Room Chat"
        >
          <div
            className={`w-10 h-10 rounded-2xl flex items-center justify-center border relative transition-all ${
              isChatPanelExpanded
                ? 'bg-violet-600/20 border-violet-500/60 text-violet-300 shadow-md shadow-violet-950/40'
                : 'bg-neutral-850 border-neutral-700/60'
            }`}
          >
            <MessageSquare className="w-5 h-5" />
            <span className="absolute -top-1 -right-1 min-w-[16px] h-4 px-1 rounded-full bg-violet-600 text-white text-[9px] font-extrabold flex items-center justify-center ring-2 ring-neutral-950">
              {chatMessagesCount}
            </span>
          </div>
          <span className="text-[10px] font-medium leading-none">Chat</span>
        </button>

        {/* 6. More / Options Button */}
        <button
          id="control-bar-more-btn"
          onClick={() => setShowOptionsMenu(true)}
          className="flex flex-col items-center space-y-1 p-1.5 rounded-2xl text-neutral-400 hover:text-white transition-all cursor-pointer active:scale-95"
          title="Room Options & Settings"
        >
          <div className="w-10 h-10 rounded-2xl flex items-center justify-center bg-neutral-850 border border-neutral-700/60">
            <MoreVertical className="w-5 h-5" />
          </div>
          <span className="text-[10px] font-medium leading-none">More</span>
        </button>

        {/* 7. Leave Room Button */}
        <button
          id="control-bar-leave-btn"
          onClick={onLeaveRoom}
          className="flex flex-col items-center space-y-1 p-1.5 rounded-2xl text-rose-400 hover:text-rose-300 transition-all cursor-pointer active:scale-95"
          title="Leave Room"
        >
          <div className="w-10 h-10 rounded-2xl flex items-center justify-center bg-rose-950/40 hover:bg-rose-900/60 border border-rose-500/40 text-rose-400 shadow-sm shadow-rose-950/50">
            <LogOut className="w-5 h-5" />
          </div>
          <span className="text-[10px] font-bold leading-none text-rose-400">Leave</span>
        </button>
      </div>

      {/* ========================================================================= */}
      {/* 🎙️ CURRENT USER SEAT VOICE-CONTROL MENU (When user taps their own seat)   */}
      {/* ========================================================================= */}
      {showMySeatActions && currentUserSpeaker && (
        <div
          id="my-seat-voice-control-modal"
          className="absolute inset-0 bg-black/80 backdrop-blur-md z-50 flex flex-col justify-end animate-fade-in"
          onClick={() => setShowMySeatActions(false)}
        >
          <div
            className="bg-neutral-900 border-t border-violet-800/50 rounded-t-3xl p-5 space-y-4 shadow-2xl max-w-md mx-auto w-full"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Header: User Info & Seat Number */}
            <div className="flex items-center justify-between pb-3 border-b border-neutral-800">
              <div className="flex items-center space-x-3">
                <div className="relative">
                  <img
                    src={currentUser.avatar}
                    alt={currentUser.name}
                    className="w-11 h-11 rounded-full object-cover border-2 border-violet-500 shadow-md"
                  />
                  {micState === 'on' ? (
                    <div className="absolute -bottom-1 -right-1 w-4 h-4 rounded-full bg-emerald-500 border border-emerald-200 flex items-center justify-center shadow-md">
                      <Mic className="w-2.5 h-2.5 text-neutral-950 stroke-[2.5]" />
                    </div>
                  ) : micState === 'muted_by_host' ? (
                    <div className="absolute -bottom-1 -right-1 w-4 h-4 rounded-full bg-amber-600 border border-amber-300 flex items-center justify-center shadow-md">
                      <Lock className="w-2.5 h-2.5 text-white stroke-[2.5]" />
                    </div>
                  ) : (
                    <div className="absolute -bottom-1 -right-1 w-4 h-4 rounded-full bg-rose-600 border border-rose-300 flex items-center justify-center shadow-md">
                      <MicOff className="w-2.5 h-2.5 text-white stroke-[2.5]" />
                    </div>
                  )}
                </div>
                <div>
                  <div className="flex items-center space-x-1.5">
                    <h3 className="text-sm font-bold text-white">{currentUser.name}</h3>
                    <span className="text-[10px] font-bold text-violet-300 bg-violet-950/70 border border-violet-700/50 px-2 py-0.2 rounded-full">
                      Seat #{(currentUserSpeaker.seatIndex ?? 0) + 1}
                    </span>
                  </div>
                  <p className="text-xs text-neutral-400 font-medium">Voice Control Menu</p>
                </div>
              </div>
              <button
                id="close-my-seat-voice-menu-btn"
                onClick={() => setShowMySeatActions(false)}
                className="p-1.5 text-neutral-400 hover:text-white rounded-full hover:bg-neutral-800 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Current Microphone State - Clearly Visible */}
            <div className="p-3 rounded-2xl bg-neutral-950/70 border border-neutral-800 flex items-center justify-between">
              <span className="text-xs text-neutral-400 font-medium">Current Mic Status:</span>
              <div className="flex items-center space-x-1.5">
                {micState === 'on' ? (
                  <span className="inline-flex items-center space-x-1.5 px-2.5 py-1 rounded-full text-xs font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 animate-pulse">
                    <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                    <Mic className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Microphone ON</span>
                  </span>
                ) : micState === 'muted_by_host' ? (
                  <span className="inline-flex items-center space-x-1.5 px-2.5 py-1 rounded-full text-xs font-bold bg-amber-500/20 text-amber-300 border border-amber-500/40">
                    <Lock className="w-3.5 h-3.5 text-amber-400" />
                    <span>Muted by Host</span>
                  </span>
                ) : micState === 'permission_denied' ? (
                  <span className="inline-flex items-center space-x-1.5 px-2.5 py-1 rounded-full text-xs font-bold bg-rose-500/20 text-rose-300 border border-rose-500/40">
                    <AlertTriangle className="w-3.5 h-3.5 text-rose-400" />
                    <span>Permission Denied</span>
                  </span>
                ) : (
                  <span className="inline-flex items-center space-x-1.5 px-2.5 py-1 rounded-full text-xs font-bold bg-rose-500/20 text-rose-300 border border-rose-500/40">
                    <MicOff className="w-3.5 h-3.5 text-rose-400" />
                    <span>Microphone OFF</span>
                  </span>
                )}
              </div>
            </div>

            {/* Host Muted Warning if applicable */}
            {micState === 'muted_by_host' && (
              <div className="p-3 bg-amber-950/40 border border-amber-500/40 rounded-xl text-xs text-amber-200 flex items-start space-x-2">
                <Lock className="w-4 h-4 text-amber-400 flex-shrink-0 mt-0.5" />
                <p className="text-[11px] leading-relaxed">
                  You were muted by the Host or Moderator. You cannot turn your microphone back ON until allowed by the host.
                </p>
              </div>
            )}

            {/* Primary Controls: Microphone ON & Microphone OFF */}
            <div className="grid grid-cols-2 gap-2.5 pt-1">
              {/* Microphone ON Button */}
              <button
                id="seat-control-mic-on-btn"
                onClick={async () => {
                  await handleTurnMicOn();
                  setShowMySeatActions(false);
                }}
                disabled={micState === 'muted_by_host'}
                className={`py-3 px-3 rounded-2xl border text-xs font-bold flex flex-col items-center justify-center space-y-1.5 transition-all cursor-pointer ${
                  micState === 'on'
                    ? 'bg-emerald-600/30 border-emerald-500/80 text-emerald-200 ring-2 ring-emerald-500/40 shadow-lg shadow-emerald-950/50'
                    : micState === 'muted_by_host'
                    ? 'bg-neutral-900 border-neutral-800 text-neutral-600 opacity-50 cursor-not-allowed'
                    : 'bg-neutral-800/90 hover:bg-emerald-950/60 border-neutral-700/80 hover:border-emerald-500/50 text-neutral-200 hover:text-emerald-300'
                }`}
              >
                <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                  micState === 'on' ? 'bg-emerald-500 text-neutral-950' : 'bg-neutral-700/80 text-emerald-400'
                }`}>
                  <Mic className="w-4 h-4 stroke-[2.5]" />
                </div>
                <div className="text-center">
                  <span className="block font-bold">Microphone ON</span>
                  <span className="text-[9px] text-neutral-400 font-normal">
                    {micState === 'on' ? 'Currently Active' : 'Start speaking'}
                  </span>
                </div>
              </button>

              {/* Microphone OFF Button */}
              <button
                id="seat-control-mic-off-btn"
                onClick={async () => {
                  await handleTurnMicOff();
                  setShowMySeatActions(false);
                }}
                className={`py-3 px-3 rounded-2xl border text-xs font-bold flex flex-col items-center justify-center space-y-1.5 transition-all cursor-pointer ${
                  micState === 'off' || micState === 'muted_by_host'
                    ? 'bg-rose-600/20 border-rose-500/70 text-rose-200 ring-2 ring-rose-500/30 shadow-lg shadow-rose-950/50'
                    : 'bg-neutral-800/90 hover:bg-rose-950/60 border-neutral-700/80 hover:border-rose-500/50 text-neutral-200 hover:text-rose-300'
                }`}
              >
                <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                  micState === 'off' || micState === 'muted_by_host' ? 'bg-rose-500 text-white' : 'bg-neutral-700/80 text-rose-400'
                }`}>
                  <MicOff className="w-4 h-4 stroke-[2.5]" />
                </div>
                <div className="text-center">
                  <span className="block font-bold">Microphone OFF</span>
                  <span className="text-[9px] text-neutral-400 font-normal">
                    {micState === 'off' || micState === 'muted_by_host' ? 'Currently Muted' : 'Mute your audio'}
                  </span>
                </div>
              </button>
            </div>

            {/* Additional Seat Actions */}
            <div className="pt-2 space-y-2 border-t border-neutral-800/80">
              {/* Move Seat */}
              <button
                id="seat-control-move-seat-btn"
                onClick={() => {
                  setShowMySeatActions(false);
                  setSeatChangeTarget({
                    speakerId: currentUser.id,
                    speakerName: currentUser.name,
                    speakerAvatar: currentUser.avatar,
                    currentSeatIndex: currentUserSpeaker.seatIndex ?? 0
                  });
                }}
                className="w-full py-2 px-3.5 rounded-xl bg-violet-600/20 hover:bg-violet-600/30 border border-violet-500/40 text-violet-200 text-xs font-semibold flex items-center justify-between cursor-pointer transition-colors"
              >
                <div className="flex items-center space-x-2">
                  <ArrowRightLeft className="w-3.5 h-3.5 text-violet-300" />
                  <span>Move to Another Seat</span>
                </div>
                <span className="text-[10px] text-violet-300 font-normal">Switch stage position</span>
              </button>

              {/* Leave Seat / Return to Audience */}
              <button
                id="modal-get-down-seat-btn"
                onClick={() => {
                  handleLeaveSeat();
                  setShowMySeatActions(false);
                }}
                className="w-full py-2 px-3.5 rounded-xl bg-rose-950/40 hover:bg-rose-950/70 border border-rose-500/40 text-rose-300 text-xs font-semibold flex items-center justify-between cursor-pointer transition-colors"
              >
                <div className="flex items-center space-x-2">
                  <LogOut className="w-3.5 h-3.5 text-rose-400" />
                  <span>Leave Seat (Get Down)</span>
                </div>
                <span className="text-[10px] text-rose-400/80 font-normal">Stay in room as listener</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 🪑 EMPTY SPEAKER SEAT MENU (Take Seat option)                            */}
      {/* ========================================================================= */}
      {selectedEmptySeat !== null && (
        <div
          id="empty-seat-modal"
          className="absolute inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fade-in"
          onClick={() => setSelectedEmptySeat(null)}
        >
          <div
            className="bg-neutral-900 border border-violet-800/40 rounded-3xl p-5 max-w-sm w-full space-y-4 shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-3 border-b border-neutral-800">
              <div className="flex items-center space-x-3">
                <div className="w-11 h-11 rounded-2xl bg-violet-950/60 border border-violet-500/40 flex items-center justify-center text-violet-300 font-bold text-sm">
                  #{selectedEmptySeat + 1}
                </div>
                <div>
                  <h3 className="text-sm font-bold text-white">Speaker Seat #{selectedEmptySeat + 1}</h3>
                  <p className="text-xs text-neutral-400">
                    {room.lockedSeats?.includes(selectedEmptySeat) ? 'Locked Seat' : 'Available Stage Seat'}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setSelectedEmptySeat(null)}
                className="p-1.5 text-neutral-400 hover:text-white rounded-full hover:bg-neutral-800 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {room.lockedSeats?.includes(selectedEmptySeat) ? (
              <div className="space-y-3">
                <div className="p-3 bg-amber-950/40 border border-amber-500/30 rounded-2xl flex items-start space-x-2 text-xs text-amber-200">
                  <Lock className="w-4 h-4 text-amber-400 flex-shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold">Seat #{selectedEmptySeat + 1} is locked</span>
                    <p className="text-[11px] text-amber-300/80 mt-0.5">
                      The host has locked this seat. Only the room host or moderator can unlock it.
                    </p>
                  </div>
                </div>

                {isHostOrModerator && (
                  <button
                    onClick={() => {
                      handleToggleLockSeat(selectedEmptySeat);
                      setSelectedEmptySeat(null);
                    }}
                    className="w-full py-2.5 rounded-xl bg-violet-600 hover:bg-violet-500 text-white text-xs font-bold flex items-center justify-center space-x-2 cursor-pointer transition-colors"
                  >
                    <Unlock className="w-4 h-4" />
                    <span>Unlock Seat #{selectedEmptySeat + 1}</span>
                  </button>
                )}

                <button
                  onClick={() => setSelectedEmptySeat(null)}
                  className="w-full py-2 text-xs text-neutral-400 hover:text-white text-center cursor-pointer"
                >
                  Close
                </button>
              </div>
            ) : isUserSpeaker ? (
              <div className="space-y-3">
                <p className="text-xs text-neutral-300 leading-relaxed">
                  You are currently sitting in Seat #{(currentUserSpeaker?.seatIndex ?? 0) + 1}. Would you like to move to Seat #{selectedEmptySeat + 1}?
                </p>

                <button
                  id="empty-seat-move-btn"
                  onClick={() => {
                    handleMoveSpeaker(currentUser.id, selectedEmptySeat);
                    setSelectedEmptySeat(null);
                  }}
                  className="w-full py-2.5 rounded-xl bg-violet-600 hover:bg-violet-500 text-white text-xs font-bold flex items-center justify-center space-x-2 cursor-pointer transition-colors shadow-md shadow-violet-600/30"
                >
                  <ArrowRightLeft className="w-4 h-4" />
                  <span>Move to Seat #{selectedEmptySeat + 1}</span>
                </button>

                <button
                  onClick={() => setSelectedEmptySeat(null)}
                  className="w-full py-2 text-xs text-neutral-400 hover:text-white text-center cursor-pointer"
                >
                  Cancel
                </button>
              </div>
            ) : (
              <div className="space-y-3">
                <p className="text-xs text-neutral-300 leading-relaxed">
                  Join the speaker stage in Seat #{selectedEmptySeat + 1}. Your microphone will start muted. You can turn your microphone ON from your seat controls whenever you are ready.
                </p>

                <button
                  id="empty-seat-take-seat-btn"
                  onClick={() => {
                    handleTakeSeat(selectedEmptySeat);
                    setSelectedEmptySeat(null);
                    showToast(`You took Seat #${selectedEmptySeat + 1}. Tap your seat to manage your microphone.`);
                  }}
                  className="w-full py-2.5 rounded-xl bg-violet-600 hover:bg-violet-500 text-white text-xs font-bold flex items-center justify-center space-x-2 cursor-pointer transition-colors shadow-md shadow-violet-600/30 active:scale-95"
                >
                  <Check className="w-4 h-4 stroke-[2.5]" />
                  <span>Take Seat</span>
                </button>

                <button
                  onClick={() => setSelectedEmptySeat(null)}
                  className="w-full py-2 text-xs text-neutral-400 hover:text-white text-center cursor-pointer"
                >
                  Cancel
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 📢 ROOM INFORMATION MODAL (Announcement, Rules, Host Bio)                 */}
      {/* ========================================================================= */}
      {showRoomInfoModal && (
        <div
          id="room-info-modal"
          className="absolute inset-0 bg-black/80 backdrop-blur-md z-50 flex flex-col justify-end sm:justify-center p-0 sm:p-4 animate-fade-in"
        >
          <div className="bg-neutral-900 border-t sm:border border-violet-800/40 rounded-t-3xl sm:rounded-3xl p-5 space-y-4 shadow-2xl max-w-lg mx-auto w-full max-h-[85vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-neutral-800">
              <div className="flex items-center space-x-2">
                <Info className="w-5 h-5 text-violet-400" />
                <h3 className="text-sm font-bold text-white uppercase tracking-wider">Room Information</h3>
              </div>
              <button
                id="close-room-info-modal-btn"
                onClick={() => setShowRoomInfoModal(false)}
                className="p-1.5 text-neutral-400 hover:text-white rounded-full hover:bg-neutral-800 cursor-pointer transition-colors"
                aria-label="Close Room Info"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* 1. Room Announcement */}
            <div className="p-3.5 rounded-2xl bg-violet-950/40 border border-violet-700/40 space-y-1.5">
              <div className="flex items-center space-x-2 text-violet-300">
                <Bell className="w-4 h-4" />
                <span className="text-xs font-bold uppercase tracking-wider">Room Announcement</span>
              </div>
              <p className="text-xs text-neutral-200 leading-relaxed">
                {room.description || 'Welcome to the SNYVO live audio room! Connect with like-minded creators, participate in on-stage discussions, and explore community clubs.'}
              </p>
            </div>

            {/* 2. Room Rules */}
            <div className="p-3.5 rounded-2xl bg-neutral-800/60 border border-neutral-700/50 space-y-2">
              <div className="flex items-center space-x-2 text-amber-300">
                <FileText className="w-4 h-4" />
                <span className="text-xs font-bold uppercase tracking-wider">Room Guidelines & Rules</span>
              </div>
              <ul className="text-xs text-neutral-300 space-y-1.5 list-disc list-inside">
                <li><strong>Respect All Participants:</strong> Keep the conversation positive and free of harassment or hate speech.</li>
                <li><strong>Microphone Etiquette:</strong> Keep your mic muted when not speaking to ensure crystal clear stage audio.</li>
                <li><strong>Stage Moderation:</strong> Host & Co-host manage seat queue and speaker turn-taking.</li>
                <li><strong>No Spam or Promotion:</strong> Unauthorized advertising or soundboard spam is strictly prohibited.</li>
              </ul>
            </div>

            {/* 3. Host Information */}
            <div className="p-3.5 rounded-2xl bg-neutral-800/60 border border-neutral-700/50 space-y-3">
              <div className="flex items-center space-x-2 text-neutral-200">
                <Crown className="w-4 h-4 text-amber-400" />
                <span className="text-xs font-bold uppercase tracking-wider">Host Profile</span>
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="relative">
                    <img
                      src={room.host.avatar}
                      alt={room.host.name}
                      className="w-12 h-12 rounded-full object-cover ring-2 ring-amber-400"
                    />
                    <span className="absolute -top-1 -right-1 text-xs">👑</span>
                  </div>
                  <div>
                    <div className="flex items-center space-x-1.5">
                      <span className="font-bold text-white text-sm">{room.host.name}</span>
                      <span className="text-[9px] font-extrabold text-amber-300 bg-amber-500/20 border border-amber-400/40 px-1.5 py-0.2 rounded-full">
                        Host
                      </span>
                    </div>
                    <p className="text-[11px] text-neutral-400">@{room.host.handle.replace('@', '')}</p>
                    <p className="text-[10px] text-violet-300 mt-0.5">{room.host.followers.toLocaleString()} followers</p>
                  </div>
                </div>

                <button
                  id="host-follow-toggle-btn"
                  onClick={() => {
                    setHasFollowedHost(!hasFollowedHost);
                    showToast(!hasFollowedHost ? `Followed ${room.host.name}!` : `Unfollowed ${room.host.name}`);
                  }}
                  className={`px-3.5 py-1.5 rounded-full text-xs font-semibold border transition-all cursor-pointer active:scale-95 ${
                    hasFollowedHost
                      ? 'bg-neutral-800 border-neutral-700 text-neutral-300'
                      : 'bg-violet-600 hover:bg-violet-500 border-violet-500 text-white shadow-md shadow-violet-600/30'
                  }`}
                >
                  {hasFollowedHost ? 'Following' : '+ Follow Host'}
                </button>
              </div>

              {room.host.bio && (
                <p className="text-xs text-neutral-300 italic bg-neutral-900/60 p-2.5 rounded-xl border border-neutral-800">
                  &ldquo;{room.host.bio}&rdquo;
                </p>
              )}
            </div>

            <button
              onClick={() => setShowRoomInfoModal(false)}
              className="w-full py-2.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-white text-xs font-semibold cursor-pointer transition-colors"
            >
              Close
            </button>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 🎁 SNYVO GIFT INTERACTION AREA (UI-Only, No Real Payment / Transactions)    */}
      {/* ========================================================================= */}
      {showGiftArea && (
        <div
          id="gift-interaction-modal"
          className="absolute inset-0 bg-black/80 backdrop-blur-md z-50 flex flex-col justify-end animate-fade-in"
        >
          <div className="bg-neutral-900 border-t border-rose-900/50 rounded-t-3xl p-5 space-y-4 shadow-2xl max-w-lg mx-auto w-full">
            <div className="flex items-center justify-between pb-2 border-b border-neutral-800">
              <div className="flex items-center space-x-2">
                <Gift className="w-5 h-5 text-rose-400" />
                <h3 className="text-sm font-bold text-white uppercase tracking-wider">Send Virtual Gift</h3>
              </div>
              <button
                id="close-gift-area-btn"
                onClick={() => setShowGiftArea(false)}
                className="p-1.5 text-neutral-400 hover:text-white rounded-full hover:bg-neutral-800 cursor-pointer transition-colors"
                aria-label="Close Gift Sheet"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* UI Notice / Disclaimer Banner */}
            <div className="p-2.5 rounded-xl bg-rose-950/40 border border-rose-500/30 flex items-start space-x-2">
              <Sparkles className="w-4 h-4 text-rose-400 flex-shrink-0 mt-0.5" />
              <p className="text-[11px] text-rose-200/90 leading-tight">
                <strong className="text-rose-300">UI Demonstration:</strong> Prepared for real payment gateway & coin wallet connection. No actual balance or payment is deducted.
              </p>
            </div>

            {/* Receiver Selection */}
            <div>
              <label className="text-xs font-semibold text-neutral-300 mb-1.5 block">Select Receiver</label>
              <div className="grid grid-cols-3 gap-2">
                <button
                  onClick={() => setSelectedGiftTarget('host')}
                  className={`p-2 rounded-xl text-xs font-medium border flex items-center justify-center space-x-1.5 transition-all cursor-pointer ${
                    selectedGiftTarget === 'host'
                      ? 'bg-amber-950/60 border-amber-500/60 text-amber-200'
                      : 'bg-neutral-800/60 border-neutral-700/60 text-neutral-400 hover:text-white'
                  }`}
                >
                  <span>👑 Host</span>
                </button>
                <button
                  onClick={() => setSelectedGiftTarget('speakers')}
                  className={`p-2 rounded-xl text-xs font-medium border flex items-center justify-center space-x-1.5 transition-all cursor-pointer ${
                    selectedGiftTarget === 'speakers'
                      ? 'bg-violet-950/60 border-violet-500/60 text-violet-200'
                      : 'bg-neutral-800/60 border-neutral-700/60 text-neutral-400 hover:text-white'
                  }`}
                >
                  <span>🎤 Stage ({room.speakers.length})</span>
                </button>
                <button
                  onClick={() => setSelectedGiftTarget('all')}
                  className={`p-2 rounded-xl text-xs font-medium border flex items-center justify-center space-x-1.5 transition-all cursor-pointer ${
                    selectedGiftTarget === 'all'
                      ? 'bg-rose-950/60 border-rose-500/60 text-rose-200'
                      : 'bg-neutral-800/60 border-neutral-700/60 text-neutral-400 hover:text-white'
                  }`}
                >
                  <span>🌟 All Room</span>
                </button>
              </div>
            </div>

            {/* Gift Items Grid */}
            <div>
              <label className="text-xs font-semibold text-neutral-300 mb-1.5 block">Select Gift Item</label>
              <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
                {[
                  { id: 'gift_rose', name: 'Cosmic Rose', icon: '🌹', coins: 10 },
                  { id: 'gift_heart', name: 'Starlight Heart', icon: '💖', coins: 50 },
                  { id: 'gift_mic', name: 'Golden Mic', icon: '🎙️', coins: 200 },
                  { id: 'gift_crown', name: 'Royal Crown', icon: '👑', coins: 500 },
                  { id: 'gift_rocket', name: 'Galaxy Rocket', icon: '🚀', coins: 1000 },
                  { id: 'gift_dragon', name: 'Dragon Spirit', icon: '🐉', coins: 5000 },
                ].map(g => (
                  <div
                    key={g.id}
                    onClick={() => setSelectedGiftItemId(g.id)}
                    className={`flex flex-col items-center p-2.5 rounded-2xl border cursor-pointer transition-all ${
                      selectedGiftItemId === g.id
                        ? 'bg-gradient-to-b from-rose-900/40 to-violet-900/40 border-rose-400/80 shadow-md shadow-rose-950/50 scale-102 ring-1 ring-rose-400'
                        : 'bg-neutral-800/50 border-neutral-700/50 hover:bg-neutral-800 text-neutral-300'
                    }`}
                  >
                    <span className="text-2xl mb-1">{g.icon}</span>
                    <span className="text-[11px] font-bold text-white text-center truncate max-w-full">{g.name}</span>
                    <span className="text-[9px] text-amber-300 mt-0.5 font-semibold">🪙 {g.coins}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Action Send Button */}
            <button
              id="send-gift-preview-btn"
              onClick={() => {
                const giftMap: Record<string, string> = {
                  gift_rose: '🌹 Cosmic Rose',
                  gift_heart: '💖 Starlight Heart',
                  gift_mic: '🎙️ Golden Mic',
                  gift_crown: '👑 Royal Crown',
                  gift_rocket: '🚀 Galaxy Rocket',
                  gift_dragon: '🐉 Dragon Spirit',
                };
                const targetMap: Record<string, string> = {
                  host: `Host (${room.host.name})`,
                  speakers: 'Stage Speakers',
                  all: 'Everyone in Room',
                };
                const giftName = giftMap[selectedGiftItemId] || 'Gift';
                const targetName = targetMap[selectedGiftTarget] || 'Room';
                handleSendReaction(selectedGiftItemId === 'gift_rose' ? '🌹' : selectedGiftItemId === 'gift_heart' ? '💖' : '🎉');
                showToast(`Sent ${giftName} to ${targetName}! (UI Demonstration)`);
                setShowGiftArea(false);
              }}
              className="w-full py-3 rounded-2xl bg-gradient-to-r from-rose-600 via-pink-600 to-amber-500 hover:brightness-110 active:scale-98 font-bold text-xs text-white shadow-lg shadow-rose-600/30 flex items-center justify-center space-x-2 cursor-pointer transition-all"
            >
              <Gift className="w-4 h-4" />
              <span>Send Gift (UI Preview)</span>
            </button>
          </div>
        </div>
      )}

      {/* SNYVO Premium Gift Box Bottom Sheet */}
      {showGiftBox && (
        <GiftBoxModal
          currentUser={currentUser}
          roomId={room.id}
          speakers={room.speakers}
          listeners={room.listeners}
          host={room.host}
          initialReceiverId={selectedGiftReceiverId}
          onClose={() => setShowGiftBox(false)}
          onGiftSent={handleGiftSent}
        />
      )}

      {/* Top Gifters Leaderboard Modal */}
      {showTopGifters && (
        <TopGiftersModal
          roomId={room.id}
          onClose={() => setShowTopGifters(false)}
          onSelectUser={(uid) => {
            setShowTopGifters(false);
            const userInRoom = [...room.speakers, ...room.listeners, room.host].find(u => u.id === uid);
            if (userInRoom) {
              openUserProfile(userInRoom);
            }
          }}
        />
      )}

      {/* Live Synchronized Gift Animation Overlay */}
      {activeGiftAnimation && (localStorage.getItem(`snyvo_gift_banner_${currentUser.id}`) !== 'false') && (
        <GiftAnimationOverlay
          animation={activeGiftAnimation}
          onDismiss={() => {
            giftService.dismissActiveAnimation();
            setActiveGiftAnimation(null);
          }}
        />
      )}

      {/* 🚀 Synchronized Cinematic Rocket Launch Animation Overlay */}
      {activeRocketLaunch && (
        <RocketLaunchAnimation
          event={activeRocketLaunch}
          onDismiss={() => {
            rocketService.dismissLaunch();
            setActiveRocketLaunch(null);
          }}
        />
      )}

      {/* 🎙️ Microphone Permission System Modal (Android & Browser Guide) */}
      {showPermissionModal && (
        <div
          id="mic-permission-modal"
          className="absolute inset-0 bg-black/80 backdrop-blur-md z-50 flex items-center justify-center p-4 animate-fade-in"
        >
          <div className="bg-neutral-900 border border-rose-500/40 rounded-3xl p-5 max-w-sm w-full space-y-4 shadow-2xl">
            <div className="flex items-center justify-between pb-2 border-b border-neutral-800">
              <div className="flex items-center space-x-2.5">
                <div className="w-9 h-9 rounded-2xl bg-rose-950/70 border border-rose-500/50 flex items-center justify-center text-rose-400">
                  <MicOff className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-white">Microphone Access</h3>
                  <p className="text-[10px] text-rose-300 font-medium">Permission Required to Speak</p>
                </div>
              </div>
              <button
                id="close-mic-permission-modal"
                onClick={() => setShowPermissionModal(false)}
                className="p-1.5 text-neutral-400 hover:text-white rounded-full hover:bg-neutral-800 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-2.5 text-xs text-neutral-300">
              <p className="leading-relaxed">
                SNYVO requires microphone permission so your stage voice can be heard by participants in real time. We do not record or store your audio.
              </p>

              <div className="p-3 bg-neutral-950/70 border border-neutral-800 rounded-2xl space-y-2 text-[11px]">
                <div className="font-semibold text-white flex items-center space-x-1.5">
                  <Shield className="w-3.5 h-3.5 text-violet-400" />
                  <span>How to Allow on Android & Chrome:</span>
                </div>
                <ul className="space-y-1.5 text-neutral-400 list-disc list-inside">
                  <li>Tap the <strong className="text-neutral-200">🔒 lock icon</strong> or site settings in your browser address bar.</li>
                  <li>Select <strong className="text-neutral-200">Permissions → Microphone</strong> and choose <strong className="text-emerald-400">Allow</strong>.</li>
                  <li>On Android device: Settings → Apps → Browser → Permissions → Microphone → <strong className="text-emerald-400">Allow</strong>.</li>
                </ul>
              </div>
            </div>

            <div className="pt-2 space-y-2">
              <button
                id="request-mic-permission-btn"
                onClick={async () => {
                  try {
                    const permRes = await voiceAudioService.requestMicrophonePermission();
                    if (permRes.granted) {
                      setShowPermissionModal(false);
                      showToast('✅ Microphone permission granted! Microphone is ready.');
                      if (isUserSpeaker) {
                        handleToggleMute();
                      }
                    } else {
                      showToast('Microphone permission not granted yet. Please check browser settings.');
                    }
                  } catch (err: any) {
                    showToast(`⚠️ ${err.message || 'Permission request failed'}`);
                  }
                }}
                className="w-full py-2.5 bg-violet-600 hover:bg-violet-500 text-white text-xs font-bold rounded-xl shadow-lg shadow-violet-600/30 cursor-pointer active:scale-95 transition-all flex items-center justify-center space-x-2"
              >
                <Mic className="w-4 h-4" />
                <span>Grant Microphone Permission</span>
              </button>

              <button
                onClick={() => setShowPermissionModal(false)}
                className="w-full py-2 text-xs text-neutral-400 hover:text-white text-center cursor-pointer transition-colors"
              >
                Cancel & Stay as Listener
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 📡 Pluggable Audio Service Interface Diagnostics Modal */}
      {showAudioEngineModal && (
        <div
          id="audio-engine-modal"
          className="absolute inset-0 bg-black/80 backdrop-blur-md z-50 flex items-center justify-center p-4 animate-fade-in"
        >
          <div className="bg-neutral-900 border border-violet-700/40 rounded-3xl p-5 max-w-sm w-full space-y-4 shadow-2xl">
            <div className="flex items-center justify-between pb-2 border-b border-neutral-800">
              <div className="flex items-center space-x-2.5">
                <div className="w-9 h-9 rounded-2xl bg-violet-950/70 border border-violet-500/50 flex items-center justify-center text-violet-400">
                  <Server className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-white">Voice Engine Architecture</h3>
                  <p className="text-[10px] text-violet-300 font-medium">Real-Time Audio Provider</p>
                </div>
              </div>
              <button
                onClick={() => setShowAudioEngineModal(false)}
                className="p-1.5 text-neutral-400 hover:text-white rounded-full hover:bg-neutral-800 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-2 text-xs">
              <div className="p-3 bg-neutral-950/70 rounded-2xl border border-neutral-800 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-neutral-400">Audio Provider:</span>
                  <span className="font-semibold text-emerald-400">WebRTC / Pluggable Core</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-neutral-400">Interface:</span>
                  <code className="text-[10px] text-violet-300 bg-neutral-900 px-1.5 py-0.5 rounded">IAudioServiceProvider</code>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-neutral-400">Microphone State:</span>
                  <span className="font-bold uppercase text-[11px] text-white">
                    {micState}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-neutral-400">Permission:</span>
                  <span className="font-semibold text-neutral-200 uppercase text-[10px]">
                    {permissionStatus}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-neutral-400">Connection State:</span>
                  <span className="font-semibold text-emerald-400 capitalize">
                    {connectionStatus}
                  </span>
                </div>
              </div>

              <div className="p-3 bg-violet-950/30 rounded-2xl border border-violet-800/30 space-y-1">
                <p className="text-[11px] text-violet-200 font-medium">
                  Decoupled Architecture
                </p>
                <p className="text-[10px] text-neutral-400 leading-relaxed">
                  The voice room is connected to a modular real-time voice provider. When WebRTC, LiveKit, or Agora credentials are provided, live peer-to-peer or SFU audio streams automatically attach without modifying UI components.
                </p>
              </div>
            </div>

            <button
              onClick={() => setShowAudioEngineModal(false)}
              className="w-full py-2.5 bg-violet-600 hover:bg-violet-500 text-white text-xs font-bold rounded-xl cursor-pointer transition-colors"
            >
              Close Diagnostics
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
