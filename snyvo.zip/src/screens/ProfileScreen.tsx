import React, { useState, useEffect } from 'react';
import {
  ChevronLeft,
  Copy,
  Check,
  Edit3,
  Share2,
  Settings,
  ChevronRight,
  Wallet,
  CheckSquare,
  Diamond,
  ShieldCheck,
  Crown,
  Gamepad2,
  Users,
  ShoppingBag,
  Medal,
  TrendingUp,
  Gift,
  CheckCircle2,
  Sparkles,
  Heart,
  UserCog,
  Flame,
} from 'lucide-react';
import { User as UserType } from '../types';
import { authService } from '../services/firebaseService';
import { userService, getNumericUserId } from '../services/userService';
import { vipService } from '../coins/vipService';
import { walletService } from '../games/walletService';
import { levelService } from '../services/levelService';

// Modals & Sub-pages
import { EditProfilePage } from '../components/profile/EditProfilePage';
import { CoinShopModal } from '../components/CoinShopModal';
import { GiftHistoryModal } from '../components/GiftHistoryModal';
import { ProfileTaskModal } from '../components/profile/ProfileTaskModal';
import { ProfileSvipModal } from '../components/profile/ProfileSvipModal';
import { ProfileAristocracyModal } from '../components/profile/ProfileAristocracyModal';
import { ProfileVipModal } from '../components/profile/ProfileVipModal';
import { ProfileGameLevelModal } from '../components/profile/ProfileGameLevelModal';
import { ProfileFamilyModal } from '../components/profile/ProfileFamilyModal';
import { ProfileMedalModal } from '../components/profile/ProfileMedalModal';
import { ProfileLevelModal } from '../components/profile/ProfileLevelModal';
import { ProfileWalletModal } from '../components/profile/ProfileWalletModal';
import { ProfileSettingsModal } from '../components/profile/ProfileSettingsModal';

interface ProfileScreenProps {
  currentUser: UserType;
  onLogout: () => void;
  onUpdateUser: (user: UserType) => void;
  onBack?: () => void;
}

export const ProfileScreen: React.FC<ProfileScreenProps> = ({
  currentUser,
  onLogout,
  onUpdateUser,
  onBack,
}) => {
  const [copiedId, setCopiedId] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [isEditProfileOpen, setIsEditProfileOpen] = useState(false);

  // Sync member-specific custom profile if saved in localStorage
  useEffect(() => {
    try {
      const savedRaw = localStorage.getItem(`snyvo_profile_custom_${currentUser.id}`);
      if (savedRaw) {
        const parsed = JSON.parse(savedRaw);
        if (
          parsed.nickname &&
          (parsed.nickname !== currentUser.name ||
            parsed.photos?.[0] !== currentUser.avatar ||
            parsed.country !== currentUser.country ||
            parsed.signature !== currentUser.signature ||
            parsed.gender !== currentUser.gender ||
            parsed.showAge !== currentUser.showAge)
        ) {
          onUpdateUser({
            ...currentUser,
            name: parsed.nickname || currentUser.name,
            avatar: parsed.photos?.[0] || currentUser.avatar,
            photos: parsed.photos || currentUser.photos,
            country: parsed.country || currentUser.country,
            countryFlag: parsed.countryFlag || currentUser.countryFlag,
            signature: parsed.signature || currentUser.signature,
            gender: parsed.gender || currentUser.gender,
            showAge: parsed.showAge !== undefined ? parsed.showAge : currentUser.showAge,
            age: parsed.age || currentUser.age,
          });
        }
      }
    } catch (e) {
      console.error(e);
    }
  }, [currentUser.id]);

  // Active modal state
  const [activeModal, setActiveModal] = useState<
    | null
    | 'wallet'
    | 'task'
    | 'svip'
    | 'aristocracy'
    | 'vip'
    | 'gameLevel'
    | 'family'
    | 'store'
    | 'medal'
    | 'level'
    | 'giftRecord'
    | 'settings'
  >(null);

  // Dynamic user data
  const numericId = currentUser.numericId || getNumericUserId(currentUser.id);
  const vipTier = vipService.getUserVipTier(currentUser.id);

  // Sent and received gifts calculation
  const [sentGifts, setSentGifts] = useState(() =>
    userService.getSentGifts(currentUser.id, currentUser.id)
  );
  const [receivedGifts, setReceivedGifts] = useState(() =>
    userService.getReceivedGifts(currentUser.id)
  );

  // Lifetime Level System Stats
  const [levelStats, setLevelStats] = useState(() =>
    levelService.getUserLevelStats(currentUser.id)
  );

  const sendingBadge = levelService.getBadgeForLevel(levelStats.sendingLevel, 'sending');
  const receivingBadge = levelService.getBadgeForLevel(levelStats.receivingLevel, 'receiving');

  useEffect(() => {
    setLevelStats(levelService.getUserLevelStats(currentUser.id));
    const unsubLevel = levelService.subscribeLevelUp((event) => {
      if (event.userId === currentUser.id || event.userId === 'usr_me') {
        setLevelStats(levelService.getUserLevelStats(currentUser.id));
      }
    });
    return unsubLevel;
  }, [currentUser.id]);

  useEffect(() => {
    const unsub = userService.subscribe(() => {
      setSentGifts(userService.getSentGifts(currentUser.id, currentUser.id));
      setReceivedGifts(userService.getReceivedGifts(currentUser.id));
      setLevelStats(levelService.getUserLevelStats(currentUser.id));
    });
    return unsub;
  }, [currentUser.id]);

  // Dynamic coin totals
  const totalSentCoins = sentGifts.reduce(
    (acc, g) => acc + (g.coinValue || 500 * (g.quantity || 1)),
    0
  );

  const totalReceivedCoins = receivedGifts.reduce(
    (acc, g) => acc + (g.receiverCoins || Math.floor(((g.coinValue || 500) * 30) / 100)),
    0
  );
  const totalGiftsCount = receivedGifts.reduce((acc, g) => acc + (g.quantity || 1), 0);

  // Dynamic Account Duration calculation
  const [accountDuration, setAccountDuration] = useState<{ days: number; hours: number }>(() => {
    try {
      const savedKey = `snyvo_created_at_${currentUser.id}`;
      let createdTs = localStorage.getItem(savedKey);
      if (!createdTs) {
        // Default established account duration: 48 days and 14 hours ago
        const initTime = Date.now() - (48 * 24 * 60 * 60 * 1000 + 14 * 60 * 60 * 1000);
        localStorage.setItem(savedKey, String(initTime));
        createdTs = String(initTime);
      }
      const diffMs = Math.max(0, Date.now() - parseInt(createdTs, 10));
      const days = Math.floor(diffMs / (1000 * 60 * 60 * 24));
      const hours = Math.floor((diffMs % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
      return { days, hours };
    } catch {
      return { days: 48, hours: 14 };
    }
  });

  // Dynamic Visitors
  const [visitorsCount, setVisitorsCount] = useState<number>(() => {
    try {
      const saved = localStorage.getItem(`snyvo_profile_visitors_${currentUser.id}`);
      if (saved) return parseInt(saved, 10);
      const initialVisitors = 3842;
      localStorage.setItem(`snyvo_profile_visitors_${currentUser.id}`, String(initialVisitors));
      return initialVisitors;
    } catch {
      return 3842;
    }
  });

  // Dynamic Likes
  const [likesCount, setLikesCount] = useState<number>(() => {
    try {
      const saved = localStorage.getItem(`snyvo_profile_likes_${currentUser.id}`);
      if (saved) return parseInt(saved, 10);
      const initialLikes = 12650;
      localStorage.setItem(`snyvo_profile_likes_${currentUser.id}`, String(initialLikes));
      return initialLikes;
    } catch {
      return 12650;
    }
  });
  const [hasLiked, setHasLiked] = useState(false);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 2500);
  };

  const handleCopyId = () => {
    navigator.clipboard.writeText(numericId);
    setCopiedId(true);
    showToast(`User ID ${numericId} copied to clipboard!`);
    setTimeout(() => setCopiedId(false), 2000);
  };

  const handleLike = () => {
    const newLikes = likesCount + 1;
    setLikesCount(newLikes);
    setHasLiked(true);
    localStorage.setItem(`snyvo_profile_likes_${currentUser.id}`, String(newLikes));
    showToast('❤️ Received +1 Like!');
  };

  // Strictly ordered 12 menu items
  const menuItems = [
    {
      id: 'wallet',
      title: 'Wallet',
      icon: <Wallet className="w-5 h-5 text-amber-500" />,
      iconBg: 'bg-amber-500/10',
      badge: '🪙 Balance',
      onClick: () => setActiveModal('wallet'),
    },
    {
      id: 'task',
      title: 'Task',
      icon: <CheckSquare className="w-5 h-5 text-orange-500" />,
      iconBg: 'bg-orange-500/10',
      badge: 'Rewards Ready',
      onClick: () => setActiveModal('task'),
    },
    {
      id: 'svip',
      title: 'SVIP',
      icon: <Diamond className="w-5 h-5 text-cyan-500" />,
      iconBg: 'bg-cyan-500/10',
      badge: 'Supreme 💎',
      onClick: () => setActiveModal('svip'),
    },
    {
      id: 'aristocracy',
      title: 'Aristocracy',
      icon: <ShieldCheck className="w-5 h-5 text-purple-600" />,
      iconBg: 'bg-purple-500/10',
      badge: 'Knight ⚔️',
      onClick: () => setActiveModal('aristocracy'),
    },
    {
      id: 'vip',
      title: 'VIP',
      icon: <Crown className="w-5 h-5 text-amber-600" />,
      iconBg: 'bg-yellow-500/10',
      badge: 'VIP 1',
      onClick: () => setActiveModal('vip'),
    },
    {
      id: 'gameLevel',
      title: 'Game Level',
      icon: <Gamepad2 className="w-5 h-5 text-emerald-600" />,
      iconBg: 'bg-emerald-500/10',
      badge: 'Master Lv. 14',
      onClick: () => setActiveModal('gameLevel'),
    },
    {
      id: 'family',
      title: 'Family',
      icon: <Users className="w-5 h-5 text-rose-500" />,
      iconBg: 'bg-rose-500/10',
      badge: 'Dhaka Royals 🇧🇩',
      onClick: () => setActiveModal('family'),
    },
    {
      id: 'store',
      title: 'Store',
      icon: <ShoppingBag className="w-5 h-5 text-blue-600" />,
      iconBg: 'bg-blue-500/10',
      badge: 'Coin Packages',
      onClick: () => setActiveModal('store'),
    },
    {
      id: 'medal',
      title: 'Medal',
      icon: <Medal className="w-5 h-5 text-amber-500" />,
      iconBg: 'bg-amber-500/10',
      badge: '6 Badges',
      onClick: () => setActiveModal('medal'),
    },
    {
      id: 'level',
      title: 'Level',
      icon: <TrendingUp className="w-5 h-5 text-violet-600" />,
      iconBg: 'bg-violet-500/10',
      badge: `Send Lv. ${levelStats.sendingLevel} | Recv Lv. ${levelStats.receivingLevel}`,
      onClick: () => setActiveModal('level'),
    },
    {
      id: 'giftRecord',
      title: 'Gift Record',
      icon: <Gift className="w-5 h-5 text-pink-600" />,
      iconBg: 'bg-pink-500/10',
      badge: 'History',
      onClick: () => setActiveModal('giftRecord'),
    },
    {
      id: 'settings',
      title: 'Settings',
      icon: <Settings className="w-5 h-5 text-neutral-600" />,
      iconBg: 'bg-neutral-500/10',
      onClick: () => setActiveModal('settings'),
    },
  ];

  return (
    <div
      id="snyvo-profile-screen"
      className="flex flex-col h-full w-full bg-neutral-950 text-white overflow-y-auto pb-24 scrollbar-none select-none"
    >
      {/* 1. TOP APP BAR */}
      <div className="sticky top-0 bg-neutral-950/90 backdrop-blur-md px-4 py-3 z-30 flex items-center justify-between border-b border-neutral-900">
        <div className="flex items-center space-x-2">
          {onBack ? (
            <button
              type="button"
              onClick={onBack}
              className="p-1.5 -ml-1.5 rounded-full hover:bg-neutral-900 text-neutral-300 hover:text-white transition-colors"
              aria-label="Go Back"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
          ) : (
            <Sparkles className="w-4 h-4 text-violet-400" />
          )}
          <span className="text-sm font-black tracking-wide text-white">Profile</span>
        </div>

        <div className="flex items-center space-x-1">
          <button
            type="button"
            onClick={() => showToast(`Profile shared: snyvo.me/id/${numericId}`)}
            className="p-2 rounded-full text-neutral-400 hover:text-white hover:bg-neutral-900 transition-colors cursor-pointer"
            title="Share Profile"
          >
            <Share2 className="w-4 h-4" />
          </button>
          <button
            type="button"
            onClick={() => setIsEditProfileOpen(true)}
            className="p-2 rounded-full text-neutral-400 hover:text-white hover:bg-neutral-900 transition-colors cursor-pointer"
            title="Edit Profile"
          >
            <Edit3 className="w-4 h-4" />
          </button>
          <button
            type="button"
            onClick={() => setActiveModal('settings')}
            className="p-2 rounded-full text-neutral-400 hover:text-white hover:bg-neutral-900 transition-colors cursor-pointer"
            title="Settings"
          >
            <Settings className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* 2. PROFILE HEADER */}
      <div className="px-5 pt-5 pb-3">
        <div className="flex items-start space-x-4">
          {/* Circular Profile Picture */}
          <div
            className="relative flex-shrink-0 cursor-pointer group"
            onClick={() => setIsEditProfileOpen(true)}
            title="Tap to Edit Profile"
          >
            <img
              src={currentUser.photos?.[0] || currentUser.avatar}
              alt={currentUser.name}
              className="w-20 h-20 rounded-full object-cover ring-3 ring-violet-500/40 shadow-xl group-hover:ring-violet-400 transition-all"
            />
            {currentUser.isVerified && (
              <div
                className="absolute -bottom-0.5 -right-0.5 w-6 h-6 rounded-full bg-violet-600 text-white flex items-center justify-center border-2 border-neutral-950 shadow-md"
                title="Verified Voice Performer"
              >
                <CheckCircle2 className="w-3.5 h-3.5" />
              </div>
            )}
            <div className="absolute inset-0 rounded-full bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
              <Edit3 className="w-4 h-4 text-white drop-shadow" />
            </div>
          </div>

          {/* Profile Details beside Profile Picture */}
          <div className="flex-1 min-w-0">
            {/* Profile Name & Badges */}
            <div className="flex items-center space-x-2 flex-wrap gap-y-1">
              <h2 className="text-lg font-black text-white truncate">{currentUser.name}</h2>
              {/* Sending Level Badge */}
              <button
                type="button"
                onClick={() => setActiveModal('level')}
                className="px-2 py-0.5 rounded-full text-[9px] font-black bg-amber-950/80 text-amber-300 border border-amber-500/60 shadow-sm flex items-center space-x-1 cursor-pointer hover:scale-105 active:scale-95 transition-transform flex-shrink-0"
                title={`Sending Level: ${levelStats.sendingLevel} (${sendingBadge.tierName})`}
              >
                <span>{sendingBadge.icon}</span>
                <span>Send Lv. {levelStats.sendingLevel}</span>
              </button>

              {/* Receiving Level Badge */}
              <button
                type="button"
                onClick={() => setActiveModal('level')}
                className="px-2 py-0.5 rounded-full text-[9px] font-black bg-pink-950/80 text-pink-300 border border-pink-500/60 shadow-sm flex items-center space-x-1 cursor-pointer hover:scale-105 active:scale-95 transition-transform flex-shrink-0"
                title={`Receiving Level: ${levelStats.receivingLevel} (${receivingBadge.tierName})`}
              >
                <span>{receivingBadge.icon}</span>
                <span>Recv Lv. {levelStats.receivingLevel}</span>
              </button>

              <span className="px-1.5 py-0.5 rounded-full text-[9px] font-black bg-gradient-to-r from-amber-400 to-yellow-400 text-neutral-950 shadow-sm flex-shrink-0">
                👑 VIP 1
              </span>
              {currentUser.country && (
                <span className="px-2 py-0.5 rounded-full text-[9px] font-bold bg-neutral-900 text-neutral-300 border border-neutral-800 flex items-center space-x-1 flex-shrink-0">
                  <span>{currentUser.countryFlag || '🇧🇩'}</span>
                  <span>{currentUser.country}</span>
                </span>
              )}
              {currentUser.gender && currentUser.gender !== 'Secret' && (
                <span className="px-1.5 py-0.5 rounded-full text-[9px] font-bold bg-neutral-900 text-neutral-300 border border-neutral-800 flex-shrink-0">
                  {currentUser.gender === 'Female' ? '♀️' : '♂️'}
                </span>
              )}
              {currentUser.showAge && currentUser.age && (
                <span className="px-1.5 py-0.5 rounded-full text-[9px] font-bold bg-neutral-900 text-neutral-300 border border-neutral-800 font-mono flex-shrink-0">
                  {currentUser.age} yrs
                </span>
              )}
            </div>

            {/* Profile ID number & ID Badge below Profile Name */}
            <div className="mt-1 flex items-center space-x-2">
              <button
                type="button"
                onClick={handleCopyId}
                className="inline-flex items-center space-x-1.5 px-2.5 py-0.5 rounded-full bg-neutral-900 border border-neutral-800 hover:border-violet-500/60 transition-colors group cursor-pointer"
                title="Click to copy User ID"
              >
                <span className="text-[10px] font-bold uppercase text-neutral-400 group-hover:text-violet-400">
                  ID:
                </span>
                <span className="text-xs font-mono font-bold text-violet-300 tracking-wide">
                  {numericId}
                </span>
                {copiedId ? (
                  <Check className="w-3 h-3 text-emerald-400 ml-0.5" />
                ) : (
                  <Copy className="w-3 h-3 text-neutral-500 group-hover:text-neutral-300 ml-0.5" />
                )}
              </button>

              <span className="text-[10px] text-emerald-400 bg-emerald-950/60 border border-emerald-800/40 px-2 py-0.5 rounded-full font-semibold flex items-center space-x-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                <span>Active</span>
              </span>
            </div>

            {/* Bio / Signature */}
            <p className="text-xs text-neutral-400 mt-1.5 line-clamp-2 leading-relaxed">
              {currentUser.signature || currentUser.bio || 'Sharing voice moments and Bangladeshi music vibes 🎙️'}
            </p>

            {/* User Photos Album Preview Strip */}
            {currentUser.photos && currentUser.photos.length > 1 && (
              <div className="mt-2 flex items-center space-x-1.5 overflow-x-auto scrollbar-none py-0.5">
                {currentUser.photos.map((p, idx) => (
                  <img
                    key={idx}
                    src={p}
                    alt={`Photo ${idx + 1}`}
                    onClick={() => setIsEditProfileOpen(true)}
                    className="w-8 h-8 rounded-lg object-cover border border-neutral-800 cursor-pointer hover:opacity-80 transition-opacity flex-shrink-0"
                    title="Tap to manage photos"
                  />
                ))}
                <button
                  type="button"
                  onClick={() => setIsEditProfileOpen(true)}
                  className="w-8 h-8 rounded-lg bg-neutral-900 border border-neutral-800 text-neutral-400 hover:text-white flex items-center justify-center text-[9px] font-mono flex-shrink-0 cursor-pointer"
                  title="Manage Photos"
                >
                  +{5 - currentUser.photos.length}
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Dynamic Labels Strip: Coin Sending, Coin Received/Gift, Account Duration */}
        <div className="mt-4 pt-3 border-t border-neutral-900 grid grid-cols-3 gap-2">
          {/* Coin Sending Label */}
          <div
            onClick={() => setActiveModal('level')}
            className="p-2 rounded-xl bg-neutral-900/60 border border-neutral-800/80 flex flex-col items-center text-center cursor-pointer hover:border-amber-500/50 transition-colors"
          >
            <span className="text-[9px] uppercase font-bold text-neutral-500 flex items-center space-x-1">
              <span>{sendingBadge.icon}</span>
              <span>Send Lv. {levelStats.sendingLevel}</span>
            </span>
            <span className="text-xs font-black text-amber-300 font-mono mt-0.5">
              {(levelStats.totalCoinsSent > 0
                ? levelStats.totalCoinsSent
                : totalSentCoins > 0
                ? totalSentCoins
                : 0
              ).toLocaleString()}{' '}
              🪙
            </span>
          </div>

          {/* Coin Received / Gift Label */}
          <div
            onClick={() => setActiveModal('level')}
            className="p-2 rounded-xl bg-neutral-900/60 border border-neutral-800/80 flex flex-col items-center text-center cursor-pointer hover:border-pink-500/50 transition-colors"
          >
            <span className="text-[9px] uppercase font-bold text-neutral-500 flex items-center space-x-1">
              <span>{receivingBadge.icon}</span>
              <span>Recv Lv. {levelStats.receivingLevel}</span>
            </span>
            <span className="text-xs font-black text-pink-300 font-mono mt-0.5">
              {(levelStats.totalCoinsReceived > 0
                ? levelStats.totalCoinsReceived
                : totalReceivedCoins > 0
                ? totalReceivedCoins
                : 0
              ).toLocaleString()}{' '}
              🪙
            </span>
          </div>

          {/* Account Duration Label */}
          <div className="p-2 rounded-xl bg-neutral-900/60 border border-neutral-800/80 flex flex-col items-center text-center">
            <span className="text-[9px] uppercase font-bold text-neutral-500 flex items-center space-x-1">
              <span>⏳</span>
              <span>Duration</span>
            </span>
            <span className="text-xs font-black text-violet-300 font-mono mt-0.5 truncate max-w-full">
              {accountDuration.days}d {accountDuration.hours}h
            </span>
          </div>
        </div>

        {/* 3. PROFILE STATISTICS (FOLLOW, VISITOR, LIKE) */}
        <div className="mt-4 pt-3 border-t border-neutral-900 grid grid-cols-3 text-center">
          {/* FOLLOW */}
          <div className="cursor-pointer">
            <div className="text-2xl font-black text-white tracking-tight">
              {currentUser.followers.toLocaleString()}
            </div>
            <div className="text-[11px] font-bold text-neutral-400 tracking-wider uppercase mt-0.5">
              FOLLOW
            </div>
          </div>

          {/* VISITOR */}
          <div className="cursor-pointer border-x border-neutral-800">
            <div className="text-2xl font-black text-white tracking-tight font-mono">
              {visitorsCount.toLocaleString()}
            </div>
            <div className="text-[11px] font-bold text-neutral-400 tracking-wider uppercase mt-0.5">
              VISITOR
            </div>
          </div>

          {/* LIKE */}
          <div
            onClick={handleLike}
            className="cursor-pointer hover:opacity-80 active:scale-95 transition-transform"
            title="Click to Send Like"
          >
            <div className="text-2xl font-black text-rose-400 tracking-tight font-mono flex items-center justify-center space-x-1">
              <span>{likesCount.toLocaleString()}</span>
              {hasLiked && <Heart className="w-3.5 h-3.5 fill-rose-500 text-rose-500 animate-bounce inline" />}
            </div>
            <div className="text-[11px] font-bold text-neutral-400 tracking-wider uppercase mt-0.5">
              LIKE
            </div>
          </div>
        </div>
      </div>

      {/* 4. DEDICATED "EDIT PROFILE" OPTION */}
      <div className="mt-3 px-3 sm:px-4">
        <div className="bg-white text-neutral-900 rounded-3xl shadow-xl border border-neutral-100 overflow-hidden">
          <button
            type="button"
            onClick={() => setIsEditProfileOpen(true)}
            className="w-full flex items-center justify-between px-4 py-3.5 hover:bg-neutral-50 active:bg-neutral-100 transition-all group cursor-pointer text-left active:scale-[0.99]"
          >
            {/* Left: Dedicated colorful modern icon & Title */}
            <div className="flex items-center space-x-3.5 min-w-0">
              <div className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 bg-violet-500/10 text-violet-600 transition-transform group-hover:scale-105">
                <UserCog className="w-5 h-5" />
              </div>
              <div className="min-w-0">
                <span className="text-sm font-bold text-neutral-900 tracking-tight block">
                  Edit Profile
                </span>
                <span className="text-[11px] text-neutral-400 font-medium truncate block">
                  Photos, Nickname, Country, Signature & Details
                </span>
              </div>
            </div>

            {/* Right: Right-facing arrow (>) */}
            <div className="flex items-center space-x-2 flex-shrink-0">
              <ChevronRight className="w-4 h-4 text-neutral-300 group-hover:text-neutral-500 transition-transform group-hover:translate-x-0.5" />
            </div>
          </button>
        </div>
      </div>

      {/* 5. CLEAN WHITE VERTICAL MENU */}
      <div className="mt-3 px-3 sm:px-4">
        <div className="bg-white text-neutral-900 rounded-3xl shadow-xl border border-neutral-100 divide-y divide-neutral-100 overflow-hidden">
          {menuItems.map((item) => (
            <button
              type="button"
              key={item.id}
              onClick={item.onClick}
              className="w-full flex items-center justify-between px-4 py-3.5 hover:bg-neutral-50 active:bg-neutral-100 transition-colors group cursor-pointer text-left"
            >
              {/* Left: Dedicated colorful icon & Menu Title */}
              <div className="flex items-center space-x-3.5 min-w-0">
                <div
                  className={`w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 transition-transform group-hover:scale-105 ${item.iconBg}`}
                >
                  {item.icon}
                </div>
                <span className="text-sm font-bold text-neutral-900 tracking-tight truncate">
                  {item.title}
                </span>
              </div>

              {/* Right: Badge / Indicator + Right-facing Arrow (>) */}
              <div className="flex items-center space-x-2 flex-shrink-0">
                {item.badge && (
                  <span className="text-[11px] font-semibold text-neutral-400 font-sans">
                    {item.badge}
                  </span>
                )}
                <ChevronRight className="w-4 h-4 text-neutral-300 group-hover:text-neutral-500 transition-transform group-hover:translate-x-0.5" />
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* MODALS */}
      {activeModal === 'wallet' && (
        <ProfileWalletModal
          currentUser={currentUser}
          onClose={() => setActiveModal(null)}
          onOpenStore={() => setActiveModal('store')}
          onToast={showToast}
        />
      )}

      {activeModal === 'task' && (
        <ProfileTaskModal
          currentUser={currentUser}
          onClose={() => setActiveModal(null)}
          onToast={showToast}
        />
      )}

      {activeModal === 'svip' && (
        <ProfileSvipModal
          currentUser={currentUser}
          onClose={() => setActiveModal(null)}
          onToast={showToast}
        />
      )}

      {activeModal === 'aristocracy' && (
        <ProfileAristocracyModal
          currentUser={currentUser}
          onClose={() => setActiveModal(null)}
          onToast={showToast}
        />
      )}

      {activeModal === 'vip' && (
        <ProfileVipModal
          currentUser={currentUser}
          onClose={() => setActiveModal(null)}
          onToast={showToast}
          onOpenStore={() => setActiveModal('store')}
        />
      )}

      {activeModal === 'gameLevel' && (
        <ProfileGameLevelModal
          currentUser={currentUser}
          onClose={() => setActiveModal(null)}
          onToast={showToast}
        />
      )}

      {activeModal === 'family' && (
        <ProfileFamilyModal
          currentUser={currentUser}
          onClose={() => setActiveModal(null)}
          onToast={showToast}
        />
      )}

      {activeModal === 'store' && (
        <CoinShopModal
          currentUser={currentUser}
          onClose={() => setActiveModal(null)}
        />
      )}

      {activeModal === 'medal' && (
        <ProfileMedalModal
          currentUser={currentUser}
          onClose={() => setActiveModal(null)}
          onToast={showToast}
        />
      )}

      {activeModal === 'level' && (
        <ProfileLevelModal
          currentUser={currentUser}
          onClose={() => setActiveModal(null)}
          onToast={showToast}
        />
      )}

      {activeModal === 'giftRecord' && (
        <GiftHistoryModal
          user={currentUser}
          onClose={() => setActiveModal(null)}
        />
      )}

      {activeModal === 'settings' && (
        <ProfileSettingsModal
          currentUser={currentUser}
          onClose={() => setActiveModal(null)}
          onLogout={onLogout}
          onToast={showToast}
        />
      )}

      {/* DEDICATED EDIT PROFILE PAGE */}
      {isEditProfileOpen && (
        <EditProfilePage
          currentUser={currentUser}
          onBack={() => setIsEditProfileOpen(false)}
          onUpdateUser={(updated) => {
            onUpdateUser(updated);
          }}
          onToast={showToast}
        />
      )}

      {/* Floating Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-20 left-1/2 -translate-x-1/2 z-50 px-4 py-2 bg-neutral-900 border border-violet-500/60 rounded-full shadow-2xl text-xs font-semibold text-white animate-fadeIn flex items-center space-x-1.5">
          <Sparkles className="w-3.5 h-3.5 text-violet-400" />
          <span>{toastMessage}</span>
        </div>
      )}
    </div>
  );
};
