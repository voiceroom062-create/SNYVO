import React, { useState } from 'react';
import { Mail, Lock, Eye, EyeOff, ArrowLeft, ArrowRight, CheckCircle2 } from 'lucide-react';
import { authService } from '../services/firebaseService';

interface LoginScreenProps {
  onSuccess: () => void;
  onNavigateToSignUp: () => void;
  onBack: () => void;
}

export const LoginScreen: React.FC<LoginScreenProps> = ({
  onSuccess,
  onNavigateToSignUp,
  onBack,
}) => {
  const [email, setEmail] = useState('alex.vance@snyvo.club');
  const [password, setPassword] = useState('voicepass123');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) {
      setError('Please fill in your email and password');
      return;
    }
    try {
      setIsLoading(true);
      setError(null);
      await authService.signInWithEmail(email, password);
      onSuccess();
    } catch (err: any) {
      setError(err?.message || 'Failed to sign in. Please check credentials.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleGoogleSignIn = async () => {
    try {
      setIsLoading(true);
      setError(null);
      await authService.signInWithGoogle();
      onSuccess();
    } catch (err: any) {
      setError('Google Sign-In simulation failed');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div id="login-screen" className="flex flex-col h-full w-full px-6 py-6 bg-neutral-950 overflow-y-auto">
      {/* Top App Bar with back button */}
      <div className="flex items-center justify-between pt-2 pb-6">
        <button
          id="login-back-btn"
          onClick={onBack}
          className="p-2 -ml-2 rounded-full text-neutral-400 hover:text-white hover:bg-neutral-900 transition-colors"
          aria-label="Back"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
        <span className="text-xs font-semibold tracking-wider text-violet-400 uppercase">
          Welcome Back
        </span>
        <div className="w-9"></div> {/* Balancer */}
      </div>

      {/* Title & Subtitle */}
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-white tracking-tight">
          Sign into SNYVO
        </h2>
        <p className="text-xs text-neutral-400 mt-1">
          Join conversations, voice clubs, and community stages.
        </p>
      </div>

      {error && (
        <div className="mb-4 p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs">
          {error}
        </div>
      )}

      {/* Form */}
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-xs font-medium text-neutral-300 mb-1.5">
            Email or Username
          </label>
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-neutral-500">
              <Mail className="w-4 h-4" />
            </div>
            <input
              id="login-email-input"
              type="text"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="name@example.com"
              className="w-full pl-10 pr-4 py-3 bg-neutral-900/90 border border-neutral-800 rounded-xl text-white text-sm placeholder-neutral-500 focus:outline-none focus:border-violet-500 focus:ring-1 focus:ring-violet-500 transition-all"
            />
          </div>
        </div>

        <div>
          <div className="flex items-center justify-between mb-1.5">
            <label className="block text-xs font-medium text-neutral-300">
              Password
            </label>
            <a href="#forgot" onClick={(e) => e.preventDefault()} className="text-[11px] text-violet-400 hover:underline">
              Forgot?
            </a>
          </div>
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-neutral-500">
              <Lock className="w-4 h-4" />
            </div>
            <input
              id="login-password-input"
              type={showPassword ? 'text' : 'password'}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              className="w-full pl-10 pr-10 py-3 bg-neutral-900/90 border border-neutral-800 rounded-xl text-white text-sm placeholder-neutral-500 focus:outline-none focus:border-violet-500 focus:ring-1 focus:ring-violet-500 transition-all"
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute inset-y-0 right-0 pr-3 flex items-center text-neutral-500 hover:text-neutral-300"
              aria-label={showPassword ? 'Hide password' : 'Show password'}
            >
              {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            </button>
          </div>
        </div>

        {/* Submit button */}
        <button
          id="login-submit-btn"
          type="submit"
          disabled={isLoading}
          className="w-full mt-2 py-3.5 px-4 rounded-xl bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-500 hover:to-indigo-500 text-white font-semibold text-sm shadow-md shadow-violet-600/30 flex items-center justify-center space-x-2 active:scale-[0.98] transition-all disabled:opacity-50"
        >
          {isLoading ? (
            <span className="inline-block w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></span>
          ) : (
            <>
              <span>Sign In</span>
              <ArrowRight className="w-4 h-4" />
            </>
          )}
        </button>
      </form>

      {/* Divider */}
      <div className="relative my-6 text-center">
        <div className="absolute inset-0 flex items-center">
          <div className="w-full border-t border-neutral-800"></div>
        </div>
        <span className="relative px-3 bg-neutral-950 text-[11px] text-neutral-400 uppercase tracking-wider">
          Or continue with
        </span>
      </div>

      {/* Social / One-Tap buttons */}
      <div className="space-y-2.5">
        <button
          id="login-google-btn"
          type="button"
          onClick={handleGoogleSignIn}
          disabled={isLoading}
          className="w-full py-3 px-4 rounded-xl bg-neutral-900 border border-neutral-800 hover:bg-neutral-800/80 text-white font-medium text-xs flex items-center justify-center space-x-2.5 transition-colors"
        >
          <svg className="w-4 h-4" viewBox="0 0 24 24">
            <path
              fill="#4285F4"
              d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.665-5.17 3.665-9.17z"
            />
            <path
              fill="#34A853"
              d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.25v3.15C3.26 21.36 7.33 24 12 24z"
            />
            <path
              fill="#FBBC05"
              d="M5.28 14.27c-.25-.72-.38-1.49-.38-2.27s.13-1.55.38-2.27V6.58H1.25C.45 8.16 0 9.94 0 12s.45 3.84 1.25 5.42l4.03-3.15z"
            />
            <path
              fill="#EA4335"
              d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.33 0 3.26 2.64 1.25 6.58l4.03 3.15c.95-2.83 3.6-4.98 6.72-4.98z"
            />
          </svg>
          <span>Continue with Google</span>
        </button>

        <button
          id="login-quick-demo-btn"
          type="button"
          onClick={() => {
            setEmail('alex.vance@snyvo.club');
            setPassword('voicepass123');
            handleSubmit(new Event('submit') as any);
          }}
          className="w-full py-2.5 px-4 rounded-xl bg-violet-950/30 border border-violet-800/40 text-violet-300 hover:bg-violet-900/40 font-medium text-xs flex items-center justify-center space-x-1.5 transition-colors"
        >
          <CheckCircle2 className="w-3.5 h-3.5 text-violet-400" />
          <span>Quick Demo Auto-Login (Alex Vance)</span>
        </button>
      </div>

      {/* Footer Link to Sign Up */}
      <div className="mt-auto pt-8 pb-4 text-center">
        <p className="text-xs text-neutral-400">
          Don't have a SNYVO invite yet?{' '}
          <button
            id="login-goto-signup-btn"
            onClick={onNavigateToSignUp}
            className="text-violet-400 hover:underline font-medium"
          >
            Create an account
          </button>
        </p>
      </div>
    </div>
  );
};
