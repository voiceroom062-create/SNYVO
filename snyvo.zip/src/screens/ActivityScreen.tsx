import React from 'react';
import { Bell, Radio, UserPlus, Heart, Sparkles, Hand } from 'lucide-react';

export const ActivityScreen: React.FC = () => {
  const notifications = [
    {
      id: 'notif_1',
      icon: Radio,
      iconColor: 'text-emerald-400',
      bg: 'bg-emerald-500/10',
      title: 'Maya Lin started a new stage',
      desc: '"Late Night Chill & Lo-Fi Beats Lounge" is now live!',
      time: '15m ago',
      unread: true,
    },
    {
      id: 'notif_2',
      icon: Hand,
      iconColor: 'text-amber-400',
      bg: 'bg-amber-500/10',
      title: 'Speaker Invitation',
      desc: 'Dr. Sarah Thorne invited you to speak on stage in "Future of AI".',
      time: '1h ago',
      unread: true,
    },
    {
      id: 'notif_3',
      icon: UserPlus,
      iconColor: 'text-violet-400',
      bg: 'bg-violet-500/10',
      title: 'New Club Follower',
      desc: 'Marcus Bell and 3 others started following your voice profile.',
      time: '3h ago',
      unread: false,
    },
    {
      id: 'notif_4',
      icon: Heart,
      iconColor: 'text-rose-400',
      bg: 'bg-rose-500/10',
      title: 'Stage Reactions',
      desc: 'Your talk received 84 reactions in the Indie Builders room.',
      time: 'Yesterday',
      unread: false,
    },
  ];

  return (
    <div id="activity-screen" className="flex flex-col h-full w-full bg-neutral-950 text-white overflow-y-auto pb-24 px-5 pt-3">
      <div className="pb-3 border-b border-neutral-900 flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-white">Activity & Alerts</h2>
          <p className="text-xs text-neutral-400 mt-0.5">Stay updated with your clubs and stages</p>
        </div>
        <span className="text-[11px] text-violet-400 font-medium">Mark all read</span>
      </div>

      <div className="pt-4 space-y-3">
        {notifications.map(n => {
          const Icon = n.icon;
          return (
            <div
              key={n.id}
              className={`p-3.5 rounded-2xl border transition-all flex items-start space-x-3 ${
                n.unread
                  ? 'bg-neutral-900/80 border-violet-500/30 shadow-md shadow-violet-950/20'
                  : 'bg-neutral-900/40 border-neutral-800/60'
              }`}
            >
              <div className={`p-2.5 rounded-xl ${n.bg} ${n.iconColor} flex-shrink-0 mt-0.5`}>
                <Icon className="w-4 h-4" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold text-white truncate">{n.title}</h4>
                  <span className="text-[10px] text-neutral-500 flex-shrink-0 ml-2">{n.time}</span>
                </div>
                <p className="text-xs text-neutral-300 mt-0.5 leading-relaxed">{n.desc}</p>
              </div>
              {n.unread && (
                <span className="w-2 h-2 rounded-full bg-violet-500 flex-shrink-0 mt-1.5"></span>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
