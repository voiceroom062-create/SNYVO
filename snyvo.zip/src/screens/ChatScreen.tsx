import React, { useState, useEffect, useRef } from 'react';
import {
  Search,
  MessageCircle,
  MoreVertical,
  ArrowLeft,
  Send,
  Smile,
  Phone,
  Video,
  Check,
  CheckCheck,
  Sparkles,
  Pin,
  ShieldCheck,
  Users,
  UserCheck,
  Bell,
  X,
} from 'lucide-react';
import { User } from '../types';
import { DirectConversation, DirectChatMessage } from '../types/chat';
import { chatService } from '../services/chatService';

interface ChatScreenProps {
  currentUser: User;
  onOpenProfile?: (user: Partial<User>) => void;
  onJoinRoomId?: (roomId: string) => void;
}

const POPULAR_EMOJIS = [
  '❤️', '🔥', '👏', '🎉', '🎙️', '✨', '😂', '😍',
  '🤩', '🚀', '💯', '👑', '👍', '🥳', '💬', '🌸',
  '⚡', '🌟', '🙌', '🎵', '🤝', '☕', '💡', '😎'
];

export const ChatScreen: React.FC<ChatScreenProps> = ({
  currentUser,
  onOpenProfile,
}) => {
  const [conversations, setConversations] = useState<DirectConversation[]>(() =>
    chatService.getConversations()
  );
  const [activeConversationId, setActiveConversationId] = useState<string | null>(null);
  const [messages, setMessages] = useState<DirectChatMessage[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTab, setActiveTab] = useState<'recent' | 'friends' | 'official'>('recent');
  const [inputText, setInputText] = useState('');
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 2500);
  };

  // Subscribe to chat updates
  useEffect(() => {
    const unsub = chatService.subscribeDirectChat(() => {
      setConversations(chatService.getConversations());
      if (activeConversationId) {
        setMessages(chatService.getConversationMessages(activeConversationId));
      }
    });

    return unsub;
  }, [activeConversationId]);

  // When opening a conversation
  useEffect(() => {
    if (activeConversationId) {
      setMessages(chatService.getConversationMessages(activeConversationId));
      chatService.markConversationAsRead(activeConversationId);
    }
  }, [activeConversationId]);

  // Auto-scroll on new direct messages
  useEffect(() => {
    if (activeConversationId) {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages.length, activeConversationId]);

  const activeConversation = conversations.find(c => c.id === activeConversationId);

  const handleSendDirectMessage = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!inputText.trim() || !activeConversationId) return;

    await chatService.sendDirectMessage(activeConversationId, inputText.trim(), currentUser);
    setInputText('');
    setShowEmojiPicker(false);
  };

  const handleInsertEmoji = (emoji: string) => {
    setInputText(prev => prev + emoji);
    inputRef.current?.focus();
  };

  // Filter conversations
  const filteredConversations = conversations.filter(c => {
    const matchesSearch =
      c.participant.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.participant.handle.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.lastMessage.text.toLowerCase().includes(searchQuery.toLowerCase());

    if (!matchesSearch) return false;

    if (activeTab === 'friends') return c.isFriend;
    if (activeTab === 'official') return c.category === 'official';
    return true; // 'recent'
  });

  const totalUnread = conversations.reduce((acc, c) => acc + c.unreadCount, 0);

  // Active friends story row
  const activeFriends = conversations.filter(c => c.isFriend || c.participant.isVerified);

  return (
    <div id="snyvo-chat-screen" className="flex-1 flex flex-col bg-neutral-950 text-white min-h-0 relative overflow-hidden">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="absolute top-4 left-1/2 -translate-x-1/2 px-4 py-2 bg-neutral-900/95 border border-violet-500/50 text-white text-xs font-semibold rounded-full shadow-2xl z-50 flex items-center space-x-2 animate-fade-in">
          <Sparkles className="w-3.5 h-3.5 text-violet-400 flex-shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 📱 CONVERSATION THREAD VIEW (When a chat is selected)                     */}
      {/* ========================================================================= */}
      {activeConversation ? (
        <div className="flex-1 flex flex-col h-full bg-neutral-950 animate-fade-in">
          {/* Header */}
          <div className="px-4 py-3 border-b border-neutral-850 bg-neutral-950/90 backdrop-blur-xl flex items-center justify-between flex-shrink-0">
            <div className="flex items-center space-x-3 min-w-0">
              <button
                id="dm-back-to-list-btn"
                onClick={() => {
                  setActiveConversationId(null);
                  setShowEmojiPicker(false);
                }}
                className="p-1.5 -ml-1 text-neutral-400 hover:text-white rounded-full hover:bg-neutral-800 transition-colors cursor-pointer"
                aria-label="Back to conversations"
              >
                <ArrowLeft className="w-5 h-5" />
              </button>

              <div
                onClick={() => onOpenProfile && onOpenProfile(activeConversation.participant)}
                className="flex items-center space-x-2.5 cursor-pointer group min-w-0"
              >
                <div className="relative flex-shrink-0">
                  <img
                    src={activeConversation.participant.avatar}
                    alt={activeConversation.participant.name}
                    className="w-10 h-10 rounded-full object-cover ring-1.5 ring-violet-500/40 group-hover:ring-violet-400 transition-all"
                  />
                  {activeConversation.isFriend && (
                    <span className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-emerald-500 rounded-full ring-2 ring-neutral-950" />
                  )}
                </div>

                <div className="min-w-0">
                  <div className="flex items-center space-x-1.5">
                    <h3 className="text-sm font-bold text-white group-hover:text-violet-300 transition-colors truncate">
                      {activeConversation.participant.name}
                    </h3>
                    {activeConversation.participant.isVerified && (
                      <ShieldCheck className="w-3.5 h-3.5 text-violet-400 flex-shrink-0" />
                    )}
                  </div>
                  <p className="text-[10px] text-neutral-400 font-mono truncate">
                    {activeConversation.participant.handle} · ID: {activeConversation.participant.numericId || '849201'}
                  </p>
                </div>
              </div>
            </div>

            {/* Quick Actions */}
            <div className="flex items-center space-x-1">
              <button
                id="dm-voice-call-btn"
                onClick={() => showToast('Voice call connection prepared for live audio service')}
                className="p-2 text-neutral-400 hover:text-white rounded-xl hover:bg-neutral-800 transition-colors cursor-pointer"
                title="Voice Call"
              >
                <Phone className="w-4 h-4" />
              </button>
              <button
                id="dm-more-options-btn"
                onClick={() => showToast('Conversation options & media gallery')}
                className="p-2 text-neutral-400 hover:text-white rounded-xl hover:bg-neutral-800 transition-colors cursor-pointer"
                title="Options"
              >
                <MoreVertical className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Architecture notice */}
          <div className="px-4 py-1.5 bg-violet-950/20 border-b border-violet-900/30 flex items-center justify-between text-[10px] text-neutral-400 flex-shrink-0">
            <span className="flex items-center space-x-1">
              <Sparkles className="w-3 h-3 text-violet-400" />
              <span>Direct messages stored locally · Ready for real-time messaging</span>
            </span>
          </div>

          {/* Messages Feed */}
          <div
            id="direct-chat-thread-container"
            className="flex-1 overflow-y-auto p-4 space-y-3 scrollbar-thin scrollbar-thumb-neutral-800"
          >
            {messages.length === 0 ? (
              <div className="py-12 text-center text-neutral-500 space-y-2">
                <MessageCircle className="w-8 h-8 mx-auto text-neutral-700" />
                <p className="text-xs font-semibold">No messages yet with {activeConversation.participant.name}</p>
                <p className="text-[11px] text-neutral-600">Send a greeting to start a private voice room conversation.</p>
              </div>
            ) : (
              messages.map((msg) => {
                const isMe = msg.isFromMe;
                return (
                  <div
                    key={msg.id}
                    id={`dm-msg-${msg.id}`}
                    className={`flex items-end space-x-2 ${isMe ? 'justify-end' : 'justify-start'}`}
                  >
                    {!isMe && (
                      <img
                        src={activeConversation.participant.avatar}
                        alt={activeConversation.participant.name}
                        className="w-7 h-7 rounded-full object-cover flex-shrink-0 mb-1 ring-1 ring-neutral-700"
                      />
                    )}

                    <div className="max-w-[78%] flex flex-col space-y-1">
                      <div
                        className={`px-3.5 py-2.5 rounded-2xl text-xs leading-relaxed break-words shadow-md ${
                          isMe
                            ? 'bg-gradient-to-r from-violet-600 to-violet-700 text-white rounded-br-xs shadow-violet-950/30'
                            : 'bg-neutral-850 border border-neutral-800 text-neutral-100 rounded-bl-xs'
                        }`}
                      >
                        <p>{msg.text}</p>
                      </div>

                      <div
                        className={`flex items-center space-x-1 px-1 text-[9px] text-neutral-400 font-mono ${
                          isMe ? 'justify-end' : 'justify-start'
                        }`}
                      >
                        <span>{msg.time}</span>
                        {isMe && (
                          <span title={msg.status}>
                            {msg.status === 'read' ? (
                              <CheckCheck className="w-3 h-3 text-violet-400 inline" />
                            ) : (
                              <Check className="w-3 h-3 text-neutral-400 inline" />
                            )}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Emoji Picker */}
          {showEmojiPicker && (
            <div
              id="dm-emoji-picker"
              className="mx-4 p-2.5 bg-neutral-900 border border-neutral-800 rounded-2xl mb-2 grid grid-cols-8 gap-1.5 shadow-2xl animate-fade-in flex-shrink-0"
            >
              {POPULAR_EMOJIS.map((emoji) => (
                <button
                  key={emoji}
                  type="button"
                  onClick={() => handleInsertEmoji(emoji)}
                  className="w-8 h-8 rounded-xl hover:bg-neutral-800 active:scale-95 flex items-center justify-center text-base cursor-pointer transition-transform"
                >
                  {emoji}
                </button>
              ))}
            </div>
          )}

          {/* Input Form */}
          <form
            id="direct-chat-input-form"
            onSubmit={handleSendDirectMessage}
            className="p-3 border-t border-neutral-850 bg-neutral-950/95 flex items-center space-x-2 flex-shrink-0"
          >
            <button
              id="dm-emoji-btn"
              type="button"
              onClick={() => setShowEmojiPicker(!showEmojiPicker)}
              className={`p-2.5 rounded-xl border transition-all cursor-pointer ${
                showEmojiPicker
                  ? 'bg-amber-500/20 border-amber-500/60 text-amber-300'
                  : 'bg-neutral-900 border-neutral-800 text-neutral-400 hover:text-white'
              }`}
              title="Insert Emoji"
            >
              <Smile className="w-4 h-4" />
            </button>

            <input
              id="direct-chat-text-input"
              ref={inputRef}
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder={`Message ${activeConversation.participant.name}...`}
              className="flex-1 bg-neutral-900 border border-neutral-800 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-violet-500 transition-colors"
            />

            <button
              id="direct-chat-send-btn"
              type="submit"
              disabled={!inputText.trim()}
              className={`p-2.5 rounded-xl text-white transition-all cursor-pointer ${
                inputText.trim()
                  ? 'bg-violet-600 hover:bg-violet-500 shadow-md shadow-violet-600/30 active:scale-95'
                  : 'bg-neutral-900 border border-neutral-800 text-neutral-600 cursor-not-allowed'
              }`}
              title="Send Message"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>
      ) : (
        /* ========================================================================= */
        /* 📋 MAIN CONVERSATION LIST (Recent Chats, Friends, Official)               */
        /* ========================================================================= */
        <div className="flex-1 flex flex-col h-full overflow-hidden">
          {/* Top Bar */}
          <div className="p-4 pb-2 border-b border-neutral-850/80 bg-neutral-950/90 backdrop-blur-xl flex-shrink-0">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center space-x-2">
                <h1 className="text-xl font-black text-white tracking-tight">Messages</h1>
                {totalUnread > 0 && (
                  <span
                    id="total-unread-badge"
                    className="px-2 py-0.5 rounded-full bg-violet-600 text-white text-[10px] font-extrabold shadow-sm shadow-violet-900/50"
                  >
                    {totalUnread} new
                  </span>
                )}
              </div>

              <div className="flex items-center space-x-2">
                <button
                  id="chat-filter-alerts-btn"
                  onClick={() => showToast('All notifications are up to date')}
                  className="p-2 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-neutral-400 hover:text-white transition-colors cursor-pointer border border-neutral-800"
                  title="Alerts"
                >
                  <Bell className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Search Input */}
            <div className="relative mb-3">
              <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-neutral-500 pointer-events-none" />
              <input
                id="chat-search-input"
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search friends or messages..."
                className="w-full bg-neutral-900/80 border border-neutral-800 rounded-xl pl-10 pr-9 py-2 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-violet-500 transition-colors"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-neutral-400 hover:text-white"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

            {/* Tab Pills */}
            <div className="flex items-center space-x-1 border-b border-neutral-850 pb-2">
              <button
                id="chat-tab-recent"
                onClick={() => setActiveTab('recent')}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                  activeTab === 'recent'
                    ? 'bg-violet-600/20 border border-violet-500/50 text-violet-300 shadow-sm'
                    : 'text-neutral-400 hover:text-white'
                }`}
              >
                Recent Chats
              </button>
              <button
                id="chat-tab-friends"
                onClick={() => setActiveTab('friends')}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer flex items-center space-x-1.5 ${
                  activeTab === 'friends'
                    ? 'bg-violet-600/20 border border-violet-500/50 text-violet-300 shadow-sm'
                    : 'text-neutral-400 hover:text-white'
                }`}
              >
                <UserCheck className="w-3.5 h-3.5" />
                <span>Friends</span>
              </button>
              <button
                id="chat-tab-official"
                onClick={() => setActiveTab('official')}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer flex items-center space-x-1.5 ${
                  activeTab === 'official'
                    ? 'bg-violet-600/20 border border-violet-500/50 text-violet-300 shadow-sm'
                    : 'text-neutral-400 hover:text-white'
                }`}
              >
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>Official</span>
              </button>
            </div>
          </div>

          {/* Active Friends Strip */}
          <div className="px-4 py-2.5 border-b border-neutral-850/60 bg-neutral-950/60 flex-shrink-0">
            <div className="flex items-center justify-between mb-2">
              <span className="text-[11px] font-bold text-neutral-400 uppercase tracking-wider">
                Stage Connections
              </span>
            </div>
            <div className="flex items-center space-x-3 overflow-x-auto scrollbar-none py-1">
              {activeFriends.map((c) => (
                <div
                  key={c.id}
                  id={`friend-pill-${c.participant.id}`}
                  onClick={() => setActiveConversationId(c.id)}
                  className="flex flex-col items-center space-y-1 cursor-pointer flex-shrink-0 group"
                  title={`Chat with ${c.participant.name}`}
                >
                  <div className="relative">
                    <img
                      src={c.participant.avatar}
                      alt={c.participant.name}
                      className="w-12 h-12 rounded-2xl object-cover ring-2 ring-violet-600/40 group-hover:ring-violet-400 transition-all p-0.5"
                    />
                    {c.isFriend && (
                      <span className="absolute bottom-0 right-0 w-3 h-3 rounded-full bg-emerald-500 ring-2 ring-neutral-950" />
                    )}
                  </div>
                  <span className="text-[10px] font-medium text-neutral-300 group-hover:text-white truncate max-w-[56px] text-center">
                    {c.participant.name.split(' ')[0]}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Conversations List */}
          <div
            id="conversations-list-container"
            className="flex-1 overflow-y-auto divide-y divide-neutral-850/60 scrollbar-thin scrollbar-thumb-neutral-800"
          >
            {filteredConversations.length === 0 ? (
              <div className="py-16 text-center text-neutral-500 space-y-2">
                <MessageCircle className="w-10 h-10 mx-auto text-neutral-700" />
                <p className="text-sm font-semibold">No conversations found</p>
                <p className="text-xs text-neutral-600">
                  {searchQuery ? 'Try a different search keyword' : 'Start chatting with friends from the voice rooms!'}
                </p>
              </div>
            ) : (
              filteredConversations.map((conv) => {
                const hasUnread = conv.unreadCount > 0;

                return (
                  <div
                    key={conv.id}
                    id={`conversation-item-${conv.id}`}
                    onClick={() => setActiveConversationId(conv.id)}
                    className={`p-3.5 flex items-center justify-between hover:bg-neutral-900/70 transition-colors cursor-pointer ${
                      hasUnread ? 'bg-neutral-900/30' : ''
                    }`}
                  >
                    <div className="flex items-center space-x-3 min-w-0 flex-1">
                      {/* Avatar */}
                      <div className="relative flex-shrink-0">
                        <img
                          src={conv.participant.avatar}
                          alt={conv.participant.name}
                          className="w-12 h-12 rounded-2xl object-cover ring-1 ring-neutral-800"
                        />
                        {conv.isPinned && (
                          <div className="absolute -top-1 -left-1 w-4 h-4 rounded-full bg-amber-500 text-neutral-950 flex items-center justify-center shadow-xs">
                            <Pin className="w-2.5 h-2.5 fill-current" />
                          </div>
                        )}
                        {conv.isFriend && (
                          <span className="absolute -bottom-0.5 -right-0.5 w-3 h-3 bg-emerald-500 rounded-full ring-2 ring-neutral-950" />
                        )}
                      </div>

                      {/* Content */}
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center justify-between mb-1">
                          <div className="flex items-center space-x-1.5 min-w-0">
                            <h3
                              className={`text-xs sm:text-sm font-bold truncate ${
                                hasUnread ? 'text-white' : 'text-neutral-200'
                              }`}
                            >
                              {conv.participant.name}
                            </h3>
                            {conv.participant.isVerified && (
                              <ShieldCheck className="w-3.5 h-3.5 text-violet-400 flex-shrink-0" />
                            )}
                            {conv.participant.level && (
                              <span className="text-[8px] font-bold px-1.5 py-0.2 rounded-full bg-neutral-800 text-neutral-300 border border-neutral-700">
                                Lv.{conv.participant.level}
                              </span>
                            )}
                          </div>
                          <span
                            className={`text-[10px] font-mono flex-shrink-0 ${
                              hasUnread ? 'text-violet-400 font-bold' : 'text-neutral-500'
                            }`}
                          >
                            {conv.lastMessage.time}
                          </span>
                        </div>

                        <div className="flex items-center justify-between">
                          <p
                            className={`text-xs truncate max-w-[200px] sm:max-w-xs ${
                              hasUnread ? 'text-neutral-100 font-semibold' : 'text-neutral-400'
                            }`}
                          >
                            {conv.lastMessage.isFromMe && (
                              <span className="text-violet-400 mr-1">You:</span>
                            )}
                            {conv.lastMessage.text}
                          </p>

                          {hasUnread && (
                            <span className="ml-2 min-w-[18px] h-4 px-1 rounded-full bg-violet-600 text-white text-[9px] font-extrabold flex items-center justify-center shadow-xs flex-shrink-0">
                              {conv.unreadCount}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}
    </div>
  );
};
