import React, { useState } from 'react';
import { GiftAnimationEvent } from '../types';
import { Volume2, VolumeX, X, Sparkles, Heart, Crown, Flame, Trophy, Star, Gem } from 'lucide-react';
import { giftSoundEngine } from '../soundEngine';
import { giftService } from '../giftService';

interface GiftAnimationOverlayProps {
  animation: GiftAnimationEvent | null;
  onDismiss: () => void;
}

export const GiftAnimationOverlay: React.FC<GiftAnimationOverlayProps> = ({
  animation,
  onDismiss,
}) => {
  const [isMuted, setIsMuted] = useState<boolean>(giftSoundEngine.getIsMuted());

  if (!animation) return null;

  const { gift, quantity, totalCoins, sender, receiver } = animation;
  const giftNameLower = gift.name.toLowerCase();

  const isRose = gift.id === 'g_rose' || giftNameLower.includes('rose');
  const isHeart = gift.id === 'g_heart' || gift.id === 'g_love' || giftNameLower.includes('heart') || giftNameLower.includes('love');
  const isCrown = gift.id === 'g_crown' || giftNameLower.includes('crown');
  const isDiamond = gift.id === 'g_diamond' || gift.id === 'lux_diamond' || giftNameLower.includes('diamond');
  const isFire = gift.id === 'g_fire' || giftNameLower.includes('fire');
  const isTrophy = gift.id === 'g_trophy' || giftNameLower.includes('trophy');
  const isStar = gift.id === 'g_star' || giftNameLower.includes('star');

  const isMega = gift.tier === 'mega';
  const isLarge = gift.tier === 'large';

  const toggleSound = () => {
    const nextMute = giftSoundEngine.toggleMute();
    setIsMuted(nextMute);
  };

  return (
    <div
      id="gift-animation-overlay"
      className="fixed inset-0 z-40 pointer-events-none flex flex-col items-center justify-between p-4 bg-black/40 backdrop-blur-[1px] overflow-hidden select-none animate-fade-in"
    >
      {/* Top Banner Control Bar: Audio & Skip (Pointer events enabled for buttons only) */}
      <div className="w-full max-w-md flex items-center justify-between z-50 pt-2 pointer-events-auto">
        <div className="flex items-center space-x-2 px-3 py-1.5 rounded-full bg-black/80 backdrop-blur-md border border-white/10 text-white text-xs shadow-lg">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
          <span className="font-bold text-[11px] tracking-wider uppercase flex items-center space-x-1">
            <span>🎁</span>
            <span>Room Gift Event</span>
          </span>
        </div>

        <div className="flex items-center space-x-2">
          {/* Mute toggle */}
          <button
            onClick={toggleSound}
            className="p-2 rounded-full bg-black/80 backdrop-blur-md border border-white/10 text-white hover:bg-neutral-800 transition-colors cursor-pointer shadow-lg active:scale-95"
            title={isMuted ? 'Unmute Audio' : 'Mute Audio'}
          >
            {isMuted ? <VolumeX className="w-4 h-4 text-rose-400" /> : <Volume2 className="w-4 h-4 text-emerald-400" />}
          </button>

          {/* Dismiss / Skip */}
          <button
            onClick={() => {
              giftService.dismissActiveAnimation();
              onDismiss();
            }}
            className="p-2 rounded-full bg-black/80 backdrop-blur-md border border-white/10 text-white hover:bg-neutral-800 transition-colors cursor-pointer shadow-lg active:scale-95"
            title="Dismiss Animation"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* --- SENDER -> GIFT -> RECEIVER HEADER BANNER --- */}
      <div className="w-full max-w-sm z-50 animate-bounce-short pointer-events-auto">
        <div className="p-2.5 sm:p-3 rounded-2xl bg-gradient-to-r from-violet-950/90 via-black/90 to-neutral-950/90 border border-violet-500/40 shadow-2xl backdrop-blur-lg flex items-center justify-between">
          {/* Sender */}
          <div className="flex items-center space-x-2 text-left">
            <img
              src={sender.avatar}
              alt={sender.name}
              className="w-9 h-9 rounded-full object-cover border-2 border-violet-400 shadow-md"
            />
            <div className="max-w-[85px] truncate">
              <span className="text-[9px] uppercase tracking-wider text-violet-300 font-bold block">
                Sender
              </span>
              <span className="text-xs font-black text-white truncate block">
                {sender.name}
              </span>
            </div>
          </div>

          {/* Center Flow Indicator */}
          <div className="flex flex-col items-center px-1">
            <span className="text-sm animate-pulse">
              {gift.icon}
            </span>
            <span className="text-[9px] text-amber-300 font-mono font-bold">
              {quantity > 1 ? `${quantity}x ` : ''}🪙 {totalCoins.toLocaleString()}
            </span>
          </div>

          {/* Receiver */}
          <div className="flex items-center space-x-2 text-right justify-end">
            <div className="max-w-[85px] truncate">
              <span className="text-[9px] uppercase tracking-wider text-rose-400 font-bold block">
                Receiver
              </span>
              <span className="text-xs font-black text-white truncate block">
                {receiver.name}
              </span>
            </div>
            <img
              src={receiver.avatar}
              alt={receiver.name}
              className="w-9 h-9 rounded-full object-cover border-2 border-rose-400 shadow-md"
            />
          </div>
        </div>
      </div>

      {/* --- CENTER STAGE ANIMATION CANVAS (Lightweight, Smooth, Non-blocking) --- */}
      <div className="flex-1 w-full max-w-md flex flex-col items-center justify-center relative pointer-events-none my-auto">
        
        {/* Background Ambient Glow */}
        <div
          className={`absolute w-72 h-72 rounded-full filter blur-3xl opacity-50 animate-pulse pointer-events-none ${
            isRose || isHeart ? 'bg-rose-600/40' :
            isCrown ? 'bg-amber-500/40' :
            isDiamond ? 'bg-cyan-500/40' :
            isFire ? 'bg-orange-600/50' :
            isTrophy || isStar ? 'bg-yellow-500/40' :
            'bg-violet-600/30'
          }`}
        />

        {/* 🌹 1. ROSE FLOATING TOWARD RECEIVER */}
        {isRose && (
          <div className="flex flex-col items-center space-y-3 animate-scale-in">
            <div className="relative flex items-center justify-center">
              {/* Drifting petals */}
              <span className="absolute -top-10 -left-10 text-2xl animate-spin-slow opacity-80">🍃</span>
              <span className="absolute -bottom-8 -right-8 text-2xl animate-bounce-slow opacity-90">🌸</span>
              <span className="absolute top-4 -right-12 text-xl animate-pulse">✨</span>

              {/* Central Floating Rose */}
              <div className="w-28 h-28 rounded-full bg-gradient-to-tr from-rose-900/60 to-pink-900/40 border border-rose-400/60 flex items-center justify-center shadow-2xl shadow-rose-600/40 animate-bounce-short">
                <span className="text-6xl drop-shadow-2xl">🌹</span>
              </div>
            </div>

            <div className="text-center z-10 space-y-1">
              <span className="text-[10px] font-black uppercase tracking-widest bg-rose-950/80 text-rose-300 border border-rose-500/50 px-3 py-0.5 rounded-full shadow-lg">
                🌹 Velvety Rose of Admiration
              </span>
              <h2 className="text-2xl sm:text-3xl font-black text-rose-200 drop-shadow-lg">
                Rose {quantity > 1 ? `×${quantity}` : ''}
              </h2>
              <p className="text-xs text-neutral-200">
                Floating to <span className="text-rose-400 font-extrabold">{receiver.name}</span>
              </p>
            </div>
          </div>
        )}

        {/* 💖 2. HEART / LOVE ANIMATION */}
        {isHeart && !isRose && (
          <div className="flex flex-col items-center space-y-3 animate-scale-in">
            <div className="relative flex items-center justify-center">
              {/* Expanding pulsating heart aura */}
              <div className="absolute -inset-6 flex items-center justify-center">
                <Heart className="w-36 h-36 text-pink-500/30 animate-ping" fill="currentColor" />
              </div>

              {/* Orbiting sparkles */}
              <span className="absolute -top-6 -left-6 text-xl animate-pulse">💕</span>
              <span className="absolute -bottom-6 -right-6 text-xl animate-pulse">✨</span>

              <div className="w-28 h-28 rounded-full bg-gradient-to-tr from-rose-600/70 to-pink-500/70 border border-pink-400/80 flex items-center justify-center shadow-2xl shadow-pink-600/50 animate-bounce-slow">
                <span className="text-6xl drop-shadow-2xl">💖</span>
              </div>
            </div>

            <div className="text-center z-10 space-y-1">
              <span className="text-[10px] font-black uppercase tracking-widest bg-pink-950/80 text-pink-300 border border-pink-500/50 px-3 py-0.5 rounded-full shadow-lg">
                💖 Warm Love & Connection
              </span>
              <h2 className="text-2xl sm:text-3xl font-black text-pink-200 drop-shadow-lg">
                {gift.name} {quantity > 1 ? `×${quantity}` : ''}
              </h2>
              <p className="text-xs text-neutral-200">
                Sharing affection with <span className="text-pink-300 font-extrabold">{receiver.name}</span>
              </p>
            </div>
          </div>
        )}

        {/* 👑 3. CROWN CORONATION ANIMATION */}
        {isCrown && (
          <div className="flex flex-col items-center space-y-3 animate-scale-in">
            <div className="relative flex items-center justify-center">
              {/* Golden starlight halo */}
              <div className="absolute -inset-8 rounded-full border-2 border-dashed border-amber-400/60 animate-spin-slow" />
              <Crown className="absolute -top-12 text-amber-400/40 w-12 h-12 animate-pulse" />

              <div className="w-28 h-28 rounded-full bg-gradient-to-tr from-amber-600/70 to-yellow-500/70 border-2 border-amber-300 flex items-center justify-center shadow-2xl shadow-amber-500/50 animate-bounce-short">
                <span className="text-6xl drop-shadow-2xl">👑</span>
              </div>
            </div>

            <div className="text-center z-10 space-y-1">
              <span className="text-[10px] font-black uppercase tracking-widest bg-amber-950/80 text-amber-300 border border-amber-500/50 px-3 py-0.5 rounded-full shadow-lg">
                👑 Royal Coronation Tribute
              </span>
              <h2 className="text-2xl sm:text-3xl font-black text-amber-200 drop-shadow-lg">
                Royal Crown {quantity > 1 ? `×${quantity}` : ''}
              </h2>
              <p className="text-xs text-neutral-200">
                Bestowed upon <span className="text-amber-300 font-extrabold">{receiver.name}</span>
              </p>
            </div>
          </div>
        )}

        {/* 💎 4. DIAMOND SPARKLE ANIMATION */}
        {isDiamond && (
          <div className="flex flex-col items-center space-y-3 animate-scale-in">
            <div className="relative flex items-center justify-center">
              {/* Diamond multi-point starlight aura */}
              <div className="absolute -inset-6 rounded-full border border-cyan-400/50 animate-ping" />
              <span className="absolute -top-6 -right-6 text-xl animate-pulse">✨</span>
              <span className="absolute -bottom-6 -left-6 text-xl animate-pulse">🔹</span>

              <div className="w-28 h-28 rounded-full bg-gradient-to-tr from-cyan-900/70 to-blue-900/70 border-2 border-cyan-400 flex items-center justify-center shadow-2xl shadow-cyan-500/50 animate-pulse">
                <span className="text-6xl drop-shadow-2xl">💎</span>
              </div>
            </div>

            <div className="text-center z-10 space-y-1">
              <span className="text-[10px] font-black uppercase tracking-widest bg-cyan-950/80 text-cyan-300 border border-cyan-500/50 px-3 py-0.5 rounded-full shadow-lg">
                💎 Radiant Diamond Sparkle
              </span>
              <h2 className="text-2xl sm:text-3xl font-black text-cyan-200 drop-shadow-lg">
                Diamond {quantity > 1 ? `×${quantity}` : ''}
              </h2>
              <p className="text-xs text-neutral-200">
                Sparkling for <span className="text-cyan-300 font-extrabold">{receiver.name}</span>
              </p>
            </div>
          </div>
        )}

        {/* 🔥 5. FIRE EFFECT ANIMATION */}
        {isFire && (
          <div className="flex flex-col items-center space-y-3 animate-scale-in">
            <div className="relative flex items-center justify-center">
              {/* Flame embers */}
              <div className="absolute -inset-6 rounded-full bg-orange-600/30 filter blur-xl animate-ping" />
              <Flame className="absolute -top-8 text-orange-400/50 w-10 h-10 animate-bounce-slow" />
              <span className="absolute -bottom-6 -right-6 text-xl animate-pulse">⚡</span>

              <div className="w-28 h-28 rounded-full bg-gradient-to-tr from-red-600/80 via-orange-500/80 to-amber-400/80 border-2 border-orange-400 flex items-center justify-center shadow-2xl shadow-orange-600/60 animate-bounce-short">
                <span className="text-6xl drop-shadow-2xl">🔥</span>
              </div>
            </div>

            <div className="text-center z-10 space-y-1">
              <span className="text-[10px] font-black uppercase tracking-widest bg-orange-950/80 text-orange-300 border border-orange-500/50 px-3 py-0.5 rounded-full shadow-lg">
                🔥 Stage Energy & Fire
              </span>
              <h2 className="text-2xl sm:text-3xl font-black text-orange-200 drop-shadow-lg">
                Fire {quantity > 1 ? `×${quantity}` : ''}
              </h2>
              <p className="text-xs text-neutral-200">
                Igniting the room for <span className="text-orange-300 font-extrabold">{receiver.name}</span>
              </p>
            </div>
          </div>
        )}

        {/* 🏆 6. TROPHY & STAR ANIMATION */}
        {(isTrophy || isStar) && !isRose && !isHeart && !isCrown && !isDiamond && !isFire && (
          <div className="flex flex-col items-center space-y-3 animate-scale-in">
            <div className="relative flex items-center justify-center">
              <div className="absolute -inset-6 rounded-full border border-yellow-400/60 animate-spin-slow" />
              <span className="absolute -top-8 text-2xl animate-pulse">⭐</span>
              <span className="absolute -bottom-6 -left-8 text-xl animate-pulse">🌟</span>

              <div className="w-28 h-28 rounded-full bg-gradient-to-tr from-yellow-600/70 to-amber-500/70 border-2 border-yellow-300 flex items-center justify-center shadow-2xl shadow-yellow-500/50 animate-bounce-short">
                <span className="text-6xl drop-shadow-2xl">{isTrophy ? '🏆' : '⭐'}</span>
              </div>
            </div>

            <div className="text-center z-10 space-y-1">
              <span className="text-[10px] font-black uppercase tracking-widest bg-yellow-950/80 text-yellow-300 border border-yellow-500/50 px-3 py-0.5 rounded-full shadow-lg">
                {isTrophy ? '🏆 Victory Championship Cup' : '⭐ Shining Star of the Room'}
              </span>
              <h2 className="text-2xl sm:text-3xl font-black text-yellow-200 drop-shadow-lg">
                {gift.name} {quantity > 1 ? `×${quantity}` : ''}
              </h2>
              <p className="text-xs text-neutral-200">
                Awarded to <span className="text-yellow-300 font-extrabold">{receiver.name}</span>
              </p>
            </div>
          </div>
        )}

        {/* 🌟 7. GENERIC / OTHER GIFTS FALLBACK */}
        {!isRose && !isHeart && !isCrown && !isDiamond && !isFire && !isTrophy && !isStar && (
          <div className="flex flex-col items-center space-y-3 animate-scale-in">
            <div className="relative flex items-center justify-center">
              <div className="w-28 h-28 rounded-full bg-gradient-to-tr from-violet-900/60 to-indigo-900/40 border border-violet-400/60 flex items-center justify-center shadow-2xl shadow-violet-600/40 animate-bounce-short">
                <span className="text-6xl drop-shadow-2xl">{gift.icon}</span>
              </div>
            </div>

            <div className="text-center z-10 space-y-1">
              <span className="text-[10px] font-black uppercase tracking-widest bg-violet-950/80 text-violet-300 border border-violet-500/50 px-3 py-0.5 rounded-full shadow-lg">
                ✨ Virtual Gift Delivery
              </span>
              <h2 className="text-2xl sm:text-3xl font-black text-white drop-shadow-lg">
                {gift.name} {quantity > 1 ? `×${quantity}` : ''}
              </h2>
              <p className="text-xs text-neutral-200">
                <span className="font-bold text-violet-300">{sender.name}</span> ➔ <span className="font-bold text-rose-300">{receiver.name}</span>
              </p>
            </div>
          </div>
        )}
      </div>

      {/* Bottom Stage Banner */}
      <div className="w-full max-w-sm z-50 pb-2 text-center animate-fade-in pointer-events-auto">
        <div className="py-2 px-4 rounded-full bg-black/80 backdrop-blur-md border border-white/10 inline-flex items-center space-x-2 text-xs text-amber-300 font-mono shadow-xl">
          <Sparkles className="w-3.5 h-3.5 text-amber-400 animate-spin-slow" />
          <span>Gift Value: 🪙 {totalCoins.toLocaleString()} Coins</span>
          <span className="text-white/40">•</span>
          <span className="text-neutral-300">Live Voice Room</span>
        </div>
      </div>
    </div>
  );
};
