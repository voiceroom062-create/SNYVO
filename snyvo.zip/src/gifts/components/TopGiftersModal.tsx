import React from 'react';
import { X, Trophy, Gift, ArrowLeft } from 'lucide-react';
import { giftService } from '../giftService';

interface TopGiftersModalProps {
  roomId: string;
  onClose: () => void;
  onSelectUser?: (userId: string) => void;
}

export const TopGiftersModal: React.FC<TopGiftersModalProps> = ({
  roomId,
  onClose,
  onSelectUser,
}) => {
  const topGifters = giftService.getTopGifters(roomId);

  const getRankBadge = (rank: number) => {
    switch (rank) {
      case 1:
        return '🥇';
      case 2:
        return '🥈';
      case 3:
        return '🥉';
      default:
        return `#${rank}`;
    }
  };

  return (
    <div
      id="top-gifters-modal"
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/85 backdrop-blur-md animate-fade-in"
    >
      <div className="w-full max-w-md bg-neutral-900 border border-neutral-800 rounded-t-3xl sm:rounded-3xl p-5 shadow-2xl flex flex-col text-white max-h-[85vh]">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-neutral-800 flex-shrink-0">
          <div className="flex items-center space-x-2.5">
            <button
              onClick={onClose}
              className="p-1.5 text-neutral-400 hover:text-white rounded-full hover:bg-neutral-800 transition-colors"
            >
              <ArrowLeft className="w-4 h-4" />
            </button>
            <div>
              <h3 className="text-sm font-bold text-white flex items-center space-x-1.5">
                <Trophy className="w-4 h-4 text-amber-400" />
                <span>Top Gifters Leaderboard</span>
              </h3>
              <p className="text-[11px] text-neutral-400">
                Top supporters and contributors in this room
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-neutral-400 hover:text-white rounded-full hover:bg-neutral-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content List */}
        <div className="my-3 overflow-y-auto flex-1 space-y-2">
          {topGifters.length === 0 ? (
            <div className="py-12 text-center text-neutral-400 flex flex-col items-center space-y-2">
              <Gift className="w-10 h-10 text-neutral-600" />
              <p className="text-sm font-medium">No gifts sent in this room yet.</p>
              <p className="text-xs text-neutral-500">
                Tap 🎁 Gifts to be the first top supporter!
              </p>
            </div>
          ) : (
            topGifters.map(g => (
              <div
                key={`tg-${g.userId}`}
                onClick={() => {
                  if (onSelectUser) onSelectUser(g.userId);
                }}
                className={`p-3 rounded-2xl border flex items-center justify-between transition-colors cursor-pointer ${
                  g.rank === 1
                    ? 'bg-gradient-to-r from-amber-950/40 via-neutral-900 to-neutral-950 border-amber-500/40 shadow-sm'
                    : 'bg-neutral-950/50 border-neutral-800/80 hover:bg-neutral-800/50'
                }`}
              >
                <div className="flex items-center space-x-3">
                  <span className="text-lg font-black w-6 text-center">
                    {getRankBadge(g.rank)}
                  </span>
                  <img
                    src={g.userAvatar}
                    alt={g.userName}
                    className="w-10 h-10 rounded-full object-cover border border-neutral-700"
                  />
                  <div>
                    <h4 className="text-xs font-bold text-white truncate max-w-[120px]">
                      {g.userName}
                    </h4>
                    <p className="text-[10px] text-neutral-400">
                      {g.giftCount} gift{g.giftCount === 1 ? '' : 's'} sent
                    </p>
                  </div>
                </div>

                <div className="text-right font-mono">
                  <span className="text-xs font-black text-amber-300">
                    🪙 {g.totalCoinsSent.toLocaleString()}
                  </span>
                  <p className="text-[9px] text-neutral-500 uppercase">Coins</p>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Footer */}
        <div className="pt-2 border-t border-neutral-800 flex-shrink-0">
          <button
            onClick={onClose}
            className="w-full py-2.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-xs font-bold text-white transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
