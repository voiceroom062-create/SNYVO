import React, { useState, useEffect } from 'react';
import {
  X,
  Sparkles,
  Check,
  AlertCircle,
  Plus,
  Coins,
  Send,
  Volume2,
  VolumeX,
  Clock,
  Award,
  Minus,
  Info,
  RefreshCw,
} from 'lucide-react';
import { GiftItem, GiftCategory, GiftTransaction, GiftLeaderboardPreparation } from '../types';
import { ALL_GIFTS, GIFT_CATEGORIES, GIFT_QUANTITY_PRESETS, POPULAR_GIFT_IDS } from '../giftData';
import { giftService } from '../giftService';
import { walletService } from '../../games/walletService';
import { giftSoundEngine } from '../soundEngine';
import { Speaker, Listener, User } from '../../types';

interface GiftBoxModalProps {
  currentUser: User;
  roomId: string;
  speakers: Speaker[];
  listeners: Listener[];
  host: User;
  initialReceiverId?: string;
  onClose: () => void;
  onGiftSent?: (tx: GiftTransaction) => void;
}

export const GiftBoxModal: React.FC<GiftBoxModalProps> = ({
  currentUser,
  roomId,
  speakers,
  listeners,
  host,
  initialReceiverId,
  onClose,
  onGiftSent,
}) => {
  // Available receivers (speakers on board + host + listeners)
  const allCandidates: { id: string; name: string; handle: string; avatar: string; role: string; roleType: 'host' | 'speaker' | 'listener' }[] = [];

  // Host
  allCandidates.push({
    id: host.id,
    name: host.name,
    handle: host.handle,
    avatar: host.avatar,
    role: '👑 Host',
    roleType: 'host',
  });

  // Speakers
  speakers.forEach(spk => {
    if (spk.id !== host.id && !allCandidates.some(c => c.id === spk.id)) {
      allCandidates.push({
        id: spk.id,
        name: spk.name,
        handle: spk.handle,
        avatar: spk.avatar,
        role: `🎤 Speaker #${(spk.seatIndex ?? 0) + 1}`,
        roleType: 'speaker',
      });
    }
  });

  // Listeners
  listeners.forEach(lis => {
    if (!allCandidates.some(c => c.id === lis.id)) {
      allCandidates.push({
        id: lis.id,
        name: lis.name,
        handle: lis.handle,
        avatar: lis.avatar,
        role: '🎧 Listener',
        roleType: 'listener',
      });
    }
  });

  // Filter candidates: prefer other users, fallback to all if sender is alone
  const selectableReceivers = allCandidates.filter(c => c.id !== currentUser.id).length > 0
    ? allCandidates.filter(c => c.id !== currentUser.id)
    : allCandidates;

  // Selected receiver state (allows unselecting to test "No receiver selected" error state)
  const defaultReceiver = selectableReceivers.find(r => r.id === initialReceiverId) || selectableReceivers[0];
  const [selectedReceiverId, setSelectedReceiverId] = useState<string | null>(defaultReceiver?.id || null);

  // Active Main View Tab
  const [activeTab, setActiveTab] = useState<'gifts' | 'activity' | 'leaderboard'>('gifts');

  // Active Category
  const [activeCategory, setActiveCategory] = useState<GiftCategory>('popular');

  // Selected Gift state (allows null to test "No gift selected" error state)
  const [selectedGift, setSelectedGift] = useState<GiftItem | null>(
    ALL_GIFTS.find(g => g.id === 'g_rose') || ALL_GIFTS[0]
  );

  // Quantity: 1, 5, 10, 20, 50, 100
  const [quantity, setQuantity] = useState<number>(1);

  // Confirmation overlay
  const [showConfirm, setShowConfirm] = useState<boolean>(false);

  // Balance and top-up
  const [userBalance, setUserBalance] = useState<number>(() => walletService.getBalance(currentUser.id));
  const [errorType, setErrorType] = useState<'none' | 'no_receiver' | 'no_gift' | 'send_failed' | 'service_unavailable'>('none');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isSending, setIsSending] = useState<boolean>(false);
  const [isMuted, setIsMuted] = useState<boolean>(giftSoundEngine.getIsMuted());

  // Room recent gift activity
  const [recentRoomActivity, setRecentRoomActivity] = useState<GiftTransaction[]>(() =>
    giftService.getTransactions(roomId).slice(0, 20)
  );

  // Leaderboard preparation data
  const [leaderboardPrep, setLeaderboardPrep] = useState<GiftLeaderboardPreparation>(() =>
    giftService.getPreparedLeaderboard(roomId)
  );

  useEffect(() => {
    const unsubWallet = walletService.subscribe(() => {
      setUserBalance(walletService.getBalance(currentUser.id));
    });

    const unsubGiftTx = giftService.subscribeTransactions(() => {
      setRecentRoomActivity(giftService.getTransactions(roomId).slice(0, 20));
      setLeaderboardPrep(giftService.getPreparedLeaderboard(roomId));
    });

    return () => {
      unsubWallet();
      unsubGiftTx();
    };
  }, [currentUser.id, roomId]);

  const selectedReceiver = selectableReceivers.find(r => r.id === selectedReceiverId) || null;

  // Filter gifts by category
  const displayedGifts = activeCategory === 'popular'
    ? ALL_GIFTS.filter(g => POPULAR_GIFT_IDS.includes(g.id))
    : ALL_GIFTS.filter(g => g.category === activeCategory);

  const totalCost = selectedGift ? selectedGift.coins * quantity : 0;

  const handleTopUp = (amount: number = 100000) => {
    walletService.topUpCoins(currentUser.id, amount);
    setErrorType('none');
    setErrorMessage(null);
  };

  const handleToggleSound = () => {
    const nextMute = giftSoundEngine.toggleMute();
    setIsMuted(nextMute);
  };

  const handleSendClick = () => {
    // 1. Validate receiver selected
    if (!selectedReceiver) {
      setErrorType('no_receiver');
      setErrorMessage('Please select a receiver from the Voice Room before sending.');
      return;
    }

    // 2. Validate gift selected
    if (!selectedGift) {
      setErrorType('no_gift');
      setErrorMessage('Please select a gift from the grid below.');
      return;
    }

    setErrorType('none');
    setErrorMessage(null);
    setShowConfirm(true);
  };

  const handleConfirmSend = () => {
    if (!selectedGift || !selectedReceiver) return;

    setIsSending(true);

    try {
      const result = giftService.sendGift({
        gift: selectedGift,
        quantity,
        sender: {
          id: currentUser.id,
          name: currentUser.name,
          handle: currentUser.handle,
          avatar: currentUser.avatar,
        },
        receiver: {
          id: selectedReceiver.id,
          name: selectedReceiver.name,
          handle: selectedReceiver.handle,
          avatar: selectedReceiver.avatar,
        },
        roomId,
      });

      setIsSending(false);

      if (result.success && result.transaction) {
        setShowConfirm(false);
        if (onGiftSent) {
          onGiftSent(result.transaction);
        }
        onClose();
      } else {
        setShowConfirm(false);
        setErrorType('send_failed');
        setErrorMessage(result.error || 'Gift sending failed. Please retry.');
      }
    } catch {
      setIsSending(false);
      setShowConfirm(false);
      setErrorType('service_unavailable');
      setErrorMessage('Gift service temporarily unavailable. Please try again.');
    }
  };

  const getTierBadge = (tier: string) => {
    switch (tier) {
      case 'mega':
        return 'bg-gradient-to-r from-amber-500 to-rose-500 text-neutral-950 font-black';
      case 'large':
        return 'bg-purple-900/70 text-purple-200 border border-purple-600/40';
      case 'medium':
        return 'bg-indigo-900/60 text-indigo-200 border border-indigo-600/40';
      default:
        return 'bg-neutral-800 text-neutral-300 border border-neutral-700/50';
    }
  };

  return (
    <div
      id="gift-box-modal"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
      className="fixed inset-0 z-50 flex items-end justify-center bg-black/60 backdrop-blur-xs animate-fade-in pointer-events-auto"
    >
      <div
        id="gift-box-sheet"
        className="w-full max-w-lg bg-neutral-950/95 border-t border-x border-neutral-800 rounded-t-3xl shadow-2xl flex flex-col max-h-[85vh] text-white overflow-hidden"
      >
        {/* Top Header: Title, Mode Badges & Controls */}
        <div className="px-4 py-3 border-b border-neutral-850 flex items-center justify-between bg-neutral-900/80 flex-shrink-0">
          <div className="flex items-center space-x-2.5">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-rose-500 via-pink-500 to-amber-500 flex items-center justify-center text-lg shadow-md shadow-rose-500/30">
              🎁
            </div>
            <div>
              <h2 className="text-sm font-black tracking-wide uppercase text-white flex items-center space-x-1.5">
                <span>SNYVO GIFT WORLD</span>
                <span className="text-[9px] px-1.5 py-0.5 rounded-md bg-rose-500/20 text-rose-300 border border-rose-500/30 font-bold">
                  LIVE
                </span>
              </h2>
              <p className="text-[10px] text-neutral-400">
                Send virtual gifts to speakers & host
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            {/* Audio Toggle */}
            <button
              onClick={handleToggleSound}
              className={`p-1.5 rounded-full border transition-colors cursor-pointer ${
                isMuted
                  ? 'bg-neutral-800 text-neutral-400 border-neutral-700'
                  : 'bg-violet-950 text-violet-300 border-violet-700'
              }`}
              title={isMuted ? 'Unmute gift sound' : 'Mute gift sound'}
            >
              {isMuted ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5" />}
            </button>

            {/* Close Button */}
            <button
              id="close-gift-panel-btn"
              onClick={onClose}
              className="p-1.5 text-neutral-400 hover:text-white rounded-full hover:bg-neutral-800 transition-colors cursor-pointer"
              aria-label="Close Gift Panel"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Navigation Tabs: Virtual Gifts | Room Activity | Leaderboard Prep */}
        <div className="px-4 py-2 border-b border-neutral-850 bg-neutral-900/50 flex items-center justify-between text-xs flex-shrink-0">
          <div className="flex items-center space-x-1">
            <button
              onClick={() => setActiveTab('gifts')}
              className={`px-3 py-1 rounded-xl font-bold text-xs transition-all cursor-pointer ${
                activeTab === 'gifts'
                  ? 'bg-gradient-to-r from-violet-600 to-rose-600 text-white shadow-sm'
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              Virtual Gifts
            </button>
            <button
              onClick={() => setActiveTab('activity')}
              className={`px-3 py-1 rounded-xl font-bold text-xs transition-all cursor-pointer flex items-center space-x-1 ${
                activeTab === 'activity'
                  ? 'bg-gradient-to-r from-violet-600 to-rose-600 text-white shadow-sm'
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              <Clock className="w-3 h-3" />
              <span>Room Activity</span>
              {recentRoomActivity.length > 0 && (
                <span className="ml-1 text-[9px] px-1.5 py-0.2 rounded-full bg-neutral-800 text-neutral-300">
                  {recentRoomActivity.length}
                </span>
              )}
            </button>
            <button
              onClick={() => setActiveTab('leaderboard')}
              className={`px-3 py-1 rounded-xl font-bold text-xs transition-all cursor-pointer flex items-center space-x-1 ${
                activeTab === 'leaderboard'
                  ? 'bg-gradient-to-r from-violet-600 to-rose-600 text-white shadow-sm'
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              <Award className="w-3 h-3" />
              <span>Rankings</span>
            </button>
          </div>

          {/* Sample Coin Indicator */}
          <div className="flex items-center space-x-1 text-[11px] font-mono font-bold text-amber-300">
            <Coins className="w-3.5 h-3.5 text-amber-400" />
            <span>{userBalance.toLocaleString()}</span>
            <button
              onClick={() => handleTopUp(100000)}
              className="ml-1 px-1.5 py-0.5 rounded-md bg-amber-500/20 text-amber-300 hover:bg-amber-500/30 border border-amber-500/30 text-[9px] cursor-pointer"
              title="Add sample demo coins"
            >
              +100K
            </button>
          </div>
        </div>

        {/* ========================================================================= */}
        {/* TAB 1: GIFTS CATALOG VIEW                                                */}
        {/* ========================================================================= */}
        {activeTab === 'gifts' && (
          <div className="flex flex-col flex-1 overflow-hidden">
            {/* 3. SELECT RECEIVER SECTION (Required) */}
            <div className="px-4 py-2.5 bg-neutral-900/40 border-b border-neutral-850 flex-shrink-0">
              <div className="flex items-center justify-between mb-1.5">
                <span className="text-[11px] font-bold text-neutral-300 uppercase tracking-wider flex items-center space-x-1.5">
                  <span>Send Gift To:</span>
                  {selectedReceiver ? (
                    <span className="text-emerald-400 font-medium normal-case flex items-center space-x-1 text-[10px]">
                      <Check className="w-3 h-3" />
                      <span>{selectedReceiver.name} selected</span>
                    </span>
                  ) : (
                    <span className="text-rose-400 font-medium normal-case text-[10px]">
                      (No receiver selected)
                    </span>
                  )}
                </span>
                {selectedReceiverId && (
                  <button
                    onClick={() => setSelectedReceiverId(null)}
                    className="text-[10px] text-neutral-400 hover:text-rose-400 transition-colors cursor-pointer"
                  >
                    Clear selection
                  </button>
                )}
              </div>

              {/* Candidates Horizontal Ribbon */}
              <div className="flex items-center space-x-2 overflow-x-auto pb-1 scrollbar-none">
                {selectableReceivers.map(rec => {
                  const isSelected = rec.id === selectedReceiverId;
                  return (
                    <button
                      key={`receiver-card-${rec.id}`}
                      id={`select-receiver-${rec.id}`}
                      onClick={() => {
                        setSelectedReceiverId(rec.id);
                        setErrorType('none');
                        setErrorMessage(null);
                      }}
                      className={`flex items-center space-x-2 px-2.5 py-1.5 rounded-2xl text-xs transition-all cursor-pointer flex-shrink-0 border relative ${
                        isSelected
                          ? 'bg-violet-950/80 border-violet-500 shadow-md shadow-violet-900/40 ring-2 ring-violet-500/60 font-bold text-white'
                          : 'bg-neutral-900/80 border-neutral-800 text-neutral-300 hover:bg-neutral-800/90 hover:border-neutral-700'
                      }`}
                    >
                      <div className="relative">
                        <img
                          src={rec.avatar}
                          alt={rec.name}
                          className="w-6 h-6 rounded-full object-cover border border-white/20"
                        />
                        {isSelected && (
                          <div className="absolute -top-1 -right-1 w-3.5 h-3.5 rounded-full bg-emerald-500 flex items-center justify-center text-white text-[8px]">
                            ✓
                          </div>
                        )}
                      </div>
                      <div className="text-left">
                        <p className="truncate max-w-[95px] text-[11px] leading-tight">{rec.name}</p>
                        <p className="text-[9px] text-violet-300/80 leading-none">{rec.role}</p>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Category Tab Bar */}
            <div className="px-3 py-1.5 flex items-center space-x-1.5 overflow-x-auto border-b border-neutral-850 bg-neutral-900/30 flex-shrink-0 scrollbar-none">
              {GIFT_CATEGORIES.map(cat => {
                const isActive = cat.id === activeCategory;
                return (
                  <button
                    key={`gift-cat-${cat.id}`}
                    onClick={() => setActiveCategory(cat.id)}
                    className={`flex items-center space-x-1 px-2.5 py-1 rounded-xl text-xs font-semibold whitespace-nowrap transition-all cursor-pointer ${
                      isActive
                        ? 'bg-gradient-to-r from-violet-600 to-rose-600 text-white shadow-xs'
                        : 'bg-neutral-850/60 text-neutral-400 hover:text-white hover:bg-neutral-800'
                    }`}
                  >
                    <span>{cat.icon}</span>
                    <span>{cat.label}</span>
                  </button>
                );
              })}
            </div>

            {/* 2. GIFT PANEL GRID */}
            <div className="p-3 overflow-y-auto flex-1 grid grid-cols-3 sm:grid-cols-4 gap-2 min-h-[210px]">
              {displayedGifts.map(gift => {
                const isSelected = selectedGift?.id === gift.id;
                return (
                  <div
                    key={`gift-card-${gift.id}`}
                    id={`gift-item-${gift.id}`}
                    onClick={() => {
                      setSelectedGift(gift);
                      setErrorType('none');
                      setErrorMessage(null);
                    }}
                    className={`relative p-2.5 rounded-2xl flex flex-col items-center justify-between text-center cursor-pointer transition-all border ${
                      isSelected
                        ? 'bg-violet-950/60 border-violet-500 shadow-lg shadow-violet-950/50 ring-2 ring-violet-500/60 scale-[1.02]'
                        : 'bg-neutral-900/60 border-neutral-850 hover:bg-neutral-850/80 hover:border-neutral-700'
                    }`}
                  >
                    {/* Top Tier Badge */}
                    <div className="w-full flex items-center justify-between mb-0.5">
                      <span className={`text-[8px] px-1.5 py-0.2 rounded-md uppercase ${getTierBadge(gift.tier)}`}>
                        {gift.tier}
                      </span>
                      {isSelected && (
                        <span className="w-3.5 h-3.5 rounded-full bg-violet-600 flex items-center justify-center text-[8px] text-white font-bold">
                          ✓
                        </span>
                      )}
                    </div>

                    {/* Gift Icon */}
                    <div className="text-3xl my-1 hover:scale-110 transition-transform">
                      {gift.icon}
                    </div>

                    {/* Gift Name */}
                    <div className="w-full">
                      <p className="text-xs font-bold text-white truncate w-full">
                        {gift.name}
                      </p>
                    </div>

                    {/* Sample Coin Value */}
                    <div className="mt-1 flex items-center space-x-1 text-[11px] font-bold text-amber-300 font-mono">
                      <span>🪙</span>
                      <span>{gift.coins.toLocaleString()}</span>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* 10. ERROR STATES BANNERS (Required) */}
            {errorType !== 'none' && errorMessage && (
              <div className="px-4 py-2 bg-rose-950/70 border-t border-rose-800/60 text-rose-300 text-xs flex items-center justify-between flex-shrink-0 animate-shake">
                <div className="flex items-center space-x-2">
                  <AlertCircle className="w-4 h-4 text-rose-400 flex-shrink-0" />
                  <span>{errorMessage}</span>
                </div>
                <button
                  onClick={() => {
                    setErrorType('none');
                    setErrorMessage(null);
                  }}
                  className="text-[10px] text-rose-300 hover:text-white underline cursor-pointer"
                >
                  Dismiss
                </button>
              </div>
            )}

            {/* 4. QUANTITY SELECTOR & SEND BUTTON */}
            <div className="p-3 bg-neutral-950 border-t border-neutral-850 flex flex-col space-y-2 flex-shrink-0">
              <div className="flex items-center justify-between text-xs">
                {/* Selected Gift Preview */}
                <div className="flex items-center space-x-2">
                  {selectedGift ? (
                    <>
                      <span className="text-2xl">{selectedGift.icon}</span>
                      <div>
                        <p className="font-bold text-white leading-tight">
                          {selectedGift.name}
                        </p>
                        <p className="text-[10px] text-amber-300 font-mono">
                          🪙 {selectedGift.coins.toLocaleString()} × {quantity} = 🪙 {totalCost.toLocaleString()}
                        </p>
                      </div>
                    </>
                  ) : (
                    <span className="text-neutral-400 italic text-[11px]">No gift selected</span>
                  )}
                </div>

                {/* 4. Quantity Presets (1, 5, 10, 20, 50, 100) */}
                <div className="flex items-center space-x-1">
                  <button
                    onClick={() => setQuantity(prev => Math.max(1, prev - 1))}
                    className="p-1 rounded-lg bg-neutral-850 hover:bg-neutral-800 text-neutral-300 cursor-pointer"
                    title="Decrease quantity"
                  >
                    <Minus className="w-3 h-3" />
                  </button>

                  {GIFT_QUANTITY_PRESETS.map(q => (
                    <button
                      key={`gift-qty-${q}`}
                      onClick={() => setQuantity(q)}
                      className={`px-1.5 py-0.5 rounded-md text-[11px] font-bold transition-colors cursor-pointer ${
                        quantity === q
                          ? 'bg-amber-400 text-neutral-950 shadow-xs'
                          : 'bg-neutral-850 text-neutral-300 hover:bg-neutral-800'
                      }`}
                    >
                      {q}
                    </button>
                  ))}

                  <button
                    onClick={() => setQuantity(prev => prev + 1)}
                    className="p-1 rounded-lg bg-neutral-850 hover:bg-neutral-800 text-neutral-300 cursor-pointer"
                    title="Increase quantity"
                  >
                    <Plus className="w-3 h-3" />
                  </button>
                </div>
              </div>

              {/* Prominent Send Gift Button */}
              <button
                id="send-gift-action-btn"
                onClick={handleSendClick}
                disabled={!selectedReceiver || !selectedGift}
                className={`w-full py-2.5 sm:py-3 rounded-2xl font-black text-xs sm:text-sm flex items-center justify-center space-x-2 transition-all shadow-lg active:scale-98 cursor-pointer ${
                  selectedReceiver && selectedGift
                    ? 'bg-gradient-to-r from-rose-600 via-pink-600 to-amber-500 hover:brightness-110 text-white shadow-rose-950/40'
                    : 'bg-neutral-850 border border-neutral-800 text-neutral-500 cursor-not-allowed'
                }`}
              >
                <Send className="w-4 h-4" />
                <span>
                  {!selectedReceiver
                    ? 'SELECT A RECEIVER TO SEND'
                    : !selectedGift
                    ? 'SELECT A GIFT TO SEND'
                    : `SEND ${quantity > 1 ? `${quantity}x ` : ''}${selectedGift.name.toUpperCase()} TO ${selectedReceiver.name.toUpperCase()} (🪙 ${totalCost.toLocaleString()})`}
                </span>
              </button>

              <div className="flex items-center justify-center space-x-1 text-[10px] text-neutral-400 text-center">
                <Info className="w-3 h-3 text-violet-400 flex-shrink-0" />
                <span>UI Demonstration: Uses sample coin balance for testing animations & room activity</span>
              </div>
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* TAB 2: 7. ROOM GIFT ACTIVITY (Required)                                   */}
        {/* ========================================================================= */}
        {activeTab === 'activity' && (
          <div className="p-4 flex-1 overflow-y-auto space-y-2.5">
            <div className="flex items-center justify-between pb-2 border-b border-neutral-850">
              <h3 className="text-xs font-bold text-neutral-300 uppercase tracking-wider flex items-center space-x-1.5">
                <Clock className="w-3.5 h-3.5 text-violet-400" />
                <span>Recent Gift Activity in this Room</span>
              </h3>
              <span className="text-[10px] text-neutral-400">
                {recentRoomActivity.length} event{recentRoomActivity.length === 1 ? '' : 's'}
              </span>
            </div>

            {recentRoomActivity.length === 0 ? (
              <div className="p-8 text-center space-y-2">
                <span className="text-4xl">🎁</span>
                <p className="text-xs font-bold text-neutral-300">No gifts sent in this room yet</p>
                <p className="text-[11px] text-neutral-400">
                  Select a gift from the catalog to be the first to send a gift!
                </p>
                <button
                  onClick={() => setActiveTab('gifts')}
                  className="px-3 py-1.5 rounded-xl bg-violet-600 text-white text-xs font-bold cursor-pointer hover:bg-violet-500 transition-colors"
                >
                  Explore Gifts Catalog
                </button>
              </div>
            ) : (
              <div className="space-y-2">
                {recentRoomActivity.map((tx) => (
                  <div
                    key={`activity-tx-${tx.id}`}
                    className="p-3 rounded-2xl bg-neutral-900/60 border border-neutral-800 flex items-center justify-between text-xs hover:bg-neutral-850/60 transition-colors"
                  >
                    <div className="flex items-center space-x-2.5">
                      <div className="text-2xl">{tx.giftIcon}</div>
                      <div>
                        <p className="font-semibold text-white">
                          <span className="text-violet-300 font-bold">{tx.senderName}</span>
                          {' sent '}
                          <span className="text-amber-300 font-bold">
                            {tx.quantity > 1 ? `${tx.quantity}x ` : ''}{tx.giftName}
                          </span>
                          {' to '}
                          <span className="text-rose-300 font-bold">{tx.receiverName}</span>
                        </p>
                        <p className="text-[10px] text-neutral-400 flex items-center space-x-2 mt-0.5">
                          <span>{tx.timestamp}</span>
                          <span>•</span>
                          <span>🪙 {tx.totalCoins.toLocaleString()} Coins</span>
                        </p>
                      </div>
                    </div>

                    <div className="text-right flex-shrink-0">
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-950/60 border border-emerald-500/40 text-emerald-300 font-bold">
                        Delivered
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* ========================================================================= */}
        {/* TAB 3: 9. GIFT LEADERBOARD PREPARATION (Required)                          */}
        {/* ========================================================================= */}
        {activeTab === 'leaderboard' && (
          <div className="p-4 flex-1 overflow-y-auto space-y-3">
            <div className="p-2.5 rounded-2xl bg-amber-950/30 border border-amber-500/30 space-y-1">
              <div className="flex items-center space-x-2 text-amber-300">
                <Award className="w-4 h-4 text-amber-400" />
                <span className="text-xs font-bold uppercase tracking-wider">
                  Leaderboard Architecture (Preview)
                </span>
              </div>
              <p className="text-[11px] text-amber-200/80 leading-relaxed">
                Data structures are fully prepared for Top Gifters, Top Gift Receivers, Daily, Weekly, and Monthly rankings.
              </p>
            </div>

            {/* Top Gifters Preparation */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-bold text-white uppercase tracking-wider">
                  🌟 Top Room Gifters
                </h4>
                <span className="text-[10px] text-neutral-400">All-Time Ranking</span>
              </div>

              {leaderboardPrep.topGifters.length === 0 ? (
                <p className="text-xs text-neutral-400 italic py-2">No leaderboard data recorded yet.</p>
              ) : (
                <div className="space-y-1.5">
                  {leaderboardPrep.topGifters.slice(0, 5).map(gifter => (
                    <div
                      key={`top-gifter-${gifter.userId}`}
                      className="p-2.5 rounded-xl bg-neutral-900/60 border border-neutral-800 flex items-center justify-between text-xs"
                    >
                      <div className="flex items-center space-x-2">
                        <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-black ${
                          gifter.rank === 1 ? 'bg-amber-400 text-neutral-950' :
                          gifter.rank === 2 ? 'bg-slate-300 text-neutral-950' :
                          gifter.rank === 3 ? 'bg-amber-700 text-white' :
                          'bg-neutral-800 text-neutral-400'
                        }`}>
                          {gifter.rank}
                        </span>
                        <img
                          src={gifter.userAvatar}
                          alt={gifter.userName}
                          className="w-6 h-6 rounded-full object-cover"
                        />
                        <span className="font-bold text-white">{gifter.userName}</span>
                      </div>
                      <span className="font-mono text-amber-300 font-bold text-[11px]">
                        🪙 {gifter.totalCoins.toLocaleString()}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Top Receivers Preparation */}
            <div className="space-y-2 pt-2 border-t border-neutral-850">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-bold text-white uppercase tracking-wider">
                  👑 Top Gift Receivers
                </h4>
                <span className="text-[10px] text-neutral-400">All-Time Ranking</span>
              </div>

              {leaderboardPrep.topGiftReceivers.length === 0 ? (
                <p className="text-xs text-neutral-400 italic py-2">No receivers recorded yet.</p>
              ) : (
                <div className="space-y-1.5">
                  {leaderboardPrep.topGiftReceivers.slice(0, 5).map(receiver => (
                    <div
                      key={`top-receiver-${receiver.userId}`}
                      className="p-2.5 rounded-xl bg-neutral-900/60 border border-neutral-800 flex items-center justify-between text-xs"
                    >
                      <div className="flex items-center space-x-2">
                        <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-black ${
                          receiver.rank === 1 ? 'bg-rose-500 text-white' :
                          receiver.rank === 2 ? 'bg-pink-600 text-white' :
                          'bg-neutral-800 text-neutral-400'
                        }`}>
                          {receiver.rank}
                        </span>
                        <img
                          src={receiver.userAvatar}
                          alt={receiver.userName}
                          className="w-6 h-6 rounded-full object-cover"
                        />
                        <span className="font-bold text-white">{receiver.userName}</span>
                      </div>
                      <span className="font-mono text-rose-300 font-bold text-[11px]">
                        🪙 {receiver.totalCoins.toLocaleString()}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {/* Confirmation Modal */}
        {showConfirm && selectedGift && selectedReceiver && (
          <div className="absolute inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4 animate-fade-in">
            <div className="w-full max-w-sm bg-neutral-900 border border-neutral-800 rounded-3xl p-5 text-center shadow-2xl space-y-4">
              <div className="w-16 h-16 mx-auto rounded-3xl bg-gradient-to-tr from-rose-500 to-amber-500 flex items-center justify-center text-4xl shadow-lg shadow-rose-500/30">
                {selectedGift.icon}
              </div>

              <div>
                <h3 className="text-base font-extrabold text-white">
                  Send {quantity > 1 ? `${quantity}x ` : ''}{selectedGift.name}?
                </h3>
                <p className="text-xs text-neutral-300 mt-1">
                  Recipient: <span className="font-bold text-violet-300">{selectedReceiver.name}</span> ({selectedReceiver.role})
                </p>
              </div>

              <div className="p-3 bg-neutral-950 border border-neutral-800 rounded-2xl space-y-1.5 text-xs">
                <div className="flex items-center justify-between">
                  <span className="text-neutral-400">Total Gift Value:</span>
                  <span className="font-extrabold text-amber-300 font-mono text-sm">
                    🪙 {totalCost.toLocaleString()} Coins
                  </span>
                </div>
                <div className="flex items-center justify-between pt-1.5 border-t border-neutral-900 text-[11px]">
                  <span className="text-emerald-400 font-medium">Receiver Benefit (30%):</span>
                  <span className="font-bold text-emerald-300 font-mono">
                    +🪙 {Math.floor((totalCost * 30) / 100).toLocaleString()} Coins
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2 pt-1">
                <button
                  onClick={() => setShowConfirm(false)}
                  className="py-2.5 rounded-xl border border-neutral-700 text-neutral-300 hover:bg-neutral-800 text-xs font-bold transition-colors cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  onClick={handleConfirmSend}
                  disabled={isSending}
                  className="py-2.5 rounded-xl bg-gradient-to-r from-rose-600 via-pink-600 to-amber-500 hover:brightness-110 text-white font-black text-xs transition-all shadow-md cursor-pointer flex items-center justify-center space-x-1"
                >
                  {isSending ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      <span>Sending...</span>
                    </>
                  ) : (
                    <span>CONFIRM & SEND</span>
                  )}
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
