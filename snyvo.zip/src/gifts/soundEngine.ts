// Web Audio API Synthesizer for SNYVO Gift Animations
// Provides authentic, high-quality, synchronized sound effects without external audio file dependencies.

class GiftSoundEngine {
  private audioCtx: AudioContext | null = null;
  private isMuted: boolean = false;

  constructor() {
    const savedMute = localStorage.getItem('snyvo_gift_sound_muted');
    if (savedMute !== null) {
      this.isMuted = savedMute === 'true';
    }
  }

  private initContext() {
    if (!this.audioCtx) {
      const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioContextClass) {
        this.audioCtx = new AudioContextClass();
      }
    }
    if (this.audioCtx && this.audioCtx.state === 'suspended') {
      this.audioCtx.resume();
    }
  }

  public toggleMute(): boolean {
    this.isMuted = !this.isMuted;
    localStorage.setItem('snyvo_gift_sound_muted', String(this.isMuted));
    return this.isMuted;
  }

  public getIsMuted(): boolean {
    return this.isMuted;
  }

  public playGiftSound(tier: 'small' | 'medium' | 'large' | 'mega', megaType?: string) {
    if (this.isMuted) return;

    try {
      this.initContext();
      if (!this.audioCtx) return;

      if (tier === 'mega') {
        switch (megaType) {
          case 'couple':
            this.playRomanticCoupleSound();
            break;
          case 'car':
            this.playLuxuryCarSound();
            break;
          case 'helicopter':
            this.playHelicopterSound();
            break;
          case 'jet':
            this.playPrivateJetSound();
            break;
          case 'world':
            this.playSnyvoWorldSound();
            break;
          default:
            this.playMegaCelebrationSound();
        }
      } else if (tier === 'large') {
        this.playLargeFanfareSound();
      } else if (tier === 'medium') {
        this.playMediumChimeSound();
      } else {
        this.playSmallPopSound();
      }
    } catch (e) {
      // Audio errors fail silently to not interrupt user experience
    }
  }

  // --- 🟢 Small Gift: Soft Pop & Bell Sparkle ---
  private playSmallPopSound() {
    if (!this.audioCtx) return;
    const now = this.audioCtx.currentTime;

    const osc = this.audioCtx.createOscillator();
    const gain = this.audioCtx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(523.25, now); // C5
    osc.frequency.exponentialRampToValueAtTime(1046.5, now + 0.15); // C6

    gain.gain.setValueAtTime(0.2, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.35);

    osc.connect(gain);
    gain.connect(this.audioCtx.destination);

    osc.start(now);
    osc.stop(now + 0.36);
  }

  // --- 🔵 Medium Gift: Harmonious Shimmer Chimes ---
  private playMediumChimeSound() {
    if (!this.audioCtx) return;
    const now = this.audioCtx.currentTime;

    const notes = [523.25, 659.25, 783.99, 1046.5]; // C5 - E5 - G5 - C6
    notes.forEach((freq, idx) => {
      if (!this.audioCtx) return;
      const osc = this.audioCtx.createOscillator();
      const gain = this.audioCtx.createGain();

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, now + idx * 0.09);

      gain.gain.setValueAtTime(0, now + idx * 0.09);
      gain.gain.linearRampToValueAtTime(0.25, now + idx * 0.09 + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.09 + 0.5);

      osc.connect(gain);
      gain.connect(this.audioCtx.destination);

      osc.start(now + idx * 0.09);
      osc.stop(now + idx * 0.09 + 0.52);
    });
  }

  // --- 🟣 Large Gift: Grand Triumphant Fanfare ---
  private playLargeFanfareSound() {
    if (!this.audioCtx) return;
    const now = this.audioCtx.currentTime;

    const chords = [
      { notes: [440, 554.37, 659.25], time: 0 },       // A major
      { notes: [554.37, 659.25, 880], time: 0.2 },      // High A
      { notes: [659.25, 830.61, 987.77, 1318.5], time: 0.45 }, // E major fanfare climax
    ];

    chords.forEach(chord => {
      chord.notes.forEach(freq => {
        if (!this.audioCtx) return;
        const osc = this.audioCtx.createOscillator();
        const gain = this.audioCtx.createGain();

        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(freq, now + chord.time);

        gain.gain.setValueAtTime(0, now + chord.time);
        gain.gain.linearRampToValueAtTime(0.12, now + chord.time + 0.03);
        gain.gain.exponentialRampToValueAtTime(0.001, now + chord.time + 0.7);

        osc.connect(gain);
        gain.connect(this.audioCtx.destination);

        osc.start(now + chord.time);
        osc.stop(now + chord.time + 0.75);
      });
    });
  }

  // --- 💑 Mega Couple (100,000 Coins): Romantic Synth Harp Harmony ---
  private playRomanticCoupleSound() {
    if (!this.audioCtx) return;
    const now = this.audioCtx.currentTime;

    // Romantic lush chord progression: Fmaj7 -> G -> Cmaj9
    const arpeggio = [
      { f: 349.23, t: 0 },    // F4
      { f: 440.0, t: 0.12 },  // A4
      { f: 523.25, t: 0.24 }, // C5
      { f: 659.25, t: 0.36 }, // E5 (maj7)
      { f: 392.0, t: 0.55 },  // G4
      { f: 493.88, t: 0.68 }, // B4
      { f: 587.33, t: 0.8 },  // D5
      { f: 523.25, t: 1.0 },  // C5
      { f: 659.25, t: 1.15 }, // E5
      { f: 783.99, t: 1.3 },  // G5
      { f: 987.77, t: 1.45 }, // B5
      { f: 1046.5, t: 1.6 },  // C6
    ];

    arpeggio.forEach(n => {
      if (!this.audioCtx) return;
      const osc = this.audioCtx.createOscillator();
      const gain = this.audioCtx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(n.f, now + n.t);

      gain.gain.setValueAtTime(0, now + n.t);
      gain.gain.linearRampToValueAtTime(0.2, now + n.t + 0.04);
      gain.gain.exponentialRampToValueAtTime(0.001, now + n.t + 0.9);

      osc.connect(gain);
      gain.connect(this.audioCtx.destination);

      osc.start(now + n.t);
      osc.stop(now + n.t + 0.95);
    });
  }

  // --- 🚗 Mega Luxury Car (300,000 Coins): Engine Rev + Acceleration + Horn ---
  private playLuxuryCarSound() {
    if (!this.audioCtx) return;
    const now = this.audioCtx.currentTime;

    // Engine rumble ramp
    const engineOsc = this.audioCtx.createOscillator();
    const engineGain = this.audioCtx.createGain();

    engineOsc.type = 'sawtooth';
    engineOsc.frequency.setValueAtTime(65, now);
    engineOsc.frequency.exponentialRampToValueAtTime(280, now + 0.8);
    engineOsc.frequency.exponentialRampToValueAtTime(140, now + 1.6);

    engineGain.gain.setValueAtTime(0.05, now);
    engineGain.gain.linearRampToValueAtTime(0.25, now + 0.6);
    engineGain.gain.exponentialRampToValueAtTime(0.001, now + 1.8);

    engineOsc.connect(engineGain);
    engineGain.connect(this.audioCtx.destination);

    engineOsc.start(now);
    engineOsc.stop(now + 1.85);

    // Luxury dual-tone horn fanfare
    [587.33, 739.99].forEach(freq => {
      if (!this.audioCtx) return;
      const horn = this.audioCtx.createOscillator();
      const hornGain = this.audioCtx.createGain();

      horn.type = 'triangle';
      horn.frequency.setValueAtTime(freq, now + 1.1);

      hornGain.gain.setValueAtTime(0, now + 1.1);
      hornGain.gain.linearRampToValueAtTime(0.18, now + 1.15);
      hornGain.gain.exponentialRampToValueAtTime(0.001, now + 1.9);

      horn.connect(hornGain);
      hornGain.connect(this.audioCtx.destination);

      horn.start(now + 1.1);
      horn.stop(now + 1.95);
    });
  }

  // --- 🚁 Mega Helicopter (400,000 Coins): Rotor Blades Chopping Sound + Aviation Flare ---
  private playHelicopterSound() {
    if (!this.audioCtx) return;
    const now = this.audioCtx.currentTime;

    // Rhythmic blade chops using modulated pulse
    const chops = 14;
    for (let i = 0; i < chops; i++) {
      const t = now + i * 0.12;
      const osc = this.audioCtx.createOscillator();
      const gain = this.audioCtx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(70 + (i % 2 === 0 ? 15 : 0), t);

      gain.gain.setValueAtTime(0.02, t);
      gain.gain.linearRampToValueAtTime(0.3, t + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.005, t + 0.11);

      osc.connect(gain);
      gain.connect(this.audioCtx.destination);

      osc.start(t);
      osc.stop(t + 0.12);
    }

    // High beacon chime
    const beacon = this.audioCtx.createOscillator();
    const beaconGain = this.audioCtx.createGain();
    beacon.type = 'sine';
    beacon.frequency.setValueAtTime(1174.66, now + 0.8); // D6
    beaconGain.gain.setValueAtTime(0, now + 0.8);
    beaconGain.gain.linearRampToValueAtTime(0.15, now + 0.85);
    beaconGain.gain.exponentialRampToValueAtTime(0.001, now + 1.7);
    beacon.connect(beaconGain);
    beaconGain.connect(this.audioCtx.destination);
    beacon.start(now + 0.8);
    beacon.stop(now + 1.75);
  }

  // --- ✈️ Mega Private Jet (500,000 Coins): Jet Turbine Swoosh + Supersonic Flyby + Grand Finale ---
  private playPrivateJetSound() {
    if (!this.audioCtx) return;
    const now = this.audioCtx.currentTime;

    // Jet turbine whine frequency sweep
    const jetOsc = this.audioCtx.createOscillator();
    const jetGain = this.audioCtx.createGain();

    jetOsc.type = 'sawtooth';
    jetOsc.frequency.setValueAtTime(150, now);
    jetOsc.frequency.exponentialRampToValueAtTime(1200, now + 1.2);
    jetOsc.frequency.exponentialRampToValueAtTime(450, now + 2.3);

    jetGain.gain.setValueAtTime(0.02, now);
    jetGain.gain.linearRampToValueAtTime(0.28, now + 1.1);
    jetGain.gain.exponentialRampToValueAtTime(0.001, now + 2.5);

    jetOsc.connect(jetGain);
    jetGain.connect(this.audioCtx.destination);

    jetOsc.start(now);
    jetOsc.stop(now + 2.55);

    // Regal celebration chime sequence
    [523.25, 659.25, 783.99, 1046.5, 1318.51, 1567.98].forEach((freq, idx) => {
      if (!this.audioCtx) return;
      const osc = this.audioCtx.createOscillator();
      const gain = this.audioCtx.createGain();

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, now + 0.9 + idx * 0.12);

      gain.gain.setValueAtTime(0, now + 0.9 + idx * 0.12);
      gain.gain.linearRampToValueAtTime(0.22, now + 0.9 + idx * 0.12 + 0.03);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.9 + idx * 0.12 + 0.8);

      osc.connect(gain);
      gain.connect(this.audioCtx.destination);

      osc.start(now + 0.9 + idx * 0.12);
      osc.stop(now + 0.9 + idx * 0.12 + 0.85);
    });
  }

  // --- 🌍 Mega SNYVO World / Universe (500,000 Coins): Cosmic Celestial Chords ---
  private playSnyvoWorldSound() {
    if (!this.audioCtx) return;
    const now = this.audioCtx.currentTime;

    // Celestial space choir shimmering chord (Cmaj9 + 11)
    const chord = [261.63, 392.0, 523.25, 659.25, 783.99, 987.77, 1174.66, 1318.51];
    chord.forEach((freq, idx) => {
      if (!this.audioCtx) return;
      const osc = this.audioCtx.createOscillator();
      const gain = this.audioCtx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, now + idx * 0.06);

      gain.gain.setValueAtTime(0, now + idx * 0.06);
      gain.gain.linearRampToValueAtTime(0.18, now + idx * 0.06 + 0.2);
      gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.06 + 2.2);

      osc.connect(gain);
      gain.connect(this.audioCtx.destination);

      osc.start(now + idx * 0.06);
      osc.stop(now + idx * 0.06 + 2.3);
    });
  }

  // --- Generic Mega Celebration Sound ---
  private playMegaCelebrationSound() {
    if (!this.audioCtx) return;
    this.playLargeFanfareSound();
    setTimeout(() => {
      this.playMediumChimeSound();
    }, 400);
  }
}

export const giftSoundEngine = new GiftSoundEngine();
