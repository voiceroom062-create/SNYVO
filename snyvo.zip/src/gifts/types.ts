export type GiftTier = 'small' | 'medium' | 'large' | 'mega';

export type GiftCategory =
  | 'popular'
  | 'countries'
  | 'landmarks'
  | 'couple'
  | 'love'
  | 'food'
  | 'vehicles'
  | 'luxury'
  | 'gaming'
  | 'special';

export interface GiftItem {
  id: string;
  name: string;
  bengaliName?: string;
  icon: string;
  category: GiftCategory;
  coins: number;
  tier: GiftTier;
  level: number;
  description?: string;
  megaType?: 'couple' | 'car' | 'helicopter' | 'jet' | 'world' | 'generic';
}

export interface GiftTransaction {
  id: string;
  giftId: string;
  giftName: string;
  giftIcon: string;
  category: GiftCategory;
  tier: GiftTier;
  coinPrice: number;
  quantity: number;
  totalCoins: number; // 100% full gift value
  receiverCoins: number; // 30% receiver share credited to ID balance
  receiverSharePercent: number; // 30
  status: 'Completed';
  senderId: string;
  senderName: string;
  senderAvatar: string;
  senderNumericId: string;
  receiverId: string;
  receiverName: string;
  receiverAvatar: string;
  receiverNumericId: string;
  timestamp: string;
  isoDate: string;
  animationId: string;
  roomId: string;
}

export interface GiftAnimationEvent {
  id: string;
  gift: GiftItem;
  quantity: number;
  totalCoins: number;
  sender: {
    id: string;
    name: string;
    avatar: string;
  };
  receiver: {
    id: string;
    name: string;
    avatar: string;
  };
  timestamp: number;
  durationMs: number;
}

export interface TopGifter {
  userId: string;
  userName: string;
  userAvatar: string;
  totalCoinsSent: number;
  giftCount: number;
  rank: number;
}

/**
 * Requirement 8: Gift History Data Structures
 * Prepared for Sent and Received gifts tracking
 */
export interface SentGiftRecord {
  id: string;
  giftId: string;
  giftName: string;
  giftIcon: string;
  senderId: string;
  senderName: string;
  senderAvatar: string;
  receiverId: string;
  receiverName: string;
  receiverAvatar: string;
  quantity: number;
  coinValue: number;
  totalCoins: number;
  timestamp: string;
  timestampMs: number;
  roomId: string;
}

export interface ReceivedGiftRecord {
  id: string;
  giftId: string;
  giftName: string;
  giftIcon: string;
  senderId: string;
  senderName: string;
  senderAvatar: string;
  receiverId: string;
  receiverName: string;
  receiverAvatar: string;
  quantity: number;
  coinValue: number;
  totalCoins: number;
  receiverCoins: number;
  timestamp: string;
  timestampMs: number;
  roomId: string;
}

/**
 * Requirement 9: Gift Leaderboard Preparation Data Structures
 * Prepared for future: Top Gifters, Top Receivers, Daily, Weekly, and Monthly rankings
 */
export type RankingPeriod = 'daily' | 'weekly' | 'monthly' | 'allTime';

export interface GiftLeaderboardEntry {
  rank: number;
  userId: string;
  userName: string;
  userAvatar: string;
  userHandle?: string;
  userRole?: string;
  totalCoins: number;
  giftCount: number;
  recentGifts?: { icon: string; count: number }[];
  lastActiveTimestamp: number;
}

export interface GiftLeaderboardPreparation {
  roomId?: string;
  period: RankingPeriod;
  topGifters: GiftLeaderboardEntry[];
  topGiftReceivers: GiftLeaderboardEntry[];
  dailyRanking: GiftLeaderboardEntry[];
  weeklyRanking: GiftLeaderboardEntry[];
  monthlyRanking: GiftLeaderboardEntry[];
  lastCalculatedAt: string;
}

