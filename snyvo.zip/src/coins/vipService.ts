import { VipTier, EntryEffectType, BoardEntryEvent } from './types';
import { User } from '../types';

const STORAGE_KEY_USER_VIP = 'snyvo_user_vip_tiers_v1';

export interface VipTierInfo {
  tier: VipTier;
  title: string;
  badgeLabel: string;
  crown: string;
  badgeBg: string;
  badgeBorder: string;
  badgeText: string;
  avatarRing: string;
  entryTitle: string;
  entryType: EntryEffectType;
  benefits: string[];
}

export const VIP_TIER_CONFIGS: Record<VipTier, VipTierInfo> = {
  REGULAR: {
    tier: 'REGULAR',
    title: 'Regular Member',
    badgeLabel: 'MEMBER',
    crown: '',
    badgeBg: 'bg-neutral-800',
    badgeBorder: 'border-neutral-700',
    badgeText: 'text-neutral-300',
    avatarRing: 'ring-neutral-700',
    entryTitle: 'Standard Entry',
    entryType: 'regular',
    benefits: ['Voice Chat & Stage Listening', 'Interactive Room Chat', 'Send & Receive Gifts'],
  },
  VIP: {
    tier: 'VIP',
    title: 'VIP Member',
    badgeLabel: '👑 VIP',
    crown: '👑',
    badgeBg: 'bg-gradient-to-r from-amber-600 to-yellow-500',
    badgeBorder: 'border-amber-400',
    badgeText: 'text-neutral-950 font-black',
    avatarRing: 'ring-2 ring-amber-400 shadow-amber-500/50 shadow-md',
    entryTitle: 'VIP Golden Flare',
    entryType: 'vip',
    benefits: [
      '👑 Golden VIP Crown on Stage & Profile',
      '✨ VIP Profile Badge',
      '🚪 Board Entry Announcement with Golden Light',
      '💬 Highlighted Voice Room Messages',
    ],
  },
  VIP_PRO: {
    tier: 'VIP_PRO',
    title: 'Royal VIP Member',
    badgeLabel: '🌟 VIP PRO',
    crown: '👑',
    badgeBg: 'bg-gradient-to-r from-purple-600 via-violet-500 to-pink-500',
    badgeBorder: 'border-purple-400',
    badgeText: 'text-white font-black',
    avatarRing: 'ring-2 ring-purple-400 shadow-purple-500/50 shadow-lg',
    entryTitle: 'Cosmic Starlight Stream',
    entryType: 'vip_pro',
    benefits: [
      '👑 Royal Purple & Gold Crown',
      '🌟 Royal VIP PRO Badge',
      '🚪 Starlight Trail Board Entry Effect',
      '🎬 Animated Stage Presence & Glowing Ring',
      '💎 Priority Stage Seat Request',
    ],
  },
  SVIP: {
    tier: 'SVIP',
    title: 'Supreme 💎 SVIP',
    badgeLabel: '💎 SVIP',
    crown: '💎👑',
    badgeBg: 'bg-gradient-to-r from-cyan-400 via-blue-500 to-fuchsia-500 animate-pulse',
    badgeBorder: 'border-cyan-300',
    badgeText: 'text-white font-black drop-shadow-md',
    avatarRing: 'ring-3 ring-cyan-300 ring-offset-2 ring-offset-neutral-950 shadow-cyan-500/60 shadow-xl',
    entryTitle: 'Supreme Galactic Dragon & Diamond Portal',
    entryType: 'svip',
    benefits: [
      '💎 Exclusive Iridescent SVIP Badge',
      '👑 Supreme Diamond SVIP Crown',
      '🚪 Supreme Galactic Dragon & Diamond Portal Entry Effect',
      '🎬 Full-Screen Cosmic Starlight Entry Animation',
      '✨ Diamond Glowing Ring on Board Seats & Profile',
      '🚀 VIP Chat Shimmer & Royal Soundwave Theme',
    ],
  },
};

class VipService {
  private userVipTiers: Record<string, VipTier> = {
    'usr_me': 'REGULAR',
    'usr_guest': 'REGULAR',
    'usr_1': 'VIP', // Maya Lin has VIP
    'usr_5': 'SVIP', // Dr. Sarah Thorne has SVIP for testing
    'usr_8': 'VIP_PRO', // Oliver King
  };
  private subscribers: (() => void)[] = [];
  private entrySubscribers: ((event: BoardEntryEvent) => void)[] = [];

  constructor() {
    this.load();
  }

  private load() {
    const saved = localStorage.getItem(STORAGE_KEY_USER_VIP);
    if (saved) {
      try {
        this.userVipTiers = { ...this.userVipTiers, ...JSON.parse(saved) };
      } catch {
        // ignore
      }
    }
  }

  private save() {
    try {
      localStorage.setItem(STORAGE_KEY_USER_VIP, JSON.stringify(this.userVipTiers));
    } catch {
      // ignore
    }
  }

  public subscribe(cb: () => void): () => void {
    this.subscribers.push(cb);
    return () => {
      this.subscribers = this.subscribers.filter(s => s !== cb);
    };
  }

  public subscribeEntry(cb: (event: BoardEntryEvent) => void): () => void {
    this.entrySubscribers.push(cb);
    return () => {
      this.entrySubscribers = this.entrySubscribers.filter(s => s !== cb);
    };
  }

  private notify() {
    this.subscribers.forEach(cb => cb());
  }

  public getUserVipTier(userId: string): VipTier {
    const key = userId === 'usr_guest' ? 'usr_me' : userId;
    return this.userVipTiers[key] || 'REGULAR';
  }

  public setUserVipTier(userId: string, tier: VipTier) {
    const key = userId === 'usr_guest' ? 'usr_me' : userId;
    const currentTier = this.userVipTiers[key] || 'REGULAR';

    // If upgrading to SVIP or higher tier, enforce tier hierarchy
    this.userVipTiers[key] = tier;
    if (key === 'usr_me') {
      this.userVipTiers['usr_guest'] = tier;
    }
    this.save();
    this.notify();
  }

  public getTierInfo(tier: VipTier): VipTierInfo {
    return VIP_TIER_CONFIGS[tier] || VIP_TIER_CONFIGS.REGULAR;
  }

  public getUserTierInfo(userId: string): VipTierInfo {
    const tier = this.getUserVipTier(userId);
    return this.getTierInfo(tier);
  }

  public triggerBoardEntry(roomId: string, user: User) {
    const vipTier = this.getUserVipTier(user.id);
    const tierInfo = this.getTierInfo(vipTier);

    const event: BoardEntryEvent = {
      id: `entry_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      roomId,
      user: {
        id: user.id,
        numericId: user.numericId || '84920194',
        name: user.name,
        handle: user.handle,
        avatar: user.avatar,
        vipTier,
      },
      entryEffectType: tierInfo.entryType,
      entryEffectTitle: tierInfo.entryTitle,
      timestamp: Date.now(),
    };

    this.entrySubscribers.forEach(cb => cb(event));
  }
}

export const vipService = new VipService();
