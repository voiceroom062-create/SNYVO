export type VipTier = 'REGULAR' | 'VIP' | 'VIP_PRO' | 'SVIP';

export type EntryEffectType = 'regular' | 'vip' | 'vip_pro' | 'svip';

export interface CoinPackage {
  id: string;
  name: string;
  coins: number;
  priceBdt: number; // Price in Bangladeshi Taka (৳)
  vipTier: VipTier;
  badge?: string; // e.g. 'Starter', 'Popular', 'Best Value', 'Supreme SVIP'
  description: string;
  vipCrown: string; // Emoji or crown type, e.g. '👑', '💎👑'
  entryEffectTitle: string;
  entryEffectType: EntryEffectType;
  active: boolean;
  isSvipPackage?: boolean;
}

export type PaymentMethod = 'bKash' | 'Nagad';

export type PaymentType = 'Personal' | 'Merchant';

export interface AdminPaymentConfig {
  bkashNumber: string;
  bkashType: PaymentType;
  nagadNumber: string;
  nagadType: PaymentType;
  whatsappNumber: string;
  telegramContact: string;
  adminNotice: string;
  paymentInstructions: string;
  supportHours: string;
}

export type OrderStatus = 'PENDING' | 'APPROVED' | 'REJECTED';

export interface PurchaseOrder {
  id: string;
  userId: string;
  userNumericId: string;
  userName: string;
  userHandle: string;
  userAvatar: string;
  packageId: string;
  packageName: string;
  coins: number;
  amountBdt: number;
  vipTierReward: VipTier;
  paymentMethod: PaymentMethod;
  senderPhone: string;
  transactionId: string; // TrxID from bKash or Nagad
  status: OrderStatus;
  createdAt: string; // ISO string
  displayTime: string;
  reviewedAt?: string;
  reviewedBy?: string;
  adminNote?: string;
}

export interface BoardEntryEvent {
  id: string;
  roomId: string;
  user: {
    id: string;
    numericId: string;
    name: string;
    handle: string;
    avatar: string;
    vipTier: VipTier;
  };
  entryEffectType: EntryEffectType;
  entryEffectTitle: string;
  timestamp: number;
}
