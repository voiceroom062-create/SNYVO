import { CoinPackage, AdminPaymentConfig } from './types';

const STORAGE_KEY_PACKAGES = 'snyvo_coin_packages_v1';
const STORAGE_KEY_ADMIN_PAYMENT = 'snyvo_admin_payment_config_v1';

// Seeded default packages with the requested 2,000,000 Coins -> ৳120 and ৳1,000 SVIP tier
export const DEFAULT_PACKAGES: CoinPackage[] = [
  {
    id: 'pkg_starter',
    name: 'Starter Coin Pack',
    coins: 2000000, // 2,000,000 Coins
    priceBdt: 120, // ৳120 as specifically requested in prompt
    vipTier: 'VIP',
    badge: 'Popular',
    description: 'Entry-level massive coins pack with VIP membership perks',
    vipCrown: '👑',
    entryEffectTitle: 'VIP Golden Flare',
    entryEffectType: 'vip',
    active: true,
  },
  {
    id: 'pkg_popular',
    name: 'Elite VIP Pack',
    coins: 5500000, // 5,500,000 Coins
    priceBdt: 300,
    vipTier: 'VIP_PRO',
    badge: 'Best Value',
    description: 'Higher VIP tier with golden starlight board entry effect',
    vipCrown: '👑',
    entryEffectTitle: 'Cosmic Starlight Stream',
    entryEffectType: 'vip_pro',
    active: true,
  },
  {
    id: 'pkg_champion',
    name: 'Royal VIP Pack',
    coins: 10000000, // 10,000,000 Coins
    priceBdt: 500,
    vipTier: 'VIP_PRO',
    badge: 'Mega Value',
    description: 'Double VIP power with royal aura and advanced entry effects',
    vipCrown: '👑',
    entryEffectTitle: 'Royal Phoenix Starlight',
    entryEffectType: 'vip_pro',
    active: true,
  },
  {
    id: 'pkg_svip_1000',
    name: 'Supreme 💎 SVIP Pack',
    coins: 22000000, // 22,000,000 Coins
    priceBdt: 1000, // ৳1,000 specific SVIP requirement in prompt
    vipTier: 'SVIP',
    badge: '💎 SVIP Exclusive',
    description: 'Unlock supreme SVIP status, SVIP Diamond Badge, Crown, and Galactic Portal Entry',
    vipCrown: '💎👑',
    entryEffectTitle: 'Galactic Dragon & Diamond Portal',
    entryEffectType: 'svip',
    active: true,
    isSvipPackage: true,
  },
];

export const DEFAULT_ADMIN_CONFIG: AdminPaymentConfig = {
  bkashNumber: '01712-345678',
  bkashType: 'Personal',
  nagadNumber: '01812-345678',
  nagadType: 'Personal',
  whatsappNumber: '+880 1712-345678',
  telegramContact: '@snyvo_admin',
  adminNotice: 'Coins কিনতে App Owner/Admin-এর সঙ্গে যোগাযোগ করুন।',
  paymentInstructions:
    '১. নিচে দেওয়া bKash বা Nagad নম্বরে Send Money করুন।\n২. পেমেন্ট সম্পন্ন হলে আপনার Sender Phone নম্বর এবং প্রাপ্ত Transaction ID (TrxID) নিচে সাবমিট করুন।\n৩. অ্যাডমিন পেমেন্ট ভেরিফাই করার পর আপনার একাউন্টে কয়েন ও VIP/SVIP রিওয়ার্ড জমা হয়ে যাবে।',
  supportHours: '24/7 Live Support',
};

class CoinConfigService {
  private packages: CoinPackage[] = [];
  private adminConfig: AdminPaymentConfig = { ...DEFAULT_ADMIN_CONFIG };
  private subscribers: (() => void)[] = [];

  constructor() {
    this.load();
  }

  private load() {
    // Packages
    const savedPackages = localStorage.getItem(STORAGE_KEY_PACKAGES);
    if (savedPackages) {
      try {
        this.packages = JSON.parse(savedPackages);
        // Ensure ৳120 and ৳1,000 packages exist
        if (!this.packages.some(p => p.priceBdt === 120)) {
          this.packages.unshift(DEFAULT_PACKAGES[0]);
          this.savePackages();
        }
        if (!this.packages.some(p => p.priceBdt === 1000 && p.vipTier === 'SVIP')) {
          this.packages.push(DEFAULT_PACKAGES[3]);
          this.savePackages();
        }
      } catch {
        this.packages = [...DEFAULT_PACKAGES];
      }
    } else {
      this.packages = [...DEFAULT_PACKAGES];
      this.savePackages();
    }

    // Admin Payment Config
    const savedConfig = localStorage.getItem(STORAGE_KEY_ADMIN_PAYMENT);
    if (savedConfig) {
      try {
        this.adminConfig = { ...DEFAULT_ADMIN_CONFIG, ...JSON.parse(savedConfig) };
      } catch {
        this.adminConfig = { ...DEFAULT_ADMIN_CONFIG };
      }
    } else {
      this.adminConfig = { ...DEFAULT_ADMIN_CONFIG };
      this.saveConfig();
    }
  }

  private savePackages() {
    try {
      localStorage.setItem(STORAGE_KEY_PACKAGES, JSON.stringify(this.packages));
    } catch {
      // ignore
    }
  }

  private saveConfig() {
    try {
      localStorage.setItem(STORAGE_KEY_ADMIN_PAYMENT, JSON.stringify(this.adminConfig));
    } catch {
      // ignore
    }
  }

  public subscribe(cb: () => void): () => void {
    this.subscribers.push(cb);
    return () => {
      this.subscribers = this.subscribers.filter(s => s !== cb);
    };
  }

  private notify() {
    this.subscribers.forEach(cb => cb());
  }

  // Packages API
  public getPackages(includeInactive = false): CoinPackage[] {
    if (includeInactive) return [...this.packages];
    return this.packages.filter(p => p.active);
  }

  public getPackageById(id: string): CoinPackage | undefined {
    return this.packages.find(p => p.id === id);
  }

  public addPackage(pkg: Omit<CoinPackage, 'id'>): CoinPackage {
    const newPkg: CoinPackage = {
      ...pkg,
      id: `pkg_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
    };
    this.packages.push(newPkg);
    this.savePackages();
    this.notify();
    return newPkg;
  }

  public updatePackage(id: string, updates: Partial<CoinPackage>): boolean {
    const idx = this.packages.findIndex(p => p.id === id);
    if (idx === -1) return false;
    this.packages[idx] = { ...this.packages[idx], ...updates };
    this.savePackages();
    this.notify();
    return true;
  }

  public deletePackage(id: string): boolean {
    const initialLen = this.packages.length;
    this.packages = this.packages.filter(p => p.id !== id);
    if (this.packages.length !== initialLen) {
      this.savePackages();
      this.notify();
      return true;
    }
    return false;
  }

  public resetPackagesToDefault() {
    this.packages = [...DEFAULT_PACKAGES];
    this.savePackages();
    this.notify();
  }

  // Admin Config API
  public getAdminConfig(): AdminPaymentConfig {
    return { ...this.adminConfig };
  }

  public updateAdminConfig(updates: Partial<AdminPaymentConfig>) {
    this.adminConfig = { ...this.adminConfig, ...updates };
    this.saveConfig();
    this.notify();
  }
}

export const coinConfigService = new CoinConfigService();
