import { PurchaseOrder, PaymentMethod, VipTier } from './types';
import { walletService } from '../games/walletService';
import { vipService } from './vipService';
import { coinConfigService } from './coinConfigService';
import { User } from '../types';
import { getNumericUserId } from '../services/userService';

const STORAGE_KEY_ORDERS = 'snyvo_coin_purchase_orders_v1';

// Seed initial realistic orders for demo and immediate testing in Admin Panel
const INITIAL_ORDERS: PurchaseOrder[] = [
  {
    id: 'ord_demo_pending_1',
    userId: 'usr_me',
    userNumericId: '84920194',
    userName: 'Alex Vance',
    userHandle: '@alexvance',
    userAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop&q=80',
    packageId: 'pkg_svip_1000',
    packageName: 'Supreme 💎 SVIP Pack',
    coins: 22000000,
    amountBdt: 1000,
    vipTierReward: 'SVIP',
    paymentMethod: 'bKash',
    senderPhone: '01712-998877',
    transactionId: 'BK9A82X019',
    status: 'PENDING',
    createdAt: new Date(Date.now() - 15 * 60 * 1000).toISOString(),
    displayTime: '15 mins ago',
  },
  {
    id: 'ord_demo_pending_2',
    userId: 'usr_2',
    userNumericId: '39482019',
    userName: 'Kofi Mensah',
    userHandle: '@kofiaudio',
    userAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&auto=format&fit=crop&q=80',
    packageId: 'pkg_starter',
    packageName: 'Starter Coin Pack',
    coins: 2000000,
    amountBdt: 120,
    vipTierReward: 'VIP',
    paymentMethod: 'Nagad',
    senderPhone: '01855-443322',
    transactionId: 'NG7719042A',
    status: 'PENDING',
    createdAt: new Date(Date.now() - 45 * 60 * 1000).toISOString(),
    displayTime: '45 mins ago',
  },
  {
    id: 'ord_demo_approved_1',
    userId: 'usr_1',
    userNumericId: '10842915',
    userName: 'Maya Lin',
    userHandle: '@mayalin',
    userAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&auto=format&fit=crop&q=80',
    packageId: 'pkg_popular',
    packageName: 'Elite VIP Pack',
    coins: 5500000,
    amountBdt: 300,
    vipTierReward: 'VIP_PRO',
    paymentMethod: 'bKash',
    senderPhone: '01911-332211',
    transactionId: 'BK3810293F',
    status: 'APPROVED',
    createdAt: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
    displayTime: '2 hours ago',
    reviewedAt: new Date(Date.now() - 110 * 60 * 1000).toISOString(),
    reviewedBy: 'Owner/Admin',
    adminNote: 'Payment verified via bKash statement. Coins & VIP PRO credited.',
  },
];

class PurchaseService {
  private orders: PurchaseOrder[] = [];
  private subscribers: (() => void)[] = [];

  constructor() {
    this.load();
  }

  private load() {
    const saved = localStorage.getItem(STORAGE_KEY_ORDERS);
    if (saved) {
      try {
        this.orders = JSON.parse(saved);
      } catch {
        this.orders = [...INITIAL_ORDERS];
      }
    } else {
      this.orders = [...INITIAL_ORDERS];
      this.save();
    }
  }

  private save() {
    try {
      localStorage.setItem(STORAGE_KEY_ORDERS, JSON.stringify(this.orders));
    } catch {
      // ignore
    }
  }

  public subscribe(cb: () => void): () => void {
    this.subscribers.push(cb);
    return () => {
      this.subscribers = this.subscribers.filter(s => s !== cb);
    };
  }

  private notify() {
    this.subscribers.forEach(cb => cb());
  }

  public getAllOrders(): PurchaseOrder[] {
    return [...this.orders];
  }

  public getUserOrders(userId: string): PurchaseOrder[] {
    const key = userId === 'usr_guest' ? 'usr_me' : userId;
    return this.orders.filter(o => o.userId === key || (key === 'usr_me' && o.userId === 'usr_guest'));
  }

  public getPendingOrdersCount(): number {
    return this.orders.filter(o => o.status === 'PENDING').length;
  }

  /**
   * User submits an order after sending payment through bKash or Nagad.
   * STRICT: No coins are credited yet! Status is PENDING verification.
   */
  public submitPurchaseOrder(
    user: User,
    packageId: string,
    paymentMethod: PaymentMethod,
    senderPhone: string,
    transactionId: string
  ): { success: boolean; order?: PurchaseOrder; error?: string } {
    const cleanTrx = transactionId.trim().toUpperCase();
    const cleanPhone = senderPhone.trim();

    if (!cleanPhone || cleanPhone.length < 9) {
      return { success: false, error: 'অনুগ্রহ করে সঠিক প্রেরক মোবাইল নম্বর লিখুন।' };
    }

    if (!cleanTrx || cleanTrx.length < 6) {
      return { success: false, error: 'অনুগ্রহ করে সঠিক Transaction ID (TrxID) লিখুন।' };
    }

    // Duplicate check on TrxID across completed orders
    const duplicateApproved = this.orders.find(
      o => o.transactionId.toUpperCase() === cleanTrx && o.status === 'APPROVED'
    );
    if (duplicateApproved) {
      return {
        success: false,
        error: 'এই Transaction ID-টি ইতিপূর্বে অনুমোদিত হয়ে গেছে। নতুন লেনদেনের TrxID প্রদান করুন।',
      };
    }

    const pkg = coinConfigService.getPackageById(packageId);
    if (!pkg) {
      return { success: false, error: 'Coin Package খুঁজে পাওয়া যায়নি।' };
    }

    const key = user.id === 'usr_guest' ? 'usr_me' : user.id;
    const numericId = user.numericId || getNumericUserId(key);

    const newOrder: PurchaseOrder = {
      id: `ord_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      userId: key,
      userNumericId: numericId,
      userName: user.name,
      userHandle: user.handle,
      userAvatar: user.avatar,
      packageId: pkg.id,
      packageName: pkg.name,
      coins: pkg.coins,
      amountBdt: pkg.priceBdt,
      vipTierReward: pkg.vipTier,
      paymentMethod,
      senderPhone: cleanPhone,
      transactionId: cleanTrx,
      status: 'PENDING',
      createdAt: new Date().toISOString(),
      displayTime: 'Just now',
    };

    this.orders.unshift(newOrder);
    this.save();
    this.notify();

    return { success: true, order: newOrder };
  }

  /**
   * Admin approves an order.
   * 1. Validates status is PENDING
   * 2. Authoritatively credits coins to the user's wallet
   * 3. Authoritatively upgrades the user's VIP/SVIP tier
   * 4. Marks order as APPROVED and saves ledger
   */
  public approveOrder(
    orderId: string,
    adminName = 'App Owner/Admin'
  ): { success: boolean; error?: string; order?: PurchaseOrder } {
    const orderIndex = this.orders.findIndex(o => o.id === orderId);
    if (orderIndex === -1) {
      return { success: false, error: 'Order not found' };
    }

    const order = this.orders[orderIndex];
    if (order.status !== 'PENDING') {
      return { success: false, error: `Order is already ${order.status}` };
    }

    // 1. Authoritative credit in walletService
    const creditRes = walletService.creditPurchasedCoins(
      order.userId,
      order.coins,
      order.id,
      order.packageName,
      order.transactionId,
      order.amountBdt
    );

    if (!creditRes.success) {
      return { success: false, error: creditRes.error || 'Failed to credit coins' };
    }

    // 2. Authoritative upgrade of VIP/SVIP tier
    if (order.vipTierReward && order.vipTierReward !== 'REGULAR') {
      vipService.setUserVipTier(order.userId, order.vipTierReward);
    }

    // 3. Update order state
    const updatedOrder: PurchaseOrder = {
      ...order,
      status: 'APPROVED',
      reviewedAt: new Date().toISOString(),
      reviewedBy: adminName,
      adminNote: `Verified by ${adminName}. ${order.coins.toLocaleString()} Coins credited + ${order.vipTierReward} unlocked.`,
    };

    this.orders[orderIndex] = updatedOrder;
    this.save();
    this.notify();

    return { success: true, order: updatedOrder };
  }

  /**
   * Admin rejects an order.
   * No coins credited, status updated to REJECTED.
   */
  public rejectOrder(
    orderId: string,
    reason = 'পেমেন্ট যাচাই করা সম্ভব হয়নি (Invalid TrxID or Amount mismatch)',
    adminName = 'App Owner/Admin'
  ): { success: boolean; error?: string; order?: PurchaseOrder } {
    const orderIndex = this.orders.findIndex(o => o.id === orderId);
    if (orderIndex === -1) {
      return { success: false, error: 'Order not found' };
    }

    const order = this.orders[orderIndex];
    if (order.status !== 'PENDING') {
      return { success: false, error: `Order is already ${order.status}` };
    }

    const updatedOrder: PurchaseOrder = {
      ...order,
      status: 'REJECTED',
      reviewedAt: new Date().toISOString(),
      reviewedBy: adminName,
      adminNote: reason,
    };

    this.orders[orderIndex] = updatedOrder;
    this.save();
    this.notify();

    return { success: true, order: updatedOrder };
  }
}

export const purchaseService = new PurchaseService();
