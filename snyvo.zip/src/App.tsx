import React, { useState, useEffect } from 'react';
import {
  ScreenType,
  VoiceRoom,
  User,
  LevelUpEvent,
} from './types';
import { authService } from './services/firebaseService';
import { roomService } from './services/roomService';
import { levelService } from './services/levelService';
import { AndroidStatusBar } from './components/AndroidStatusBar';
import { AndroidNavBar } from './components/AndroidNavBar';
import { ActiveRoomMiniPlayer } from './components/ActiveRoomMiniPlayer';
import { CreateRoomModal } from './components/CreateRoomModal';
import { ComposeCodeModal } from './components/ComposeCodeModal';
import { UserProfileModal } from './components/UserProfileModal';
import { LevelUpModal } from './components/level/LevelUpModal';

import { SplashScreen } from './screens/SplashScreen';
import { LoginScreen } from './screens/LoginScreen';
import { SignUpScreen } from './screens/SignUpScreen';
import { HomeScreen } from './screens/HomeScreen';
import { VoiceRoomScreen } from './screens/VoiceRoomScreen';
import { ProfileScreen } from './screens/ProfileScreen';
import { ExploreScreen } from './screens/ExploreScreen';
import { ActivityScreen } from './screens/ActivityScreen';
import { ChatScreen } from './screens/ChatScreen';

import { Smartphone, Code, Maximize2, Minimize2, Radio } from 'lucide-react';

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<ScreenType>('splash');
  const [currentUser, setCurrentUser] = useState<User>(() => {
    return authService.getCurrentUser() || {
      id: 'usr_guest',
      name: 'Alex Vance',
      handle: '@alexvance',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop&q=80',
      bio: 'Exploring voice clubs and live stages 🎙️',
      followers: 1420,
      following: 388,
      roomsHosted: 42,
      clubs: ['Midnight Thinkers', 'Future of AI'],
      interests: ['Tech & AI', 'Music & Lo-Fi'],
      isVerified: true
    };
  });

  const [activeRoom, setActiveRoom] = useState<VoiceRoom | null>(null);
  const [isMiniPlayerActive, setIsMiniPlayerActive] = useState<boolean>(false);
  const [isCreateModalOpen, setIsCreateModalOpen] = useState<boolean>(false);
  const [isComposeModalOpen, setIsComposeModalOpen] = useState<boolean>(false);
  const [rooms, setRooms] = useState<VoiceRoom[]>(roomService.getRooms());
  const [deviceFrameMode, setDeviceFrameMode] = useState<boolean>(true);
  const [selectedProfileUser, setSelectedProfileUser] = useState<User | null>(null);
  const [globalLevelUpEvent, setGlobalLevelUpEvent] = useState<LevelUpEvent | null>(null);

  // Sync auth state & global level up notifications
  useEffect(() => {
    const unsubAuth = authService.onAuthStateChanged((user) => {
      if (user) {
        setCurrentUser(user);
      }
    });

    const unsubLevel = levelService.subscribeLevelUp((event) => {
      setGlobalLevelUpEvent(event);
    });

    const unsubRooms = roomService.subscribe(() => {
      setRooms([...roomService.getRooms()]);
      const currentActive = roomService.getActiveRoom();
      setActiveRoom(currentActive);
      if (!currentActive) {
        setIsMiniPlayerActive(false);
      }
    });

    return () => {
      unsubAuth();
      unsubLevel();
      unsubRooms();
    };
  }, []);

  // Handlers
  const handleJoinRoom = (room: VoiceRoom) => {
    // If user is currently in a room different from the target room, leave cleanly
    if (activeRoom && activeRoom.id !== room.id) {
      roomService.leaveRoom(currentUser);
    }
    const joined = roomService.joinRoom(room.id, currentUser, false);
    if (joined) {
      setActiveRoom(joined);
      setIsMiniPlayerActive(false);
      setCurrentScreen('room');
    }
  };

  const handleMinimizeRoom = () => {
    setIsMiniPlayerActive(true);
    setCurrentScreen('home');
  };

  const handleLeaveRoom = () => {
    roomService.leaveRoom(currentUser);
    setActiveRoom(null);
    setIsMiniPlayerActive(false);
    if (currentScreen === 'room') {
      setCurrentScreen('home');
    }
  };

  const handleToggleMute = () => {
    roomService.toggleMute(currentUser);
  };

  const handleCreateRoomSuccess = (newRoom: VoiceRoom) => {
    setIsCreateModalOpen(false);
    setActiveRoom(newRoom);
    setIsMiniPlayerActive(false);
    setCurrentScreen('room');
  };

  const handleLogout = async () => {
    await authService.signOut();
    setCurrentScreen('login');
  };

  const showBottomNav = ['home', 'explore', 'activity', 'profile', 'chat'].includes(currentScreen);

  return (
    <div className="h-full min-h-screen w-full bg-neutral-950 text-white flex flex-col items-center justify-center p-0 sm:p-4 select-none font-sans overflow-hidden">
      {/* Top Bar for Live Preview tools: Jetpack Compose Inspector, Device Frame switch */}
      <header className="w-full max-w-lg mb-2 hidden sm:flex items-center justify-between px-3 py-1.5 text-xs text-neutral-400">
        <div className="flex items-center space-x-2">
          <span className="flex items-center space-x-1.5 font-bold tracking-wider text-violet-400 uppercase">
            <Radio className="w-3.5 h-3.5 text-emerald-400 animate-pulse" />
            <span>SNYVO Android v1.0</span>
          </span>
          <span className="text-neutral-600">|</span>
          <span className="text-[11px] text-neutral-400">Kotlin & Jetpack Compose</span>
        </div>

        <div className="flex items-center space-x-2">
          <button
            onClick={() => setIsComposeModalOpen(true)}
            className="px-2.5 py-1 rounded-lg bg-violet-950/60 hover:bg-violet-900/60 border border-violet-700/40 text-violet-300 text-xs font-semibold flex items-center space-x-1 transition-all"
            title="Inspect Jetpack Compose Source Code"
          >
            <Code className="w-3.5 h-3.5 text-violet-400" />
            <span>Compose Code</span>
          </button>

          <button
            onClick={() => setDeviceFrameMode(!deviceFrameMode)}
            className="p-1 rounded-lg bg-neutral-900 hover:bg-neutral-800 text-neutral-300 hover:text-white transition-colors"
            title={deviceFrameMode ? "Switch to Full Screen" : "Show Android Device Frame"}
          >
            {deviceFrameMode ? <Maximize2 className="w-3.5 h-3.5" /> : <Minimize2 className="w-3.5 h-3.5" />}
          </button>
        </div>
      </header>

      {/* Main Container / Mobile Device Shell */}
      <main
        id="snyvo-mobile-shell"
        className={`w-full relative flex flex-col transition-all duration-300 ${
          deviceFrameMode
            ? 'h-full sm:h-[840px] sm:max-h-[92vh] sm:max-w-[400px] sm:rounded-[44px] sm:border-[8px] sm:border-neutral-800 sm:shadow-2xl sm:shadow-violet-950/30'
            : 'w-full max-w-md h-full'
        } bg-neutral-950 overflow-hidden`}
        style={{
          boxShadow: deviceFrameMode ? '0 25px 60px -15px rgba(0, 0, 0, 0.9), 0 0 40px rgba(124, 58, 237, 0.15)' : 'none'
        }}
      >
        {/* Android Status Bar */}
        <AndroidStatusBar />

        {/* Screen Content Viewport */}
        <div className="flex-1 relative overflow-hidden flex flex-col">
          {currentScreen === 'splash' && (
            <SplashScreen
              onContinue={() => setCurrentScreen('home')}
              onLoginClick={() => setCurrentScreen('login')}
              onSignUpClick={() => setCurrentScreen('signup')}
            />
          )}

          {currentScreen === 'login' && (
            <LoginScreen
              onSuccess={() => setCurrentScreen('home')}
              onNavigateToSignUp={() => setCurrentScreen('signup')}
              onBack={() => setCurrentScreen('splash')}
            />
          )}

          {currentScreen === 'signup' && (
            <SignUpScreen
              onSuccess={() => setCurrentScreen('home')}
              onNavigateToLogin={() => setCurrentScreen('login')}
              onBack={() => setCurrentScreen('login')}
            />
          )}

          {currentScreen === 'home' && (
            <HomeScreen
              currentUser={currentUser}
              rooms={rooms}
              onJoinRoom={handleJoinRoom}
              onNavigate={(s) => setCurrentScreen(s)}
              onOpenCreateRoom={() => setIsCreateModalOpen(true)}
              onOpenProfile={(u) => {
                if (u.id === currentUser.id || u.id === 'usr_me' || u.id === 'usr_guest') {
                  setCurrentScreen('profile');
                } else {
                  setSelectedProfileUser(u);
                }
              }}
            />
          )}

          {currentScreen === 'room' && activeRoom && (
            <VoiceRoomScreen
              room={activeRoom}
              currentUser={currentUser}
              onMinimize={handleMinimizeRoom}
              onLeaveRoom={handleLeaveRoom}
              onJoinRoom={handleJoinRoom}
            />
          )}

          {currentScreen === 'profile' && (
            <ProfileScreen
              currentUser={currentUser}
              onLogout={handleLogout}
              onUpdateUser={(u) => setCurrentUser(u)}
              onBack={() => setCurrentScreen('home')}
            />
          )}

          {currentScreen === 'explore' && (
            <ExploreScreen
              rooms={rooms}
              onJoinRoom={handleJoinRoom}
            />
          )}

          {(currentScreen === 'activity' || currentScreen === 'chat') && (
            <ChatScreen
              currentUser={currentUser}
              onOpenProfile={(u) => setSelectedProfileUser(u as User)}
              onJoinRoomId={(roomId) => {
                const r = rooms.find(room => room.id === roomId);
                if (r) handleJoinRoom(r);
              }}
            />
          )}
        </div>

        {/* Floating Mini Player (if room is active & user navigated away) */}
        {activeRoom && isMiniPlayerActive && currentScreen !== 'room' && (
          <ActiveRoomMiniPlayer
            room={activeRoom}
            currentUser={currentUser}
            isMuted={roomService.isUserMuted()}
            onMaximize={() => {
              setIsMiniPlayerActive(false);
              setCurrentScreen('room');
            }}
            onToggleMute={handleToggleMute}
            onLeave={handleLeaveRoom}
          />
        )}

        {/* Bottom Navigation (for tabbed screens) */}
        {showBottomNav && (
          <AndroidNavBar
            activeScreen={currentScreen}
            onNavigate={(screen) => setCurrentScreen(screen)}
            onOpenCreateRoom={() => setIsCreateModalOpen(true)}
          />
        )}
      </main>

      {/* Floating Create Room Modal Sheet */}
      {isCreateModalOpen && (
        <CreateRoomModal
          currentUser={currentUser}
          onClose={() => setIsCreateModalOpen(false)}
          onRoomCreated={handleCreateRoomSuccess}
          onReturnToActiveRoom={(r) => {
            setActiveRoom(r);
            setIsMiniPlayerActive(false);
            setCurrentScreen('room');
          }}
        />
      )}

      {/* Global User Profile Modal */}
      {selectedProfileUser && (
        <UserProfileModal
          user={selectedProfileUser}
          currentUser={currentUser}
          currentRoom={activeRoom}
          onClose={() => setSelectedProfileUser(null)}
          onJoinRoom={(r) => {
            setSelectedProfileUser(null);
            handleJoinRoom(r);
          }}
          onUpdateCurrentUser={(u) => setCurrentUser(u)}
        />
      )}

      {/* Jetpack Compose & Kotlin Source Code Modal */}
      {isComposeModalOpen && (
        <ComposeCodeModal
          activeScreen={currentScreen}
          onClose={() => setIsComposeModalOpen(false)}
        />
      )}

      {/* Global Level Up Celebratory Modal */}
      {globalLevelUpEvent && (
        <LevelUpModal
          event={globalLevelUpEvent}
          onClose={() => setGlobalLevelUpEvent(null)}
        />
      )}
    </div>
  );
}
